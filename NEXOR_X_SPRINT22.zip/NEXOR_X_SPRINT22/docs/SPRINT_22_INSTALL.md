# Instalação da Sprint 22

```bash
python tools/apply_sprint22.py
python -m compileall -q src tests tools
python -m pytest -q tests/test_testnet_orders.py
python -m pytest -q
```

Endpoint:

- `POST /api/exchange/testnet/orders` — exige `X-NEXOR-ADMIN-TOKEN`

A ordem só é enviada quando o conector está explicitamente em TESTNET.
