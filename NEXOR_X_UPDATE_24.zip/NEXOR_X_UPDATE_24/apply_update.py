from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_connector() -> None:
    path = ROOT / "src/nexor_x/exchange/binance_live.py"
    text = path.read_text(encoding="utf-8")

    if "async def get_testnet_order(" not in text:
        marker = "    async def create_testnet_order(\n"
        if marker not in text:
            raise RuntimeError("create_testnet_order marker not found")
        methods = (
            "    async def get_testnet_order(\n"
            "        self,\n"
            "        *,\n"
            "        symbol: str,\n"
            "        client_order_id: str | None = None,\n"
            "        exchange_order_id: str | None = None,\n"
            "    ) -> dict[str, Any]:\n"
            "        if not self.policy.use_testnet:\n"
            "            raise RuntimeError('Order query is restricted to TESTNET')\n"
            "        params: dict[str, Any] = {'symbol': symbol}\n"
            "        if client_order_id:\n"
            "            params['origClientOrderId'] = client_order_id\n"
            "        elif exchange_order_id:\n"
            "            params['orderId'] = exchange_order_id\n"
            "        else:\n"
            "            raise ValueError('order identifier is required')\n"
            "        return await self._signed_get('/fapi/v1/order', params)\n\n"
            "    async def cancel_testnet_order(\n"
            "        self,\n"
            "        *,\n"
            "        symbol: str,\n"
            "        client_order_id: str | None = None,\n"
            "        exchange_order_id: str | None = None,\n"
            "    ) -> dict[str, Any]:\n"
            "        if not self.policy.use_testnet:\n"
            "            raise RuntimeError('Order cancel is restricted to TESTNET')\n"
            "        params: dict[str, Any] = {'symbol': symbol}\n"
            "        if client_order_id:\n"
            "            params['origClientOrderId'] = client_order_id\n"
            "        elif exchange_order_id:\n"
            "            params['orderId'] = exchange_order_id\n"
            "        else:\n"
            "            raise ValueError('order identifier is required')\n"
            "        return await self._signed_delete('/fapi/v1/order', params)\n\n"
            "    async def _signed_delete(\n"
            "        self,\n"
            "        path: str,\n"
            "        params: dict[str, Any],\n"
            "    ) -> dict[str, Any]:\n"
            "        client = self._require_client()\n"
            "        timestamp = int(time.time() * 1000) + self._time_offset_ms\n"
            "        payload = {\n"
            "            **params,\n"
            "            'timestamp': timestamp,\n"
            "            'recvWindow': self.policy.recv_window_ms,\n"
            "        }\n"
            "        query = urlencode(payload)\n"
            "        signature = hmac.new(\n"
            "            self.credentials.api_secret.encode('utf-8'),\n"
            "            query.encode('utf-8'),\n"
            "            hashlib.sha256,\n"
            "        ).hexdigest()\n"
            "        headers = {'X-MBX-APIKEY': self.credentials.api_key}\n"
            "        response = await client.delete(\n"
            "            f'{self.base_url}{path}?{query}&signature={signature}',\n"
            "            headers=headers,\n"
            "        )\n"
            "        response.raise_for_status()\n"
            "        return dict(response.json())\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_block = (
        "from nexor_x.orders import (\n"
        "    OrderAuditRepository,\n"
        "    TestnetOrderLifecycleService,\n"
        ")\n"
    )
    if "TestnetOrderLifecycleService" not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_block, 1)

    if "self.testnet_order_lifecycle = TestnetOrderLifecycleService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        block = (
            "        self.testnet_order_lifecycle = TestnetOrderLifecycleService(\n"
            "            self.binance_live\n"
            "        )\n"
            "        self.order_audit = OrderAuditRepository(self.database)\n"
        )
        text = text.replace(marker, block + marker, 1)

    if "await self.order_audit.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.order_audit.start()\n",
            1,
        )

    if "async def testnet_order_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def testnet_order_status(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.testnet_order_lifecycle.status(\n"
            "            symbol=str(payload['symbol']),\n"
            "            client_order_id=(\n"
            "                None if not payload.get('client_order_id')\n"
            "                else str(payload['client_order_id'])\n"
            "            ),\n"
            "            exchange_order_id=(\n"
            "                None if not payload.get('exchange_order_id')\n"
            "                else str(payload['exchange_order_id'])\n"
            "            ),\n"
            "        )\n"
            "        order = result['order']\n"
            "        await self.order_audit.save(\n"
            "            event_type='STATUS',\n"
            "            symbol=order['symbol'],\n"
            "            payload=result,\n"
            "            client_order_id=order['client_order_id'],\n"
            "            exchange_order_id=order['exchange_order_id'],\n"
            "        )\n"
            "        return result\n\n"
            "    async def testnet_order_cancel(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.testnet_order_lifecycle.cancel(\n"
            "            symbol=str(payload['symbol']),\n"
            "            client_order_id=(\n"
            "                None if not payload.get('client_order_id')\n"
            "                else str(payload['client_order_id'])\n"
            "            ),\n"
            "            exchange_order_id=(\n"
            "                None if not payload.get('exchange_order_id')\n"
            "                else str(payload['exchange_order_id'])\n"
            "            ),\n"
            "        )\n"
            "        await self.order_audit.save(\n"
            "            event_type='CANCEL',\n"
            "            symbol=result['symbol'],\n"
            "            payload=result,\n"
            "            client_order_id=result['client_order_id'],\n"
            "            exchange_order_id=result['exchange_order_id'],\n"
            "        )\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if "class TestnetOrderLookupRequest(BaseModel):" not in text:
        marker = "class ChatRequest(BaseModel):\n"
        if marker not in text:
            raise RuntimeError("ChatRequest marker not found")
        model = (
            "class TestnetOrderLookupRequest(BaseModel):\n"
            "    symbol: str = Field(min_length=3, max_length=30)\n"
            "    client_order_id: str | None = Field(default=None, max_length=36)\n"
            "    exchange_order_id: str | None = Field(default=None, max_length=64)\n\n"
        )
        text = text.replace(marker, model + marker, 1)

    if '@app.post("/api/exchange/testnet/orders/status")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.post("/api/exchange/testnet/orders/status")\n'
            "    async def testnet_order_status(\n"
            "        body: TestnetOrderLookupRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        try:\n"
            "            return await kernel.testnet_order_status(body.model_dump())\n"
            "        except (KeyError, TypeError, ValueError, RuntimeError) as exc:\n"
            "            raise HTTPException(status_code=422, detail=str(exc)) from exc\n\n"
            '    @app.post("/api/exchange/testnet/orders/cancel")\n'
            "    async def testnet_order_cancel(\n"
            "        body: TestnetOrderLookupRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        try:\n"
            "            return await kernel.testnet_order_cancel(body.model_dump())\n"
            "        except (KeyError, TypeError, ValueError, RuntimeError) as exc:\n"
            "            raise HTTPException(status_code=422, detail=str(exc)) from exc\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(r'version = "[^"]+"', 'version = "0.24.0"', text, count=1)
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.24.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_connector()
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 24 aplicado com sucesso.")


if __name__ == "__main__":
    main()
