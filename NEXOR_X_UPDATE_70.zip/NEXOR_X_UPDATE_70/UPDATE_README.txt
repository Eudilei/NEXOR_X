NEXOR X UPDATE 70 - LABORATORIO DE DIAGNOSTICO DO BACKTEST

O laboratorio agora recebe as operacoes fechadas de um backtest e produz:
- resultado bruto, taxas e resultado liquido;
- Profit Factor liquido e drawdown;
- desempenho por estrategia e regime;
- diagnostico individual de cada operacao;
- ranking das causas mais frequentes;
- campos ausentes e nivel de confianca do diagnostico;
- testes recomendados, sem alterar parametros automaticamente.

Causas detectadas incluem:
- custos consumindo o lucro;
- slippage excessivo;
- R:R planejado abaixo do minimo;
- risco/tamanho de posicao excessivo;
- edge fraco;
- estrategia incompatível com o regime;
- entrada com excursao adversa forte;
- lucro que existiu e nao foi protegido;
- devolucao excessiva antes da saida;
- stop depois de movimento favoravel.

Endpoints:
POST /api/laboratory/backtest-diagnostics/run
GET  /api/laboratory/backtest-diagnostics/status

Validacao:
- 328 testes aprovados;
- compilacao e lint critico aprovados;
- PnL principal: NET_AFTER_FEES;
- LIVE bloqueado.
