
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def verify_update_61_present() -> None:
    audit_tool = (
        ROOT / "tools/final_evidence_integrity_audit.py"
    )
    if not audit_tool.exists():
        raise RuntimeError(
            "Update 61 não detectada: "
            "final_evidence_integrity_audit.py ausente"
        )


def copy_payload() -> None:
    for rel in (
        "tools/live_preauthorization_dossier.py",
        "tests/test_live_preauthorization_dossier.py",
        "docs/AUDIT_UPDATE_62.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.62.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.62.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    verify_update_61_present()
    copy_payload()
    patch_version()
    print(
        "NEXOR X Update 62 aplicada: LIVE Pre-Authorization Dossier "
        "instalado. Trading runtime não alterado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
