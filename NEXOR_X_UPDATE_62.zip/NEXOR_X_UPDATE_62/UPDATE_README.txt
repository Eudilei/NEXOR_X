NEXOR X UPDATE 62 — LIVE PRE-AUTHORIZATION DOSSIER

Objetivo:
  preparar o dossiê técnico necessário ANTES de qualquer futura autorização LIVE.

O dossiê verifica:
  - final_evidence_integrity_audit = FINAL_EVIDENCE_VERIFIED;
  - NEXOR_MODE não está em LIVE;
  - BINANCE_API_KEY está configurada;
  - BINANCE_API_SECRET está configurada;
  - TELEGRAM_BOT_TOKEN está configurado;
  - TELEGRAM_CHAT_ID está configurado;
  - nenhuma credencial é exibida no relatório.

Saída:
  LIVE_PREAUTH_READY
  ou
  LIVE_PREAUTH_BLOCKED

Relatório:
  reports/live_preauthorization_dossier.json

Uso:
  python tools/live_preauthorization_dossier.py

IMPORTANTE:
  LIVE_PREAUTH_READY NÃO habilita LIVE.
  Ele apenas informa que a documentação/evidência/configuração mínima está
  pronta para uma futura etapa explícita de autorização.

Trading runtime não é alterado.
LIVE permanece bloqueado.
