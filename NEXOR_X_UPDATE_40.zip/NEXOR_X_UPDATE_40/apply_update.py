from __future__ import annotations

from pathlib import Path
import re

ROOT = Path.cwd()


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = "from nexor_x.operations import LiveReadinessEvaluator\n"
    if import_line not in text:
        marker = "from nexor_x.notifications import TelegramEventNotifier\n"
        fallback = "from nexor_x.position.service import PositionPolicy\n"
        if marker in text:
            text = text.replace(marker, marker + import_line, 1)
        elif fallback in text:
            text = text.replace(fallback, fallback + import_line, 1)
        else:
            raise RuntimeError("Marcador de import do kernel não encontrado")

    if "self.live_readiness_evaluator = LiveReadinessEvaluator()" not in text:
        marker = "        self._started = False\n"
        if marker not in text:
            raise RuntimeError("Marcador de inicialização do kernel não encontrado")
        text = text.replace(
            marker,
            "        self.live_readiness_evaluator = LiveReadinessEvaluator()\n" + marker,
            1,
        )

    if "async def live_readiness_status(" not in text:
        marker = "    async def external_credentials_status(\n"
        if marker not in text:
            raise RuntimeError("Marcador external_credentials_status não encontrado")
        method = '''    async def live_readiness_status(
        self,
    ) -> dict[str, object]:
        credentials = await self.external_credentials_status()
        recovery = await self.recovery_status()
        supervisor = await self.operational_supervisor_status()
        integration = await self.integration_health_status()
        validation = await self.validation_snapshot_status()
        campaign = await self.validation_campaign_status()
        cycle = await self.validation_cycle_status()
        runtime = await self.runtime_status()
        report = self.live_readiness_evaluator.evaluate(
            mode=self.settings.nexor_mode.value,
            credentials=credentials,
            recovery=recovery,
            supervisor=supervisor,
            integration=integration,
            validation=validation,
            campaign=campaign,
            cycle=cycle,
            runtime=runtime,
        )
        await self.event_bus.publish(Event(
            "live.readiness_evaluated",
            {
                "status": report["status"],
                "candidate_ready": report["candidate_ready"],
                "live_allowed": False,
                "blockers": report["blockers"],
            },
            "live_readiness",
        ))
        return report

'''
        text = text.replace(marker, method + marker, 1)

    old = 'event.topic.startswith(("system.", "market.", "quant.", "laboratory.", "risk.", "execution.", "position."))'
    new = 'event.topic.startswith(("system.", "market.", "quant.", "laboratory.", "risk.", "execution.", "position.", "live."))'
    if old in text:
        text = text.replace(old, new, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)
    if '@app.get("/api/live/readiness")' not in text:
        marker = '@app.get("/api/system/credentials")'
        if marker not in text:
            raise RuntimeError("Marcador de endpoint de credenciais não encontrado")
        block = '''@app.get("/api/live/readiness")
    async def live_readiness_status(
        _: None = Depends(require_admin),
    ) -> dict[str, Any]:
        return await kernel.live_readiness_status()

    '''
        text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_notifications() -> None:
    path = ROOT / "src/nexor_x/notifications/telegram_events.py"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    if '"live.readiness_evaluated",' not in text:
        marker = '        "validation.cycle_completed",\n'
        if marker in text:
            text = text.replace(marker, marker + '        "live.readiness_evaluated",\n', 1)

    if 'if topic == "live.readiness_evaluated":' not in text:
        marker = "        return None\n\n    @staticmethod\n    def _number"
        if marker in text:
            block = '''        if topic == "live.readiness_evaluated":
            ready = bool(payload.get("candidate_ready", False))
            blockers = list(payload.get("blockers") or [])
            blocker_text = ", ".join(str(item) for item in blockers[:6])
            return (
                "🧪 PRONTIDÃO PARA FUTURO LIVE\\n"
                f"Infra/validação: {'PRONTA' if ready else 'EM ANDAMENTO'}\\n"
                f"Bloqueios: {blocker_text or '-'}\\n"
                "Operação real: BLOQUEADA"
            )

        return None

    @staticmethod
    def _number'''
            text = text.replace(marker, block, 1)
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(r'version = "[^"]+"', 'version = "0.40.0"', text, count=1)
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = _read(init)
    text = re.sub(r'__version__\s*=\s*"[^"]+"', '__version__ = "0.40.0"', text)
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_notifications()
    patch_version()
    print("NEXOR X Update 40 aplicado com sucesso. LIVE permanece bloqueado.")


if __name__ == "__main__":
    main()
