NEXOR X UPDATE 40 — PRONTIDÃO LIVE AUDITÁVEL

Esta atualização NÃO libera ordens reais.

Ela adiciona um consolidado de prontidão operacional que verifica:
- credenciais externas configuradas;
- recuperação/reconciliação;
- supervisor operacional;
- saúde de integração;
- snapshot/campanha/ciclo de validação;
- runtime;
- modo atual.

Novo endpoint administrativo:
GET /api/live/readiness

O retorno separa:
candidate_ready = infraestrutura/validação suficientemente pronta para uma futura etapa de certificação.
live_allowed = false (continua bloqueado nesta atualização).

Requer NEXOR X 0.39.0.
