"""NEXOR X package."""
__version__ = "0.4.0"
