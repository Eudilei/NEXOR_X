
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def verify_update_59_present() -> None:
    recorder = ROOT / "tools/evidence_progress_recorder.py"
    runner = ROOT / "tools/validation_campaign_runner.py"

    if not recorder.exists():
        raise RuntimeError(
            "Update 59 não detectada: evidence_progress_recorder.py ausente"
        )
    if not runner.exists():
        raise RuntimeError(
            "Update 58 não detectada: validation_campaign_runner.py ausente"
        )


def copy_payload() -> None:
    for rel in (
        "tools/evidence_completion_watchdog.py",
        "tests/test_evidence_completion_watchdog.py",
        "docs/AUDIT_UPDATE_60.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.60.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.60.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    verify_update_59_present()
    copy_payload()
    patch_version()
    print(
        "NEXOR X Update 60 aplicada: Evidence Completion Watchdog instalado. "
        "Trading runtime não alterado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
