NEXOR X UPDATE 60 — EVIDENCE COMPLETION WATCHDOG & FINAL EVIDENCE BUNDLE

Objetivo:
  fechar a etapa operacional de validação sem alterar a arquitetura congelada.

O watchdog verifica:
  - Release Candidate = RC_READY;
  - Final Technical Completion = TECHNICALLY_COMPLETE;
  - Final Validation Campaign = COMPLETE;
  - evidence_certified = true;
  - candidate_ready = true;
  - live_allowed continua false.

Quando todos os critérios forem satisfeitos, gera:
  reports/final_evidence_bundle.json
  reports/final_evidence_bundle.sha256

Status:
  EVIDENCE_PENDING
  FINAL_EVIDENCE_READY

Uso:
  python tools/evidence_completion_watchdog.py --once

ou continuamente:
  python tools/evidence_completion_watchdog.py

Variáveis:
  NEXOR_BASE_URL=http://127.0.0.1:8000
  NEXOR_ADMIN_TOKEN=<token administrativo>
  NEXOR_EVIDENCE_WATCH_INTERVAL_SECONDS=1800

IMPORTANTE:
  FINAL_EVIDENCE_READY NÃO habilita LIVE.
  Uma eventual liberação LIVE deverá ser uma etapa explícita e separada.

LIVE permanece bloqueado.
