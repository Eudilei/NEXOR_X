
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/validation/release_candidate.py",
        "tests/test_release_candidate_audit.py",
        "docs/NEXOR_X_RELEASE_CANDIDATE.md",
        "docs/AUDIT_UPDATE_56.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_validation_init() -> None:
    path = ROOT / "src/nexor_x/validation/__init__.py"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    imp = (
        "from .release_candidate import "
        "ReleaseCandidateAudit\n"
    )
    if imp not in text:
        text = imp + text

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.validation.release_candidate import "
        "ReleaseCandidateAudit\n"
    )
    anchor = (
        "from nexor_x.validation.final_dashboard import "
        "FinalTechnicalDashboardSnapshot\n"
    )

    if import_line not in text:
        if anchor not in text:
            raise RuntimeError(
                "Update 55 não detectada: FinalTechnicalDashboardSnapshot ausente"
            )
        text = text.replace(
            anchor,
            anchor + import_line,
            1,
        )

    init_line = (
        "        self.release_candidate_audit = "
        "ReleaseCandidateAudit()\n"
    )
    anchor2 = (
        "        self.final_dashboard_snapshot = "
        "FinalTechnicalDashboardSnapshot()\n"
    )

    if init_line not in text:
        if anchor2 not in text:
            raise RuntimeError(
                "Update 55 não detectada: final_dashboard_snapshot ausente"
            )
        text = text.replace(
            anchor2,
            anchor2 + init_line,
            1,
        )

    if "async def release_candidate_audit_status(" not in text:
        marker = "    async def final_dashboard_snapshot_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 55 não detectada: final dashboard method ausente"
            )

        method = (
            "    async def release_candidate_audit_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        acceptance = await self.operational_acceptance_audit()\n"
            "        final_snapshot = await self.final_dashboard_snapshot_status()\n"
            "        components = {\n"
            '            "live_readiness": hasattr(self, "live_readiness"),\n'
            '            "live_certification": hasattr(self, "live_certification"),\n'
            '            "performance_degradation": hasattr(self, "performance_degradation_guard"),\n'
            '            "recovery_hysteresis": hasattr(self, "entry_recovery_guard"),\n'
            '            "entry_admission": hasattr(self, "entry_admission_controller"),\n'
            '            "post_recovery_probation": hasattr(self, "post_recovery_probation"),\n'
            '            "exposure_ramp": hasattr(self, "probation_exposure_ramp"),\n'
            '            "entry_reservation": hasattr(self, "entry_reservation_guard"),\n'
            '            "entry_decision_trace": hasattr(self, "entry_decision_trace"),\n'
            '            "operational_readiness_summary": hasattr(self, "operational_readiness_summary"),\n'
            '            "operational_acceptance_audit": hasattr(self, "operational_acceptance_audit"),\n'
            '            "final_validation_campaign": hasattr(self, "final_validation_campaign"),\n'
            '            "final_technical_completion": hasattr(self, "final_technical_completion"),\n'
            '            "final_dashboard_snapshot": hasattr(self, "final_dashboard_snapshot"),\n'
            "        }\n"
            "        return self.release_candidate_audit.evaluate(\n"
            "            acceptance=acceptance,\n"
            "            final_snapshot=final_snapshot,\n"
            "            component_presence=components,\n"
            '            version="0.56.0",\n'
            "        )\n\n"
        )

        text = text.replace(
            marker,
            method + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/validation/release-candidate")' in text:
        return

    marker = '@app.get("/api/validation/final-snapshot")'
    if marker not in text:
        raise RuntimeError(
            "Update 55 não detectada: final-snapshot endpoint ausente"
        )

    block = (
        '@app.get("/api/validation/release-candidate")\n'
        "    async def release_candidate_audit_status(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return await kernel.release_candidate_audit_status()\n\n"
        "    "
    )

    text = text.replace(
        marker,
        block + marker,
        1,
    )
    path.write_text(text, encoding="utf-8")


def patch_dashboard() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if 'id="releaseCandidateStatus"' in text:
        return

    anchor = (
        '<div class="service"><b>LIVE</b><br><small id="finalLive">BLOQUEADO</small></div>'
    )
    if anchor not in text:
        raise RuntimeError(
            "Update 55 não detectada: card de fechamento técnico ausente"
        )

    extra = (
        anchor
        + '<div class="service"><b>Release Candidate</b>'
        + '<br><small id="releaseCandidateStatus">-</small></div>'
    )

    text = text.replace(anchor, extra, 1)

    js_anchor = "async function finalTechnical(){"
    if js_anchor not in text:
        raise RuntimeError(
            "Update 55 não detectada: função finalTechnical ausente"
        )

    rc_js = (
        "async function releaseCandidate(){"
        "const token=adminToken.value;"
        "if(!token){releaseCandidateStatus.textContent='INFORME O TOKEN';return}"
        "try{"
        "const r=await fetch('/api/validation/release-candidate',{headers:{'X-NEXOR-ADMIN-TOKEN':token}});"
        "const x=await r.json();"
        "if(!r.ok)throw new Error(x.detail||'Falha');"
        "releaseCandidateStatus.textContent=x.status;"
        "}catch(e){releaseCandidateStatus.textContent='INDISPONIVEL'}"
        "}\n"
    )

    text = text.replace(
        js_anchor,
        rc_js + js_anchor,
        1,
    )

    interval_old = (
        "setInterval(()=>{market();quant();scanner();finalTechnical()},15000);"
    )
    interval_new = (
        "setInterval(()=>{market();quant();scanner();finalTechnical();releaseCandidate()},15000);"
    )

    if interval_old in text:
        text = text.replace(
            interval_old,
            interval_new,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.56.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.56.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_validation_init()
    patch_kernel()
    patch_api()
    patch_dashboard()
    patch_version()
    print(
        "NEXOR X Update 56 aplicada: Release Candidate Audit e "
        "Architecture Freeze adicionados. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
