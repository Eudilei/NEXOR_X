NEXOR X UPDATE 56 — RELEASE CANDIDATE AUDIT & ARCHITECTURE FREEZE

Objetivo:
  encerrar formalmente a fase de construção da arquitetura e criar o
  Release Candidate do NEXOR X.

RC_READY exige:
  - Operational Acceptance Audit = PASS;
  - Final Technical Dashboard disponível;
  - entry decision trace read-only;
  - readiness summary read-only;
  - final snapshot read-only;
  - live_allowed=false;
  - live_certified=false;
  - todos os componentes críticos das Updates 40–55 presentes.

IMPORTANTE:
  RC_READY NÃO significa TECHNICALLY_COMPLETE.
  A campanha PAPER/TESTNET e a certificação de evidências continuam rodando.
  Depois da Update 56, a arquitetura deve permanecer congelada salvo bug real
  ou falha encontrada nos testes.

Novo endpoint:
  GET /api/validation/release-candidate

Novo documento:
  docs/NEXOR_X_RELEASE_CANDIDATE.md

LIVE permanece bloqueado.

Requer NEXOR X 0.55.0.
