NEXOR X UPDATE 73 - FUNIL DE DECISAO EM DUAS ETAPAS

REQUISITO: NEXOR X 0.72.0 ja instalado.

1. Descobre contratos Binance USDT PERPETUAL em negociacao.
2. Analise rasa de liquidez, volatilidade util e movimento.
3. Mantem exatamente os 60 melhores elegiveis, ou todos quando houver menos de 60.
4. Executa a analise profunda somente nessa selecao.
5. Shadow Learning e PAPER recebem apenas o universo selecionado.
6. Uma ordem PAPER somente pode nascer depois de calibracao, contexto, risco e capacidade.

A lista de cinco simbolos permanece somente como contingencia quando ainda nao existe
uma selecao valida. O update nao habilita LIVE.
