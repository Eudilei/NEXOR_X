from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.integration import IntegrationHealthService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.integration_health = IntegrationHealthService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        text = text.replace(
            marker,
            "        self.integration_health = "
            "IntegrationHealthService(self.database)\n"
            + marker,
            1,
        )

    if "await self.integration_health.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.integration_health.start()\n",
            1,
        )

    if "async def integration_health_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def integration_health_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.integration_health.status()\n\n"
            "    async def integration_health_evaluate(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.integration_health.evaluate(payload)\n"
            "        await self.event_bus.publish(Event(\n"
            "            'integration.health_evaluated',\n"
            "            {\n"
            "                'status': result['status'],\n"
            "                'paper_ready': result['paper_ready'],\n"
            "                'testnet_ready': result['testnet_ready'],\n"
            "                'live_ready': False,\n"
            "            },\n"
            "            'integration_health',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if "class IntegrationHealthRequest(BaseModel):" not in text:
        marker = "class ChatRequest(BaseModel):\n"
        if marker not in text:
            raise RuntimeError("ChatRequest marker not found")
        model = (
            "class IntegrationHealthRequest(BaseModel):\n"
            "    database_ok: bool\n"
            "    market_ok: bool\n"
            "    scanner_ok: bool\n"
            "    strategy_ok: bool\n"
            "    allocation_ok: bool\n"
            "    recovery_ok: bool\n"
            "    supervisor_ok: bool\n"
            "    certification_ok: bool\n"
            "    update_registry_ok: bool\n"
            "    testnet_connector_ok: bool\n"
            "    critical_test_failures: int = Field(ge=0, le=1000000)\n"
            "    operational_incidents: int = Field(ge=0, le=1000000)\n\n"
        )
        text = text.replace(marker, model + marker, 1)

    if '@app.get("/api/system/integration-health")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.get("/api/system/integration-health")\n'
            "    async def integration_health_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.integration_health_status()\n\n"
            '    @app.post("/api/system/integration-health/evaluate")\n'
            "    async def integration_health_evaluate(\n"
            "        body: IntegrationHealthRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.integration_health_evaluate(\n"
            "            body.model_dump()\n"
            "        )\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.29.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.29.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 29 aplicado com sucesso.")


if __name__ == "__main__":
    main()
