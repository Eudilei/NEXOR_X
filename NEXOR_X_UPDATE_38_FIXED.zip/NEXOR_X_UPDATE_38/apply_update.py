from __future__ import annotations
from pathlib import Path
import re
ROOT = Path.cwd()

def patch_auto_paper_bug() -> None:
    path = ROOT / "src/nexor_x/autopaper/service.py"
    text = path.read_text(encoding="utf-8")

    legacy = '        positions = list(portfolio.get("open_positions") or [])\n'
    current = '        positions = list(portfolio.get("positions") or [])\n'
    compatible = (
        '        raw_open_positions = portfolio.get("open_positions")\n'
        '        if isinstance(raw_open_positions, (list, tuple)):\n'
        '            positions = list(raw_open_positions)\n'
        '        else:\n'
        '            positions = list(portfolio.get("positions") or [])\n'
    )

    if compatible in text:
        pass
    elif legacy in text:
        text = text.replace(legacy, compatible, 1)
    elif current in text:
        text = text.replace(current, compatible, 1)
    else:
        raise RuntimeError("AutoPaper position marker not found")

    path.write_text(text, encoding="utf-8")

def patch_config() -> None:
    path=ROOT/"src/nexor_x/config.py"; text=path.read_text(encoding="utf-8")
    fields="    auto_position_management_enabled: bool = True\n    auto_position_management_interval_seconds: float = 5.0\n"
    if "auto_position_management_enabled:" not in text:
        marker="    model_config = SettingsConfigDict("
        if marker not in text: raise RuntimeError("Config model marker not found")
        text=text.replace(marker,fields+"\n"+marker,1)
    mapping_marker='        "AUTO_PAPER_ENABLED": "auto_paper_enabled",\n'
    mapping='        "AUTO_POSITION_MANAGEMENT_ENABLED": "auto_position_management_enabled",\n        "AUTO_POSITION_MANAGEMENT_INTERVAL_SECONDS": "auto_position_management_interval_seconds",\n'
    if '"AUTO_POSITION_MANAGEMENT_ENABLED"' not in text:
        if mapping_marker not in text: raise RuntimeError("Config env mapping marker not found")
        text=text.replace(mapping_marker,mapping+mapping_marker,1)
    path.write_text(text,encoding="utf-8")

def patch_kernel() -> None:
    path=ROOT/"src/nexor_x/kernel.py"; text=path.read_text(encoding="utf-8")
    imp="from nexor_x.automanage import AutoPositionManagementService\n"
    if imp not in text:
        marker="from nexor_x.autopaper import AutoPaperService\n"
        if marker not in text: raise RuntimeError("AutoPaper import marker not found")
        text=text.replace(marker,marker+imp,1)
    if "self.auto_position_management = AutoPositionManagementService(" not in text:
        marker="        self.telegram = TelegramService("
        if marker not in text: raise RuntimeError("Telegram constructor marker not found")
        block="        self.auto_position_management = AutoPositionManagementService(\n            self.database,\n            self.manage_all_positions,\n        )\n"
        text=text.replace(marker,block+marker,1)
    if "await self.auto_position_management.start()" not in text:
        marker="        await self.auto_paper.start()\n"
        if marker not in text: raise RuntimeError("AutoPaper startup marker not found")
        text=text.replace(marker,marker+"        await self.auto_position_management.start()\n",1)
    if '"auto_position_management_cycle"' not in text and "'auto_position_management_cycle'" not in text:
        marker="        if self.settings.auto_paper_enabled:\n"
        if marker not in text: raise RuntimeError("AutoPaper scheduler marker not found")
        sched="        if self.settings.auto_position_management_enabled:\n            self.scheduler.add_job(\n                ScheduledJob(\n                    'auto_position_management_cycle',\n                    self.settings.auto_position_management_interval_seconds,\n                    self._scheduled_auto_position_management,\n                )\n            )\n"
        text=text.replace(marker,sched+marker,1)
    if "async def auto_position_management_status" not in text:
        marker="    async def auto_paper_status(self) -> dict[str, object]:\n"
        if marker not in text: raise RuntimeError("AutoPaper status marker not found")
        methods="    async def auto_position_management_status(self) -> dict[str, object]:\n        return await self.auto_position_management.status()\n\n    async def auto_position_management_run(self) -> dict[str, object]:\n        if self.settings.nexor_mode.value != 'PAPER':\n            raise RuntimeError('Gestão automática permitida somente em PAPER')\n        result = await self.auto_position_management.run_once()\n        await self.event_bus.publish(Event('position.auto_management_cycle', {\n            'evaluated_positions': result['evaluated_positions'],\n            'action_count': result['action_count'],\n            'closed_positions': result['closed_positions'],\n            'live_execution_allowed': False,\n        }, 'auto_position_management'))\n        return result\n\n"
        text=text.replace(marker,methods+marker,1)
    if "async def _scheduled_auto_position_management" not in text:
        marker="    async def _scheduled_auto_paper(self) -> None:\n"
        if marker not in text: raise RuntimeError("Scheduled AutoPaper marker not found")
        scheduled="    async def _scheduled_auto_position_management(self) -> None:\n        try:\n            await self.auto_position_management_run()\n        except Exception as exc:\n            self._log.warning('scheduled_auto_position_management_failed error=%s', exc)\n\n"
        text=text.replace(marker,scheduled+marker,1)
    path.write_text(text,encoding="utf-8")

def patch_api() -> None:
    path=ROOT/"src/nexor_x/api/app.py"; text=path.read_text(encoding="utf-8")
    if '@app.get("/api/positions/auto-manage/status")' not in text:
        marker='    @app.post("/api/positions/manage-all")\n'
        if marker not in text: raise RuntimeError("manage-all endpoint marker not found")
        endpoints='    @app.get("/api/positions/auto-manage/status")\n    async def auto_position_management_status(_: None = Depends(require_admin)) -> dict[str, Any]:\n        return await kernel.auto_position_management_status()\n\n    @app.post("/api/positions/auto-manage/run")\n    async def auto_position_management_run(_: None = Depends(require_admin)) -> dict[str, Any]:\n        try:\n            return await kernel.auto_position_management_run()\n        except RuntimeError as exc:\n            raise HTTPException(status_code=409, detail=str(exc)) from exc\n\n'
        text=text.replace(marker,endpoints+marker,1)
    path.write_text(text,encoding="utf-8")

def patch_env_example() -> None:
    path=ROOT/".env.example"; text=path.read_text(encoding="utf-8") if path.exists() else ""
    if "AUTO_POSITION_MANAGEMENT_ENABLED=" not in text:
        text += "\n# GESTÃO AUTOMÁTICA DAS POSIÇÕES EM SIMULAÇÃO\nAUTO_POSITION_MANAGEMENT_ENABLED=true\nAUTO_POSITION_MANAGEMENT_INTERVAL_SECONDS=5\n"
        path.write_text(text,encoding="utf-8")

def patch_version() -> None:
    path=ROOT/"pyproject.toml"; text=path.read_text(encoding="utf-8"); text=re.sub(r'version = "[^"]+"','version = "0.38.0"',text,count=1); path.write_text(text,encoding="utf-8")
    path=ROOT/"src/nexor_x/__init__.py"; text=path.read_text(encoding="utf-8"); text=re.sub(r'__version__\s*=\s*"[^"]+"','__version__ = "0.38.0"',text); path.write_text(text,encoding="utf-8")

def main() -> None:
    patch_auto_paper_bug(); patch_config(); patch_kernel(); patch_api(); patch_env_example(); patch_version(); print("NEXOR X Update 38 aplicado com sucesso.")
if __name__ == "__main__": main()
