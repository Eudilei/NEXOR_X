NEXOR X UPDATE 38 — GESTÃO AUTÔNOMA DE POSIÇÕES

Em PAPER, acompanha posições a cada 5 segundos e aplica a política existente de stop, break-even, parcial e trailing. Também corrige a detecção de posições já abertas do AutoPaper. LIVE permanece bloqueado.

Correção: AutoPaper agora aceita o formato legado e o formato atual do snapshot de portfólio.
