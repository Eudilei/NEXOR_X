NEXOR X UPDATE 45 — POST-RECOVERY PROBATION GATE

Objetivo:
  fazer o retorno após um bloqueio crítico acontecer de forma gradual,
  evitando que o NEXOR recupere toda a frequência de novas entradas logo
  após o Recovery Hysteresis liberar o sistema.

Política padrão:
  - inicia automaticamente quando a Update 44 gera RECOVERED;
  - duração mínima: 60 minutos;
  - somente estado NORMAL permite nova exposição durante a provação;
  - intervalo mínimo entre novas entradas: 15 minutos;
  - no máximo 3 admissões durante a provação;
  - reduce-only continua sempre permitido;
  - CAUTION durante a provação bloqueia novas entradas;
  - BLOCKED continua sendo tratado pela histerese da Update 44;
  - estado persistido em data/entry_probation_state.json.

Fluxo:
  Performance Degradation
    -> Recovery Hysteresis
    -> Post-Recovery Probation
    -> Entry Admission
    -> PAPER / TESTNET

Novo endpoint administrativo:
  GET /api/operations/post-recovery-probation

LIVE permanece bloqueado.

Requer NEXOR X 0.44.0.
