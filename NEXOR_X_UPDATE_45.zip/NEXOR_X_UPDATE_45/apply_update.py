from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    items = (
        (
            PAYLOAD / "src/nexor_x/operations/post_recovery_probation.py",
            ROOT / "src/nexor_x/operations/post_recovery_probation.py",
        ),
        (
            PAYLOAD / "tests/test_post_recovery_probation.py",
            ROOT / "tests/test_post_recovery_probation.py",
        ),
        (
            PAYLOAD / "docs/AUDIT_UPDATE_45.md",
            ROOT / "docs/AUDIT_UPDATE_45.md",
        ),
    )
    for src, dst in items:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)

    imp = (
        "from .post_recovery_probation import "
        "PostRecoveryProbationController, PostRecoveryProbationPolicy\n"
    )
    if imp not in text:
        text = imp + text

    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "PostRecoveryProbationController" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += (
            '\n    "PostRecoveryProbationController",'
            '\n    "PostRecoveryProbationPolicy",\n'
        )
        text = text[:match.start(1)] + body + text[match.end(1):]

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.operations.post_recovery_probation import "
        "PostRecoveryProbationController\n"
    )
    if import_line not in text:
        marker = (
            "from nexor_x.operations.recovery_hysteresis import "
            "RecoveryHysteresisController\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 44 não detectada: RecoveryHysteresisController ausente"
            )
        text = text.replace(marker, marker + import_line, 1)

    if "self.post_recovery_probation = PostRecoveryProbationController(" not in text:
        marker = (
            "        self.entry_recovery_guard = RecoveryHysteresisController(\n"
            '            state_path="data/entry_recovery_state.json"\n'
            "        )\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 44 não detectada: entry_recovery_guard ausente"
            )
        init_line = (
            "        self.post_recovery_probation = "
            "PostRecoveryProbationController(\n"
            '            state_path="data/entry_probation_state.json"\n'
            "        )\n"
        )
        text = text.replace(marker, marker + init_line, 1)

    old = (
        "        recovery = self.entry_recovery_guard.evaluate(\n"
        "            degradation=degradation,\n"
        "        )\n"
        "        report = self.entry_admission_controller.evaluate(\n"
        '            degradation=recovery["degradation"],\n'
        "            action=action,\n"
        "            reduce_only=reduce_only,\n"
        "        )\n"
    )
    new = (
        "        recovery = self.entry_recovery_guard.evaluate(\n"
        "            degradation=degradation,\n"
        "        )\n"
        '        if recovery["transition"] == "RECOVERED":\n'
        "            self.post_recovery_probation.start()\n"
        "        probation = self.post_recovery_probation.evaluate(\n"
        '            degradation=recovery["degradation"],\n'
        "            action=action,\n"
        "            reduce_only=reduce_only,\n"
        "        )\n"
        "        report = self.entry_admission_controller.evaluate(\n"
        '            degradation=probation["degradation"],\n'
        "            action=action,\n"
        "            reduce_only=reduce_only,\n"
        "        )\n"
        '        report["post_recovery_probation"] = {\n'
        '            "active": probation["active"],\n'
        '            "allowed": probation["allowed"],\n'
        '            "block_reason": probation["block_reason"],\n'
        '            "admitted_entries": probation["admitted_entries"],\n'
        '            "max_entries_during_probation": (\n'
        '                probation["max_entries_during_probation"]\n'
        '            ),\n'
        '            "remaining_seconds": probation["remaining_seconds"],\n'
        "        }\n"
    )
    if old not in text:
        raise RuntimeError(
            "Update 44 não detectada ou entry_admission_status mudou; "
            "atualização abortada com segurança"
        )
    text = text.replace(old, new, 1)

    old_require = (
        '        if report["allowed"]:\n'
        "            return report\n"
        '        reasons = list(report.get("hard_reasons") or [])\n'
    )
    new_require = (
        '        if report["allowed"]:\n'
        "            if not reduce_only:\n"
        "                degradation = await self.performance_degradation_status()\n"
        "                recovery = self.entry_recovery_guard.evaluate(\n"
        "                    degradation=degradation,\n"
        "                )\n"
        "                probation = self.post_recovery_probation.admit(\n"
        '                    degradation=recovery["degradation"],\n'
        "                    action=action,\n"
        "                    reduce_only=False,\n"
        "                )\n"
        '                if not probation["allowed"]:\n'
        "                    raise RuntimeError(\n"
        '                        "New entry blocked by post-recovery probation: "\n'
        '                        + str(probation.get("block_reason") or "blocked")\n'
        "                    )\n"
        '                report["post_recovery_probation"] = {\n'
        '                    "active": probation["active"],\n'
        '                    "allowed": probation["allowed"],\n'
        '                    "block_reason": probation["block_reason"],\n'
        '                    "admitted_entries": probation["admitted_entries"],\n'
        '                    "max_entries_during_probation": (\n'
        '                        probation["max_entries_during_probation"]\n'
        '                    ),\n'
        '                    "remaining_seconds": probation["remaining_seconds"],\n'
        "                }\n"
        "            return report\n"
        '        reasons = list(report.get("hard_reasons") or [])\n'
    )
    if old_require not in text:
        raise RuntimeError(
            "Update 43/44 não detectada: require_entry_admission mudou; "
            "atualização abortada com segurança"
        )
    text = text.replace(old_require, new_require, 1)

    if "async def post_recovery_probation_status(" not in text:
        marker = "    async def entry_recovery_hysteresis_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 44 não detectada: recovery status ausente"
            )
        method = (
            "    async def post_recovery_probation_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return self.post_recovery_probation.status()\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/operations/post-recovery-probation")' not in text:
        marker = '@app.get("/api/operations/recovery-hysteresis")'
        if marker not in text:
            raise RuntimeError(
                "Update 44 não detectada: endpoint recovery-hysteresis ausente"
            )
        block = (
            '@app.get("/api/operations/post-recovery-probation")\n'
            "    async def post_recovery_probation_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.post_recovery_probation_status()\n\n"
            "    "
        )
        text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_notifications() -> None:
    path = ROOT / "src/nexor_x/notifications/telegram_events.py"
    if not path.exists():
        return

    text = path.read_text(encoding="utf-8")

    # Reaproveita o evento RECOVERED da Update 44: acrescenta explicação
    # de que a retomada entra em provação gradual.
    old = (
        '"Novas entradas voltam a seguir os demais gates.\\n"\n'
        '                    "LIVE: BLOQUEADO"\n'
    )
    new = (
        '"O sistema entrou em provação de retomada gradual.\\n"\n'
        '"Máx. 3 admissões, com 15 min entre elas, por 60 min.\\n"\n'
        '                    "LIVE: BLOQUEADO"\n'
    )
    if old in text:
        text = text.replace(old, new, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.45.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = _read(init)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.45.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_notifications()
    patch_version()
    print(
        "NEXOR X Update 45 aplicada: provação pós-recuperação ativa. "
        "LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
