from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()



def patch_evidence_exports() -> None:
    path = ROOT / "src/nexor_x/evidence/__init__.py"
    text = path.read_text(encoding="utf-8")

    collector_import = (
        "from .collector import EvidenceCollector, EvidenceSnapshot\n"
    )
    if collector_import not in text:
        text = collector_import + text

    # Preserve every legacy export already present. Only extend __all__ when it
    # exists as a simple list/tuple; otherwise the direct imports above are enough.
    if "__all__" in text:
        if '"EvidenceCollector"' not in text:
            marker = "__all__ = ["
            if marker in text:
                text = text.replace(
                    marker,
                    marker
                    + '\n    "EvidenceCollector",'
                    + '\n    "EvidenceSnapshot",',
                    1,
                )

    path.write_text(text, encoding="utf-8")

def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.evidence import EvidenceCollector\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.evidence_collector = EvidenceCollector(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        text = text.replace(
            marker,
            "        self.evidence_collector = EvidenceCollector(self.database)\n"
            + marker,
            1,
        )

    if "async def validation_evidence_collect" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def validation_evidence_collect(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        snapshot = await self.evidence_collector.collect()\n"
            "        result = snapshot.to_dict()\n"
            "        await self.event_bus.publish(Event(\n"
            "            'validation.evidence_collected',\n"
            "            {\n"
            "                'paper_trades': result['paper_trades'],\n"
            "                'integration_healthy': "
            "result['integration_healthy'],\n"
            "                'recovery_ok': result['recovery_ok'],\n"
            "                'live_allowed': False,\n"
            "            },\n"
            "            'evidence_collector',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if '@app.get("/api/validation/evidence")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoint = (
            '    @app.get("/api/validation/evidence")\n'
            "    async def validation_evidence_collect(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_evidence_collect()\n\n"
        )
        text = text.replace(marker, endpoint + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.32.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.32.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_evidence_exports()
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 32 aplicado com sucesso.")


if __name__ == "__main__":
    main()
