NEXOR X UPDATE 32 — COLETOR AUTOMÁTICO DE EVIDÊNCIAS

Envie este ZIP para a raiz do repositório.
Não descompacte e não use Codespaces.

O GitHub Actions executará a suíte completa antes do commit automático.
