NEXOR X UPDATE 65 — FILTER DECISION TELEMETRY INTEGRATION

Liga o monitor de rigidez da Update 64 ao fluxo real de decisão.

Registra:
- aprovação/rejeição;
- blockers;
- grupos CRITICAL / SCORE / REGIME;
- taxa de aprovação;
- filtros que mais rejeitam.

Não altera a decisão.
Não relaxa filtros críticos.
LIVE permanece bloqueado.
