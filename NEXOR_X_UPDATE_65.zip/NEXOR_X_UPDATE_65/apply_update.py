
from __future__ import annotations
from pathlib import Path
import re, shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"

def read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")

def copy_payload():
    # filter_rigidity is copied too, intentionally identical/self-contained.
    for rel in (
        "src/nexor_x/operations/filter_rigidity.py",
        "src/nexor_x/operations/filter_decision_telemetry.py",
        "tests/test_filter_decision_telemetry.py",
        "docs/AUDIT_UPDATE_65.md",
    ):
        src, dst = PAYLOAD / rel, ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def patch_ops_init():
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = read(path)
    imp = "from .filter_decision_telemetry import FilterDecisionTelemetry\n"
    if imp not in text:
        text = imp + text
    path.write_text(text, encoding="utf-8")

def patch_kernel():
    path = ROOT / "src/nexor_x/kernel.py"
    text = read(path)

    imp = (
        "from nexor_x.operations.filter_decision_telemetry import "
        "FilterDecisionTelemetry\n"
    )
    anchor = (
        "from nexor_x.operations.filter_rigidity import "
        "FilterRigidityMonitor\n"
    )
    if imp not in text:
        if anchor not in text:
            raise RuntimeError("Update 64 não detectada")
        text = text.replace(anchor, anchor + imp, 1)

    init = "        self.filter_decision_telemetry = FilterDecisionTelemetry()\n"
    anchor2 = (
        "        self.filter_rigidity_monitor = "
        "FilterRigidityMonitor(\n"
    )
    if init not in text:
        idx = text.find(anchor2)
        if idx < 0:
            raise RuntimeError("FilterRigidityMonitor não inicializado")
        text = text[:idx] + init + text[idx:]

    if "self.filter_decision_telemetry.record_trace(" not in text:
        old = (
            "        return self.entry_decision_trace.build(\n"
            "            degradation=degradation,\n"
            "            recovery=recovery,\n"
            "            probation=probation,\n"
            "            exposure=exposure,\n"
            "            reservation=reservation,\n"
            "        )\n"
        )
        new = (
            "        trace = self.entry_decision_trace.build(\n"
            "            degradation=degradation,\n"
            "            recovery=recovery,\n"
            "            probation=probation,\n"
            "            exposure=exposure,\n"
            "            reservation=reservation,\n"
            "        )\n"
            "        self.filter_decision_telemetry.record_trace(\n"
            "            monitor=self.filter_rigidity_monitor,\n"
            "            trace=trace,\n"
            "        )\n"
            "        return trace\n"
        )
        if old not in text:
            raise RuntimeError(
                "Corpo esperado de unified_entry_decision_trace não encontrado; "
                "patch abortado."
            )
        text = text.replace(old, new, 1)

    path.write_text(text, encoding="utf-8")

def patch_version():
    path = ROOT / "pyproject.toml"
    text = read(path)
    text = re.sub(r'version = "[^"]+"', 'version = "0.65.0"', text, count=1)
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.65.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")

def main():
    copy_payload()
    patch_ops_init()
    patch_kernel()
    patch_version()
    print(
        "Update 65 aplicada: telemetria ligada ao monitor; "
        "decisão original preservada; LIVE bloqueado."
    )

if __name__ == "__main__":
    main()
