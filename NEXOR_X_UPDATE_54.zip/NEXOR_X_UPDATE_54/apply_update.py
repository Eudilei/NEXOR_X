
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/validation/final_completion.py",
        "tests/test_final_technical_completion.py",
        "docs/AUDIT_UPDATE_54.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_validation_init() -> None:
    path = ROOT / "src/nexor_x/validation/__init__.py"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    imp = (
        "from .final_completion import "
        "FinalTechnicalCompletionGate\n"
    )
    if imp not in text:
        text = imp + text

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.validation.final_completion import "
        "FinalTechnicalCompletionGate\n"
    )
    anchor = (
        "from nexor_x.validation.final_campaign import "
        "FinalValidationCampaignController\n"
    )

    if import_line not in text:
        if anchor not in text:
            raise RuntimeError(
                "Update 53 não detectada: FinalValidationCampaignController ausente"
            )
        text = text.replace(
            anchor,
            anchor + import_line,
            1,
        )

    init_line = (
        "        self.final_technical_completion = "
        "FinalTechnicalCompletionGate()\n"
    )
    anchor2 = (
        "        self.final_validation_campaign = "
        "FinalValidationCampaignController(\n"
    )

    if init_line not in text:
        idx = text.find(anchor2)
        if idx < 0:
            raise RuntimeError(
                "Update 53 não detectada: final_validation_campaign ausente"
            )
        text = text[:idx] + init_line + text[idx:]

    if "async def final_technical_completion_status(" not in text:
        marker = "    async def final_validation_campaign_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 53 não detectada: final campaign status ausente"
            )

        method = (
            "    async def final_technical_completion_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        acceptance = await self.operational_acceptance_audit()\n"
            "        campaign = await self.final_validation_campaign_status()\n"
            "        readiness = await self.live_readiness_status()\n"
            "        certification = await self.live_certification_status()\n"
            "        return self.final_technical_completion.evaluate(\n"
            "            acceptance_audit=acceptance,\n"
            "            campaign=campaign,\n"
            "            readiness=readiness,\n"
            "            certification=certification,\n"
            "        )\n\n"
        )
        text = text.replace(
            marker,
            method + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/validation/final-completion")' in text:
        return

    marker = '@app.get("/api/validation/final-campaign")'
    if marker not in text:
        raise RuntimeError(
            "Update 53 não detectada: final-campaign endpoint ausente"
        )

    block = (
        '@app.get("/api/validation/final-completion")\n'
        "    async def final_technical_completion_status(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return await kernel.final_technical_completion_status()\n\n"
        "    "
    )

    text = text.replace(
        marker,
        block + marker,
        1,
    )
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.54.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.54.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_validation_init()
    patch_kernel()
    patch_api()
    patch_version()
    print(
        "NEXOR X Update 54 aplicada: Final Technical Completion Gate "
        "adicionado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
