NEXOR X UPDATE 71 - HISTORICAL DATASET EVIDENCE BRIDGE

Esta atualizacao aproveita a base existente binance_todos_simbolos sem baixar novamente.

Inclui:
- descoberta recursiva de *USDT-5m-AAAA-MM.zip;
- leitura de um CSV por ZIP;
- SHA-256, tamanho, datas, candles e cobertura por simbolo;
- validacao OHLCV, ordem temporal, duplicados, faltas e maior buraco;
- relatorios JSON e Markdown;
- adaptador seguro do positions.jsonl do laboratorio 7.3.15.58;
- diagnostico de fatores negativos e positivos;
- classificacao explicita de resultados antigos como diagnosticos, nao prova final;
- zero download automatico, zero preenchimento artificial e zero ordem.

Depois de aplicar, execute:
AUDITAR_DADOS_HISTORICOS.bat

O programa pedira somente o caminho da pasta binance_todos_simbolos.

Para diagnosticar resultados que o laboratorio antigo ja gerou, execute:
DIAGNOSTICAR_RESULTADO_LABORATORIO_ANTIGO.bat

Validacao:
- 331 testes aprovados;
- compilacao e lint critico aprovados;
- LIVE bloqueado.
