
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/operations/operational_readiness_summary.py",
        "tests/test_operational_readiness_summary.py",
        "docs/AUDIT_UPDATE_51.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)

    imp = (
        "from .operational_readiness_summary import "
        "UnifiedOperationalReadinessSummary\n"
    )
    if imp not in text:
        text = imp + text

    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "UnifiedOperationalReadinessSummary" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += '\n    "UnifiedOperationalReadinessSummary",\n'
        text = text[:match.start(1)] + body + text[match.end(1):]

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.operations.operational_readiness_summary import "
        "UnifiedOperationalReadinessSummary\n"
    )
    anchor = (
        "from nexor_x.operations.entry_decision_trace import "
        "UnifiedEntryDecisionTrace\n"
    )

    if import_line not in text:
        if anchor not in text:
            raise RuntimeError(
                "Update 50 não detectada: UnifiedEntryDecisionTrace ausente"
            )
        text = text.replace(anchor, anchor + import_line, 1)

    init_line = (
        "        self.operational_readiness_summary = "
        "UnifiedOperationalReadinessSummary()\n"
    )
    anchor2 = (
        "        self.entry_decision_trace = "
        "UnifiedEntryDecisionTrace()\n"
    )

    if init_line not in text:
        if anchor2 not in text:
            raise RuntimeError(
                "Update 50 não detectada: entry_decision_trace ausente"
            )
        text = text.replace(anchor2, anchor2 + init_line, 1)

    if "async def operational_readiness_summary(" not in text:
        marker = "    async def unified_entry_decision_trace(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 50 não detectada: unified_entry_decision_trace ausente"
            )

        method = (
            "    async def operational_readiness_summary(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        readiness = await self.live_readiness_status()\n"
            "        certification = await self.live_certification_status()\n"
            "        degradation = await self.performance_degradation_status()\n"
            "        entry_trace = await self.unified_entry_decision_trace()\n"
            "        return self.operational_readiness_summary.build(\n"
            "            readiness=readiness,\n"
            "            certification=certification,\n"
            "            degradation=degradation,\n"
            "            entry_trace=entry_trace,\n"
            "        )\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/operations/readiness-summary")' in text:
        return

    marker = '@app.get("/api/operations/entry-decision-trace")'
    if marker not in text:
        raise RuntimeError(
            "Update 50 não detectada: entry-decision-trace endpoint ausente"
        )

    block = (
        '@app.get("/api/operations/readiness-summary")\n'
        "    async def operational_readiness_summary(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return await kernel.operational_readiness_summary()\n\n"
        "    "
    )

    text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.51.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.51.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_version()
    print(
        "NEXOR X Update 51 aplicada: Unified Operational "
        "Readiness Summary adicionado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
