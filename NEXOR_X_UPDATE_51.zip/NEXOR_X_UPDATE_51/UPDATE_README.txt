NEXOR X UPDATE 51 — UNIFIED OPERATIONAL READINESS SUMMARY

Consolida:
- Live Readiness
- Evidence Certification
- Performance Degradation
- Unified Entry Decision Trace

Novo endpoint:
GET /api/operations/readiness-summary

A saída informa status geral, blockers, warnings, multiplicador de exposição
e se novas entradas PAPER/TESTNET estão liberadas.

LIVE permanece bloqueado.
