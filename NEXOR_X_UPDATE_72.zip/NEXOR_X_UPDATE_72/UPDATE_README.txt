NEXOR X UPDATE 72 - AUTORIDADE CAUSAL E SHADOW LEARNING

Corrige o bloqueio de inicializacao da calibracao sem liberar ordens indevidas.

Inclui:
- Shadow Learning causal para os mesmos cinco simbolos do scanner;
- usa Market Intelligence, Evidence Engine e Quant Brain atuais;
- aplica stop, break-even, parcial e trailing com os parametros PAPER atuais;
- somente posicoes shadow encerradas viram quant_observations;
- nenhuma posicao shadow altera carteira ou envia ordem;
- gate PAPER continua exigindo calibracao e backtest contextual;
- agendamento configuravel, padrao de 60 segundos;
- laboratorio externo de paridade versionado separadamente.

Seguranca:
- PAPER nao e contornado;
- TESTNET e LIVE nao sao chamados;
- LIVE permanece bloqueado.

Validacao realizada no ambiente disponivel:
- compilacao dos modulos alterados;
- teste unitario do ciclo causal shadow;
- seis testes do laboratorio standalone, incluindo replay ponta a ponta.
