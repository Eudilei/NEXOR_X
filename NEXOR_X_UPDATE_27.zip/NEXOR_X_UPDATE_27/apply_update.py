from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel_status() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")
    needle = (
        '            "live_certified": False,\n'
        "        }\n"
    )
    replacement = (
        '            "live_certified": False,\n'
        '            "version": __version__,\n'
        "        }\n"
    )
    if '"version": __version__' not in text:
        if needle not in text:
            raise RuntimeError("Kernel status marker not found")
        text = text.replace(needle, replacement, 1)
    path.write_text(text, encoding="utf-8")


def patch_api_dashboard() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.dashboard import COMMAND_CENTER_V2\n"
    if import_line not in text:
        marker = "from nexor_x import __version__\n"
        if marker not in text:
            raise RuntimeError("API version import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    text = text.replace(
        "        return COMMAND_CENTER\n",
        "        return COMMAND_CENTER_V2\n",
        1,
    )

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.27.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.27.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel_status()
    patch_api_dashboard()
    patch_version()
    print("NEXOR X Update 27 aplicado com sucesso.")


if __name__ == "__main__":
    main()
