NEXOR X UPDATE 34 — BACKTEST CONTEXTUAL PRÉ-ENTRADA

Envie este ZIP para a raiz do repositório.
Não descompacte e não use Codespaces.

A partir desta atualização, toda tentativa de entrada PAPER passa por:
1. Pre-Trade Gate existente;
2. backtest histórico do mesmo ativo + direção + regime;
3. verificação de amostra, PF, Expected R, desempenho recente,
   drawdown e walk-forward leve.

Se o backtest contextual reprovar, a entrada é bloqueada.
LIVE continua bloqueado.
