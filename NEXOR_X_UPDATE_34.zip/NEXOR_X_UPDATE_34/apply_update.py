from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_block = (
        "from nexor_x.pretrade_backtest import (\n"
        "    ContextBacktestPolicy,\n"
        "    ContextBacktestService,\n"
        ")\n"
    )
    if "ContextBacktestService" not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_block, 1)

    if "self.context_backtest = ContextBacktestService(" not in text:
        marker = "        self.portfolio = PortfolioService("
        if marker not in text:
            raise RuntimeError("Portfolio constructor marker not found")
        block = (
            "        self.context_backtest = ContextBacktestService(\n"
            "            self.database,\n"
            "            self.laboratory,\n"
            "            ContextBacktestPolicy(\n"
            "                minimum_samples="
            "settings.pretrade_backtest_minimum_samples,\n"
            "                maximum_samples="
            "settings.pretrade_backtest_maximum_samples,\n"
            "                minimum_profit_factor="
            "settings.pretrade_backtest_minimum_profit_factor,\n"
            "                minimum_expected_r="
            "settings.pretrade_backtest_minimum_expected_r,\n"
            "                minimum_recent_profit_factor="
            "settings.pretrade_backtest_minimum_recent_profit_factor,\n"
            "                minimum_recent_expected_r="
            "settings.pretrade_backtest_minimum_recent_expected_r,\n"
            "                maximum_drawdown_r="
            "settings.pretrade_backtest_maximum_drawdown_r,\n"
            "                minimum_walk_forward_pass_ratio="
            "settings.pretrade_backtest_minimum_walk_forward_pass_ratio,\n"
            "                folds=settings.pretrade_backtest_folds,\n"
            "            ),\n"
            "        )\n"
        )
        text = text.replace(marker, block + marker, 1)

    if "await self.context_backtest.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.context_backtest.start()\n",
            1,
        )

    # Integrate contextual backtest inside the authoritative readiness path.
    marker = (
        "        readiness = self.pre_trade_gate.evaluate(\n"
        "            symbol=symbol,\n"
        "            mode=self.settings.nexor_mode,\n"
        "            market=market,\n"
        "            quant=quant,\n"
        "            portfolio=portfolio,\n"
        "        )\n"
    )
    addition = (
        marker
        + "        contextual = await self.context_backtest.evaluate(\n"
        + "            symbol=symbol,\n"
        + "            decision=str(quant.get('decision') or 'NO_EDGE'),\n"
        + "            regime=str(market.get('regime') or 'UNKNOWN'),\n"
        + "        )\n"
    )
    if "contextual = await self.context_backtest.evaluate(" not in text:
        if marker not in text:
            raise RuntimeError("PreTradeGate evaluation marker not found")
        text = text.replace(marker, addition, 1)

    old = (
        "        result = readiness.to_dict()\n"
        "        result[\"portfolio\"] = portfolio\n"
    )
    new = (
        "        result = readiness.to_dict()\n"
        "        result['context_backtest'] = contextual\n"
        "        result['checks']['context_backtest'] = "
        "bool(contextual['approved'])\n"
        "        if not contextual['approved']:\n"
        "            result['allowed'] = False\n"
        "            result['decision'] = 'BLOCKED'\n"
        "            result['risk_budget'] = 0.0\n"
        "            reasons = list(result.get('reasons') or [])\n"
        "            reasons.append(\n"
        "                'backtest contextual reprovado: '\n"
        "                + ', '.join(contextual['blockers'])\n"
        "            )\n"
        "            result['reasons'] = reasons\n"
        "        result[\"portfolio\"] = portfolio\n"
    )
    if "result['context_backtest'] = contextual" not in text:
        if old not in text:
            raise RuntimeError("Readiness result marker not found")
        text = text.replace(old, new, 1)

    # Persist event after contextual decision too.
    event_marker = (
        '                    "risk_budget": readiness.risk_budget,\n'
        "                },\n"
    )
    event_new = (
        '                    "risk_budget": readiness.risk_budget,\n'
        '                    "context_backtest_approved": '
        "contextual['approved'],\n"
        "                },\n"
    )
    if '"context_backtest_approved"' not in text:
        if event_marker not in text:
            raise RuntimeError("Readiness event marker not found")
        text = text.replace(event_marker, event_new, 1)

    if "async def context_backtest_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def context_backtest_status(\n"
            "        self, symbol: str | None = None,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.context_backtest.latest(symbol=symbol)\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if '@app.get("/api/backtest/context/{symbol}")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoint = (
            '    @app.get("/api/backtest/context/{symbol}")\n'
            "    async def context_backtest_status(\n"
            "        symbol: str,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.context_backtest_status(symbol)\n\n"
        )
        text = text.replace(marker, endpoint + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_config() -> None:
    path = ROOT / "src/nexor_x/config.py"
    text = path.read_text(encoding="utf-8")

    fields = (
        "    pretrade_backtest_minimum_samples: int = 30\n"
        "    pretrade_backtest_maximum_samples: int = 300\n"
        "    pretrade_backtest_minimum_profit_factor: float = 1.10\n"
        "    pretrade_backtest_minimum_expected_r: float = 0.05\n"
        "    pretrade_backtest_minimum_recent_profit_factor: float = 1.00\n"
        "    pretrade_backtest_minimum_recent_expected_r: float = 0.00\n"
        "    pretrade_backtest_maximum_drawdown_r: float = 8.0\n"
        "    pretrade_backtest_minimum_walk_forward_pass_ratio: float = 0.60\n"
        "    pretrade_backtest_folds: int = 3\n"
    )
    if "pretrade_backtest_minimum_samples" not in text:
        marker = "    model_config = SettingsConfigDict("
        if marker not in text:
            raise RuntimeError("Config model marker not found")
        text = text.replace(marker, fields + "\n" + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.34.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.34.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_config()
    patch_version()
    print("NEXOR X Update 34 aplicado com sucesso.")


if __name__ == "__main__":
    main()
