NEXOR X UPDATE 23

Envie este ZIP diretamente para a raiz do repositório.
Não descompacte e não use Codespaces.

O GitHub Actions:
- valida o pacote;
- aplica o payload;
- executa apply_update.py;
- instala dependências;
- compila;
- executa lint crítico;
- executa a suíte completa de testes;
- remove o ZIP;
- faz commit automático somente se tudo passar.

Compatibilidade: preserva tools/apply_sprint*.py exigidos pelos testes existentes.
