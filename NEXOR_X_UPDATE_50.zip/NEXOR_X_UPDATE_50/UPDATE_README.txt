NEXOR X UPDATE 50 — UNIFIED ENTRY DECISION TRACE

Objetivo:
  mostrar em um único relatório exatamente por que uma nova entrada está
  liberada ou bloqueada.

Consolida:
  - Performance Degradation
  - Recovery Hysteresis
  - Post-Recovery Probation
  - Exposure Ramp
  - Atomic Entry Reservation

A consulta é read-only: não consome confirmação, vaga ou reserva.

Endpoint:
  GET /api/operations/entry-decision-trace

LIVE permanece bloqueado.
