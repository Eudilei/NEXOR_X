
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/operations/entry_decision_trace.py",
        "tests/test_entry_decision_trace.py",
        "docs/AUDIT_UPDATE_50.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)

    imp = "from .entry_decision_trace import UnifiedEntryDecisionTrace\n"
    if imp not in text:
        text = imp + text

    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "UnifiedEntryDecisionTrace" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += '\n    "UnifiedEntryDecisionTrace",\n'
        text = text[:match.start(1)] + body + text[match.end(1):]

    path.write_text(text, encoding="utf-8")


def patch_recovery_status() -> None:
    path = ROOT / "src/nexor_x/operations/recovery_hysteresis.py"
    text = _read(path)

    if "def status(" in text:
        return

    marker = "    def _can_count_healthy_check("
    if marker not in text:
        raise RuntimeError("Recovery Hysteresis esperado não encontrado")

    method = (
        "    def status(\n"
        "        self,\n"
        "        *,\n"
        "        now: datetime | None = None,\n"
        "    ) -> dict[str, Any]:\n"
        "        now = self._utc(now)\n"
        "        return {\n"
        '            "latched": bool(self._state["latched"]),\n'
        '            "blocked_since": self._state.get("blocked_since"),\n'
        '            "healthy_checks": int(self._state.get("healthy_checks", 0)),\n'
        '            "required_healthy_checks": self.policy.required_healthy_checks,\n'
        '            "cooldown_seconds": self.policy.cooldown_seconds,\n'
        '            "elapsed_since_block_seconds": self._elapsed_seconds(now),\n'
        '            "min_healthy_check_interval_seconds": (\n'
        '                self.policy.min_healthy_check_interval_seconds\n'
        "            ),\n"
        '            "read_only": True,\n'
        '            "live_allowed": False,\n'
        '            "evaluated_at": now.isoformat(),\n'
        "        }\n\n"
    )

    text = text.replace(marker, method + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.operations.entry_decision_trace import "
        "UnifiedEntryDecisionTrace\n"
    )
    anchor = (
        "from nexor_x.operations.entry_reservation import "
        "AtomicEntryReservationGuard\n"
    )
    if import_line not in text:
        if anchor not in text:
            raise RuntimeError(
                "Update 47+ não detectada: entry reservation ausente"
            )
        text = text.replace(anchor, anchor + import_line, 1)

    init_line = (
        "        self.entry_decision_trace = UnifiedEntryDecisionTrace()\n"
    )
    if init_line not in text:
        anchor2 = (
            "        self.entry_reservation_guard = "
            "AtomicEntryReservationGuard(\n"
        )
        idx = text.find(anchor2)
        if idx < 0:
            raise RuntimeError("entry_reservation_guard não encontrado")
        text = text[:idx] + init_line + text[idx:]

    if "async def unified_entry_decision_trace(" not in text:
        marker = "    async def entry_reservation_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 47 não detectada: reservation status ausente"
            )

        method = (
            "    async def unified_entry_decision_trace(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        degradation = await self.performance_degradation_status()\n"
            "        recovery = self.entry_recovery_guard.status()\n"
            "        probation = self.post_recovery_probation.status()\n"
            "        exposure = self.probation_exposure_ramp.evaluate(\n"
            "            probation=probation,\n"
            "            reduce_only=False,\n"
            "        )\n"
            "        reservation = self.entry_reservation_guard.status()\n"
            "        return self.entry_decision_trace.build(\n"
            "            degradation=degradation,\n"
            "            recovery=recovery,\n"
            "            probation=probation,\n"
            "            exposure=exposure,\n"
            "            reservation=reservation,\n"
            "        )\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/operations/entry-decision-trace")' in text:
        return

    marker = '@app.get("/api/operations/entry-reservation")'
    if marker not in text:
        raise RuntimeError(
            "Update 47 não detectada: reservation endpoint ausente"
        )

    block = (
        '@app.get("/api/operations/entry-decision-trace")\n'
        "    async def unified_entry_decision_trace(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return await kernel.unified_entry_decision_trace()\n\n"
        "    "
    )
    text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.50.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.50.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_recovery_status()
    patch_kernel()
    patch_api()
    patch_version()
    print(
        "NEXOR X Update 50 aplicada: Unified Entry Decision Trace "
        "adicionado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
