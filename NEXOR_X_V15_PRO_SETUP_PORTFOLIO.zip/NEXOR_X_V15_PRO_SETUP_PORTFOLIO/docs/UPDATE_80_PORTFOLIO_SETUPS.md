# V15 — Portfólio de setups por regime

- Estratégia passou a ser a unidade de decisão; Quant Brain é confirmação, não veto global.
- Setups: Trend Pullback, Breakout + Retest, Momentum, Liquidity Sweep, Mean Reversion e Range Trading.
- Cada observação causal agora preserva `strategy_id`.
- Backtest pré-entrada e Adaptive Edge avaliam símbolo + direção + regime + setup.
- Shadow Learning preserva o setup que originou cada observação.
- Risco e custos continuam autoritativos; LIVE não é liberado por esta atualização.
- Laboratório continua limitado a 5 símbolos apenas para acelerar replay.
