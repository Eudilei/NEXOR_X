from __future__ import annotations

from dataclasses import dataclass
from math import exp, isfinite
from typing import Any, Iterable


@dataclass(frozen=True, slots=True)
class AdaptiveEdgePolicy:
    minimum_exact_samples: int = 8
    minimum_context_samples: int = 30
    minimum_global_samples: int = 60
    minimum_effective_samples: float = 18.0
    minimum_profit_factor: float = 1.05
    minimum_expected_r: float = 0.03
    minimum_recent_expected_r: float = -0.01
    minimum_stability_ratio: float = 0.50
    shrinkage_strength: float = 24.0
    recency_half_life_samples: float = 60.0
    cost_buffer_r: float = 0.03
    minimum_confidence: float = 0.42


class AdaptiveContextEdge:
    """Causal hierarchical estimator for entry quality.

    It never uses future observations. Exact context evidence is preferred, but
    when it is sparse the estimate is shrunk toward broader contexts instead of
    either blocking forever or trusting a tiny sample. The result is an
    explainable research/PAPER gate; it does not authorize LIVE execution.
    """

    def __init__(self, policy: AdaptiveEdgePolicy | None = None) -> None:
        self.policy = policy or AdaptiveEdgePolicy()

    def evaluate(
        self,
        *,
        symbol: str,
        decision: str,
        regime: str,
        strategy_id: str | None,
        observations: Iterable[dict[str, Any]],
    ) -> dict[str, Any]:
        symbol = symbol.upper()
        decision = decision.upper()
        regime = regime.upper()
        strategy_id = str(strategy_id or "NO_STRATEGY")
        rows = [row for row in observations if self._finite(row.get("realized_r"))]

        levels = [
            ("EXACT", lambda r: self._eq(r, symbol, decision, regime, strategy_id)),
            ("SYMBOL_CONTEXT", lambda r: self._eq(r, symbol, decision, regime, None)),
            ("STRATEGY_CONTEXT", lambda r: self._eq(r, None, decision, regime, strategy_id)),
            ("MARKET_CONTEXT", lambda r: self._eq(r, None, decision, regime, None)),
            ("GLOBAL", lambda r: True),
        ]
        summaries: list[dict[str, Any]] = []
        for name, matcher in levels:
            values = [float(r["realized_r"]) for r in rows if matcher(r)]
            summaries.append({"level": name, **self._metrics(values)})

        broad = next((x for x in summaries if x["sample_count"] >= self.policy.minimum_context_samples), summaries[-1])
        exact = summaries[0]
        exact_n = exact["sample_count"]
        reliability = exact_n / (exact_n + self.policy.shrinkage_strength) if exact_n else 0.0
        expected_r = reliability * exact["weighted_expected_r"] + (1.0-reliability) * broad["weighted_expected_r"]
        pf = reliability * min(exact["profit_factor"], 5.0) + (1.0-reliability) * min(broad["profit_factor"], 5.0)
        effective_samples = reliability * exact["effective_samples"] + (1.0-reliability) * broad["effective_samples"]
        stability = reliability * exact["stability_ratio"] + (1.0-reliability) * broad["stability_ratio"]
        recent_expected = reliability * exact["recent_expected_r"] + (1.0-reliability) * broad["recent_expected_r"]
        net_edge = expected_r - self.policy.cost_buffer_r
        blended_std = reliability * exact["weighted_std_r"] + (1.0-reliability) * broad["weighted_std_r"]
        uncertainty_penalty = min(0.15, 0.35*blended_std/max(effective_samples, 1.0)**0.5)
        conservative_net_edge = net_edge-uncertainty_penalty

        sample_conf = min(effective_samples / max(self.policy.minimum_effective_samples*2.0, 1.0), 1.0)
        edge_conf = min(max((net_edge + 0.10) / 0.30, 0.0), 1.0)
        confidence = 0.55*sample_conf + 0.45*edge_conf

        checks = {
            "adaptive_exact_support": exact_n >= self.policy.minimum_exact_samples,
            "adaptive_global_support": summaries[-1]["sample_count"] >= self.policy.minimum_global_samples,
            "adaptive_samples": effective_samples >= self.policy.minimum_effective_samples,
            "adaptive_profit_factor": pf >= self.policy.minimum_profit_factor,
            "adaptive_expected_r": expected_r >= self.policy.minimum_expected_r,
            "adaptive_net_edge": net_edge > 0.0,
            "adaptive_uncertainty_margin": conservative_net_edge > 0.0,
            "adaptive_recent_edge": recent_expected >= self.policy.minimum_recent_expected_r,
            "adaptive_stability": stability >= self.policy.minimum_stability_ratio,
            "adaptive_confidence": confidence >= self.policy.minimum_confidence,
        }
        approved = all(checks.values())
        blockers = [name.upper() for name, passed in checks.items() if not passed]
        return {
            "status": "APPROVED" if approved else "OBSERVE",
            "approved": approved,
            "symbol": symbol,
            "decision": decision,
            "regime": regime,
            "strategy_id": strategy_id,
            "exact_samples": exact_n,
            "anchor_level": broad["level"],
            "effective_samples": round(effective_samples, 4),
            "shrunk_expected_r": round(expected_r, 6),
            "shrunk_profit_factor": round(pf, 6),
            "recent_expected_r": round(recent_expected, 6),
            "stability_ratio": round(stability, 6),
            "cost_buffer_r": self.policy.cost_buffer_r,
            "net_edge_after_buffer_r": round(net_edge, 6),
            "uncertainty_penalty_r": round(uncertainty_penalty, 6),
            "conservative_net_edge_r": round(conservative_net_edge, 6),
            "confidence": round(confidence, 6),
            "checks": checks,
            "blockers": blockers,
            "levels": summaries,
            "live_execution_allowed": False,
        }

    def _metrics(self, values: list[float]) -> dict[str, Any]:
        if not values:
            return {"sample_count": 0, "effective_samples": 0.0, "weighted_expected_r": 0.0,
                    "profit_factor": 0.0, "recent_expected_r": 0.0, "stability_ratio": 0.0,
                    "weighted_std_r": 0.0}
        n = len(values)
        decay = exp(-0.6931471805599453 / max(self.policy.recency_half_life_samples, 1.0))
        weights = [decay ** (n-1-i) for i in range(n)]
        weight_sum = sum(weights)
        weighted_expected = sum(v*w for v, w in zip(values, weights)) / weight_sum
        variance = sum(w*(v-weighted_expected)**2 for v, w in zip(values, weights))/weight_sum
        weighted_std = variance**0.5
        effective = weight_sum
        profit = sum(max(v, 0.0)*w for v, w in zip(values, weights))
        loss = abs(sum(min(v, 0.0)*w for v, w in zip(values, weights)))
        pf = profit/loss if loss else (5.0 if profit else 0.0)
        recent_count = min(max(n//4, 5), 40)
        recent = values[-recent_count:]
        recent_expected = sum(recent)/len(recent)
        folds = self._folds(values, 4)
        positive = sum(1 for fold in folds if fold and sum(fold)/len(fold) > 0.0)
        stability = positive/len(folds) if folds else 0.0
        return {"sample_count": n, "effective_samples": round(effective, 4),
                "weighted_expected_r": round(weighted_expected, 6),
                "profit_factor": round(pf, 6), "recent_expected_r": round(recent_expected, 6),
                "stability_ratio": round(stability, 6), "weighted_std_r": round(weighted_std, 6)}

    @staticmethod
    def _folds(values: list[float], count: int) -> list[list[float]]:
        if not values:
            return []
        size = max(len(values)//count, 1)
        result = []
        start = 0
        for index in range(count):
            end = len(values) if index == count-1 else min(start+size, len(values))
            if start < len(values):
                result.append(values[start:end])
            start = end
        return result

    @staticmethod
    def _finite(value: Any) -> bool:
        try:
            return isfinite(float(value))
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _eq(row: dict[str, Any], symbol: str | None, decision: str | None,
            regime: str | None, strategy_id: str | None) -> bool:
        if symbol is not None and str(row.get("symbol") or "").upper() != symbol:
            return False
        if decision is not None and str(row.get("decision") or "").upper() != decision:
            return False
        if regime is not None and str(row.get("regime") or "").upper() != regime:
            return False
        if strategy_id is not None and str(row.get("strategy_id") or "NO_STRATEGY") != strategy_id:
            return False
        return True
