from nexor_x.strategy import StrategyCandle, StrategySignalEngine


def _bars():
    out=[]
    p=100.0
    for i in range(80):
        close=p*(1.001 if i<79 else 1.0)
        out.append(StrategyCandle(i, p, max(p,close)*1.001, min(p,close)*0.999, close, 100.0))
        p=close
    return out

def test_portfolio_contains_six_independent_setups():
    signals=StrategySignalEngine().evaluate(_bars(), regime="TREND_UP", market_decision="SHORT_BIAS")
    ids={x.strategy_id for x in signals}
    assert ids == {"trend_pullback","breakout_retest","momentum","liquidity_sweep","mean_reversion","range_trading"}
    assert all("quant_direction_alignment_advisory" in x.checks for x in signals)
