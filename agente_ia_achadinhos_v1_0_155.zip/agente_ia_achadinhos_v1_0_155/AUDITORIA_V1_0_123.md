# Auditoria v1.0.124

## Objetivo
Corrigir inconsistências da v1.0.122 sem remover o novo banco de vozes.

## Correções
- Testes legados de gênero não exigem mais Antonio/Francisca, pois o produto agora usa locutores pt-BR realmente distintos.
- Teste legado de humor atualizado para a sequência atual que inclui `humor_viral`.
- Validação adicionada para garantir diversidade real de timbres Edge e Gemini, e não apenas variação de velocidade/pitch.
- Seleção manual continua soberana; o modo Automático só escolhe voz pelo estilo quando `auto` está selecionado.
- Narrador Viral BR permanece como direção original de estilo, sem clonagem de pessoa real.

## Compatibilidade
- Gemini TTS continua sendo priorizado quando `GEMINI_API_KEY` está configurada.
- Edge TTS continua como fallback gratuito.
- Perfis existentes da v1.0.122 foram preservados.
