# Auditoria v1.0.149

## Objetivo
Reduzir o tempo real de produção sem remover recursos existentes e corrigir o fluxo de falha observado ao publicar no TikTok.

## Diagnóstico confirmado pelo vídeo 19273.mp4
- A montagem permaneceu vários minutos em "Criando o vídeo".
- O código baixava as mesmas imagens duas vezes na mesma produção: uma vez em `generate_production_assets` e novamente em `compose_product_first_video`.
- Os segmentos visuais eram renderizados em sequência, um FFmpeg por cena.
- A falha do TikTok mostrada no histórico foi `unaudited_client_can_only_post_to_private_accounts`.
- Isso confirma que OAuth/conexão e envio até o Direct Post estão funcionando, mas o TikTok ainda trata o cliente de Content Posting como não auditado para postagem pública.

## Correções de desempenho
- Reaproveitamento das imagens já baixadas na etapa de composição; elimina o segundo download/decodificação do mesmo anúncio.
- Download de imagens em paralelo, limitado a 4 tarefas para não estourar recursos do Render.
- Renderização de segmentos em paralelo, limitada a 2 FFmpeg simultâneos.
- Cache local existente preservado.
- Seleção de 5 a 7 cenas preservada conforme a duração.
- Nenhuma mudança destrutiva no banco, modelos, rotas existentes ou fluxo de aprovação.

## Correção TikTok
- Erros da API agora preservam `error.code` e `log_id` para diagnóstico real.
- Quando o TikTok devolve especificamente `unaudited_client_can_only_post_to_private_accounts`, a produção não é perdida: o agente usa o endpoint oficial `video.upload` e envia o MP4 como rascunho para a caixa de entrada do TikTok.
- O histórico passa a indicar `enviado_tiktok_revisao` e explica que a conclusão deve ser feita no app enquanto a auditoria Direct Post não estiver liberada.
- Para clientes já auditados, o Direct Post continua exatamente como antes.

## Validação
- `python -m compileall -q app`: OK.
- Testes direcionados TikTok + render rápido: 8 testes aprovados.
- Suíte completa foi iniciada e não apresentou falha antes de atingir o limite de execução de 45 s deste ambiente.

## Importante
A aprovação do aplicativo em Produção no TikTok Developers não é, por si só, prova de que a auditoria específica do Direct Post público foi liberada. O erro real registrado pelo TikTok no vídeo comprova que, nesta conta/cliente, a postagem pública automática ainda está sujeita a essa restrição.
