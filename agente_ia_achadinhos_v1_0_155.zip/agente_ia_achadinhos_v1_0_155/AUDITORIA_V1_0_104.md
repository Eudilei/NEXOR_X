# Auditoria v1.0.104

## Objetivo
Estabilizar o enriquecimento do Mercado Livre após os 403 PolicyAgent e impedir perda de dados já confirmados em varreduras parciais.

## Correções
- `/products/{id}` passa a usar modo `auto`, tentando autenticação e fallback público quando permitido.
- Bloqueios `PolicyAgent` passam a ser memorizados por família de endpoint já na primeira ocorrência da varredura.
- Famílias de `/sale_price` e `/prices` são normalizadas no cache para evitar insistência em vários itens após bloqueio de política.
- `_save_preselected()` compara `listing_url` com o metadado correto, não com `affiliate_url`.
- Varredura parcial não zera preço, preço anterior, nota, avaliações, vendas ou estoque previamente confirmados.
- Formulário manual preserva `oficial_marketplace` quando a mídia já foi importada oficialmente do Mercado Livre.

## Validação
Testes específicos v1.0.104 + persistência v1.0.103 + enriquecimento oficial v1.0.97: 9 aprovados.
`python -m compileall -q app`: aprovado.
