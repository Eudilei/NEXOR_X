# Auditoria v1.0.122

## Problema encontrado
Na v1.0.121, o cadastro tinha mais locutores, porém o endpoint de criação convertia `auto` cedo demais usando apenas gênero. Isso impedia o worker de escolher a voz a partir do estilo do roteiro e fazia muitos vídeos caírem em uma voz natural.

## Correções
- `auto` é preservado até o worker.
- Nova função `choose_free_voice_profile` combina estilo, gênero e semente de variação.
- Oito novos perfis de interpretação e timbres Gemini distintos.
- Perfil `narrador_viral_br` busca energia de humor viral brasileiro sem imitar identidade vocal de pessoa real.
- Interface expõe os novos estilos em grupo próprio.

## Segurança/regressão
- Perfis explícitos nunca são substituídos pelo modo automático.
- Fallback Edge permanece disponível.
- Testes cobrem rotação automática, gênero, seleção manual e UI.
