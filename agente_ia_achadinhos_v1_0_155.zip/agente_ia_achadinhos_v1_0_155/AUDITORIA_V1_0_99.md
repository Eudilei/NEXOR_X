# Auditoria v1.0.99

Correções aplicadas:
- enriquecimento independente da sessão de banco;
- fallback autenticado e público para ofertas de catálogo;
- avaliação de até 10 anúncios e escolha da oferta com dados mais completos;
- coleta de galeria sem parar após a primeira imagem;
- preservação de estoque confirmado;
- separação rígida entre link original e link afiliado;
- mídia oficial do marketplace reconhecida automaticamente quando há fotos.
