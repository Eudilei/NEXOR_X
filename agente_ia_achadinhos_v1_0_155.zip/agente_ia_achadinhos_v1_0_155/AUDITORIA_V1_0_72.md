# Auditoria v1.0.72 — métricas comerciais Mercado Livre

## Diagnóstico

A coleta de avaliações consultava o endpoint sem autenticação e sem o contexto do `catalog_product_id`. Além disso, o total dependia apenas de `paging.total`, que pode vir vazio. A quantidade vendida era extraída de um dicionário mesclado, sem preservar a prioridade da oferta real nem registrar a origem do dado.

## Correções

- Consulta de avaliações autenticada, com fallback anônimo.
- Inclusão de `catalog_product_id` na consulta de itens de catálogo.
- Total de avaliações por `paging.total`; fallback pela soma de `rating_levels`.
- Nota, total e distribuição de estrelas persistidos com origem confirmada.
- Quantidade vendida priorizada por oferta real, depois Buy Box, página pública e catálogo.
- Origem e escopo da quantidade vendida registrados nos metadados.
- Diagnóstico da tela Site Zavomi ampliado com nota, avaliações, vendas e origem.
- Dados anteriores válidos são preservados quando uma consulta temporária não retorna métricas.

## Validação

Toda a suíte foi executada com sucesso, incluindo três testes novos específicos para as métricas comerciais.
