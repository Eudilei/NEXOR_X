# Auditoria v1.0.128

Correções executadas após auditoria da v1.0.127:

- removidos nomes de pessoas que não correspondiam aos identificadores de voz Gemini;
- cada perfil rico mantém identificador Gemini exclusivo;
- seleção manual continua soberana e não é trocada pelo modo automático;
- perfis Gemini não caem silenciosamente para Antonio/Francisca;
- preview da tela de roteiro e da tela de produção exibe provedor e timbre realmente usados;
- arquivo de áudio final continua separado por perfil+timbre, impedindo reutilização de áudio antigo;
- Gemini TTS tenta o modelo configurado e possui fallback controlado entre 3.1 Flash TTS e 2.5 Flash TTS;
- removidos arquivos RELEASE antigos, banco SQLite local e caches do pacote de distribuição;
- dashboard atualizado para v1.0.128.

Validação:

- `python -m compileall -q app`: aprovado;
- 34 testes focados em voz, preview, diversidade, seleção manual, humor e métricas: aprovados;
- a suíte integral do projeto foi iniciada, porém excedeu o limite de tempo do ambiente; não foi registrada falha antes do timeout.

Observação operacional:

A diversidade real de timbres depende de `GEMINI_API_KEY`. Sem a chave, o sistema mostra explicitamente apenas os fallbacks Edge Antonio e Francisca.
