# Auditoria v1.0.135

- Roteirista Visual atualizado para usar `gemini-3.6-flash` como primeira opção, conforme documentação atual da Gemini API.
- Descoberta dinâmica de modelos: consulta `/v1beta/models` com a mesma `GEMINI_API_KEY` e prioriza modelos Flash com `generateContent`.
- Mantidos fallbacks 3.5/2.5 Flash e diagnóstico detalhado por HTTP.
- Se nenhuma foto real puder ser baixada, a IA Visual não finge análise: informa o problema para correção.
- Adicionadas 10 opções cômicas extras (5 masculinas e 5 femininas), com cinco timbres distintos dentro de cada novo grupo.
- Nenhuma chave adicional é necessária para visão: usa a mesma `GEMINI_API_KEY` do Gemini TTS.
