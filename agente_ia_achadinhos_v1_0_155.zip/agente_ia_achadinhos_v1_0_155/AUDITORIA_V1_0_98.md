# Auditoria v1.0.98

## Causa encontrada
A v1.0.97 enriquecia resultados do tipo PRODUCT somente quando `buy_box_winner` já trazia um ITEM_ID. Muitos rankings oficiais retornam um produto de catálogo sem esse campo. Nesses casos, o agente mantinha apenas a URL `/p/MLB...` e nunca executava as consultas de preço, avaliações, estoque, descrição e galeria do anúncio real.

A atualização manual também não chamava `item_sale_prices`, portanto podia localizar o anúncio e ainda manter o preço como não confirmado.

## Correções
- resolve o ITEM_ID por `/products/{catalog_id}/items` quando a Buy Box não o expõe;
- usa a URL do anúncio real durante o enriquecimento;
- permite consulta do detalhe do item com fallback público;
- aplica `/sale_price` e `/prices` também na atualização manual;
- preserva links afiliados confirmados e não inventa métricas ausentes.
