# Auditoria v1.0.74 — descoberta resiliente

- Bloqueios PolicyAgent 403 são consolidados e não geram chamadas repetidas indefinidamente.
- Quando o detalhe oficial é bloqueado, o agente tenta a página pública do produto.
- Nota e avaliações ausentes não impedem qualificação se preço, estoque e oferta forem confirmados.
- Valores conhecidos abaixo dos mínimos continuam reprovados.
- Produtos duplicados são consolidados, priorizando a oferta mais completa.
- A interface separa pendências essenciais de métricas não obrigatórias em atualização.
