# Auditoria v1.0.78

## Problemas corrigidos

- O preço retornado pelo catálogo/buy-box podia substituir o preço atual realmente exibido na página pública.
- Quando o valor de catálogo era maior, ele não era reaproveitado corretamente como candidato a preço anterior.
- Os campos manuais exigiam vírgulas e pontos, causando valores como 30.386,00 e 48,0.
- A avaliação podia aceitar valores impossíveis acima de 5.

## Nova regra de preços

1. O preço público exibido ao comprador tem prioridade como preço atual.
2. O preço anterior precisa ser maior que o preço atual.
3. Um preço maior retornado pela API pode ser usado como preço anterior quando a página pública confirma um preço atual menor.
4. Na ausência de evidência válida, o preço anterior permanece vazio.

## Máscaras manuais

- Preço: 14781 -> 147,81.
- Avaliação: 49 -> 4,9.
- Comissão: 12 -> 12,0; 125 -> 12,5.
- Avaliações e vendas: somente dígitos, com separador de milhares automático.

## Validação

- Compilação Python concluída.
- 274 testes aprovados.
