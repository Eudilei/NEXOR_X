# Auditoria técnica — Agente IA v1.0.76

## Objetivo
Substituir o núcleo monolítico de descoberta por uma esteira consolidada, sem manter duas implementações concorrentes.

## Alterações executadas
- `run_discovery` tornou-se somente uma fachada de compatibilidade.
- A implementação única passou para `app/services/discovery/pipeline.py`.
- Criados módulos de responsabilidade única para ranking, evidências, histórico e coletores.
- Corrigido erro de persistência que podia reutilizar o produto/resultado de afiliado do candidato anterior.
- Cada campo enriquecido passa a registrar fonte e confiança em `source_metadata_json`.
- Classificação de completude A/B/C/D adicionada.
- Preço anterior passa a usar o valor oficial quando disponível e, na ausência, o histórico confirmado do próprio Zavomi.
- Link normal permanece apenas como referência operacional interna; site, roteiro e publicações continuam exigindo `affiliate_link_confirmed`.
- Nenhum parâmetro de afiliado é fabricado. A geração depende de fonte oficial configurada.

## Estrutura consolidada
- `app/services/discovery/pipeline.py`
- `app/services/discovery/ranking.py`
- `app/services/discovery/history.py`
- `app/services/discovery/models.py`
- `app/services/discovery/collectors/`

## Validação
- Suíte completa executada.
- Testes de regressão do buscador, integrações, roteiro, mídia, site e redes sociais.
- Testes novos para níveis de qualidade e rastreabilidade das fontes.
