from enum import Enum
from pydantic import BaseModel, Field, HttpUrl


class ProductCategory(str, Enum):
    CASA = "casa"
    COZINHA = "cozinha"
    ORGANIZACAO = "organizacao"
    LIMPEZA = "limpeza"
    BELEZA = "beleza"
    CUIDADOS_PESSOAIS = "cuidados_pessoais"
    ELETRONICOS = "eletronicos"
    CELULARES_ACESSORIOS = "celulares_acessorios"
    INFORMATICA = "informatica"
    FERRAMENTAS = "ferramentas"
    AUTOMOTIVO = "automotivo"
    PET = "pet"
    INFANTIL = "infantil"
    ESPORTE_LAZER = "esporte_lazer"
    ESCRITORIO_PAPELARIA = "escritorio_papelaria"
    MODA_ACESSORIOS = "moda_acessorios"
    VIAGEM = "viagem"
    JARDIM = "jardim"
    SEGURANCA = "seguranca"
    UTILIDADES = "utilidades"


class ProductStatus(str, Enum):
    FOUND = "encontrado"
    REVIEW = "em_analise"
    APPROVED = "aprovado"
    REJECTED = "reprovado"
    CONTENT_READY = "conteudo_pronto"
    PUBLISHED = "publicado"
    PAUSED = "pausado"


class ProductInput(BaseModel):
    title: str = Field(min_length=3, max_length=180)
    category: ProductCategory
    marketplace: str = "mercado_livre"
    price: float = Field(gt=0)
    original_price: float | None = Field(default=None, gt=0)
    rating: float = Field(default=0, ge=0, le=5)
    review_count: int = Field(default=0, ge=0)
    sold_quantity: int = Field(default=0, ge=0)
    seller_reputation: float = Field(default=0, ge=0, le=100)
    commission_pct: float = Field(default=0, ge=0, le=100)
    stock_available: bool = True
    visual_quality: float = Field(default=5, ge=0, le=10)
    demonstration_ease: float = Field(default=5, ge=0, le=10)
    novelty: float = Field(default=5, ge=0, le=10)
    return_risk: float = Field(default=5, ge=0, le=10)
    affiliate_url: HttpUrl
    media_license: str = "origem_nao_confirmada"


class ProductScore(BaseModel):
    total: float
    classification: str
    approved: bool
    reasons: list[str]


class ScriptRequest(BaseModel):
    product: ProductInput
    format: str = "automatico"
    duration_seconds: int = Field(default=40, ge=10, le=45)
    production_engine: str = "free_editor"
    presenter_type: str = "realista"
    presenter_gender: str = "automatico"
    presenter_age: str = "jovem"
    presenter_energy: str = "alegre"
    presenter_style: str = "creator"
    voice: str = "coral"
    voice_instructions: str = "Fale em português do Brasil, com voz jovem, alegre, natural e ritmo de vídeo curto."
    variation_index: int = Field(default=0, ge=0, le=9)
    writer_engine: str = "free_ai"
    creativity_level: str = "equilibrado"
    target_platforms: str = "all"
    product_description: str = ""
    source_images: list[str] = Field(default_factory=list)


class ScriptOutput(BaseModel):
    hook: str
    narration: str
    on_screen_text: list[str]
    caption: str
    call_to_action: str
    hashtags: list[str]
