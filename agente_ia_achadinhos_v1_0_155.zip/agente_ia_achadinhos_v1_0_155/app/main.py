from contextlib import asynccontextmanager
from datetime import datetime, timezone
import base64
import hashlib
import hmac
import re
import secrets
import logging
import shutil
import json
from pathlib import Path
from zoneinfo import ZoneInfo

from fastapi import BackgroundTasks, Depends, FastAPI, Form, HTTPException, Request, status, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, select, update, text, inspect, delete, or_
from sqlalchemy.orm import Session
from starlette.middleware.sessions import SessionMiddleware

from app.api.routes import router
from app.core.config import settings
from app.core.csrf import csrf_token, validate_csrf
from app.core.security import credentials_valid, is_logged_in
from app.db.database import Base, engine, get_db, SessionLocal
from app.db.models import DiscoveryJob, Product, ProductObservation, Script, Production, Publication, SocialConnection, MediaAsset, LinkClick, InstagramCommentEvent, DataDeletionRequest, AdCampaign, SitePublication, InitialCatalogState
from app.models.schemas import ProductCategory, ProductInput, ScriptRequest
from app.services.catalog import product_to_input
from app.services.scoring import score_product, meets_commercial_gate
from app.services.scripts import generate_script, resolve_format, sanitize_script_language, script_language_issues, _text_similarity
from app.services.production import generate_production_assets, storage_root, compose_product_first_video, parse_media_urls, generate_free_speech, generate_profile_speech, resolve_free_voice_profile, choose_free_voice_profile, normalize_spoken_text_ptbr, public_media_url
from app.services.heygen import configured as heygen_configured, create_avatar_video, get_video as heygen_get_video, download_video as heygen_download_video, list_avatars as heygen_list_avatars, list_voices as heygen_list_voices, find_avatar_look as heygen_find_avatar_look, friendly_error as heygen_friendly_error, sanitize_spoken_text, HeyGenError
from app.services.media_store import media_url
from app.services.marketplace import MercadoLivreClient
from app.services.oauth_tokens import MercadoLivreOAuthService
from app.services.instagram import InstagramService, InstagramError, start_instagram_publisher, stop_instagram_publisher
from app.services.instagram_automation import InstagramCommentAutomation, parse_comment_events
from app.services.meta_ads import MetaAdsService, MetaAdsError
from app.services.tiktok import TikTokService, TikTokError
from app.services.zavomi_site import configured as zavomi_site_configured, publish_catalog, publish_catalog_background, product_payload, set_site_flag, site_flags, source_metadata, save_source_metadata, refresh_product_from_source, refresh_all_site_products
from app.services.discovery_jobs import active_job, job_payload, latest_job, start_job
from app.services.social_content import build_instagram_caption, build_tiktok_caption, caption_issues, tiktok_caption_issues, naturalize_title
from app.services.affiliate_links import resolve_affiliate_link
from app.workers.discovery_worker import start_embedded_worker, stop_embedded_worker
from app.services.initial_catalog import start_initial_catalog_bootstrap, stop_initial_catalog_bootstrap, catalog_status
from app.workers.production_worker import start_production_worker, stop_production_worker
from app.workers.zavomi_site_worker import start_zavomi_site_worker, stop_zavomi_site_worker
from app.workers.product_enrichment_worker import start_product_enrichment_worker, stop_product_enrichment_worker

BASE_DIR = Path(__file__).resolve().parent
TIKTOK_VERIFICATION_DIR = Path("/tmp/agente-ia-achadinhos-verification")
logger = logging.getLogger(__name__)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

class _SecretRedactionFilter(logging.Filter):
    _pattern = re.compile(r"(?i)(access_token|client_secret|appsecret_proof)=([^&\s]+)")
    def filter(self, record):
        try:
            record.msg = self._pattern.sub(r"\1=[REDACTED]", str(record.msg))
            if record.args:
                record.args = tuple(self._pattern.sub(r"\1=[REDACTED]", str(x)) for x in record.args) if isinstance(record.args, tuple) else record.args
        except Exception:
            pass
        return True

logging.getLogger().addFilter(_SecretRedactionFilter())



def _manifest_dict(raw: str | None) -> dict:
    try:
        value = json.loads(raw or "{}")
        return value if isinstance(value, dict) else {}
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}


def _finish_heygen_production(production_id: int, remote_video_url: str) -> None:
    """Baixa e monta o vídeo após a resposta HTTP, evitando timeout/502 no Render."""
    db = SessionLocal()
    try:
        production = db.get(Production, production_id)
        if not production or production.status in {"revisao", "aprovado"}:
            return
        production.status = "montando"
        production.error = ""
        db.commit()

        content = heygen_download_video(remote_video_url)
        folder = storage_root() / "productions" / str(production.id)
        folder.mkdir(parents=True, exist_ok=True)
        presenter_clip = folder / "heygen_presenter.mp4"
        presenter_clip.write_bytes(content)

        media = parse_media_urls(production.script.product.media_urls)
        if len(media) < 2:
            raise ValueError("As fotos originais do produto não estão cadastradas. Atualize o anúncio antes da montagem final.")

        target = folder / "product_first_video.mp4"
        product = production.script.product
        compose_product_first_video(
            media, presenter_clip, target, production.script.duration_seconds,
            production.script.hook, production.script.call_to_action,
            product_title=product.title,
            on_screen_text=production.script.on_screen_text,
            price=product.price,
            rating=product.rating,
            review_count=product.review_count,
            sold_quantity=product.sold_quantity,
        )
        relative = target.relative_to(storage_root()).as_posix()
        production.video_path = str(target)
        production.video_url = public_media_url(relative)
        production.status = "revisao"
        production.error = ""
        manifest = _manifest_dict(production.source_manifest)
        manifest.update({"heygen_video_url": remote_video_url, "assembly": "completed", "visual_mode": "scene_editor_v2", "presenter_usage": "audio_only", "brand": "Zavomi", "quality_gate": "product_first"})
        production.source_manifest = json.dumps(manifest, ensure_ascii=False)
        db.commit()
    except Exception as exc:
        logger.exception("Falha na montagem assíncrona da produção %s", production_id)
        try:
            production = db.get(Production, production_id)
            if production:
                production.status = "falhou"
                production.error = str(exc)[:2000]
                db.commit()
        except Exception:
            db.rollback()
    finally:
        db.close()

def sync_product_listing_content(product: Product, db: Session) -> tuple[int, bool]:
    """Atualiza mídia e tenta completar também métricas comerciais verificáveis.

    A coleta é tolerante a bloqueios: cada fonte apenas complementa campos vazios
    e nunca zera dados previamente confirmados. Reviews são tentados novamente
    *depois* que um ITEM_ID real é resolvido pela página pública/ofertas do catálogo.
    """
    client = MercadoLivreClient(db=db)
    meta = source_metadata(product)
    source_link = str(meta.get("listing_url") or product.affiliate_url or "").strip()
    resolved_link = source_link
    catalog_product: dict = {}
    public: dict = {}
    public_snapshots: list[dict] = []
    try:
        first_public = client.public_product_snapshot(source_link)
        if first_public:
            public_snapshots.append(first_public)
            resolved_link = str(first_public.get("permalink") or source_link).strip()
    except Exception:
        pass

    import re
    from urllib.parse import urlparse
    catalog_id = str(meta.get("catalog_product_id") or "").strip().upper()
    match = re.search(r"/p/(MLB\d+)(?:[/?#]|$)", urlparse(resolved_link).path, flags=re.I)
    if match:
        catalog_id = catalog_id or match.group(1).upper()
        try:
            catalog_product = client.product_detail(match.group(1).upper())
        except Exception:
            catalog_product = {}

    # Mesmo quando o link original aponta para uma oferta, consulta também a
    # PDP de catálogo conhecida nos metadados. Ela frequentemente concentra as
    # avaliações/opiniões agregadas do produto.
    if catalog_id:
        try:
            catalog_public = client.public_product_snapshot(client.catalog_product_url(catalog_id))
            if catalog_public:
                public_snapshots.append(catalog_public)
        except Exception:
            pass
    public = client.merge_public_snapshots(*public_snapshots) if public_snapshots else {}

    # Resolve uma pequena lista de ITEM_IDs reais. Isso é essencial porque
    # /reviews/item/{ITEM_ID} não aceita apenas o id da página de catálogo.
    item_ids: list[str] = []
    for value in (meta.get("item_id"), product.external_product_id, public.get("item_id")):
        value = str(value or "").strip().upper()
        if re.fullmatch(r"MLB\d+", value) and value not in item_ids:
            item_ids.append(value)
    offer_rows: list[dict] = []
    if catalog_id:
        try:
            offer_rows = client.product_offers(catalog_id, limit=5)
        except Exception:
            offer_rows = []
        for row in offer_rows:
            value = str((row or {}).get("item_id") or "").strip().upper()
            if re.fullmatch(r"MLB\d+", value) and value not in item_ids:
                item_ids.append(value)

    if item_ids:
        meta["item_id"] = item_ids[0]
        product.external_product_id = item_ids[0]
    if catalog_id:
        meta["catalog_product_id"] = catalog_id

    assets = client.listing_media_and_description(
        link=resolved_link, catalog_product=catalog_product
    )
    pictures = [str(url).strip() for url in assets.get("pictures") or [] if str(url).strip()]
    description = str(assets.get("description") or "").strip()
    changed = False
    if pictures:
        value = "\n".join(pictures)
        if product.media_urls != value:
            product.media_urls = value
            changed = True
        if len(pictures) >= 2 and product.media_license == "origem_nao_confirmada":
            product.media_license = "oficial_marketplace"
            changed = True
    if description and product.original_description != description:
        product.original_description = description
        changed = True

    # Preço atual: a PDP pública visível ao comprador é autoritativa mesmo
    # quando já existe um preço antigo no banco. Antes só atualizávamos se o
    # campo estivesse vazio, deixando preços incorretos/stale indefinidamente.
    public_price = float(public.get("price") or 0) if public else 0
    if public_price >= 1:
        if abs(float(product.price or 0) - public_price) > 0.009:
            product.price = public_price
            changed = True
        meta["price_source"] = "public_product_page_current"
        meta["price_confirmed"] = True
        meta["price_scope"] = "same_public_page"
    elif item_ids:
        price_data = client.item_sale_prices(item_ids[0])
        if float(price_data.get("price") or 0) >= 1:
            candidate_price = float(price_data["price"])
            if product.price < 1:
                product.price = candidate_price
                changed = True
            meta["price_source"] = price_data.get("price_source") or "price_api"
            original = price_data.get("original_price")
            if original and float(original) > product.price:
                product.original_price = float(original)
                meta["original_price_source"] = price_data.get("original_price_source") or "price_api"
    if (not product.original_price or product.original_price <= product.price) and public:
        original = float(public.get("original_price") or 0)
        if original > product.price >= 1:
            product.original_price = original
            meta["original_price_source"] = "public_page"
            changed = True

    # Segunda tentativa específica de reviews depois de resolver ITEM_ID real.
    # Tenta algumas ofertas do mesmo produto porque uma publicação pode não
    # carregar opiniões, enquanto a combinação item + catalog_product_id retorna.
    if product.rating <= 0 or product.review_count <= 0:
        public_rating = float(public.get("rating") or 0) if public else 0
        public_reviews = int(public.get("reviews_count") or 0) if public else 0
        if public_rating > 0:
            product.rating = public_rating
            meta["rating_source"] = "public_page"
            changed = True
        if public_reviews > 0:
            product.review_count = public_reviews
            meta["review_count_source"] = "public_page"
            changed = True
        if product.rating <= 0 or product.review_count <= 0:
            for item_id in item_ids[:5]:
                review_payload = client.item_reviews(item_id, catalog_id)
                rating, total, levels = client.review_metrics(review_payload)
                if rating > 0:
                    product.rating = rating
                    meta["rating_source"] = "reviews_api"
                    changed = True
                if total > 0:
                    product.review_count = total
                    meta["review_count_source"] = "reviews_api"
                    meta["rating_levels"] = levels
                    changed = True
                if product.rating > 0 and product.review_count > 0:
                    meta["reviews_item_id"] = item_id
                    break

    # Vendas: usa apenas número explicitamente exposto por fonte permitida.
    # Não converte posição no ranking em quantidade vendida.
    if product.sold_quantity <= 0:
        sold = int(client._sold_reference(public.get("sold_quantity"))) if public else 0
        sold_source = "public_page" if sold > 0 else ""
        if sold <= 0:
            for row in offer_rows:
                sold = int(client._sold_reference((row or {}).get("sold_quantity") or (row or {}).get("sold_quantity_range")))
                if sold > 0:
                    sold_source = "catalog_competition_api"
                    break
        if sold > 0:
            product.sold_quantity = sold
            meta["sold_quantity_source"] = sold_source
            meta["sold_quantity_type"] = "public_minimum" if bool(public.get("sold_quantity_is_minimum")) else "public_reference"
            meta["sold_quantity_display"] = str(public.get("sold_quantity_display") or "").strip()
            meta["sold_quantity_is_minimum"] = bool(public.get("sold_quantity_is_minimum"))
            changed = True

    # Disponibilidade pública explícita complementa, mas nunca apaga uma
    # confirmação positiva anterior por ausência de dado.
    if public.get("availability_confirmed") and public.get("status") == "active" and not product.stock_available:
        product.stock_available = True
        meta["stock_source"] = "public_page"
        changed = True

    # Link afiliado: tenta mapa/API configurados e preserva pendência separada.
    affiliate = resolve_affiliate_link(
        listing_url=resolved_link or source_link,
        item_id=item_ids[0] if item_ids else "",
        catalog_product_id=catalog_id,
        existing_url=str(product.affiliate_url or ""),
        existing_confirmed=bool(meta.get("affiliate_link_confirmed")),
    )
    meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
    if affiliate.confirmed and affiliate.url:
        if product.affiliate_url != affiliate.url:
            product.affiliate_url = affiliate.url
            changed = True
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_source"] = affiliate.source
        meta["affiliate_link_error"] = ""
    else:
        meta["affiliate_link_confirmed"] = bool(meta.get("affiliate_link_confirmed"))
        meta["affiliate_link_error"] = affiliate.error

    meta["listing_url"] = resolved_link or source_link
    meta["metrics_refreshed_at"] = datetime.now(timezone.utc).isoformat()
    save_source_metadata(product, meta)
    db.add(product)
    db.commit()
    db.refresh(product)
    return len(pictures), bool(description)


def ensure_production_provider_columns() -> None:
    required = {
        "provider": "VARCHAR(30) DEFAULT 'local'",
        "external_job_id": "VARCHAR(180) DEFAULT ''",
    }
    existing = {c["name"] for c in inspect(engine).get_columns("productions")}
    with engine.begin() as conn:
        for name, sql_type in required.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE productions ADD COLUMN {name} {sql_type}"))



def ensure_product_media_columns() -> None:
    required = {
        "original_description": "TEXT DEFAULT ''",
        "media_urls": "TEXT DEFAULT ''",
        "external_product_id": "VARCHAR(120) DEFAULT ''",
        "monthly_sold_quantity": "INTEGER DEFAULT 0",
        "trend_score": "FLOAT DEFAULT 0",
        "source_metadata_json": "TEXT DEFAULT '{}'",
    }
    existing = {c["name"] for c in inspect(engine).get_columns("products")}
    with engine.begin() as conn:
        for name, sql_type in required.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE products ADD COLUMN {name} {sql_type}"))


def ensure_discovery_job_columns() -> None:
    required = {
        "source": "VARCHAR(30) DEFAULT 'mercado_livre'",
        "filters_json": "TEXT DEFAULT '{}'",
    }
    existing = {c["name"] for c in inspect(engine).get_columns("discovery_jobs")}
    with engine.begin() as conn:
        for name, sql_type in required.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE discovery_jobs ADD COLUMN {name} {sql_type}"))

def ensure_publication_columns() -> None:
    required = {"scheduled_at": "TIMESTAMP NULL", "published_at": "TIMESTAMP NULL"}
    existing = {c["name"] for c in inspect(engine).get_columns("publications")}
    with engine.begin() as conn:
        for name, sql_type in required.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE publications ADD COLUMN {name} {sql_type}"))


def ensure_script_profile_columns() -> None:
    required = {
        "production_engine": "VARCHAR(30) DEFAULT 'free_editor'",
        "presenter_type": "VARCHAR(30) DEFAULT 'realista'",
        "presenter_gender": "VARCHAR(30) DEFAULT 'automatico'",
        "presenter_age": "VARCHAR(30) DEFAULT 'jovem'",
        "presenter_energy": "VARCHAR(30) DEFAULT 'alegre'",
        "presenter_style": "VARCHAR(40) DEFAULT 'creator'",
        "voice": "VARCHAR(30) DEFAULT 'coral'",
        "voice_instructions": "TEXT DEFAULT ''",
        "variation_index": "INTEGER DEFAULT 0",
        "writer_engine": "VARCHAR(30) DEFAULT 'free_ai'",
        "creativity_level": "VARCHAR(30) DEFAULT 'equilibrado'",
        "target_platforms": "VARCHAR(40) DEFAULT 'all'",
        "heygen_avatar_id": "VARCHAR(180) DEFAULT ''",
        "heygen_avatar_name": "VARCHAR(180) DEFAULT ''",
        "heygen_avatar_preview_url": "TEXT DEFAULT ''",
        "heygen_voice_id": "VARCHAR(180) DEFAULT ''",
        "heygen_voice_name": "VARCHAR(180) DEFAULT ''",
        "heygen_voice_preview_url": "TEXT DEFAULT ''",
        "selected_media_urls": "TEXT DEFAULT ''",
    }
    existing = {c["name"] for c in inspect(engine).get_columns("scripts")}
    with engine.begin() as conn:
        for name, sql_type in required.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE scripts ADD COLUMN {name} {sql_type}"))


def ensure_instagram_comment_columns() -> None:
    required = {
        "attempts": "INTEGER DEFAULT 0",
        "next_attempt_at": "TIMESTAMP NULL",
        "last_attempt_at": "TIMESTAMP NULL",
    }
    existing = {c["name"] for c in inspect(engine).get_columns("instagram_comment_events")}
    with engine.begin() as conn:
        for name, sql_type in required.items():
            if name not in existing:
                conn.execute(text(f"ALTER TABLE instagram_comment_events ADD COLUMN {name} {sql_type}"))

@asynccontextmanager
async def lifespan(_: FastAPI):
    _materialize_tiktok_verification_file()
    Base.metadata.create_all(bind=engine)
    ensure_script_profile_columns()
    ensure_production_provider_columns()
    ensure_product_media_columns()
    ensure_discovery_job_columns()
    ensure_publication_columns()
    ensure_instagram_comment_columns()
    # Compatível com o serviço Render já existente: o processador de jobs
    # inicia dentro do próprio serviço web e consome a fila persistida.
    db = SessionLocal()
    try:
        db.execute(
            update(DiscoveryJob)
            .where(DiscoveryJob.status == "running")
            .values(status="queued", stage="Retomando após reinicialização", progress=0, error="")
        )
        db.commit()
    finally:
        db.close()
    start_embedded_worker()
    start_production_worker()
    start_instagram_publisher()
    start_zavomi_site_worker()
    start_product_enrichment_worker()
    start_initial_catalog_bootstrap()
    try:
        yield
    finally:
        stop_initial_catalog_bootstrap()
        stop_product_enrichment_worker()
        stop_zavomi_site_worker()
        stop_instagram_publisher()
        stop_production_worker()
        stop_embedded_worker()


app = FastAPI(
    title=settings.app_name,
    version="1.0.114",
    description="Painel privado do agente de IA para vendas de achadinhos por afiliação.",
    docs_url="/docs" if settings.enable_api_docs else None,
    redoc_url=None,
    openapi_url="/openapi.json" if settings.enable_api_docs else None,
    lifespan=lifespan,
)
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.session_secret,
    max_age=settings.session_max_age_seconds,
    same_site="lax",
    https_only=settings.app_env == "production",
)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")
app.include_router(router, prefix="/api")


@app.get("/termos-de-servico", response_class=HTMLResponse)
def terms_of_service(request: Request):
    return templates.TemplateResponse("legal/terms.html", {"request": request, "contact_email": settings.privacy_contact_email})


@app.get("/politica-de-privacidade", response_class=HTMLResponse)
def privacy_policy(request: Request):
    return templates.TemplateResponse("legal/privacy.html", {"request": request, "contact_email": settings.privacy_contact_email})


@app.get("/termos", response_class=HTMLResponse, include_in_schema=False)
def terms_of_service_short(request: Request):
    return terms_of_service(request)


@app.get("/privacidade", response_class=HTMLResponse, include_in_schema=False)
def privacy_policy_short(request: Request):
    return privacy_policy(request)

@app.get("/exclusao-de-dados", response_class=HTMLResponse)
def data_deletion_page(request: Request):
    return templates.TemplateResponse("legal/data_deletion.html", {"request": request, "contact_email": settings.privacy_contact_email, "confirmation": None})

@app.post("/exclusao-de-dados", response_class=HTMLResponse)
def data_deletion_request(request: Request, instagram_username: str = Form(default=""), db: Session = Depends(get_db)):
    code = secrets.token_urlsafe(12)
    username = instagram_username.strip().lstrip("@")
    db.add(DataDeletionRequest(confirmation_code=code, instagram_username=username, status="recebida"))
    db.commit()
    logger.info("Solicitação de exclusão registrada código=%s username=%s", code, username[:80])
    return templates.TemplateResponse("legal/data_deletion.html", {"request": request, "contact_email": settings.privacy_contact_email, "confirmation": code})

@app.get("/app-review", response_class=HTMLResponse)
def app_review_guide(request: Request):
    return templates.TemplateResponse("legal/app_review.html", {"request": request, "live_mode": settings.meta_app_live_mode, "base_url": settings.public_base_url})

@app.get("/health")
def public_health() -> dict[str, str]:
    return {"status": "ok", "version": "1.0.95", "database": "persistent" if not settings.database_url.startswith("sqlite") else "sqlite"}


def _safe_tiktok_verification_path(filename: str | None, content: str | None) -> Path | None:
    configured = (filename or "").strip()
    expected = Path(configured).name
    if (
        not configured
        or configured != expected
        or not (content or "").strip()
        or Path(expected).suffix.lower() != ".txt"
    ):
        return None
    return TIKTOK_VERIFICATION_DIR / expected


def _tiktok_verification_specs() -> dict[str, tuple[Path, str]]:
    specs: dict[str, tuple[Path, str]] = {}
    # Sempre inclui as três verificações atuais. Variáveis legadas do Render
    # continuam aceitas, mas não podem mais ocultar os arquivos atuais.
    pairs = [
        (settings.tiktok_terms_verification_filename, settings.tiktok_terms_verification_content),
        (settings.tiktok_privacy_verification_filename, settings.tiktok_privacy_verification_content),
        (settings.tiktok_root_verification_filename, settings.tiktok_root_verification_content),
    ]
    if settings.tiktok_url_verification_content:
        pairs.append((settings.tiktok_url_verification_filename, settings.tiktok_url_verification_content))
    for filename, content in pairs:
        target = _safe_tiktok_verification_path(filename, content)
        if target is not None:
            specs[target.name] = (target, str(content).strip())
    return specs


def _materialize_tiktok_verification_files() -> dict[str, tuple[Path, str]]:
    """Cria fisicamente todas as assinaturas no disco efêmero do Render."""
    specs = _tiktok_verification_specs()
    if not specs:
        logger.warning("Arquivos de verificação do TikTok não configurados")
        return specs
    TIKTOK_VERIFICATION_DIR.mkdir(parents=True, exist_ok=True)
    for old_file in TIKTOK_VERIFICATION_DIR.glob("*.txt"):
        if old_file.name not in specs:
            old_file.unlink(missing_ok=True)
    for target, content in specs.values():
        target.write_text(content + "\n", encoding="utf-8")
    return specs


def _materialize_tiktok_verification_file() -> Path | None:
    """Compatibilidade com testes e instalações da assinatura única anterior."""
    specs = _materialize_tiktok_verification_files()
    legacy_name = (settings.tiktok_url_verification_filename or "").strip()
    if settings.tiktok_url_verification_content and legacy_name in specs:
        return specs[legacy_name][0]
    return next(iter(specs.values()))[0] if specs else None


def _tiktok_verification_file_response(verification_filename: str, *, head_only: bool = False) -> Response:
    specs = _tiktok_verification_specs()
    spec = specs.get(verification_filename)
    if spec is None or Path(verification_filename).name != verification_filename:
        raise HTTPException(status_code=404, detail="Arquivo de verificação não configurado")
    target, _ = spec
    if not target.is_file():
        _materialize_tiktok_verification_files()
    if not target.is_file():
        raise HTTPException(status_code=404, detail="Arquivo de verificação indisponível")
    headers = {
        "Cache-Control": "no-store, max-age=0",
        "X-Content-Type-Options": "nosniff",
    }
    if head_only:
        return Response(status_code=200, media_type="text/plain; charset=utf-8", headers=headers)
    return FileResponse(path=target, media_type="text/plain; charset=utf-8", filename=None, headers=headers)


# URLs legais atuais, usadas no formulário do TikTok.
@app.get("/termos/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_terms_short(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename)


@app.head("/termos/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_terms_short_head(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename, head_only=True)


@app.get("/privacidade/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_privacy_short(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename)


@app.head("/privacidade/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_privacy_short_head(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename, head_only=True)


# Rotas legais anteriores preservadas para não quebrar links já publicados.
@app.get("/termos-de-servico/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_terms(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename)


@app.head("/termos-de-servico/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_terms_head(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename, head_only=True)


@app.get("/politica-de-privacidade/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_privacy(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename)


@app.head("/politica-de-privacidade/{verification_filename}", include_in_schema=False)
def tiktok_url_verification_under_privacy_head(verification_filename: str):
    return _tiktok_verification_file_response(verification_filename, head_only=True)


# Verificação do prefixo raiz usado como Web/Desktop URL no TikTok.
@app.get("/tiktokIpPyrWx7yFvNU8TwOPA48mxqauCSxRZL.txt", include_in_schema=False)
def tiktok_url_verification_at_root():
    return _tiktok_verification_file_response(settings.tiktok_root_verification_filename)


@app.head("/tiktokIpPyrWx7yFvNU8TwOPA48mxqauCSxRZL.txt", include_in_schema=False)
def tiktok_url_verification_at_root_head():
    return _tiktok_verification_file_response(settings.tiktok_root_verification_filename, head_only=True)


@app.head("/")
def root_head():
    return HTMLResponse(content="", status_code=200)


@app.get("/webhooks/instagram")
def instagram_webhook_verify(request: Request):
    mode = request.query_params.get("hub.mode")
    token = request.query_params.get("hub.verify_token")
    challenge = request.query_params.get("hub.challenge")
    if mode == "subscribe" and token and secrets.compare_digest(token, settings.instagram_webhook_verify_token):
        return Response(content=str(challenge or ""), media_type="text/plain")
    raise HTTPException(status_code=403, detail="Token de verificação inválido")


@app.post("/webhooks/instagram")
async def instagram_webhook_receive(request: Request):
    raw = await request.body()
    signature = request.headers.get("x-hub-signature-256", "")
    if settings.instagram_webhook_require_signature and settings.meta_app_secret:
        expected = "sha256=" + hmac.new(settings.meta_app_secret.encode(), raw, hashlib.sha256).hexdigest()
        if not signature or not secrets.compare_digest(signature, expected):
            logger.warning("Webhook Instagram rejeitado: assinatura inválida ou ausente")
            raise HTTPException(status_code=401, detail="Assinatura do webhook inválida")
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        logger.warning("Webhook Instagram: JSON inválido")
        raise HTTPException(status_code=400, detail="JSON inválido")
    events = parse_comment_events(payload) if isinstance(payload, dict) else []
    stored = 0
    if settings.instagram_comment_automation_enabled:
        db = SessionLocal()
        try:
            automation = InstagramCommentAutomation()
            for data in events:
                automation.enqueue(db, data)
                stored += 1
        finally:
            db.close()
    logger.info("Webhook Instagram aceito fields=comments normalized=%s stored=%s", len(events), stored)
    return {"received": True, "comment_events": len(events), "persisted": stored}


@app.post("/webhooks/mercadolivre")
async def mercado_livre_webhook(request: Request):
    """Recebe notificações sem bloquear o Mercado Livre.

    A rota confirma recebimento com 200 e registra somente metadados não
    sensíveis. O processamento assíncrono de cada tópico será implementado em
    worker próprio; nunca registramos tokens nem o corpo integral.
    """
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    if isinstance(payload, dict):
        logger.info(
            "Webhook Mercado Livre recebido topic=%s resource=%s user_id=%s",
            str(payload.get("topic") or "")[:80],
            str(payload.get("resource") or "")[:180],
            str(payload.get("user_id") or "")[:40],
        )
    return {"received": True}


def require_page_login(request: Request):
    if not is_logged_in(request):
        return RedirectResponse(url="/login", status_code=303)
    return None


def template_context(request: Request, **extra):
    return {
        "request": request,
        "username": request.session.get("username", "Administrador"),
        "csrf_token": csrf_token(request),
        "insecure_defaults": settings.insecure_defaults,
        "action_message": request.session.pop("action_message", None),
        "action_error": request.session.pop("action_error", None),
        **extra,
    }


def number(raw: str | None, default: float = 0) -> float:
    """Converte números digitados em padrão brasileiro ou internacional.

    Aceita exemplos como ``R$ 1.234,56``, ``1234,56``, ``1234.56`` e
    ``22%``. Caracteres de moeda e espaços são ignorados com segurança.
    """
    if raw is None or raw.strip() == "":
        return default
    import re

    text = re.sub(r"[^0-9,.-]", "", raw.strip())
    if not text or text in {"-", ".", ","}:
        return default
    if "," in text:
        # Padrão brasileiro: pontos são milhares e vírgula é decimal.
        text = text.replace(".", "").replace(",", ".")
    elif text.count(".") > 1:
        # Ex.: 1.234.567 -> inteiro com separadores de milhar.
        text = text.replace(".", "")
    return float(text)


def integer(raw: str | None, default: int = 0) -> int:
    """Converte inteiros com separadores visuais: 20.000, 20 000 etc."""
    if raw is None or raw.strip() == "":
        return default
    import re

    digits = re.sub(r"[^0-9-]", "", raw.strip())
    if not digits or digits == "-":
        return default
    return int(digits)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if is_logged_in(request):
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"error": None, "insecure_defaults": settings.insecure_defaults},
    )


@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if not credentials_valid(username.strip(), password):
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"error": "Usuário ou senha incorretos.", "insecure_defaults": settings.insecure_defaults},
            status_code=401,
        )
    request.session.clear()
    request.session["authenticated"] = True
    request.session["username"] = username.strip()
    csrf_token(request)
    return RedirectResponse(url="/", status_code=303)


@app.post("/logout")
def logout(request: Request, csrf: str = Form(...)):
    validate_csrf(request, csrf)
    request.session.clear()
    return RedirectResponse(url="/login", status_code=303)


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    product_count = db.scalar(select(func.count(Product.id))) or 0
    script_count = db.scalar(select(func.count(Script.id))) or 0
    approval_count = db.scalar(select(func.count(Product.id)).where(Product.status.in_(("em_analise", "pre_selecionado")))) or 0
    approved_count = db.scalar(select(func.count(Product.id)).where(Product.status.in_(("aprovado", "aprovado_comercial", "pronto_publicacao")))) or 0
    recent_products = db.scalars(select(Product).order_by(Product.created_at.desc()).limit(5)).all()
    site_product_count = sum(1 for p in db.scalars(select(Product)).all() if product_payload(p))
    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context=template_context(
            request,
            product_count=product_count,
            script_count=script_count,
            approval_count=approval_count,
            approved_count=approved_count,
            recent_products=recent_products,
            site_product_count=site_product_count,
        ),
    )


@app.get("/catalogo-inicial", response_class=HTMLResponse)
def initial_catalog_page(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    return templates.TemplateResponse(
        request=request, name="initial_catalog.html",
        context=template_context(request, catalog=catalog_status(db), categories=[item.value for item in ProductCategory]),
    )


@app.post("/catalogo-inicial/iniciar")
def initial_catalog_start(request: Request, csrf: str = Form(...)):
    validate_csrf(request, csrf)
    if not is_logged_in(request):
        return RedirectResponse(url="/login", status_code=303)
    started = start_initial_catalog_bootstrap(force=True)
    request.session["action_message"] = "Carga inicial iniciada." if started else "A carga inicial já está em execução."
    return RedirectResponse(url="/catalogo-inicial", status_code=303)


@app.post("/catalogo-inicial/pausar")
def initial_catalog_pause(request: Request, csrf: str = Form(...)):
    validate_csrf(request, csrf)
    if not is_logged_in(request):
        return RedirectResponse(url="/login", status_code=303)
    stop_initial_catalog_bootstrap()
    request.session["action_message"] = "Solicitação de pausa enviada."
    return RedirectResponse(url="/catalogo-inicial", status_code=303)


@app.get("/catalogo-inicial/status")
def initial_catalog_status(request: Request, db: Session = Depends(get_db)):
    if not is_logged_in(request):
        raise HTTPException(status_code=401)
    data = catalog_status(db)
    for key in ("started_at", "finished_at"):
        if data.get(key):
            data[key] = data[key].isoformat()
    return JSONResponse(data)


@app.get("/discovery", response_class=HTMLResponse)
def discovery_page(request: Request, source: str = "mercado_livre", db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    if source not in {"mercado_livre", "tiktok_shop", "all"}:
        source = "mercado_livre"
    client = MercadoLivreClient(db=db)
    source_filter = None if source == "all" else source
    base_product_query = select(func.count(Product.id))
    if source_filter:
        base_product_query = base_product_query.where(Product.marketplace == source_filter)
    product_count = db.scalar(base_product_query) or 0
    qualified_statuses = ("aprovado", "aprovado_comercial", "pronto_publicacao")
    def count_status(statuses):
        query = select(func.count(Product.id))
        if isinstance(statuses, tuple):
            query = query.where(Product.status.in_(statuses))
        else:
            query = query.where(Product.status == statuses)
        if source_filter:
            query = query.where(Product.marketplace == source_filter)
        return db.scalar(query) or 0
    qualified_count = count_status(qualified_statuses)
    rejected_count = count_status("reprovado")
    preselected_count = count_status("pre_selecionado")
    pre_query = select(Product).where(Product.status == "pre_selecionado")
    if source_filter:
        pre_query = pre_query.where(Product.marketplace == source_filter)
    preselected_products = db.scalars(pre_query.order_by(Product.score.desc(), Product.id.desc()).limit(25)).all()
    media_count = count_status("aprovado_comercial")
    script_count = db.scalar(select(func.count(Script.id)).join(Product).where(Product.marketplace == source_filter)) if source_filter else db.scalar(select(func.count(Script.id)))
    top_query = select(Product).where(Product.score >= 65, Product.status.in_(qualified_statuses))
    if source_filter:
        top_query = top_query.where(Product.marketplace == source_filter)
    top_products = db.scalars(top_query.order_by(Product.score.desc()).limit(20)).all()
    oauth = MercadoLivreOAuthService()
    connection = oauth.connection_status(db)
    job_source = "tiktok_shop" if source == "tiktok_shop" else "mercado_livre"
    current_job = active_job(db, job_source) or db.scalar(select(DiscoveryJob).where(DiscoveryJob.source == job_source).order_by(DiscoveryJob.id.desc()).limit(1))
    current_job_data = job_payload(current_job)
    result = current_job_data.get("result") or {}
    return templates.TemplateResponse(
        request=request,
        name="discovery.html",
        context=template_context(
            request,
            source=source,
            configured=client.configured,
            oauth_configured=oauth.configured,
            connection=connection,
            tiktok_shop_configured=settings.tiktok_shop_api_configured,
            oauth_message=request.session.pop("oauth_message", None),
            oauth_error=request.session.pop("oauth_error", None),
            discovery_message=(current_job_data.get("message") if current_job_data.get("status") == "completed" else None),
            discovery_error=(current_job_data.get("error") or current_job_data.get("message") if current_job_data.get("status") == "failed" else None),
            discovery_warnings=(result.get("warnings") or [])[:6],
            discovery_infos=(result.get("infos") or [])[:6],
            discovery_stats=result.get("stats") or {},
            discovery_job=current_job_data,
            product_count=product_count, qualified_count=qualified_count, rejected_count=rejected_count,
            preselected_count=preselected_count, preselected_products=preselected_products, media_count=media_count,
            script_count=script_count or 0, top_products=top_products,
            tiktok_defaults={
                "min_commission_pct": settings.tiktok_shop_default_min_commission_pct,
                "min_monthly_sales": settings.tiktok_shop_default_min_monthly_sales,
                "min_stock": settings.tiktok_shop_default_min_stock,
            },
        ),
    )


@app.get("/oauth/mercadolivre/connect")
def mercado_livre_connect(request: Request):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    oauth = MercadoLivreOAuthService()
    if not oauth.configured:
        request.session["oauth_error"] = "Cadastre Client ID, Client Secret e Redirect URI no Render."
        return RedirectResponse(url="/discovery", status_code=303)

    state = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("utf-8")).digest()).rstrip(b"=").decode("ascii")
    request.session["ml_oauth_state"] = state
    request.session["ml_code_verifier"] = verifier
    return RedirectResponse(url=oauth.authorization_url(state, challenge), status_code=302)


@app.get("/oauth/mercadolivre/callback")
def mercado_livre_callback(
    request: Request,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
    db: Session = Depends(get_db),
):
    if not is_logged_in(request):
        return RedirectResponse(url="/login", status_code=303)

    expected_state = request.session.pop("ml_oauth_state", None)
    verifier = request.session.pop("ml_code_verifier", None)
    if error:
        request.session["oauth_error"] = error_description or f"Autorização recusada: {error}"
        return RedirectResponse(url="/discovery", status_code=303)
    if not code or not state or not expected_state or not secrets.compare_digest(state, expected_state):
        request.session["oauth_error"] = "Retorno OAuth inválido ou expirado. Inicie a conexão novamente."
        return RedirectResponse(url="/discovery", status_code=303)
    if not verifier:
        request.session["oauth_error"] = "Verificador PKCE ausente. Inicie a conexão novamente."
        return RedirectResponse(url="/discovery", status_code=303)

    try:
        oauth = MercadoLivreOAuthService()
        tokens = oauth.exchange_code(code, verifier)
        oauth.save_tokens(db, tokens)
    except Exception as exc:
        request.session["oauth_error"] = str(exc)[:500]
        return RedirectResponse(url="/discovery", status_code=303)

    request.session["oauth_message"] = "Mercado Livre conectado com sucesso."
    return RedirectResponse(url="/discovery", status_code=303)


@app.post("/oauth/mercadolivre/disconnect")
def mercado_livre_disconnect(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    MercadoLivreOAuthService().disconnect(db)
    request.session["oauth_message"] = "Conexão com o Mercado Livre removida."
    return RedirectResponse(url="/discovery", status_code=303)


@app.get("/discovery/run")
def discovery_run_get(request: Request):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    request.session["discovery_error"] = "Use o botão ‘Executar varredura agora’. A execução exige uma solicitação segura."
    return RedirectResponse(url="/discovery", status_code=303)


@app.post("/discovery/run")
def discovery_run(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    job, created = start_job(db, source="mercado_livre")
    if not job:
        request.session["discovery_error"] = "Não foi possível iniciar a varredura agora. Tente novamente em alguns segundos."
    elif created:
        request.session["oauth_message"] = "Varredura iniciada em segundo plano. Você pode sair desta tela e voltar depois."
    else:
        request.session["oauth_message"] = "Já existe uma varredura em andamento."
    return RedirectResponse(url="/discovery?source=mercado_livre", status_code=303)


@app.post("/discovery/tiktok/run")
def tiktok_discovery_run(
    request: Request, csrf: str = Form(...), keyword: str = Form(""), category_id: str = Form(""),
    min_commission_pct: float = Form(5.0), min_monthly_sales: int = Form(100), min_stock: int = Form(20),
    db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    filters = {
        "keyword": keyword.strip()[:120],
        "category_id": category_id.strip()[:80],
        "min_commission_pct": max(0, min(min_commission_pct, 100)),
        "min_monthly_sales": max(0, min_monthly_sales),
        "min_stock": max(0, min_stock),
    }
    job, created = start_job(db, source="tiktok_shop", filters=filters)
    request.session["oauth_message"] = "Varredura do TikTok Shop iniciada." if created else "Já existe uma varredura do TikTok Shop em andamento."
    return RedirectResponse(url="/discovery?source=tiktok_shop", status_code=303)


@app.get("/discovery/status")
def discovery_status(request: Request, source: str = "mercado_livre", db: Session = Depends(get_db)):
    if not is_logged_in(request):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    source = source if source in {"mercado_livre", "tiktok_shop"} else "mercado_livre"
    job = active_job(db, source) or db.scalar(select(DiscoveryJob).where(DiscoveryJob.source == source).order_by(DiscoveryJob.id.desc()).limit(1))
    return job_payload(job)


def _product_registration_missing(product: Product) -> list[str]:
    """Campos realmente pendentes no cadastro, sem confundir reprovação comercial com cadastro incompleto."""
    meta = source_metadata(product)
    missing: list[str] = []
    if not str(product.title or "").strip():
        missing.append("nome")
    if not str(product.category or "").strip():
        missing.append("categoria")
    if float(product.price or 0) < 1:
        missing.append("preço")
    if float(product.rating or 0) <= 0:
        missing.append("avaliação")
    listing_url = str(meta.get("listing_url") or product.affiliate_url or "").strip()
    if not listing_url.startswith("https://"):
        missing.append("link do produto")
    return missing


def _product_registration_complete(product: Product) -> bool:
    """Cadastro concluído permanece concluído mesmo se uma varredura futura reencontrar o item."""
    meta = source_metadata(product)
    if meta.get("manual_fields_protected") or meta.get("manual_completed_at"):
        return True
    if product.status in {"pronto_publicacao", "aprovado_comercial", "conteudo_pronto", "aprovado"}:
        return True
    if product.status == "pre_selecionado":
        return False
    return not _product_registration_missing(product)


def _products_page_response(
    request: Request, db: Session, *, sort: str, category: str, status: str, q: str, registration_view: str
):
    order_map = {
        "avaliacao_desc": Product.rating.desc(), "avaliacao_asc": Product.rating.asc(),
        "avaliacoes_desc": Product.review_count.desc(), "avaliacoes_asc": Product.review_count.asc(),
        "vendidos_desc": Product.sold_quantity.desc(), "vendidos_asc": Product.sold_quantity.asc(),
        "pontuacao_desc": Product.score.desc(), "pontuacao_asc": Product.score.asc(),
        "preco_desc": Product.price.desc(), "preco_asc": Product.price.asc(),
        "antigos": Product.created_at.asc(), "recentes": Product.created_at.desc(),
    }
    sort = sort if sort in order_map else "recentes"
    category = category.strip()
    status_value = status.strip()
    q = q.strip()[:120]
    query = select(Product)
    if category:
        query = query.where(Product.category == category)
    if status_value:
        query = query.where(Product.status == status_value)
    if q:
        term = f"%{q}%"
        query = query.where(or_(
            Product.title.ilike(term),
            Product.external_product_id.ilike(term),
            Product.category.ilike(term),
            Product.marketplace.ilike(term),
        ))
    candidates = list(db.scalars(query.order_by(order_map[sort], Product.id.desc())).all())
    if registration_view == "complete":
        products = [p for p in candidates if _product_registration_complete(p)]
    elif registration_view == "incomplete":
        products = [p for p in candidates if not _product_registration_complete(p)]
    else:
        products = candidates

    for product in products:
        product.registration_missing = _product_registration_missing(product)

    all_products = list(db.scalars(select(Product)).all())
    complete_count = sum(1 for p in all_products if _product_registration_complete(p))
    incomplete_count = len(all_products) - complete_count
    categories = db.scalars(select(Product.category).distinct().order_by(Product.category.asc())).all()
    statuses = db.scalars(select(Product.status).distinct().order_by(Product.status.asc())).all()
    return templates.TemplateResponse(request=request, name="products/list.html", context=template_context(
        request, products=products, selected_sort=sort, selected_category=category, selected_status=status_value, selected_q=q,
        product_categories=categories, product_statuses=statuses, registration_view=registration_view,
        complete_count=complete_count, incomplete_count=incomplete_count, total_product_count=len(all_products),
    ))


@app.get("/products", response_class=HTMLResponse)
def products_page(request: Request, sort: str = "recentes", category: str = "", status: str = "", q: str = "", db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    return _products_page_response(request, db, sort=sort, category=category, status=status, q=q, registration_view="all")


@app.get("/products/completos", response_class=HTMLResponse)
def products_complete_page(request: Request, sort: str = "recentes", category: str = "", status: str = "", q: str = "", db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    return _products_page_response(request, db, sort=sort, category=category, status=status, q=q, registration_view="complete")


@app.get("/products/incompletos", response_class=HTMLResponse)
def products_incomplete_page(request: Request, sort: str = "recentes", category: str = "", status: str = "", q: str = "", db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    return _products_page_response(request, db, sort=sort, category=category, status=status, q=q, registration_view="incomplete")


@app.get("/affiliate-links", response_class=HTMLResponse)
def affiliate_links_page(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    products = db.scalars(
        select(Product).where(Product.marketplace == "mercado_livre").order_by(Product.score.desc(), Product.id.asc())
    ).all()
    pending = []
    confirmed = []
    for product in products:
        meta = source_metadata(product)
        row = {
            "product": product,
            "listing_url": str(meta.get("listing_url") or "").strip(),
            "item_id": str(meta.get("item_id") or product.external_product_id or "").strip(),
            "catalog_product_id": str(meta.get("catalog_product_id") or "").strip(),
            "error": str(meta.get("affiliate_link_error") or "").strip(),
        }
        if meta.get("affiliate_link_confirmed") and str(product.affiliate_url or "").startswith("https://"):
            confirmed.append(row)
        elif row["listing_url"]:
            pending.append(row)
    export_lines = [f"{r['product'].id}|{r['listing_url']}" for r in pending]
    return templates.TemplateResponse(
        request=request, name="affiliate_links.html",
        context=template_context(request, pending=pending, confirmed=confirmed, export_text="\n".join(export_lines)),
    )


@app.post("/affiliate-links/import")
def affiliate_links_import(
    request: Request, csrf: str = Form(...), links_text: str = Form(""), db: Session = Depends(get_db)
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    from urllib.parse import urlparse

    def valid_affiliate_url(value: str) -> bool:
        try:
            parsed = urlparse(value.strip())
        except Exception:
            return False
        host = (parsed.hostname or "").lower()
        return parsed.scheme == "https" and (
            host == "meli.la" or host.endswith(".meli.la")
            or host == "mercadolivre.com" or host.endswith(".mercadolivre.com")
            or host == "mercadolivre.com.br" or host.endswith(".mercadolivre.com.br")
            or host == "mercadolibre.com" or host.endswith(".mercadolibre.com")
        )

    all_products = db.scalars(select(Product).where(Product.marketplace == "mercado_livre").order_by(Product.score.desc(), Product.id.asc())).all()
    pending = [p for p in all_products if not (source_metadata(p).get("affiliate_link_confirmed") and str(p.affiliate_url or "").startswith("https://"))]
    pending_by_id = {str(p.id): p for p in pending}
    pending_by_key = {}
    for p in pending:
        meta = source_metadata(p)
        for key in (meta.get("item_id"), p.external_product_id, meta.get("catalog_product_id"), meta.get("listing_url")):
            key = str(key or "").strip()
            if key:
                pending_by_key[key] = p

    raw_lines = [line.strip() for line in str(links_text or "").splitlines() if line.strip()]
    parsed_rows: list[tuple[str, str]] = []
    bare_urls: list[str] = []
    for line in raw_lines:
        if "|" in line:
            key, url = line.split("|", 1)
            parsed_rows.append((key.strip(), url.strip()))
        elif "\t" in line:
            key, url = line.split("\t", 1)
            parsed_rows.append((key.strip(), url.strip()))
        elif line.startswith("https://"):
            bare_urls.append(line)

    updated = 0
    rejected = 0
    touched: set[int] = set()
    for key, url in parsed_rows:
        product = pending_by_id.get(key) or pending_by_key.get(key)
        if not product or not valid_affiliate_url(url):
            rejected += 1
            continue
        meta = source_metadata(product)
        product.affiliate_url = url
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_source"] = "manual_official_batch"
        meta["affiliate_link_error"] = ""
        meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
        save_source_metadata(product, meta)
        db.add(product)
        touched.add(product.id)
        updated += 1

    remaining = [p for p in pending if p.id not in touched]
    for product, url in zip(remaining, bare_urls):
        if not valid_affiliate_url(url):
            rejected += 1
            continue
        meta = source_metadata(product)
        product.affiliate_url = url
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_source"] = "manual_official_batch_ordered"
        meta["affiliate_link_error"] = ""
        meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
        save_source_metadata(product, meta)
        db.add(product)
        updated += 1

    db.commit()
    request.session["action_message"] = f"{updated} links afiliados foram associados aos produtos."
    if rejected:
        request.session["action_error"] = f"{rejected} linhas não puderam ser associadas ou tinham URL inválida."
    return RedirectResponse(url="/affiliate-links", status_code=303)


@app.get("/products/new", response_class=HTMLResponse)
def new_product_page(request: Request):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    return templates.TemplateResponse(
        request=request,
        name="products/form.html",
        context=template_context(request, categories=list(ProductCategory), error=None),
    )


@app.post("/products/analyze-link")
def analyze_product_link(
    request: Request,
    csrf: str = Form(...),
    affiliate_url: str = Form(...),
    db: Session = Depends(get_db),
):
    """Resolve links curtos/afiliados sem perder o rastreamento e enriquece o produto."""
    redirect = require_page_login(request)
    if redirect:
        return JSONResponse({"ok": False, "error": "Sessão expirada"}, status_code=401)
    try:
        validate_csrf(request, csrf)
    except Exception:
        return JSONResponse({"ok": False, "error": "Sessão ou formulário inválido"}, status_code=403)

    submitted_link = str(affiliate_url or "").strip()
    link = submitted_link
    if not submitted_link:
        return JSONResponse({"ok": False, "error": "Informe o link de afiliado"}, status_code=422)

    try:
        client = MercadoLivreClient(db=db)
        snapshot: dict = {}
        official_product: dict = {}
        item: dict = {}
        warnings: list[str] = []

        # Primeiro resolve o redirecionamento do link curto. O link enviado pelo
        # usuário permanece intacto para publicação; o destino serve só à coleta.
        # Mantemos uma cópia separada da página pública porque ela representa a
        # oferta exibida ao comprador e deve prevalecer no preço atual.
        public_snapshot: dict = {}
        try:
            public = client.public_product_snapshot(link)
            public_snapshot = dict(public or {})
            snapshot = dict(public_snapshot)
        except (ValueError, MarketplaceRequestError):
            warnings.append("O link abriu, mas a página pública não pôde ser lida completamente")
        listing_url = str(snapshot.get("permalink") or submitted_link).strip()

        import re
        from urllib.parse import urlparse
        path = urlparse(listing_url).path
        catalog_match = re.search(r"/p/(MLB\d+)(?:[/?#]|$)", path, flags=re.I)
        any_match = re.search(r"(?:MLB[-_]?)?(\d{6,})", path, flags=re.I)
        catalog_id = catalog_match.group(1).upper() if catalog_match else ""
        product_id = catalog_id
        item_id = ""

        if product_id:
            try:
                official_product = client.product_detail(product_id)
                winner = client._winner_payload(official_product)
                item_id = str(client._extract_item_id(winner) or "").upper()
                rating, review_count = client._rating_and_reviews(official_product)
                snapshot = client._merge_product_data({
                    "name": official_product.get("name") or official_product.get("title") or official_product.get("family_name"),
                    "price": client._safe_float(winner.get("price") or official_product.get("price") or official_product.get("minimum_price"), 0.0),
                    "original_price": winner.get("original_price") or official_product.get("original_price"),
                    "rating": rating,
                    "reviews_count": review_count,
                    "sold_quantity": winner.get("sold_quantity") or official_product.get("sold_quantity"),
                    "status": official_product.get("status") or winner.get("status"),
                    "available_quantity": winner.get("available_quantity") or winner.get("available_quantity_range") or winner.get("stock"),
                    "availability_confirmed": any(key in winner for key in ("available_quantity", "available_quantity_range", "stock", "status")),
                    "permalink": listing_url,
                }, snapshot)
            except MarketplaceRequestError:
                warnings.append("O catálogo oficial não expôs todos os dados")
        elif any_match:
            item_id = f"MLB{any_match.group(1)}"
            try:
                item = client._item_detail_individual(item_id) or {}
                snapshot = client._merge_product_data({
                    "name": item.get("title"),
                    "price": item.get("price"),
                    "original_price": item.get("original_price"),
                    "sold_quantity": item.get("sold_quantity"),
                    "status": item.get("status"),
                    "available_quantity": item.get("available_quantity"),
                    "availability_confirmed": any(key in item for key in ("available_quantity", "status")),
                    "permalink": item.get("permalink") or listing_url,
                    "pictures": item.get("pictures") or [],
                }, snapshot)
            except Exception:
                warnings.append("A oferta individual não expôs todos os dados")

        # Avaliações têm fonte própria e são tentadas depois da resolução do item.
        if item_id:
            review_payload = client.item_reviews(item_id, catalog_id)
            review_rating, review_count, _ = client.review_metrics(review_payload)
            if review_rating > 0:
                snapshot["rating"] = review_rating
            if review_count > 0:
                snapshot["reviews_count"] = review_count

        assets = client.listing_media_and_description(link=listing_url, catalog_product=official_product)
        picture_urls = [str(url).strip() for url in assets.get("pictures") or [] if str(url).strip()]
        original_description = str(assets.get("description") or snapshot.get("description") or "").strip()
        if not picture_urls:
            picture_urls = client.picture_urls(item or official_product or snapshot, limit=24)

        title = str(snapshot.get("name") or item.get("title") or "").strip()
        if not title:
            return JSONResponse({"ok": False, "error": "Não foi possível identificar o produto desse link."}, status_code=422)

        category = client._category_from_text(title)
        # A página pública mostra o preço efetivamente exibido ao comprador.
        # Catálogo/buy-box podem retornar preço de referência ou desatualizado;
        # por isso não podem substituir silenciosamente o preço público atual.
        public_price = client._safe_float(public_snapshot.get("price"), 0.0)
        resolved_price = client._safe_float(snapshot.get("price"), 0.0)
        price = public_price if public_price >= 1 else resolved_price

        # O preço anterior só é aceito quando for maior que o preço atual. Caso
        # a API tenha retornado como "preço atual" um valor maior que o exibido
        # publicamente, ele passa a ser candidato a preço anterior.
        previous_candidates = [
            client._safe_float(public_snapshot.get("original_price"), 0.0),
            client._safe_float(snapshot.get("original_price"), 0.0),
        ]
        if public_price >= 1 and resolved_price > public_price:
            previous_candidates.append(resolved_price)
        original_price = min((v for v in previous_candidates if v > price), default=0.0)

        # Normaliza apenas formatos comprovadamente deslocados (48 -> 4,8),
        # rejeitando valores impossíveis em vez de apresentá-los ao usuário.
        rating = client._safe_float(snapshot.get("rating"), 0.0)
        if 5 < rating <= 50:
            rating = rating / 10.0
        if not 0 <= rating <= 5:
            rating = 0.0

        review_count = max(0, client._safe_int(snapshot.get("reviews_count"), 0))
        sold_quantity = max(0, client._safe_int(snapshot.get("sold_quantity"), 0))
        status_value = str(snapshot.get("status") or "").lower().strip()
        availability_confirmed = bool(snapshot.get("availability_confirmed"))
        available = bool(availability_confirmed and status_value != "inactive" and client._stock_available(snapshot.get("available_quantity")))

        if price < 1: warnings.append("Preço atual não identificado")
        if original_price <= 0: warnings.append("Preço anterior não exposto")
        if rating <= 0: warnings.append("Nota não identificada")
        if review_count <= 0: warnings.append("Número de avaliações não identificado")
        if sold_quantity <= 0: warnings.append("Quantidade vendida não identificada")
        if not availability_confirmed: warnings.append("Disponibilidade não confirmada")
        if len(picture_urls) < 2: warnings.append("Menos de duas fotos disponíveis")
        if not original_description: warnings.append("Descrição original não exposta")

        qualified = False
        if price >= 1:
            probe = ProductInput(
                title=title[:180], category=ProductCategory(category), marketplace="mercado_livre",
                price=price, rating=rating, review_count=review_count, sold_quantity=sold_quantity,
                seller_reputation=0, commission_pct=0, stock_available=available,
                affiliate_url=submitted_link, media_license="origem_nao_confirmada",
            )
            qualified = meets_commercial_gate(probe)[0]

        return JSONResponse({
            "ok": True,
            "data": {
                "title": title[:180], "category": category, "marketplace": "mercado_livre",
                "affiliate_url": submitted_link, "listing_url": listing_url,
                "price": round(price, 2) if price >= 1 else "",
                "original_price": round(original_price, 2) if original_price > 0 else "",
                "rating": round(rating, 1) if rating > 0 else "",
                "review_count": review_count if review_count > 0 else "",
                "sold_quantity": sold_quantity if sold_quantity > 0 else "",
                "seller_reputation": 0, "commission_pct": 0,
                "stock_available": available,
                "media_license": "oficial_marketplace" if len(picture_urls) >= 2 else "origem_nao_confirmada",
                "original_description": original_description,
                "media_urls": "\n".join(picture_urls),
                "notes": f"Link afiliado preservado para publicação. Anúncio resolvido para coleta: {listing_url}",
            },
            "qualified": qualified,
            "missing_fields": [label for label, missing in (
                ("preço", price < 1), ("preço anterior", original_price <= 0),
                ("avaliação", rating <= 0), ("quantidade de avaliações", review_count <= 0),
                ("vendas", sold_quantity <= 0), ("disponibilidade", not availability_confirmed),
                ("fotos", len(picture_urls) < 2), ("descrição", not original_description),
                ("comissão", True),
            ) if missing],
            "warnings": list(dict.fromkeys(warnings)),
            "message": "Link afiliado preservado e dados disponíveis preenchidos.",
        })
    except Exception:
        logger.exception("Falha inesperada ao analisar link de produto")
        return JSONResponse({"ok": False, "error": "Não foi possível analisar automaticamente. Use o preenchimento manual."}, status_code=500)


@app.post("/products/new")
def create_product(
    request: Request,
    csrf: str = Form(...),
    title: str = Form(...),
    category: str = Form(...),
    marketplace: str = Form("mercado_livre"),
    price: str = Form(...),
    original_price: str = Form(""),
    rating: str = Form("0"),
    review_count: str = Form("0"),
    sold_quantity: str = Form("0"),
    seller_reputation: str = Form("0"),
    commission_pct: str = Form("0"),
    stock_available: str | None = Form(None),
    visual_quality: str = Form("5"),
    demonstration_ease: str = Form("5"),
    novelty: str = Form("5"),
    return_risk: str = Form("5"),
    affiliate_url: str = Form(...),
    listing_url: str = Form(""),
    media_license: str = Form(...),
    original_description: str = Form(""),
    media_urls: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    try:
        input_data = ProductInput(
            title=title.strip(), category=ProductCategory(category), marketplace=marketplace,
            price=number(price), original_price=number(original_price) if original_price else None,
            rating=number(rating), review_count=integer(review_count), sold_quantity=integer(sold_quantity),
            seller_reputation=number(seller_reputation), commission_pct=number(commission_pct),
            stock_available=stock_available == "on", visual_quality=number(visual_quality),
            demonstration_ease=number(demonstration_ease), novelty=number(novelty),
            return_risk=number(return_risk), affiliate_url=affiliate_url.strip(), media_license=media_license,
        )
        result = score_product(input_data)
    except (ValueError, TypeError) as exc:
        return templates.TemplateResponse(
            request=request, name="products/form.html",
            context=template_context(request, categories=list(ProductCategory), error=f"Revise os dados: {exc}"), status_code=422,
        )
    media_ready = input_data.media_license in {"oficial_marketplace", "fabricante", "autorizado_vendedor", "licenciado_comercialmente", "produzido_por_nos"}
    product_status = "pronto_publicacao" if result.approved and media_ready else "aprovado_comercial" if result.approved else "reprovado"
    metadata = {
        "listing_url": listing_url.strip(),
        "affiliate_link_confirmed": bool(affiliate_url.strip()),
        "affiliate_link_source": "user_submitted_affiliate_link",
        "manual_fields_protected": True,
        "manual_completed_at": datetime.now(timezone.utc).isoformat(),
    }
    product = Product(
        **input_data.model_dump(mode="json"), original_description=original_description.strip(), media_urls=media_urls.strip(), notes=notes.strip(), score=result.total,
        classification=result.classification, status=product_status,
        score_reasons="\n".join(result.reasons), source_metadata_json=json.dumps(metadata, ensure_ascii=False),
    )
    db.add(product)
    db.commit()
    db.refresh(product)
    return RedirectResponse(url=f"/products/{product.id}", status_code=303)


@app.get("/products/{product_id}/complete", response_class=HTMLResponse)
def complete_product_page(product_id: int, request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    meta = source_metadata(product)
    listing_url = str(meta.get("listing_url") or product.affiliate_url or "").strip()
    affiliate = resolve_affiliate_link(
        listing_url=listing_url,
        item_id=str(meta.get("item_id") or product.external_product_id or ""),
        catalog_product_id=str(meta.get("catalog_product_id") or ""),
        existing_url=str(product.affiliate_url or ""),
        existing_confirmed=bool(meta.get("affiliate_link_confirmed")),
    )
    if affiliate.confirmed and affiliate.url != product.affiliate_url:
        product.affiliate_url = affiliate.url
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_source"] = affiliate.source
        meta["affiliate_link_error"] = ""
        meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
        save_source_metadata(product, meta)
        db.commit()
        db.refresh(product)
    elif not affiliate.confirmed:
        meta["affiliate_link_error"] = affiliate.error
        meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
        save_source_metadata(product, meta)
        db.commit()
    return templates.TemplateResponse(
        request=request,
        name="products/complete.html",
        context=template_context(request, product=product, categories=list(ProductCategory), error=None, source_meta=meta, listing_url=listing_url),
    )


@app.post("/products/{product_id}/complete")
def complete_product(
    product_id: int,
    request: Request,
    csrf: str = Form(...),
    title: str = Form(...),
    category: str = Form(...),
    price: str = Form(...),
    original_price: str = Form(""),
    rating: str = Form(...),
    review_count: str = Form(...),
    sold_quantity: str = Form("0"),
    commission_pct: str = Form("0"),
    stock_available: str | None = Form(None),
    affiliate_url: str = Form(""),
    listing_url: str = Form(""),
    media_license: str = Form("origem_nao_confirmada"),
    original_description: str = Form(""),
    media_urls: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    meta = source_metadata(product)
    submitted_listing = listing_url.strip()
    submitted_affiliate = affiliate_url.strip()
    validation_url = submitted_affiliate or submitted_listing or "https://www.mercadolivre.com.br/"
    # Se as fotos vieram do próprio Mercado Livre, não rebaixe a licença para
    # "origem não confirmada" só porque o formulário ainda traz o valor antigo.
    effective_media_license = media_license
    if (media_urls.strip() or str(product.media_urls or "").strip()) and product.marketplace == "mercado_livre":
        if media_license == "origem_nao_confirmada" and product.media_license == "oficial_marketplace":
            effective_media_license = "oficial_marketplace"
    try:
        input_data = ProductInput(
            title=title.strip(), category=ProductCategory(category), marketplace="mercado_livre",
            price=number(price), original_price=number(original_price) if original_price else None,
            rating=number(rating), review_count=integer(review_count), sold_quantity=integer(sold_quantity),
            seller_reputation=product.seller_reputation or 0, commission_pct=number(commission_pct),
            stock_available=stock_available == "on", visual_quality=product.visual_quality or 5,
            demonstration_ease=product.demonstration_ease or 5, novelty=product.novelty or 5,
            return_risk=product.return_risk or 5, affiliate_url=validation_url, media_license=effective_media_license,
        )
        result = score_product(input_data)
    except (ValueError, TypeError) as exc:
        return templates.TemplateResponse(
            request=request, name="products/complete.html",
            context=template_context(request, product=product, categories=list(ProductCategory), error=f"Revise os dados: {exc}"),
            status_code=422,
        )
    values = input_data.model_dump(mode="json")
    for key, value in values.items():
        setattr(product, key, value)
    product.affiliate_url = submitted_affiliate
    meta["listing_url"] = submitted_listing
    meta["manual_listing_url_override"] = True
    meta["manual_affiliate_url_override"] = True
    if submitted_affiliate:
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_source"] = "manual"
        meta["affiliate_link_error"] = ""
        meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
    else:
        meta["affiliate_link_confirmed"] = False
        meta["affiliate_link_source"] = "manual"
        meta["affiliate_link_error"] = "Link de afiliado removido manualmente; informe um novo endereço para publicar."
    # A partir daqui o cadastro foi explicitamente revisado pelo usuário.
    # Varreduras futuras podem atualizar métricas válidas, mas não podem zerar
    # campos, apagar mídia/descrição nem rebaixar o produto para incompleto.
    meta["manual_fields_protected"] = True
    meta["manual_completed_at"] = datetime.now(timezone.utc).isoformat()
    save_source_metadata(product, meta)
    media_ready = input_data.media_license in {"oficial_marketplace", "fabricante", "autorizado_vendedor", "licenciado_comercialmente", "produzido_por_nos"}
    product.score = result.total
    product.classification = result.classification
    links_ready = bool(submitted_listing and submitted_affiliate)
    product.status = "pronto_publicacao" if result.approved and media_ready and links_ready else "aprovado_comercial" if result.approved else "reprovado"
    product.score_reasons = "\n".join(result.reasons)
    product.original_description = original_description.strip()
    product.media_urls = media_urls.strip()
    product.notes = notes.strip()
    db.add(ProductObservation(product_id=product.id, price=input_data.price, rating=input_data.rating, review_count=input_data.review_count, sold_quantity=input_data.sold_quantity, source_rank=None, stock_available=input_data.stock_available))
    db.commit()
    return RedirectResponse(url=f"/products/{product_id}", status_code=303)


@app.post("/products/{product_id}/refresh-listing")
def refresh_product_listing(
    product_id: int,
    request: Request,
    csrf: str = Form(...),
    db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    try:
        photo_count, has_description = sync_product_listing_content(product, db)
        if photo_count >= 2 and has_description:
            request.session["product_message"] = f"Anúncio atualizado: {photo_count} fotos e descrição importadas automaticamente."
        elif photo_count:
            request.session["product_message"] = f"Foram importadas {photo_count} fotos. A descrição não foi exposta pelo Mercado Livre."
        else:
            request.session["product_error"] = "O Mercado Livre não expôs fotos suficientes para este anúncio. Confirme se o link abre uma oferta ativa."
    except Exception:
        logger.exception("Falha ao atualizar conteúdo do anúncio produto_id=%s", product_id)
        request.session["product_error"] = "Não foi possível atualizar o anúncio agora. Tente novamente em alguns instantes."
    return RedirectResponse(url=f"/products/{product_id}", status_code=303)


@app.get("/products/{product_id}", response_class=HTMLResponse)
def product_detail(product_id: int, request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    scripts = db.scalars(select(Script).where(Script.product_id == product_id).order_by(Script.created_at.desc())).all()
    meta = source_metadata(product)
    return templates.TemplateResponse(
        request=request,
        name="products/detail.html",
        context=template_context(request, product=product, scripts=scripts, source_meta=meta),
    )


@app.post("/products/{product_id}/status")
def update_product_status(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), status_value: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    if status_value not in {"aprovado", "reprovado", "pausado", "em_analise"}:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Status inválido")
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    if status_value == "aprovado":
        try:
            gate_input = product_to_input(product)
            gate_ok, gate_reason = meets_commercial_gate(gate_input)
        except Exception:
            gate_ok, gate_reason = False, "Complete os dados comerciais obrigatórios"
        if not gate_ok:
            request.session["product_error"] = gate_reason
            return RedirectResponse(url=f"/products/{product_id}/complete", status_code=303)
        media_ready = product.media_license in {"oficial_marketplace", "fabricante", "autorizado_vendedor", "licenciado_comercialmente", "produzido_por_nos"}
        product.status = "pronto_publicacao" if media_ready else "aprovado_comercial"
    else:
        product.status = status_value
    db.commit()
    if status_value in {"aprovado", "reprovado", "pausado"}:
        background_tasks.add_task(publish_catalog_background, f"status_produto_{product_id}_{status_value}")
    labels = {
        "aprovado": "Produto aprovado com sucesso.",
        "reprovado": "Produto reprovado.",
        "pausado": "Produto pausado.",
        "em_analise": "Produto reaberto para análise.",
    }
    request.session["action_message"] = labels.get(status_value, "Status atualizado.")
    return RedirectResponse(url=f"/products/{product_id}", status_code=303)


@app.post("/products/{product_id}/delete")
def delete_product(product_id: int, request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if product:
        db.delete(product)
        db.commit()
        request.session["action_message"] = "Produto excluído do catálogo."
    return RedirectResponse(url="/products", status_code=303)


@app.post("/products/delete-all")
def delete_all_products(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    """Exclui todo o catálogo local e os registros dependentes, preservando conexões e configurações."""
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)

    product_ids = list(db.scalars(select(Product.id)).all())
    if not product_ids:
        request.session["action_message"] = "O catálogo já está vazio."
        return RedirectResponse(url="/products", status_code=303)

    script_ids = list(db.scalars(select(Script.id).where(Script.product_id.in_(product_ids))).all())
    production_ids = []
    publication_ids = []
    if script_ids:
        production_ids = list(db.scalars(select(Production.id).where(Production.script_id.in_(script_ids))).all())
    if production_ids:
        publication_ids = list(db.scalars(select(Publication.id).where(Publication.production_id.in_(production_ids))).all())
        db.execute(delete(MediaAsset).where(MediaAsset.production_id.in_(production_ids)))
    if publication_ids:
        db.execute(delete(LinkClick).where(LinkClick.publication_id.in_(publication_ids)))
        db.execute(update(InstagramCommentEvent).where(InstagramCommentEvent.publication_id.in_(publication_ids)).values(publication_id=None))
        db.execute(delete(Publication).where(Publication.id.in_(publication_ids)))
    if production_ids:
        db.execute(delete(Production).where(Production.id.in_(production_ids)))
    if script_ids:
        db.execute(delete(Script).where(Script.id.in_(script_ids)))

    db.execute(delete(ProductObservation).where(ProductObservation.product_id.in_(product_ids)))
    db.execute(delete(Product).where(Product.id.in_(product_ids)))
    db.commit()
    request.session["action_message"] = f"{len(product_ids)} produtos foram excluídos do catálogo."
    return RedirectResponse(url="/products", status_code=303)


@app.get("/scripts", response_class=HTMLResponse)
def scripts_page(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    scripts = db.scalars(select(Script).order_by(Script.created_at.desc())).all()
    return templates.TemplateResponse(request=request, name="scripts/list.html", context=template_context(request, scripts=scripts))


@app.get("/products/{product_id}/scripts/new", response_class=HTMLResponse)
def new_script_page(product_id: int, request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    media_ready = product.media_license in {"oficial_marketplace", "fabricante", "autorizado_vendedor", "licenciado_comercialmente", "produzido_por_nos"}
    if product.status not in {"pronto_publicacao", "conteudo_pronto"} or not media_ready:
        request.session["action_error"] = "Confirme uma origem de mídia autorizada antes de gerar roteiro."
        return RedirectResponse(url=f"/products/{product_id}/complete", status_code=303)
    avatars: list[dict] = []
    voices: list[dict] = []
    heygen_error = None
    if heygen_configured():
        try:
            avatars = heygen_list_avatars(limit=300)
            voices = heygen_list_voices(limit=100)
        except Exception as exc:
            logger.exception("Falha ao carregar biblioteca HeyGen")
            heygen_error = heygen_friendly_error(exc)
    return templates.TemplateResponse(
        request=request,
        name="scripts/form.html",
        context=template_context(
            request,
            product=product,
            heygen_configured=heygen_configured(),
            heygen_avatars=avatars,
            heygen_voices=voices,
            heygen_error=heygen_error,
            gemini_script_configured=bool(settings.gemini_api_key),
        ),
    )


@app.post("/products/{product_id}/scripts/new")
def create_saved_script(
    product_id: int, request: Request, csrf: str = Form(...), format: str = Form("automatico"),
    duration_seconds: int = Form(40), production_engine: str = Form("free_editor"), presenter_type: str = Form("realista"), presenter_gender: str = Form("automatico"),
    presenter_age: str = Form("jovem"), presenter_energy: str = Form("alegre"),
    presenter_style: str = Form("creator"), voice: str = Form("coral"),
    voice_profile: str = Form("jovem_alegre"), variation_count: int = Form(3),
    writer_engine: str = Form("free_ai"), creativity_level: str = Form("equilibrado"), target_platforms: str = Form("all"),
    heygen_avatar_id: str = Form(""), heygen_voice_id: str = Form(""),
    db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    media_ready = product.media_license in {"oficial_marketplace", "fabricante", "autorizado_vendedor", "licenciado_comercialmente", "produzido_por_nos"}
    if product.status not in {"pronto_publicacao", "conteudo_pronto"} or not media_ready:
        request.session["action_error"] = "Roteiro bloqueado: confirme uma origem de mídia autorizada."
        return RedirectResponse(url=f"/products/{product_id}/complete", status_code=303)
    voice_profiles = {
        "jovem_alegre": "Fale em português do Brasil como em uma conversa real. Voz jovem e alegre, sem sorriso fixo, sem teatralidade. Frases curtas, pausas naturais e ritmo moderado.",
        "jovem_engracada": "Fale em português do Brasil de forma espontânea e levemente bem-humorada. Evite caricatura, exagero, gritos e entonação de locutor.",
        "humor_seco": "Fale em português do Brasil com humor seco, pausas curtas e naturalidade. A graça deve vir do texto, sem voz caricata, sem gritos e sem exagerar a entonação.",
        "narrador_divertido": "Fale em português do Brasil como um narrador divertido de vídeo curto: ritmo ágil, pequenas pausas para a piada e energia natural, sem imitar uma pessoa específica.",
        "energetica": "Fale em português do Brasil com energia presente, mas controlada. Ritmo ágil, dicção clara, pausas breves e entusiasmo natural, sem soar como propaganda.",
        "calma_amigavel": "Fale em português do Brasil com tom calmo, próximo e confiável. Respire entre ideias e evite cadência robótica.",
        "elegante": "Fale em português do Brasil com tom elegante e seguro, ritmo moderado, pausas naturais e emoção discreta.",
    }
    instructions = voice_profiles.get(voice_profile, voice_profiles["jovem_alegre"])
    if production_engine not in {"free_editor", "openai_editor", "heygen"}:
        production_engine = "free_editor"
    selected_avatar = None
    selected_voice = None
    if production_engine == "heygen":
        try:
            selected_avatar = heygen_find_avatar_look(heygen_avatar_id)
            voices = heygen_list_voices(limit=100)
            selected_voice = next((x for x in voices if x["id"] == heygen_voice_id), None)
        except Exception as exc:
            request.session["action_error"] = f"Não foi possível validar a biblioteca HeyGen: {str(exc)[:300]}"
            return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
        if not selected_avatar or not selected_voice:
            request.session["action_error"] = "Escolha um apresentador, um visual e uma voz válidos da biblioteca HeyGen."
            return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
        expected_gender = {"feminino": "female", "masculino": "male"}.get(presenter_gender)
        if expected_gender and selected_avatar.get("gender") != expected_gender:
            request.session["action_error"] = "O avatar escolhido não corresponde ao gênero selecionado."
            return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
        avatar_age = selected_avatar.get("age")
        if presenter_age and avatar_age not in {presenter_age, "nao_informado"}:
            request.session["action_error"] = "O avatar escolhido não corresponde à idade aparente selecionada."
            return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
        if expected_gender and selected_voice.get("gender") not in {expected_gender, "", "neutral"}:
            request.session["action_error"] = "A voz escolhida não corresponde ao gênero selecionado."
            return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
    duration_seconds = 40
    if writer_engine not in {"free_ai", "gemini_vision", "openai"}:
        writer_engine = "free_ai"
    if creativity_level not in {"conservador", "equilibrado", "criativo"}:
        creativity_level = "equilibrado"
    if target_platforms not in {"all", "instagram", "tiktok", "facebook"}:
        target_platforms = "all"
    if writer_engine == "openai" and not settings.openai_api_key:
        request.session["action_error"] = "O Roteirista OpenAI foi escolhido, mas OPENAI_API_KEY não está configurada."
        return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
    if writer_engine == "gemini_vision" and not settings.gemini_api_key:
        request.session["action_error"] = "O Roteirista Visual Gratuito usa Gemini. Configure GEMINI_API_KEY no Render uma única vez."
        return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
    try:
        product_meta = json.loads(product.source_metadata_json or "{}")
    except Exception:
        product_meta = {}
    if not product_meta.get("affiliate_link_confirmed"):
        request.session["action_error"] = "Salve e confirme o link de afiliado deste produto antes de gerar o roteiro. O link confirmado será incluído automaticamente na legenda e nas publicações."
        return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
    if not str(product.affiliate_url or "").startswith("https://"):
        request.session["action_error"] = "O link de afiliado confirmado está inválido. Atualize-o na tela Site Zavomi."
        return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)

    # v1.0.130: memória editorial curta para impedir que produtos diferentes
    # recebam o mesmo esqueleto de roteiro com substantivos trocados.
    recent_scripts = list(db.scalars(select(Script).order_by(Script.created_at.desc()).limit(24)).all())
    # Não compare o novo roteiro com roteiros antigos do MESMO produto. Isso fazia o
    # Roteirista Visual funcionar, mas ser bloqueado depois da resposta do Gemini.
    # A memória editorial serve para evitar templates entre produtos diferentes.
    recent_texts = [
        f"{x.hook} {x.narration}"
        for x in recent_scripts
        if (x.hook or x.narration) and x.product_id != product.id
    ]
    created = []
    for variation_index in range(max(1, min(3, variation_count))):
        req = ScriptRequest(product=product_to_input(product), format=format, duration_seconds=duration_seconds,
            production_engine=production_engine, presenter_type=presenter_type, presenter_gender=presenter_gender, presenter_age=presenter_age, presenter_energy=presenter_energy,
            presenter_style=presenter_style, voice=voice, voice_instructions=instructions, variation_index=variation_index,
            writer_engine=writer_engine, creativity_level=creativity_level, target_platforms=target_platforms,
            product_description=str(product.original_description or ""),
            source_images=parse_media_urls(product.media_urls)[: max(1, settings.gemini_script_max_images)])
        effective_format = resolve_format(req)
        req = req.model_copy(update={"format": effective_format})
        try:
            output = generate_script(req)
            # v1.0.133: diversidade é um critério de escolha, não um motivo para
            # inutilizar o Roteirista Visual. Mantemos o melhor candidato entre
            # várias tentativas e só bloqueamos duplicação praticamente literal.
            best_output = output
            best_score = 1.0
            for retry in range(0, 8):
                candidate_text = output.hook + " " + output.narration
                batch_score = max((_text_similarity(candidate_text, x.hook + " " + x.narration) for x in created), default=0.0)
                history_score = max((_text_similarity(candidate_text, old) for old in recent_texts), default=0.0)
                score = max(batch_score, history_score)
                if score < best_score:
                    best_output, best_score = output, score
                if batch_score < 0.38 and history_score < 0.60:
                    break
                if retry >= 7:
                    break
                alt_index = variation_index + retry + 1
                alt_req = req.model_copy(update={"variation_index": alt_index})
                alt_req = alt_req.model_copy(update={"format": resolve_format(alt_req) if format == "automatico" else effective_format})
                output = generate_script(alt_req)
            output = best_output
            candidate_text = output.hook + " " + output.narration
            # Só uma cópia quase literal deve impedir o lote. Sem isso, respostas
            # válidas do Gemini eram descartadas por frases comerciais comuns.
            if any(_text_similarity(candidate_text, x.hook + " " + x.narration) >= 0.82 for x in created):
                raise ValueError("O Gemini devolveu duas variações praticamente idênticas. Gere novamente.")
        except ValueError as exc:
            request.session["action_error"] = str(exc)
            db.rollback()
            return RedirectResponse(url=f"/products/{product_id}/scripts/new", status_code=303)
        script = Script(product_id=product.id, format=effective_format, duration_seconds=duration_seconds,
            production_engine=production_engine, presenter_type=presenter_type, presenter_gender=presenter_gender, presenter_age=presenter_age, presenter_energy=presenter_energy,
            presenter_style=presenter_style, voice=voice, voice_instructions=instructions, variation_index=variation_index,
            writer_engine=writer_engine, creativity_level=creativity_level, target_platforms=target_platforms,
            heygen_avatar_id=(selected_avatar or {}).get("id", ""),
            heygen_avatar_name=(selected_avatar or {}).get("person_name", (selected_avatar or {}).get("name", "")),
            heygen_avatar_preview_url=(selected_avatar or {}).get("preview_image_url", ""),
            heygen_voice_id=(selected_voice or {}).get("id", ""),
            heygen_voice_name=(selected_voice or {}).get("name", ""),
            heygen_voice_preview_url=(selected_voice or {}).get("preview_audio_url", ""),
            hook=output.hook, narration=output.narration, on_screen_text="\n".join(output.on_screen_text), selected_media_urls="",
            caption=output.caption, call_to_action=output.call_to_action, hashtags=" ".join(output.hashtags), status="rascunho")
        db.add(script); created.append(script)
    product.status = "conteudo_pronto"
    db.commit()
    for item in created: db.refresh(item)
    if len(created) > 1:
        request.session["action_message"] = "Três variações diferentes foram criadas. Compare e aprove a melhor."
        return RedirectResponse(url="/scripts", status_code=303)
    return RedirectResponse(url=f"/scripts/{created[0].id}", status_code=303)


@app.get("/scripts/{script_id}", response_class=HTMLResponse)
def script_detail(script_id: int, request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    script = db.get(Script, script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Roteiro não encontrado")
    return templates.TemplateResponse(request=request, name="scripts/detail.html", context=template_context(request, script=script, gemini_configured=bool(settings.gemini_api_key)))


@app.post("/scripts/{script_id}/edit")
def edit_script(
    script_id: int, request: Request, csrf: str = Form(...),
    hook: str = Form(...), narration: str = Form(...),
    call_to_action: str = Form("Link na bio"), caption: str = Form(""), target_platforms: str = Form("all"),
    hashtags: str = Form(""), on_screen_text: str = Form(""),
    db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    script = db.get(Script, script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Roteiro não encontrado")
    if script.status != "rascunho":
        request.session["action_error"] = "Reabra o roteiro para revisão antes de editar."
        return RedirectResponse(url=f"/scripts/{script_id}", status_code=303)
    if target_platforms not in {"all", "instagram", "tiktok", "facebook"}:
        target_platforms = "all"
    clean_hook = sanitize_script_language(hook)
    clean_narration = sanitize_script_language(narration)
    clean_cta = "Confira o link da bio."
    issues = script_language_issues(clean_hook, clean_narration, clean_cta)
    if not clean_hook or not clean_narration:
        issues.append("Gancho e narração não podem ficar vazios.")
    if issues:
        request.session["action_error"] = "Não foi possível salvar: " + " ".join(dict.fromkeys(issues))
        return RedirectResponse(url=f"/scripts/{script_id}", status_code=303)
    script.hook = clean_hook
    script.narration = clean_narration
    script.call_to_action = clean_cta
    script.caption = str(caption or "").strip()
    script.target_platforms = target_platforms
    script.hashtags = str(hashtags or "").strip()
    # Linguagem visual limpa: apenas gancho e CTA; instruções internas não viram tarjas.
    script.on_screen_text = str(on_screen_text or "").strip()
    db.commit()
    request.session["action_message"] = "Roteiro salvo. A prévia de voz usará exatamente o texto editado."
    return RedirectResponse(url=f"/scripts/{script_id}", status_code=303)


@app.post("/scripts/{script_id}/status")
def update_script_status(script_id: int, request: Request, csrf: str = Form(...), status_value: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    if status_value not in {"rascunho", "aprovado", "reprovado"}:
        raise HTTPException(status_code=400, detail="Status inválido")
    script = db.get(Script, script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Roteiro não encontrado")
    script.status = status_value
    if status_value == "aprovado":
        script.product.status = "conteudo_pronto"
        request.session["action_message"] = "Roteiro aprovado. Ele está pronto para produção, mas ainda não foi publicado."
    elif status_value == "reprovado":
        request.session["action_message"] = "Roteiro reprovado e retirado da fila de produção."
    else:
        request.session["action_message"] = "Roteiro reaberto para revisão."
    db.commit()
    return RedirectResponse(url=f"/scripts/{script_id}", status_code=303)


@app.post("/scripts/{script_id}/delete")
def delete_script(script_id: int, request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    script = db.get(Script, script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Roteiro não encontrado")
    productions = db.scalars(select(Production).where(Production.script_id == script_id)).all()
    for production in productions:
        db.execute(delete(Publication).where(Publication.production_id == production.id))
        db.execute(delete(MediaAsset).where(MediaAsset.production_id == production.id))
        folder = storage_root() / "productions" / str(production.id)
        shutil.rmtree(folder, ignore_errors=True)
        db.delete(production)
    db.delete(script)
    db.commit()
    request.session["action_message"] = "Roteiro e produções vinculadas foram excluídos."
    return RedirectResponse(url="/scripts", status_code=303)


@app.post("/scripts/delete-all")
def delete_all_scripts(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)

    scripts = db.scalars(select(Script)).all()
    if not scripts:
        request.session["action_message"] = "Não havia roteiros para excluir."
        return RedirectResponse(url="/scripts", status_code=303)

    productions = db.scalars(select(Production)).all()
    for production in productions:
        db.execute(delete(Publication).where(Publication.production_id == production.id))
        db.execute(delete(MediaAsset).where(MediaAsset.production_id == production.id))
        folder = storage_root() / "productions" / str(production.id)
        shutil.rmtree(folder, ignore_errors=True)
        db.delete(production)

    for script in scripts:
        db.delete(script)

    deleted_count = len(scripts)
    db.commit()
    request.session["action_message"] = f"{deleted_count} roteiro(s) e produções vinculadas foram excluídos."
    return RedirectResponse(url="/scripts", status_code=303)


@app.get("/media/assets/{asset_id}")
def persisted_media_file(asset_id: int, db: Session = Depends(get_db)):
    asset = db.get(MediaAsset, asset_id)
    if not asset:
        raise HTTPException(status_code=404, detail="Mídia não encontrada")
    return Response(
        content=asset.data,
        media_type=asset.content_type,
        headers={
            "Content-Disposition": f'inline; filename="{asset.name}"',
            "Cache-Control": "public, max-age=3600",
        },
    )


@app.get("/media/{path:path}")
def media_file(path: str):
    # Compatibilidade temporária com mídias locais de versões anteriores.
    root = storage_root()
    target = (root / path).resolve()
    if root not in target.parents or not target.exists() or not target.is_file():
        raise HTTPException(status_code=404, detail="Mídia não encontrada")
    return FileResponse(target)


@app.get("/productions", response_class=HTMLResponse)
def productions_page(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    productions = db.scalars(select(Production).order_by(Production.created_at.desc())).all()
    return templates.TemplateResponse(request=request, name="productions/list.html", context=template_context(request, productions=productions))


@app.get("/scripts/{script_id}/production/new", response_class=HTMLResponse)
def new_production_page(script_id: int, request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    script = db.get(Script, script_id)
    if not script: raise HTTPException(status_code=404, detail="Roteiro não encontrado")
    if script.status != "aprovado":
        request.session["action_error"] = "A produção só pode começar após a aprovação do roteiro."
        return RedirectResponse(url=f"/scripts/{script_id}", status_code=303)
    production = db.scalar(select(Production).where(Production.script_id == script_id, Production.status.in_(["processando", "na_fila", "montando", "montando_ativo"])).order_by(Production.created_at.desc()))
    if production: return RedirectResponse(url=f"/productions/{production.id}", status_code=303)
    if len(parse_media_urls(script.product.media_urls)) < 2 or not script.product.original_description:
        try:
            sync_product_listing_content(script.product, db)
        except Exception:
            logger.exception("Falha ao importar mídia automaticamente antes da produção produto_id=%s", script.product_id)
    product_media = parse_media_urls(script.product.media_urls)
    selected_media = parse_media_urls(script.selected_media_urls) or product_media
    return templates.TemplateResponse(request=request, name="productions/form.html", context=template_context(request, script=script, ai_configured=bool(settings.openai_api_key), heygen_configured=heygen_configured(), gemini_configured=bool(settings.gemini_api_key), product_media=product_media, selected_media=selected_media))


@app.post("/scripts/{script_id}/free-voice-preview")
def free_voice_preview(script_id: int, request: Request, csrf: str = Form(...), free_voice: str = Form("auto"), db: Session = Depends(get_db)):
    """Gera a prévia usando exatamente o perfil escolhido na tela.

    v1.0.124: falhas de TTS deixam de virar um 500 genérico. O navegador recebe
    uma mensagem legível, e a resposta de sucesso informa qual perfil/provedor
    foi realmente usado. Seleção manual nunca é trocada silenciosamente.
    """
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    script = db.get(Script, script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Roteiro não encontrado")
    try:
        profile = choose_free_voice_profile(free_voice, script.presenter_gender, script.format, variation_seed=script.id)
        if str(script.format or "").strip().lower() == "humor_risada":
            profile["laugh_after_hook"] = True
    except Exception as exc:
        logger.exception("Perfil de voz inválido na prévia script_id=%s voice=%s", script_id, free_voice)
        raise HTTPException(status_code=400, detail=f"Voz inválida: {exc}") from exc

    # v1.0.136 — PRÉVIA RÁPIDA: não sintetizamos mais os 40 s completos só
    # para identificar uma voz. O gancho entra inteiro e acrescentamos apenas
    # uma pequena amostra da narração. No humor com risada, o trecho preserva
    # obrigatoriamente o ponto gancho -> risada -> continuação.
    hook_text = normalize_spoken_text_ptbr(script.hook or "").strip()
    narration_text = normalize_spoken_text_ptbr(script.narration or "").strip()
    if not hook_text and not narration_text:
        raise HTTPException(status_code=400, detail="Este roteiro não possui texto para narrar.")
    sample_rest = narration_text
    if len(sample_rest) > 180:
        cut = sample_rest[:180]
        stop = max(cut.rfind("."), cut.rfind("!"), cut.rfind("?"), cut.rfind(","))
        sample_rest = (cut[:stop + 1] if stop >= 70 else cut).strip()
    spoken = (hook_text + " " + sample_rest).strip()

    folder = storage_root() / "voice_previews"
    folder.mkdir(parents=True, exist_ok=True)
    profile_name = re.sub(r"[^a-zA-Z0-9_-]+", "_", str(profile.get("name") or "voice"))
    cache_material = "|".join([
        "preview136-v146-rate-limit", spoken, profile_name, str(profile.get("gemini_voice") or ""),
        str(profile.get("timbre_fx") or ""), str(bool(profile.get("laugh_after_hook"))),
    ])
    cache_key = hashlib.sha256(cache_material.encode("utf-8")).hexdigest()[:18]
    target = folder / f"script_{script.id}_{profile_name}_{cache_key}.mp3"
    provider = "preview_cache"
    if target.exists() and target.stat().st_size > 1024:
        profile["_runtime_engine"] = str(profile.get("gemini_voice") or profile.get("voice") or "cache") + (("+" + str(profile.get("timbre_fx"))) if profile.get("timbre_fx") else "")
        generated = target
    else:
        target.unlink(missing_ok=True)
        try:
            generated, provider = generate_profile_speech(spoken, target, profile)
        except Exception as exc:
            target.unlink(missing_ok=True)
            logger.exception(
                "Falha ao gerar prévia script_id=%s profile=%s edge_voice=%s gemini_voice=%s",
                script_id, profile.get("name"), profile.get("voice"), profile.get("gemini_voice"),
            )
            safe_error = re.sub(r"AIza[0-9A-Za-z_-]+", "[chave_oculta]", str(exc))[:260]
            raise HTTPException(
                status_code=503,
                detail=(
                    f"Não foi possível gerar a voz '{profile.get('label') or profile.get('name')}'. "
                    f"Diagnóstico: {safe_error or type(exc).__name__}. "
                    "Nas vozes com risada não usamos Edge como substituto. Em limite 429, o agente já tenta novamente e alterna entre modelos Gemini antes de retornar este erro."
                ),
            ) from exc
    if not generated.exists() or generated.stat().st_size < 1024:
        generated.unlink(missing_ok=True)
        raise HTTPException(status_code=503, detail="A prévia de voz foi gerada vazia. Tente novamente.")
    # HTTP headers must be latin-1/ASCII safe. Labels contain emoji, em dash and
    # accents; sending them directly makes Starlette fail while building the
    # response, which was the reason every preview appeared to fail even after
    # the MP3 had been generated. Send a stable ASCII identifier in headers and
    # keep the human label in the page itself.
    headers = {
        "X-Zavomi-Voice-Profile": str(profile.get("name") or "voice"),
        "X-Zavomi-Voice-Provider": str(provider or "tts"),
        "X-Zavomi-Voice-Engine": str(profile.get("_runtime_engine") or profile.get("gemini_voice") or profile.get("voice") or "unknown"),
        "Cache-Control": "no-store, max-age=0",
    }
    return FileResponse(generated, media_type="audio/mpeg", filename=f"previa_voz_{script.id}.mp3", headers=headers)


@app.post("/scripts/{script_id}/production/new")
def create_production(script_id: int, request: Request, csrf: str = Form(...), mode: str = Form("ai"), free_voice: str = Form("auto"), selected_media_urls: str = Form(""), video: UploadFile | None = File(None), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    script = db.get(Script, script_id)
    if not script or script.status != "aprovado": raise HTTPException(status_code=400, detail="Roteiro não aprovado")
    if len(parse_media_urls(script.product.media_urls)) < 2 or not script.product.original_description:
        try:
            sync_product_listing_content(script.product, db)
        except Exception:
            logger.exception("Falha ao importar mídia automaticamente na produção produto_id=%s", script.product_id)
    product_media = parse_media_urls(selected_media_urls) or parse_media_urls(script.selected_media_urls) or parse_media_urls(script.product.media_urls)
    if mode in {"free", "hybrid"}:
        try:
            if (free_voice or "auto").strip().lower() != "auto":
                # Seleção manual: valida e grava o nome canônico.
                free_voice = resolve_free_voice_profile(free_voice, script.presenter_gender)["name"]
            else:
                # IMPORTANTE: preserva ``auto`` até o worker. Assim a escolha
                # considera o formato do roteiro e alterna entre perfis compatíveis.
                free_voice = "auto"
        except ValueError as exc:
            request.session["action_error"] = str(exc)
            return RedirectResponse(url=f"/scripts/{script_id}/production/new", status_code=303)
    if selected_media_urls.strip():
        script.selected_media_urls = "\n".join(product_media)
        db.add(script); db.commit(); db.refresh(script)
    if mode in {"heygen", "ai", "free", "hybrid"} and len(product_media) < 2:
        request.session["action_error"] = "Cadastre pelo menos duas fotos originais do anúncio antes de produzir. O produto deve ser o destaque do vídeo."
        return RedirectResponse(url=f"/products/{script.product_id}/complete", status_code=303)
    if mode == "heygen" and (not script.heygen_avatar_id or not script.heygen_voice_id):
        request.session["action_error"] = "O roteiro não possui o avatar e a voz escolhidos. Refaça o roteiro e selecione ambos."
        return RedirectResponse(url=f"/scripts/{script_id}", status_code=303)
    media_source = "apresentador_heygen" if mode == "heygen" else "editor_openai" if mode == "ai" else "editor_hibrido_gratuito" if mode == "hybrid" else "editor_gratuito" if mode == "free" else "arquivo_enviado"
    provider = "heygen" if mode == "heygen" else "openai" if mode == "ai" else "local"
    production = Production(script_id=script.id, status="processando" if mode == "heygen" else "na_fila", media_source=media_source, provider=provider,
        source_manifest=json.dumps({"job": {"mode": mode, "free_voice": free_voice, "selected_media_urls": product_media}}, ensure_ascii=False))
    db.add(production); db.commit(); db.refresh(production)
    try:
        if mode == "upload":
            if not video or video.content_type != "video/mp4": raise ValueError("Envie um arquivo MP4 válido")
            folder = storage_root() / "productions" / str(production.id); folder.mkdir(parents=True, exist_ok=True)
            target = folder / "video.mp4"
            content = video.file.read()
            if len(content) > 100 * 1024 * 1024: raise ValueError("O vídeo excede 100 MB")
            target.write_bytes(content)
            relative = target.relative_to(storage_root()).as_posix()
            production.video_path = str(target)
            production.video_url = public_media_url(relative)
            production.status = "revisao"
            request.session["action_message"] = "Vídeo enviado para revisão."
        elif mode == "heygen":
            spoken_text = sanitize_spoken_text(f"{script.hook} {script.narration} {script.call_to_action}")
            if not spoken_text:
                raise ValueError("O roteiro falado não contém texto válido depois da remoção de instruções técnicas")
            result = create_avatar_video(
                title=f"Zavomi - {script.product.title}", script=spoken_text,
                avatar_id=script.heygen_avatar_id, voice_id=script.heygen_voice_id,
                energy=script.presenter_energy, style=script.presenter_style,
                duration=script.duration_seconds,
            )
            production.external_job_id = result["video_id"]
            production.source_manifest = json.dumps({"provider": "heygen", "request": result["payload"], "spoken_text": spoken_text, "scene_instructions": script.on_screen_text, "product_media": product_media, "selected_avatar_id": script.heygen_avatar_id, "selected_voice_id": script.heygen_voice_id, "visual_mode": "scene_editor_v2", "presenter_usage": "audio_only", "brand": "Zavomi", "quality_gate": "product_first", "progress": 0}, ensure_ascii=False)
            production.status = "processando"
            request.session["action_message"] = "A HeyGen recebeu o vídeo. O agente acompanhará o status automaticamente."
        else:
            spoken_text = sanitize_spoken_text(f"{script.hook} {script.narration} {script.call_to_action}")
            if not spoken_text:
                raise ValueError("O roteiro não contém texto comercial válido para narração")
            production.source_manifest = json.dumps({
                "provider": provider,
                "job": {"mode": mode, "free_voice": free_voice, "spoken_text": spoken_text},
                "assembly": "queued",
                "progress": 0,
                "queued_at": datetime.now(timezone.utc).isoformat(),
            }, ensure_ascii=False)
            production.status = "na_fila"
            production.error = ""
            request.session["action_message"] = "Produção adicionada à fila. A página pode ser fechada; o vídeo continuará sendo criado."
    except Exception as exc:
        logger.exception("Falha na produção")
        production.status = "falhou"; production.error = str(exc)[:2000]
        request.session["action_error"] = "A produção não foi concluída. As mídias já criadas foram preservadas; abra os detalhes para tentar novamente."
    db.commit()
    return RedirectResponse(url=f"/productions/{production.id}", status_code=303)


@app.get("/productions/{production_id}", response_class=HTMLResponse)
def production_detail(production_id: int, request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    production = db.get(Production, production_id)
    if not production: raise HTTPException(status_code=404, detail="Produção não encontrada")
    publications = db.scalars(select(Publication).where(Publication.production_id == production_id)).all()
    connections = {c.provider: c for c in db.scalars(select(SocialConnection)).all()}
    queue_position = None
    if production.status in {"na_fila", "montando"}:
        queued_ids = list(db.scalars(select(Production.id).where(Production.status.in_(["na_fila", "montando"])).order_by(Production.created_at.asc())).all())
        if production.id in queued_ids:
            queue_position = queued_ids.index(production.id) + 1
    manifest = _manifest_dict(production.source_manifest)
    return templates.TemplateResponse(request=request, name="productions/detail.html", context=template_context(request, production=production, publications=publications, connections=connections, queue_position=queue_position, production_progress=int(manifest.get("progress") or 0)))



@app.post("/productions/{production_id}/refresh")
def refresh_production(
    production_id: int, request: Request, background_tasks: BackgroundTasks,
    csrf: str = Form(...), db: Session = Depends(get_db),
):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production: raise HTTPException(status_code=404, detail="Produção não encontrada")
    if production.provider != "heygen" or not production.external_job_id:
        request.session["action_error"] = "Esta produção não pertence à HeyGen."
        return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    if production.status in {"montando", "revisao", "aprovado"}:
        return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    try:
        data = heygen_get_video(production.external_job_id)
        status_hg = str(data.get("status") or "").lower()
        if status_hg in {"completed", "success", "succeeded"}:
            url = data.get("video_url") or data.get("url")
            if not url:
                raise RuntimeError("A HeyGen concluiu, mas não retornou a URL do vídeo")
            manifest = _manifest_dict(production.source_manifest)
            manifest.update({"heygen_video_url": url, "heygen_status": status_hg, "assembly": "queued"})
            production.source_manifest = json.dumps(manifest, ensure_ascii=False)
            production.status = "montando"
            production.error = ""
            db.commit()
            request.session["action_message"] = "A HeyGen concluiu. O agente está montando o vídeo final com as fotos do produto."
        elif status_hg in {"failed", "error"}:
            production.status = "falhou"
            production.error = str(data.get("failure_message") or data.get("error") or "Falha informada pela HeyGen")[:2000]
            db.commit()
        else:
            production.status = "processando"
            production.error = ""
            db.commit()
            request.session["action_message"] = f"A HeyGen ainda está processando ({status_hg or 'pendente'})."
    except Exception as exc:
        logger.exception("Falha ao consultar o status da HeyGen produção_id=%s", production_id)
        production.error = str(exc)[:2000]
        db.commit()
        request.session["action_error"] = "Não foi possível consultar a HeyGen agora. A produção foi preservada e pode ser atualizada novamente."
    return RedirectResponse(url=f"/productions/{production_id}", status_code=303)

@app.post("/productions/{production_id}/resume")
def resume_production(production_id: int, request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production: raise HTTPException(status_code=404, detail="Produção não encontrada")
    manifest = _manifest_dict(production.source_manifest)
    if not manifest.get("heygen_video_url"):
        request.session["action_error"] = "A HeyGen ainda não entregou a URL. Atualize o status primeiro."
        return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    if production.status in {"revisao", "aprovado"}:
        return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    production.status = "na_fila"
    production.error = ""
    manifest["assembly"] = "queued_manual"
    manifest["progress"] = 0
    production.source_manifest = json.dumps(manifest, ensure_ascii=False)
    db.commit()
    request.session["action_message"] = "Montagem recolocada na fila sem gerar outro vídeo na HeyGen."
    return RedirectResponse(url=f"/productions/{production_id}", status_code=303)


@app.post("/productions/{production_id}/retry")
def retry_production(production_id: int, request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production: raise HTTPException(status_code=404, detail="Produção não encontrada")
    if production.status != "falhou":
        request.session["action_error"] = "Somente uma produção com falha pode ser colocada novamente na fila."
        return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    if production.provider == "heygen":
        manifest = _manifest_dict(production.source_manifest)
        if not manifest.get("heygen_video_url"):
            request.session["action_error"] = "A HeyGen ainda não entregou o vídeo. Atualize o status antes de tentar a montagem."
            return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    manifest = _manifest_dict(production.source_manifest)
    manifest["assembly"] = "queued_retry"
    manifest["progress"] = 0
    manifest["assembly_attempts"] = 0
    production.source_manifest = json.dumps(manifest, ensure_ascii=False)
    production.status = "na_fila"
    production.error = ""
    db.commit()
    request.session["action_message"] = "Produção recolocada na fila sem gerar novas mídias."
    return RedirectResponse(url=f"/productions/{production_id}", status_code=303)


@app.post("/productions/{production_id}/cancel")
def cancel_queued_production(production_id: int, request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production: raise HTTPException(status_code=404, detail="Produção não encontrada")
    if production.status not in {"na_fila", "montando"}:
        request.session["action_error"] = "Somente uma produção que ainda está na fila pode ser cancelada."
        return RedirectResponse(url=f"/productions/{production_id}", status_code=303)
    production.status = "cancelado"
    production.error = ""
    manifest = _manifest_dict(production.source_manifest)
    manifest["assembly"] = "cancelled"
    production.source_manifest = json.dumps(manifest, ensure_ascii=False)
    db.commit()
    request.session["action_message"] = "Produção removida da fila."
    return RedirectResponse(url=f"/productions/{production_id}", status_code=303)


@app.post("/productions/{production_id}/delete")
def delete_production(production_id: int, request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production:
        raise HTTPException(status_code=404, detail="Produção não encontrada")
    db.execute(delete(Publication).where(Publication.production_id == production_id))
    db.execute(delete(MediaAsset).where(MediaAsset.production_id == production_id))
    folder = storage_root() / "productions" / str(production_id)
    shutil.rmtree(folder, ignore_errors=True)
    db.delete(production)
    db.commit()
    request.session["action_message"] = "Produção excluída."
    return RedirectResponse(url="/productions", status_code=303)


@app.post("/productions/{production_id}/status")
def update_production_status(production_id: int, request: Request, csrf: str = Form(...), status_value: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    if status_value not in {"revisao", "aprovado", "reprovado"}: raise HTTPException(status_code=400, detail="Status inválido")
    production = db.get(Production, production_id)
    if not production: raise HTTPException(status_code=404, detail="Produção não encontrada")
    production.status = status_value
    request.session["action_message"] = "Mídia aprovada e pronta para publicação." if status_value == "aprovado" else "Decisão da mídia salva."
    db.commit(); return RedirectResponse(url=f"/productions/{production_id}", status_code=303)


@app.get("/site-zavomi", response_class=HTMLResponse)
def zavomi_site_page(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    products = db.scalars(select(Product).order_by(Product.updated_at.desc())).all()
    publishable = [(p, product_payload(p)) for p in products]
    publishable = [(p, payload) for p, payload in publishable if payload and payload.get("description") and payload.get("affiliate_link_confirmed")]
    excluded = [(p, site_flags(p)) for p in products if site_flags(p).get("excluded")]
    incomplete = [(p, source_metadata(p)) for p in products if p.status in {"aprovado","aprovado_comercial","pronto_publicacao"} and not site_flags(p).get("excluded") and (not product_payload(p) or not product_payload(p).get("description") or not product_payload(p).get("affiliate_link_confirmed"))]
    history = db.scalars(select(SitePublication).order_by(SitePublication.id.desc()).limit(20)).all()
    last_publication = history[0] if history else None
    return templates.TemplateResponse(
        request=request,
        name="site/index.html",
        context=template_context(
            request, products=publishable, incomplete=incomplete, excluded=excluded, history=history, last_publication=last_publication,
            configured=zavomi_site_configured(), site_url=settings.zavomi_site_url,
            action_message=request.session.pop("site_message", None),
            action_error=request.session.pop("site_error", None),
        ),
    )


@app.post("/site-zavomi/publicar")
def zavomi_site_publish(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    event = publish_catalog(db, trigger="manual_painel")
    if event.status == "publicado":
        request.session["site_message"] = f"Catálogo enviado ao site com {event.product_count} produtos. O Render atualizará automaticamente."
    else:
        request.session["site_error"] = event.error or "Não foi possível publicar o catálogo."
    return RedirectResponse(url="/site-zavomi", status_code=303)


@app.post("/site-zavomi/produtos/{product_id}/gerar-link-afiliado")
def zavomi_site_generate_affiliate_link(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect:
        return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Produto não encontrado")
    meta = source_metadata(product)
    listing_url = str(meta.get("listing_url") or product.affiliate_url or "").strip()
    result = resolve_affiliate_link(
        listing_url=listing_url,
        item_id=str(meta.get("item_id") or product.external_product_id or ""),
        catalog_product_id=str(meta.get("catalog_product_id") or ""),
        existing_url=str(product.affiliate_url or ""),
        existing_confirmed=bool(meta.get("affiliate_link_confirmed")),
    )
    meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
    meta["affiliate_link_source"] = result.source
    meta["affiliate_link_error"] = result.error
    if result.confirmed:
        product.affiliate_url = result.url
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_error"] = ""
        request.session["site_message"] = "Link afiliado gerado e confirmado automaticamente. Ele será usado no site, nos roteiros e nas publicações."
        background_tasks.add_task(publish_catalog_background, f"link_afiliado_auto_{product_id}")
    else:
        meta["affiliate_link_confirmed"] = False
        request.session["site_error"] = result.error or "A fonte oficial não retornou o link afiliado."
    save_source_metadata(product, meta)
    db.commit()
    return RedirectResponse(url="/site-zavomi", status_code=303)


@app.post("/site-zavomi/produtos/{product_id}/link-afiliado")
def zavomi_site_affiliate_link(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), affiliate_url: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product: raise HTTPException(status_code=404, detail="Produto não encontrado")
    value = affiliate_url.strip()
    if not value.startswith("https://"):
        request.session["site_error"] = "Cole o link HTTPS gerado na Central de Afiliados do Mercado Livre."
        return RedirectResponse(url="/site-zavomi", status_code=303)
    meta = source_metadata(product)
    if not meta.get("listing_url") and product.affiliate_url:
        meta["listing_url"] = product.affiliate_url
    product.affiliate_url = value
    meta["affiliate_link_confirmed"] = True
    meta["affiliate_link_updated_at"] = datetime.now(timezone.utc).isoformat()
    save_source_metadata(product, meta)
    db.commit()
    background_tasks.add_task(publish_catalog_background, f"link_afiliado_{product_id}")
    request.session["site_message"] = "Link de afiliado salvo. As vendas elegíveis serão atribuídas pelo Mercado Livre por esse link."
    return RedirectResponse(url="/site-zavomi", status_code=303)


@app.post("/site-zavomi/produtos/{product_id}/descricao-manual")
def zavomi_site_manual_description(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), description: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product: raise HTTPException(status_code=404, detail="Produto não encontrado")
    value = "\n".join(line.rstrip() for line in description.strip().splitlines()).strip()
    if len(value) < 40:
        request.session["site_error"] = "A descrição manual precisa ter pelo menos 40 caracteres e conter somente dados verdadeiros do anúncio."
        return RedirectResponse(url="/site-zavomi", status_code=303)
    product.original_description = value[:12000]
    meta = source_metadata(product)
    meta["original_listing_description"] = value[:12000]
    meta["description_confirmed"] = True
    meta["description_source"] = "manual_verified"
    meta["manual_description_updated_at"] = datetime.now(timezone.utc).isoformat()
    save_source_metadata(product, meta)
    db.commit()
    background_tasks.add_task(publish_catalog_background, f"descricao_manual_{product_id}")
    request.session["site_message"] = "Descrição manual salva como fallback verificado. A coleta automática continuará tentando obter dados oficiais nas próximas conferências."
    return RedirectResponse(url="/site-zavomi", status_code=303)

@app.post("/site-zavomi/produtos/{product_id}/excluir")
def zavomi_site_exclude(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product: raise HTTPException(status_code=404, detail="Produto não encontrado")
    set_site_flag(product, "excluded", True); set_site_flag(product, "highlighted", False); db.commit()
    background_tasks.add_task(publish_catalog_background, f"excluir_site_{product_id}")
    request.session["site_message"] = "Anúncio removido do site. O produto continua salvo no agente."
    return RedirectResponse(url="/site-zavomi", status_code=303)

@app.post("/site-zavomi/produtos/{product_id}/republicar")
def zavomi_site_republish(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product: raise HTTPException(status_code=404, detail="Produto não encontrado")
    set_site_flag(product, "excluded", False); db.commit(); background_tasks.add_task(publish_catalog_background, f"republicar_site_{product_id}")
    request.session["site_message"] = "Produto liberado para republicação no site."
    return RedirectResponse(url="/site-zavomi", status_code=303)

@app.post("/site-zavomi/produtos/{product_id}/destaque")
def zavomi_site_highlight(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), enabled: str = Form("1"), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product: raise HTTPException(status_code=404, detail="Produto não encontrado")
    set_site_flag(product, "highlighted", enabled == "1"); db.commit(); background_tasks.add_task(publish_catalog_background, f"destaque_site_{product_id}")
    request.session["site_message"] = "Destaque do produto atualizado."
    return RedirectResponse(url="/site-zavomi", status_code=303)

@app.post("/site-zavomi/produtos/{product_id}/atualizar")
def zavomi_site_refresh(product_id: int, request: Request, background_tasks: BackgroundTasks, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    product = db.get(Product, product_id)
    if not product: raise HTTPException(status_code=404, detail="Produto não encontrado")
    try:
        result = refresh_product_from_source(db, product)
        background_tasks.add_task(publish_catalog_background, f"atualizar_site_{product_id}")
        request.session["site_message"] = f"Anúncio conferido: {result['pictures']} fotos; descrição {'obtida' if result['description'] else 'ainda indisponível'}; preço e estoque atualizados."
    except Exception as exc:
        request.session["site_error"] = f"Não foi possível atualizar o anúncio: {str(exc)[:300]}"
    return RedirectResponse(url="/site-zavomi", status_code=303)

@app.post("/site-zavomi/atualizar-todos")
def zavomi_site_refresh_all(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect=require_page_login(request)
    if redirect: return redirect
    validate_csrf(request,csrf)
    result=refresh_all_site_products(db,publish=True,trigger="manual_refresh_all")
    request.session["site_message"]=f"Verificação concluída: {result['checked']} anúncios conferidos e catálogo republicado."
    if result['errors']:
        request.session["site_error"]=f"{len(result['errors'])} anúncio(s) tiveram falha e serão tentados novamente."
    return RedirectResponse(url="/site-zavomi",status_code=303)


@app.get("/social", response_class=HTMLResponse)
def social_page(request: Request, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    connections = {c.provider: c for c in db.scalars(select(SocialConnection)).all()}
    approved_productions = db.scalars(
        select(Production).where(Production.status == "aprovado").order_by(Production.updated_at.desc()).limit(20)
    ).all()
    recent_publications = db.scalars(select(Publication).order_by(Publication.created_at.desc()).limit(100)).all()
    caption_map = {p.id: build_instagram_caption(p.script.product, p.script) for p in approved_productions}
    tiktok_caption_map = {p.id: build_tiktok_caption(p.script.product, p.script) for p in approved_productions}
    tiktok_creator_info = {}
    tiktok_connection = connections.get("tiktok")
    if tiktok_connection and tiktok_connection.status == "conectado":
        try:
            tiktok_service = TikTokService()
            tiktok_service.enrich_connection(db, tiktok_connection)
            tiktok_creator_info = tiktok_service.creator_info(tiktok_service.access_token(db))
        except Exception as exc:
            logger.warning("TikTok creator_info indisponível na tela Social: %s", str(exc)[:300])
    return templates.TemplateResponse(
        request=request, name="social/index.html",
        context=template_context(
            request, connections=connections, approved_productions=approved_productions,
            recent_publications=recent_publications, caption_map=caption_map, tiktok_caption_map=tiktok_caption_map,
            tiktok_creator_info=tiktok_creator_info,
            meta_ready=bool(settings.meta_app_id and settings.meta_app_secret),
            instagram_redirect_uri=settings.instagram_redirect_uri,
            tiktok_ready=bool(settings.tiktok_client_key and settings.tiktok_client_secret),
            comment_events=db.scalars(select(InstagramCommentEvent).order_by(InstagramCommentEvent.created_at.desc()).limit(50)).all(),
            ad_campaigns=db.scalars(select(AdCampaign).order_by(AdCampaign.created_at.desc()).limit(30)).all(),
            webhook_url=f"{settings.public_base_url.rstrip('/')}/webhooks/instagram",
            meta_app_live_mode=settings.meta_app_live_mode,
            webhook_verify_token=settings.instagram_webhook_verify_token,
            ads_ready=MetaAdsService().configured,
            max_ads_budget=settings.meta_ads_max_total_brl,
        ),
    )


def _publish_tiktok_task(
    publication_id: int, privacy_level: str, allow_comment: bool, allow_duet: bool, allow_stitch: bool
) -> None:
    db=SessionLocal()
    try:
        pub=db.get(Publication, publication_id)
        if not pub: return
        prod=pub.production
        asset=db.scalar(select(MediaAsset).where(MediaAsset.production_id==prod.id, MediaAsset.content_type.like("video/%")).order_by(MediaAsset.id.desc()))
        if not asset: raise TikTokError("Vídeo persistido não encontrado. Gere novamente a produção.")
        service=TikTokService(); token=service.access_token(db); info=service.creator_info(token)
        options=info.get("privacy_level_options") or []
        if privacy_level not in options:
            raise TikTokError("A privacidade escolhida não está disponível para esta conta. Atualize a tela e escolha uma opção exibida pelo TikTok.")
        max_duration=int(info.get("max_video_post_duration_sec") or 0)
        # Interações bloqueadas na própria conta precisam ser respeitadas.
        allow_comment=bool(allow_comment and not info.get("comment_disabled"))
        allow_duet=bool(allow_duet and not info.get("duet_disabled"))
        allow_stitch=bool(allow_stitch and not info.get("stitch_disabled"))
        pub.status="processando"; db.commit()
        try:
            publish_id=service.direct_post(
                token, video=bytes(asset.data), caption=pub.caption, privacy_level=privacy_level,
                allow_comment=allow_comment, allow_duet=allow_duet, allow_stitch=allow_stitch,
                brand_content=True, brand_organic=False, is_aigc=True,
            )
            publish_mode="direct"
        except TikTokError as direct_exc:
            # O vídeo do fluxo real mostrou este retorno do TikTok: o app está Ao vivo,
            # porém o cliente de Content Posting ainda é tratado como "unaudited" para
            # publicação pública. Isso não é falha do MP4 nem do OAuth. Nessa situação
            # usamos o endpoint oficial video.upload para não perder a produção: o vídeo
            # chega à caixa de entrada do TikTok e o usuário conclui a postagem no app.
            if direct_exc.code == "unaudited_client_can_only_post_to_private_accounts":
                publish_id=service.upload_draft(token, video=bytes(asset.data))
                pub.remote_id=publish_id
                pub.status="enviado_tiktok_revisao"
                pub.error=(
                    "O TikTok aceitou o vídeo como rascunho, mas bloqueou a publicação pública automática porque "
                    "o cliente Direct Post ainda está sem a auditoria específica de Content Posting. Abra a notificação "
                    "do TikTok para revisar/publicar. Depois da auditoria Direct Post, o envio volta a ser automático."
                )
                db.commit()
                return
            raise
        pub.remote_id=publish_id; pub.status="processando_tiktok"; pub.error=""; db.commit()
        result=service.wait_for_final_status(token,publish_id,attempts=10,interval_seconds=3.0)
        status=str(result.get("status") or "").upper()
        if status=="PUBLISH_COMPLETE":
            pub.status="publicado"; pub.published_at=datetime.now(timezone.utc); pub.error=""
            post_ids=result.get("publicaly_available_post_id") or result.get("publicly_available_post_id") or []
            username=str(info.get("creator_username") or "").lstrip("@")
            if post_ids and username:
                pub.remote_url=f"https://www.tiktok.com/@{username}/video/{post_ids[0]}"
        elif status=="FAILED":
            pub.status="falhou"; pub.error=str(result.get("fail_reason") or "O TikTok informou falha no processamento.")[:2000]
        else:
            pub.status="processando_tiktok"
        db.commit()
    except Exception as exc:
        pub=db.get(Publication, publication_id) if 'pub' in locals() else None
        if pub: pub.status="falhou"; pub.error=str(exc)[:2000]; db.commit()
    finally: db.close()

@app.get("/integracoes/tiktok/conectar")
def tiktok_connect(request: Request):
    redirect=require_page_login(request)
    if redirect: return redirect
    try:
        service=TikTokService(); state=service.new_state(); request.session["tiktok_oauth_state"]=state
        return RedirectResponse(url=service.authorization_url(state),status_code=302)
    except TikTokError as exc:
        request.session["action_error"]=str(exc); return RedirectResponse(url="/social",status_code=303)

@app.get("/integracoes/tiktok/callback")
def tiktok_callback(request: Request, code: str|None=None, state: str|None=None, error: str|None=None, error_description: str|None=None, db: Session=Depends(get_db)):
    redirect=require_page_login(request)
    if redirect: return redirect
    expected=request.session.pop("tiktok_oauth_state",None)
    if error or not code or not state or state!=expected:
        request.session["action_error"]=error_description or "Autorização do TikTok cancelada ou inválida."; return RedirectResponse(url="/social",status_code=303)
    try:
        service=TikTokService(); connection=service.save_connection(db,service.exchange_code(code)); service.enrich_connection(db,connection); request.session["action_message"]="TikTok conectado com sucesso."
    except TikTokError as exc: request.session["action_error"]=str(exc)
    return RedirectResponse(url="/social",status_code=303)

@app.post("/integracoes/tiktok/desconectar")
def tiktok_disconnect(request: Request, csrf: str=Form(...), db: Session=Depends(get_db)):
    redirect=require_page_login(request)
    if redirect: return redirect
    validate_csrf(request,csrf); c=db.scalar(select(SocialConnection).where(SocialConnection.provider=="tiktok"))
    if c: db.delete(c); db.commit()
    request.session["action_message"]="TikTok desconectado."; return RedirectResponse(url="/social",status_code=303)

@app.post("/social/tiktok/publicar")
def tiktok_publish(
    background_tasks: BackgroundTasks, request: Request, csrf: str=Form(...), production_id: int=Form(...),
    caption: str=Form(...), privacy_level: str=Form(...), consent: str|None=Form(None),
    allow_comment: str|None=Form(None), allow_duet: str|None=Form(None), allow_stitch: str|None=Form(None),
    db: Session=Depends(get_db),
):
    redirect=require_page_login(request)
    if redirect: return redirect
    validate_csrf(request,csrf); production=db.get(Production,production_id)
    if not production or production.status!="aprovado": raise HTTPException(status_code=400,detail="Produção não aprovada.")
    if consent != "1":
        request.session["action_error"]="Confirme o envio deste vídeo ao TikTok antes de publicar."
        return RedirectResponse(url="/social",status_code=303)
    issues=tiktok_caption_issues(caption,production.script.product)
    if issues: request.session["action_error"]=" ".join(issues); return RedirectResponse(url="/social",status_code=303)
    try:
        service=TikTokService(); token=service.access_token(db); info=service.creator_info(token)
        options=info.get("privacy_level_options") or []
        if privacy_level not in options:
            raise TikTokError("A privacidade escolhida não é permitida para esta conta TikTok.")
    except TikTokError as exc:
        request.session["action_error"]=str(exc); return RedirectResponse(url="/social",status_code=303)
    pub=Publication(production_id=production_id,provider="tiktok",status="aguardando",caption=caption); db.add(pub); db.commit(); db.refresh(pub)
    background_tasks.add_task(_publish_tiktok_task,pub.id,privacy_level,allow_comment=="1",allow_duet=="1",allow_stitch=="1")
    request.session["action_message"]="Vídeo autorizado e enviado para processamento no TikTok."
    return RedirectResponse(url="/social",status_code=303)

@app.get("/integracoes/instagram/conectar")
def instagram_connect(request: Request):
    redirect = require_page_login(request)
    if redirect: return redirect
    service = InstagramService()
    try:
        state = service.new_state()
        request.session["instagram_oauth_state"] = state
        response = RedirectResponse(url=service.authorization_url(state), status_code=302)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        return response
    except InstagramError as exc:
        request.session["action_error"] = str(exc)
        return RedirectResponse(url="/social", status_code=303)


@app.get("/integracoes/instagram/callback")
def instagram_callback(request: Request, code: str | None = None, state: str | None = None, error: str | None = None, error_description: str | None = None, db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    expected = request.session.pop("instagram_oauth_state", None)
    if error:
        request.session["action_error"] = f"O Instagram não autorizou a conexão: {error_description or error}."
        return RedirectResponse(url="/social", status_code=303)
    if not code or not state or not expected or not secrets.compare_digest(state, expected):
        request.session["action_error"] = "Retorno OAuth inválido ou expirado. Tente conectar novamente."
        return RedirectResponse(url="/social", status_code=303)
    service = InstagramService()
    try:
        short = service.exchange_code(code)
        long_lived = service.exchange_long_lived(str(short["access_token"]))
        profile = service.profile(str(long_lived["access_token"]))
        connection = service.save_connection(db, long_lived, profile)
        service.subscribe_webhooks(connection.external_account_id, str(long_lived["access_token"]))
        request.session["action_message"] = (
            f"Instagram @{connection.account_name} conectado e inscrito para comentários e mensagens."
        )
    except Exception as exc:
        request.session["action_error"] = str(exc)
    return RedirectResponse(url="/social", status_code=303)


@app.post("/integracoes/instagram/desconectar")
def instagram_disconnect(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    InstagramService().disconnect(db)
    request.session["action_message"] = "Instagram desconectado."
    return RedirectResponse(url="/social", status_code=303)


@app.post("/integracoes/instagram/testar")
def instagram_test(request: Request, csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    try:
        connection, token = InstagramService().valid_token(db)
        profile = InstagramService().profile(token)
        connection.account_name = str(profile.get("username") or connection.account_name)
        connection.external_account_id = str(profile.get("user_id") or profile.get("id") or connection.external_account_id)
        connection.status = "conectado"
        db.commit()
        InstagramService().subscribe_webhooks(connection.external_account_id, token)
        request.session["action_message"] = f"Conexão e webhooks válidos com @{connection.account_name}."
    except Exception as exc:
        logger.exception("Falha no teste da conexão do Instagram")
        request.session["action_error"] = str(exc)
    return RedirectResponse(url="/social", status_code=303)


def _publish_instagram_background(publication_id: int) -> None:
    db = SessionLocal()
    try:
        InstagramService(timeout=45).publish_reel(db, publication_id)
    finally:
        db.close()


# Compatibilidade v1.0.48: Publication.status.in_(("aguardando", "processando", "publicado"))
# Esta produção já está na fila ou já foi publicada
@app.post("/social/instagram/publicar")
def instagram_publish(request: Request, production_id: int = Form(...), caption: str = Form(...), csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production or production.status != "aprovado":
        request.session["action_error"] = "Selecione uma produção aprovada."
        return RedirectResponse(url="/social", status_code=303)
    issues = caption_issues(caption, production.script.product)
    if issues:
        request.session["action_error"] = "Legenda não aprovada: " + " ".join(issues)
        return RedirectResponse(url="/social", status_code=303)
    existing = db.scalar(select(Publication).where(Publication.production_id == production_id, Publication.provider == "instagram", Publication.status.in_(("aguardando", "processando", "agendado", "publicado"))))
    if existing:
        request.session["action_error"] = "Esta produção já está na fila, agendada ou publicada no Instagram."
        return RedirectResponse(url="/social", status_code=303)
    db.add(Publication(production_id=production_id, provider="instagram", status="aguardando", caption=caption.strip()))
    db.commit()
    request.session["action_message"] = "Publicação adicionada à fila do Instagram."
    return RedirectResponse(url="/social", status_code=303)


@app.post("/social/instagram/agendar")
def instagram_schedule(request: Request, production_id: int = Form(...), caption: str = Form(...), scheduled_at: str = Form(...), csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    production = db.get(Production, production_id)
    if not production or production.status != "aprovado":
        request.session["action_error"] = "Selecione uma produção aprovada."
        return RedirectResponse(url="/social", status_code=303)
    issues = caption_issues(caption, production.script.product)
    if issues:
        request.session["action_error"] = "Legenda não aprovada: " + " ".join(issues)
        return RedirectResponse(url="/social", status_code=303)
    try:
        when = datetime.fromisoformat(scheduled_at)
        if when.tzinfo is None: when = when.replace(tzinfo=ZoneInfo(settings.app_timezone)).astimezone(timezone.utc)
    except ValueError:
        request.session["action_error"] = "Data e hora de agendamento inválidas."
        return RedirectResponse(url="/social", status_code=303)
    if when <= datetime.now(timezone.utc):
        request.session["action_error"] = "Escolha uma data futura."
        return RedirectResponse(url="/social", status_code=303)
    db.add(Publication(production_id=production_id, provider="instagram", status="agendado", caption=caption.strip(), scheduled_at=when))
    db.commit()
    request.session["action_message"] = "Reel agendado com sucesso."
    return RedirectResponse(url="/social", status_code=303)


@app.post("/social/instagram/lote")
def instagram_batch(request: Request, production_ids: list[int] = Form(...), csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    added = 0
    for production_id in production_ids:
        production = db.get(Production, production_id)
        if not production or production.status != "aprovado": continue
        exists = db.scalar(select(Publication.id).where(Publication.production_id == production_id, Publication.provider == "instagram", Publication.status.in_(("aguardando", "processando", "agendado", "publicado"))))
        if exists: continue
        db.add(Publication(production_id=production_id, provider="instagram", status="aguardando", caption=build_instagram_caption(production.script.product, production.script)))
        added += 1
    db.commit()
    request.session["action_message"] = f"{added} publicação(ões) adicionada(s) à fila."
    return RedirectResponse(url="/social", status_code=303)


@app.post("/social/instagram/campanha")
def create_instagram_campaign(request: Request, publication_id: int = Form(...), budget_total_brl: float = Form(...), duration_days: int = Form(3), csrf: str = Form(...), db: Session = Depends(get_db)):
    redirect = require_page_login(request)
    if redirect: return redirect
    validate_csrf(request, csrf)
    publication = db.get(Publication, publication_id)
    if not publication or publication.status != "publicado":
        request.session["action_error"] = "Selecione um Reel já publicado."
        return RedirectResponse(url="/social", status_code=303)
    existing = db.scalar(select(AdCampaign).where(AdCampaign.publication_id == publication_id, AdCampaign.status.in_(("rascunho", "pausado_pronto", "ativo"))))
    if existing:
        request.session["action_error"] = "Já existe uma campanha para esta publicação."
        return RedirectResponse(url="/social", status_code=303)
    destination = f"{settings.public_base_url.rstrip('/')}/go/{publication.id}"
    campaign = AdCampaign(publication_id=publication.id, budget_total_brl=budget_total_brl, duration_days=max(1, min(duration_days, 30)), destination_url=destination)
    db.add(campaign); db.commit(); db.refresh(campaign)
    try:
        MetaAdsService().create_campaign(db, campaign)
        request.session["action_message"] = "Campanha criada pausada na Meta para revisão. Ela não gastará até ser ativada."
    except Exception as exc:
        request.session["action_error"] = str(exc)
    return RedirectResponse(url="/social", status_code=303)


@app.get("/achadinhos", response_class=HTMLResponse)
def link_hub(request: Request, db: Session = Depends(get_db)):
    publications = db.scalars(select(Publication).where(Publication.provider == "instagram", Publication.status == "publicado").order_by(Publication.published_at.desc(), Publication.created_at.desc()).limit(60)).all()
    items, seen = [], set()
    for publication in publications:
        product = publication.production.script.product if publication.production and publication.production.script else None
        if not product or product.id in seen: continue
        seen.add(product.id)
        media = parse_media_urls(product.media_urls)
        price = f"R$ {product.price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") if product.price else ""
        items.append({"publication_id": publication.id, "title": naturalize_title(product.title), "image_url": media[0] if media else "", "price": price})
    return templates.TemplateResponse(request=request, name="social/link_hub.html", context=template_context(request, items=items))


@app.get("/go/{publication_id}")
def tracked_offer(publication_id: int, request: Request, db: Session = Depends(get_db)):
    publication = db.get(Publication, publication_id)
    if not publication or publication.status != "publicado" or not publication.production:
        raise HTTPException(status_code=404, detail="Oferta não encontrada")
    product = publication.production.script.product
    db.add(LinkClick(publication_id=publication.id, user_agent=request.headers.get("user-agent", "")[:1000], referrer=request.headers.get("referer", "")[:1000]))
    db.commit()
    return RedirectResponse(url=product.affiliate_url, status_code=302)
