from __future__ import annotations
from datetime import datetime, timedelta, timezone
import logging, threading, time
from sqlalchemy import select
from app.core.config import settings
from app.db.database import SessionLocal
from app.db.models import SitePublication
from app.services.zavomi_site import refresh_all_site_products
logger=logging.getLogger(__name__)
_stop=threading.Event(); _thread=None

def _due(db)->bool:
    last=db.scalar(select(SitePublication).where(SitePublication.trigger=="daily_refresh").order_by(SitePublication.id.desc()))
    return not last or not last.created_at or last.created_at < datetime.now(timezone.utc)-timedelta(hours=20)

def _run():
    while not _stop.is_set():
        try:
            db=SessionLocal()
            try:
                if _due(db):
                    refresh_all_site_products(db,publish=True,trigger="daily_refresh")
            finally: db.close()
        except Exception: logger.exception("Falha na atualização diária do site Zavomi")
        _stop.wait(max(900,int(settings.zavomi_daily_refresh_interval_seconds or 3600)))

def start_zavomi_site_worker():
    global _thread
    if not settings.zavomi_daily_refresh_enabled or (_thread and _thread.is_alive()): return
    _stop.clear(); _thread=threading.Thread(target=_run,name="zavomi-site-refresh",daemon=True); _thread.start()

def stop_zavomi_site_worker():
    _stop.set()
