from __future__ import annotations

import logging
import threading

from app.core.config import settings
from app.db.database import SessionLocal
from app.services.product_enrichment import enrich_incomplete_products

logger = logging.getLogger(__name__)
_stop = threading.Event()
_thread: threading.Thread | None = None


def _run() -> None:
    # Aguarda o serviço estabilizar e a carga inicial retomar antes da primeira
    # consulta externa; isso evita competir com o boot/deploy do Render.
    if _stop.wait(max(0, int(settings.product_enrichment_initial_delay_seconds or 0))):
        return
    while not _stop.is_set():
        try:
            db = SessionLocal()
            try:
                result = enrich_incomplete_products(
                    db,
                    batch_size=max(1, min(5, int(settings.product_enrichment_batch_size or 3))),
                )
                if result.get("processed"):
                    logger.info(
                        "Enriquecimento comercial: %s processados, %s melhorados, %s elegíveis",
                        result.get("processed"), result.get("updated"), result.get("eligible"),
                    )
            finally:
                db.close()
        except Exception:
            logger.exception("Falha no ciclo de enriquecimento comercial")
        _stop.wait(max(1800, int(settings.product_enrichment_interval_seconds or 3600)))


def start_product_enrichment_worker() -> None:
    global _thread
    if not settings.product_enrichment_enabled or (_thread and _thread.is_alive()):
        return
    _stop.clear()
    _thread = threading.Thread(target=_run, name="product-commercial-enrichment", daemon=True)
    _thread.start()


def stop_product_enrichment_worker() -> None:
    _stop.set()
