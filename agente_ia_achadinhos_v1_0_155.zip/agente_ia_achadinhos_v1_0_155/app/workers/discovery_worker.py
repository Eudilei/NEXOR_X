from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone

from sqlalchemy import inspect, text

from app.core.config import settings
from app.db.database import Base, engine, SessionLocal
from app.db.models import DiscoveryJob
from app.services.autonomous import run_discovery
from app.services.tiktok_discovery import run_tiktok_discovery
from app.services.product_enrichment import enrich_incomplete_products
from app.services.discovery_jobs import claim_next_job, recover_stale_jobs

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_stop_event = threading.Event()
_worker_thread: threading.Thread | None = None
_start_lock = threading.Lock()


def utcnow():
    return datetime.now(timezone.utc)


def progress(job_id: int, value: int, stage: str):
    db = SessionLocal()
    try:
        job = db.get(DiscoveryJob, job_id)
        if job:
            job.progress = max(0, min(100, int(value)))
            job.stage = str(stage)[:120]
            job.updated_at = utcnow()
            db.commit()
    finally:
        db.close()


def run_once() -> bool:
    db = SessionLocal()
    try:
        job = claim_next_job(db)
        if not job:
            return False
        job_id = job.id
        try:
            try:
                filters = json.loads(job.filters_json or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                filters = {}
            if job.source == "tiktok_shop":
                result = run_tiktok_discovery(
                    db,
                    filters=filters,
                    max_products=settings.discovery_max_products,
                    progress_callback=lambda p, s: progress(job_id, p, s),
                )
            else:
                result = run_discovery(
                    db,
                    max_products=settings.discovery_max_products,
                    progress_callback=lambda p, s: progress(job_id, p, s),
                )
            # Após uma varredura do Mercado Livre, fazemos um pequeno burst
            # de enriquecimento SOMENTE nos pré-selecionados do ranking. Ele
            # roda no worker da descoberta (nunca no boot web) e ignora o
            # agendamento apenas para estes candidatos recém-selecionados.
            if job.source != "tiktok_shop" and result.get("status") == "concluido":
                try:
                    burst = enrich_incomplete_products(
                        db,
                        batch_size=max(1, min(8, int(getattr(settings, "discovery_priority_enrichment_batch_size", 6) or 6))),
                        preselected_only=True,
                        ignore_schedule=True,
                    )
                    result["priority_enrichment"] = {
                        "eligible": burst.get("eligible", 0),
                        "processed": burst.get("processed", 0),
                        "updated": burst.get("updated", 0),
                        "errors": len(burst.get("errors") or []),
                    }
                except Exception:
                    logger.exception("Falha no enriquecimento prioritário pós-varredura")

            job = db.get(DiscoveryJob, job_id)
            if not job:
                return True
            job.result_json = json.dumps(result, ensure_ascii=False, default=str)
            job.message = str(result.get("message") or "Varredura finalizada.")[:2000]
            job.status = "failed" if result.get("status") in {"api_indisponivel", "erro_controlado"} else "completed"
            job.error = job.message if job.status == "failed" else ""
            job.progress = 100
            job.stage = "Concluída" if job.status == "completed" else "Falha controlada"
            job.finished_at = utcnow()
            job.updated_at = utcnow()
            db.commit()
        except Exception as exc:
            logger.exception("Falha no processamento da varredura")
            db.rollback()
            job = db.get(DiscoveryJob, job_id)
            if job:
                job.status = "failed"
                job.stage = "Falha inesperada"
                job.error = str(exc)[:2000]
                job.message = "A varredura falhou e pode ser iniciada novamente."
                job.finished_at = utcnow()
                job.updated_at = utcnow()
                db.commit()
        return True
    finally:
        db.close()



def _ensure_discovery_schema() -> None:
    inspector = inspect(engine)
    if "discovery_jobs" in inspector.get_table_names():
        existing = {column["name"] for column in inspector.get_columns("discovery_jobs")}
        with engine.begin() as conn:
            if "source" not in existing:
                conn.execute(text("ALTER TABLE discovery_jobs ADD COLUMN source VARCHAR(30) DEFAULT 'mercado_livre'"))
            if "filters_json" not in existing:
                conn.execute(text("ALTER TABLE discovery_jobs ADD COLUMN filters_json TEXT DEFAULT '{}'"))
    if "products" in inspector.get_table_names():
        existing = {column["name"] for column in inspector.get_columns("products")}
        required = {
            "external_product_id": "VARCHAR(120) DEFAULT ''",
            "monthly_sold_quantity": "INTEGER DEFAULT 0",
            "trend_score": "FLOAT DEFAULT 0",
            "source_metadata_json": "TEXT DEFAULT '{}'",
        }
        with engine.begin() as conn:
            for name, sql_type in required.items():
                if name not in existing:
                    conn.execute(text(f"ALTER TABLE products ADD COLUMN {name} {sql_type}"))

def worker_loop():
    Base.metadata.create_all(bind=engine)
    _ensure_discovery_schema()
    db = SessionLocal()
    try:
        recover_stale_jobs(db, stale_after_minutes=1)
    finally:
        db.close()
    logger.info("Processador de varredura iniciado no serviço web")
    while not _stop_event.is_set():
        worked = run_once()
        if not worked:
            _stop_event.wait(max(1, settings.discovery_worker_poll_seconds))


def start_embedded_worker() -> bool:
    global _worker_thread
    if not settings.discovery_embedded_worker_enabled:
        return False
    with _start_lock:
        if _worker_thread and _worker_thread.is_alive():
            return False
        _stop_event.clear()
        _worker_thread = threading.Thread(
            target=worker_loop,
            name="discovery-worker",
            daemon=True,
        )
        _worker_thread.start()
        return True


def stop_embedded_worker():
    _stop_event.set()


def main():
    worker_loop()


if __name__ == "__main__":
    main()
