from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select, update
from sqlalchemy.exc import OperationalError

from app.db.database import SessionLocal
from app.db.models import Production, InstagramCommentEvent
from app.services.heygen import get_video, download_video
from app.services.media_store import persist_file, media_url
from app.services.instagram_automation import InstagramCommentAutomation
from app.services.hybrid_video import create_hybrid_direction
from app.services.production import (
    storage_root,
    compose_product_first_video,
    parse_media_urls,
    generate_production_assets,
    public_media_url,
)

logger = logging.getLogger(__name__)
_stop = threading.Event()
_thread: threading.Thread | None = None
_lock = threading.Lock()


def _manifest(raw: str | None) -> dict:
    try:
        value = json.loads(raw or "{}")
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _claim(production_id: int) -> bool:
    db = SessionLocal()
    try:
        result = db.execute(
            update(Production)
            .where(Production.id == production_id, Production.status.in_(["na_fila", "montando"]))
            .values(status="montando_ativo", error="")
        )
        db.commit()
        return bool(result.rowcount)
    finally:
        db.close()


def _finish_file(db, production: Production, target: Path, manifest: dict) -> None:
    if not target.exists() or target.stat().st_size < 20_000:
        raise RuntimeError("O MP4 final não passou na validação de tamanho")
    # Evita gravar blobs grandes no PostgreSQL do Render, que pode encerrar a
    # conexão durante INSERTs de mídia. O arquivo final fica no storage local
    # servido pela rota /media, preservando a revisão e o download.
    if target.stat().st_size > 8 * 1024 * 1024:
        raise RuntimeError("O vídeo final ficou maior que 8 MB. A montagem será refeita com compressão segura.")
    relative = target.relative_to(storage_root()).as_posix()
    production.video_path = str(target)
    # Persiste o MP4 no banco para sobreviver a reinícios do Render. O arquivo
    # local continua disponível para revisão, mas a URL pública usada pela Meta
    # aponta para o ativo persistente.
    asset = persist_file(
        db, production_id=production.id, path=target,
        content_type="video/mp4", replace_name=True,
    )
    production.video_url = media_url(asset.id)
    production.status = "revisao"
    production.error = ""
    manifest.update({
        "assembly": "completed",
        "assembly_finished_at": datetime.now(timezone.utc).isoformat(),
        "worker": "persistent_queue_v3_fast",
        "progress": 100,
    })
    production.source_manifest = json.dumps(manifest, ensure_ascii=False)
    db.commit()


def _assemble_heygen(db, production: Production, manifest: dict) -> None:
    remote_url = str(manifest.get("heygen_video_url") or "")
    if not remote_url:
        raise RuntimeError("A URL concluída da HeyGen não foi registrada")
    folder = storage_root() / "productions" / str(production.id)
    folder.mkdir(parents=True, exist_ok=True)
    presenter = folder / "heygen_presenter.mp4"
    if not presenter.exists() or presenter.stat().st_size < 1024:
        presenter.write_bytes(download_video(remote_url))
    product = production.script.product
    images = parse_media_urls(manifest.get("job", {}).get("selected_media_urls")) or parse_media_urls(production.script.selected_media_urls) or parse_media_urls(product.media_urls)
    if len(images) < 2:
        raise RuntimeError("O anúncio não possui duas fotos válidas para a montagem")
    manifest["progress"] = 35
    production.source_manifest = json.dumps(manifest, ensure_ascii=False)
    db.commit()
    target = folder / "product_first_video.mp4"
    compose_product_first_video(
        images, presenter, target, production.script.duration_seconds,
        production.script.hook, production.script.call_to_action,
        product_title=product.title, on_screen_text=production.script.on_screen_text,
        price=product.price, rating=product.rating, review_count=product.review_count,
        sold_quantity=product.sold_quantity,
    )
    _finish_file(db, production, target, manifest)


def _assemble_local(db, production: Production, manifest: dict) -> None:
    script = production.script
    product = script.product
    job = manifest.get("job") if isinstance(manifest.get("job"), dict) else {}
    mode = str(job.get("mode") or "free")
    manifest["progress"] = 15
    production.source_manifest = json.dumps(manifest, ensure_ascii=False)
    db.commit()
    media_urls = parse_media_urls(job.get("selected_media_urls")) or parse_media_urls(script.selected_media_urls) or parse_media_urls(product.media_urls)
    effective_hook = script.hook
    effective_narration = script.narration
    effective_screen_text = script.on_screen_text
    effective_scene_plan: list[dict] | None = None
    if mode == "hybrid":
        direction = create_hybrid_direction(
            product_title=product.title, description=product.original_description,
            hook=script.hook, narration=script.narration, on_screen_text=script.on_screen_text,
            media_urls=media_urls, duration_seconds=script.duration_seconds,
        )
        media_urls = [media_urls[i] for i in direction.image_order if 0 <= i < len(media_urls)]
        effective_hook = direction.hook
        effective_narration = direction.narration
        effective_screen_text = direction.on_screen_text
        effective_scene_plan = direction.scene_plan
        manifest["hybrid_direction"] = direction.to_dict()
        job["hybrid_provider"] = direction.provider
        job["hybrid_fallback_used"] = direction.fallback_used
    result = generate_production_assets(
        production.id, product.title, effective_hook, effective_narration, script.duration_seconds,
        presenter_gender=script.presenter_gender, presenter_age=script.presenter_age,
        presenter_energy=script.presenter_energy, presenter_style=script.presenter_style,
        voice=script.voice, voice_instructions=script.voice_instructions,
        on_screen_text=effective_screen_text,
        product_media_urls=media_urls,
        original_description=product.original_description,
        use_ai_voice=(mode == "ai"), use_free_voice=(mode in {"free", "hybrid"}),
        free_voice=str(job.get("free_voice") or "auto"),
        spoken_text=(f"{effective_hook} {effective_narration} {script.call_to_action}" if mode == "hybrid" else str(job.get("spoken_text") or "")),
        call_to_action=script.call_to_action, narration_style=script.format,
        price=product.price, rating=product.rating,
        review_count=product.review_count, sold_quantity=product.sold_quantity,
        scene_plan=effective_scene_plan,
    )
    generated_manifest = _manifest(result.get("source_manifest"))
    manifest.update(generated_manifest)
    manifest["job"] = job
    _finish_file(db, production, Path(result["video_path"]), manifest)


def _assemble(production_id: int) -> None:
    if not _claim(production_id):
        return
    db = SessionLocal()
    try:
        production = db.get(Production, production_id)
        if not production:
            return
        manifest = _manifest(production.source_manifest)
        manifest.update({
            "assembly": "active",
            "assembly_started_at": datetime.now(timezone.utc).isoformat(),
            "assembly_timeout_seconds": 150,
            "progress": 10,
        })
        production.source_manifest = json.dumps(manifest, ensure_ascii=False)
        db.commit()
        if production.provider == "heygen":
            _assemble_heygen(db, production, manifest)
        else:
            _assemble_local(db, production, manifest)
    except Exception as exc:
        logger.exception("Falha ao montar produção %s", production_id)
        try:
            db.rollback()
        except Exception:
            pass
        # Uma queda temporária do PostgreSQL não pode matar o worker nem marcar
        # definitivamente a produção como falha. Reabre uma sessão limpa.
        try:
            db.close()
        except Exception:
            pass
        recovery = SessionLocal()
        try:
            production = recovery.get(Production, production_id)
            if production:
                manifest = _manifest(production.source_manifest)
                attempts = int(manifest.get("assembly_attempts") or 0) + 1
                manifest.update({
                    "assembly_attempts": attempts,
                    "last_assembly_error": str(exc)[:1000],
                    "progress": 0,
                })
                production.source_manifest = json.dumps(manifest, ensure_ascii=False)
                transient_db_error = isinstance(exc, OperationalError) or "server closed the connection" in str(exc).lower()
                if transient_db_error:
                    production.status = "na_fila"
                else:
                    production.status = "falhou" if attempts >= 2 else "na_fila"
                production.error = str(exc)[:2000]
                recovery.commit()
        except Exception:
            logger.exception("Não foi possível registrar a recuperação da produção %s", production_id)
            try:
                recovery.rollback()
            except Exception:
                pass
        finally:
            recovery.close()
    finally:
        try:
            db.close()
        except Exception:
            pass


def _poll_heygen() -> bool:
    db = SessionLocal()
    try:
        production = db.scalar(select(Production).where(
            Production.provider == "heygen", Production.status == "processando"
        ).order_by(Production.created_at.asc()))
        if not production or not production.external_job_id:
            return False
        try:
            data = get_video(production.external_job_id)
            status = str(data.get("status") or "").lower()
            if status in {"completed", "success", "succeeded"}:
                url = data.get("video_url") or data.get("url")
                if not url:
                    raise RuntimeError("HeyGen concluiu sem URL")
                manifest = _manifest(production.source_manifest)
                manifest.update({"heygen_video_url": str(url), "heygen_status": status, "assembly": "queued", "progress": 0})
                production.source_manifest = json.dumps(manifest, ensure_ascii=False)
                production.status = "na_fila"
                production.error = ""
                db.commit()
                return True
            if status in {"failed", "error"}:
                production.status = "falhou"
                production.error = str(data.get("failure_message") or data.get("error") or "Falha HeyGen")[:2000]
                db.commit()
                return True
        except Exception as exc:
            production.error = f"Consulta temporária: {str(exc)[:500]}"
            db.commit()
        return False
    finally:
        db.close()


def run_once() -> bool:
    now = datetime.now(timezone.utc)
    db = SessionLocal()
    try:
        comment_id = db.scalar(select(InstagramCommentEvent.id).where(
            InstagramCommentEvent.status.in_(["aguardando", "tentar_novamente"]),
            (InstagramCommentEvent.next_attempt_at.is_(None)) | (InstagramCommentEvent.next_attempt_at <= now),
        ).order_by(InstagramCommentEvent.created_at.asc()))
        queued = db.scalar(select(Production.id).where(
            Production.status.in_(["na_fila", "montando"])
        ).order_by(Production.created_at.asc()))
    finally:
        db.close()
    if comment_id:
        db = SessionLocal()
        try:
            InstagramCommentAutomation().process_event(db, int(comment_id))
        finally:
            db.close()
        return True
    if queued:
        _assemble(int(queued))
        return True
    return _poll_heygen()


def loop() -> None:
    # Dá tempo para o serviço responder ao health check do Render antes de tocar
    # no banco ou iniciar FFmpeg durante um deploy.
    if _stop.wait(15):
        return
    while not _stop.is_set():
        try:
            db = SessionLocal()
            try:
                db.execute(update(Production).where(Production.status == "montando_ativo").values(status="na_fila"))
                db.commit()
            finally:
                db.close()
            break
        except Exception:
            logger.exception("Banco indisponível ao iniciar worker; nova tentativa em 5 segundos")
            if _stop.wait(5):
                return
    logger.info("Worker persistente e fila de produções iniciados")
    while not _stop.is_set():
        try:
            worked = run_once()
            if not worked:
                _stop.wait(2)
        except Exception:
            logger.exception("Falha temporária no ciclo do worker; ele continuará ativo")
            _stop.wait(5)


def start_production_worker() -> bool:
    global _thread
    with _lock:
        if _thread and _thread.is_alive():
            return False
        _stop.clear()
        _thread = threading.Thread(target=loop, name="production-worker", daemon=True)
        _thread.start()
        return True


def stop_production_worker() -> None:
    _stop.set()
