import hmac
from fastapi import HTTPException, Request, status
from app.core.config import settings


def credentials_valid(username: str, password: str) -> bool:
    return hmac.compare_digest(username, settings.admin_username) and hmac.compare_digest(
        password, settings.admin_password
    )


def require_api_login(request: Request) -> None:
    if not request.session.get("authenticated"):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Autenticação necessária")


def is_logged_in(request: Request) -> bool:
    return bool(request.session.get("authenticated"))
