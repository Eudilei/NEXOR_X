from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Agente IA de Achadinhos"
    app_env: str = "production"
    database_url: str = "sqlite:///./achadinhos.db"

    admin_username: str = "admin"
    admin_password: str = "troque-esta-senha"
    session_secret: str = "troque-este-segredo"
    session_max_age_seconds: int = 28800
    enable_api_docs: bool = False

    openai_api_key: str | None = None
    mercado_livre_client_id: str | None = None
    mercado_livre_client_secret: str | None = None
    mercado_livre_redirect_uri: str = "https://agente-ia-achadinhos.onrender.com/oauth/mercadolivre/callback"
    mercado_livre_access_token: str | None = None  # fallback temporário/legado
    # Integração opcional com um gerador OFICIAL de links da conta de afiliado.
    # O agente nunca transforma um link comum em afiliado por conta própria.
    mercado_livre_affiliate_api_url: str | None = None
    mercado_livre_affiliate_api_token: str | None = None
    mercado_livre_affiliate_api_timeout_seconds: int = 20
    # Alternativa para feed/mapa oficial exportado pela conta: JSON no formato
    # {"MLB123": "https://link-afiliado...", "https://produto...": "https://link..."}
    mercado_livre_affiliate_links_json: str | None = None
    discovery_auto_enabled: bool = True
    discovery_max_products: int = 25
    discovery_parallel_workers: int = 4
    # Limites de resiliência da varredura. Consultas externas nunca podem
    # manter o job preso indefinidamente; dados já obtidos são preservados e
    # fontes lentas ficam para a próxima atualização.
    mercado_livre_http_timeout_seconds: float = 8.0
    discovery_offer_probe_limit: int = 3
    discovery_candidate_timeout_seconds: float = 28.0
    discovery_scan_timeout_seconds: float = 600.0
    discovery_enrichment_multiplier: int = 3
    discovery_worker_poll_seconds: int = 3
    discovery_embedded_worker_enabled: bool = True
    # Fallback opcional de navegador real para dados públicos que o HTML bruto
    # ou a API não expõem. Nunca usa login/cookies pessoais nem tenta contornar CAPTCHA.
    mercado_livre_browser_fallback_enabled: bool = False
    mercado_livre_browser_timeout_seconds: float = 7.0
    mercado_livre_browser_max_products_per_scan: int = 2
    mercado_livre_browser_wait_ms: int = 600
    initial_catalog_bootstrap_enabled: bool = True
    initial_catalog_products_per_category: int = 25
    initial_catalog_max_rounds: int = 4
    initial_catalog_pause_seconds: float = 2.0
    allow_sqlite_in_production: bool = False
    mercado_livre_discovery_category_ids: str | None = None
    meta_app_id: str | None = None
    meta_app_secret: str | None = None
    instagram_redirect_uri: str = "https://agente-ia-achadinhos.onrender.com/integracoes/instagram/callback"
    instagram_webhook_verify_token: str = "troque-este-token-do-webhook"
    instagram_comment_automation_enabled: bool = True
    instagram_webhook_require_signature: bool = True
    meta_app_live_mode: bool = False
    privacy_contact_email: str = "contato@zavomi.com.br"
    meta_ads_access_token: str | None = None
    meta_ad_account_id: str | None = None
    meta_page_id: str | None = None
    meta_ads_max_total_brl: float = 30.0
    tiktok_client_key: str | None = None
    tiktok_client_secret: str | None = None
    tiktok_redirect_uri: str = "https://agente-ia-achadinhos.onrender.com/integracoes/tiktok/callback"
    tiktok_default_privacy_level: str = "PUBLIC_TO_EVERYONE"
    # Verificação de propriedade das URLs no TikTok for Developers.
    # Mantemos um par por URL porque o TikTok gera assinaturas independentes.
    tiktok_terms_verification_filename: str = "tiktokJQz98WyODAiMd8f8amEcvdcilL5JDScP.txt"
    tiktok_terms_verification_content: str = "tiktok-developers-site-verification=JQz98WyODAiMd8f8amEcvdcilL5JDScP"
    tiktok_privacy_verification_filename: str = "tiktokcW0wljDqyHw9qVE9FP8iLzSmegp0xq8c.txt"
    tiktok_privacy_verification_content: str = "tiktok-developers-site-verification=cW0wljDqyHw9qVE9FP8iLzSmegp0xq8c"
    tiktok_root_verification_filename: str = "tiktokIpPyrWx7yFvNU8TwOPA48mxqauCSxRZL.txt"
    tiktok_root_verification_content: str = "tiktok-developers-site-verification=IpPyrWx7yFvNU8TwOPA48mxqauCSxRZL"
    # Compatibilidade com instalações anteriores que usavam uma única assinatura.
    tiktok_url_verification_filename: str = "tiktok-developers-site-verification.txt"
    tiktok_url_verification_content: str | None = None
    tiktok_shop_app_key: str | None = None
    tiktok_shop_app_secret: str | None = None
    tiktok_shop_access_token: str | None = None
    tiktok_shop_creator_search_path: str | None = None
    tiktok_shop_api_base_url: str = "https://open-api.tiktokglobalshop.com"
    tiktok_shop_region: str = "BR"
    tiktok_shop_default_min_commission_pct: float = 5.0
    tiktok_shop_default_min_monthly_sales: int = 100
    tiktok_shop_default_min_stock: int = 20
    public_base_url: str = "https://agente-ia-achadinhos.onrender.com"
    zavomi_site_url: str = "https://www.zavomi.com.br"
    github_site_owner: str = "Eudilei"
    github_site_repo: str = "zavomi-site"
    github_site_branch: str = "main"
    github_site_catalog_path: str = "data/products.json"
    github_site_token: str | None = None
    zavomi_daily_refresh_enabled: bool = True
    zavomi_daily_refresh_hour: int = 6
    zavomi_daily_refresh_interval_seconds: int = 3600
    # Enriquecimento incremental de produtos com métricas ausentes. Processa
    # pequenos lotes para não sobrecarregar a API/página pública do marketplace.
    product_enrichment_enabled: bool = True
    product_enrichment_interval_seconds: int = 3600
    product_enrichment_batch_size: int = 3
    product_enrichment_initial_delay_seconds: int = 300
    discovery_priority_enrichment_batch_size: int = 6
    app_timezone: str = "America/Manaus"
    storage_dir: str = "storage"
    openai_image_model: str = "gpt-image-1"
    hook_image_generation_enabled: bool = True
    hook_image_duration_seconds: float = 3.0
    openai_tts_model: str = "gpt-4o-mini-tts"
    openai_tts_voice: str = "coral"
    openai_script_model: str = "gpt-4.1-mini"
    openai_script_timeout_seconds: int = 75
    # Diretor multimodal gratuito opcional. Quando indisponível, o motor híbrido
    # continua automaticamente com o Diretor Zavomi e a voz gratuita atual.
    gemini_api_key: str | None = None
    gemini_video_model: str = "gemini-3.5-flash"
    gemini_timeout_seconds: int = 75
    # Roteirista multimodal gratuito: analisa fotos reais + descrição + métricas.
    # A chave pode ser criada sem custo no Google AI Studio, respeitando os limites do free tier.
    gemini_script_model: str = "gemini-3.6-flash"
    gemini_script_fallback_models: str = "gemini-3.5-flash,gemini-2.5-flash,gemini-2.5-flash-lite"
    gemini_script_timeout_seconds: int = 60
    gemini_script_max_images: int = 4
    # TTS expressivo gratuito: usa a mesma GEMINI_API_KEY do roteirista visual.
    gemini_tts_model: str = "gemini-3.1-flash-tts-preview"
    gemini_tts_timeout_seconds: int = 90
    enable_ai_voice: bool = True
    heygen_api_key: str | None = None
    # Mantidos apenas por compatibilidade com instalações antigas; a v1.0.7
    # seleciona avatar e voz pela biblioteca automática da HeyGen.
    heygen_female_avatar_id: str | None = None
    heygen_male_avatar_id: str | None = None
    heygen_neutral_avatar_id: str | None = None
    heygen_female_voice_id: str | None = None
    heygen_male_voice_id: str | None = None
    heygen_neutral_voice_id: str | None = None
    heygen_engine: str = "avatar_iv"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def insecure_defaults(self) -> bool:
        return (
            self.admin_password == "troque-esta-senha"
            or self.session_secret == "troque-este-segredo"
        )

    @property
    def tiktok_shop_api_configured(self) -> bool:
        return bool(
            self.tiktok_shop_app_key
            and self.tiktok_shop_app_secret
            and self.tiktok_shop_access_token
            and self.tiktok_shop_creator_search_path
        )

    @property
    def mercado_livre_oauth_configured(self) -> bool:
        return bool(
            self.mercado_livre_client_id
            and self.mercado_livre_client_secret
            and self.mercado_livre_redirect_uri
        )


settings = Settings()
