from fastapi import APIRouter, Depends
from app.core.security import require_api_login
from app.models.schemas import ProductInput, ProductScore, ScriptRequest, ScriptOutput
from app.services.scoring import score_product
from app.services.scripts import generate_script

router = APIRouter(dependencies=[Depends(require_api_login)])


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/products/score", response_model=ProductScore)
def evaluate_product(product: ProductInput) -> ProductScore:
    return score_product(product)


@router.post("/content/script", response_model=ScriptOutput)
def create_script(request: ScriptRequest) -> ScriptOutput:
    return generate_script(request)
