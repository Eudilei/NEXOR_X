from collections.abc import Generator
import os

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import settings

DATABASE_URL = settings.database_url
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgres://"):]
elif DATABASE_URL.startswith("postgresql://") and "+psycopg" not in DATABASE_URL:
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgresql://"):]

connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine_kwargs = {"pool_pre_ping": True, "pool_recycle": 180}
if not settings.database_url.startswith("sqlite"):
    # A varredura mantém uma sessão ativa enquanto consulta as fontes e usa
    # sessões curtas adicionais para salvar o progresso. O pool anterior
    # (2 conexões, sem overflow) esgotava durante tarefas em segundo plano.
    pool_size = max(2, int(os.getenv("DB_POOL_SIZE", "5")))
    max_overflow = max(0, int(os.getenv("DB_MAX_OVERFLOW", "5")))
    pool_timeout = max(15, int(os.getenv("DB_POOL_TIMEOUT", "60")))
    engine_kwargs.update({
        "pool_size": pool_size,
        "max_overflow": max_overflow,
        "pool_timeout": pool_timeout,
        "pool_use_lifo": True,
    })
    connect_args.update({"connect_timeout": 10, "keepalives": 1, "keepalives_idle": 30, "keepalives_interval": 10, "keepalives_count": 3})
engine = create_engine(DATABASE_URL, connect_args=connect_args, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
