from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, LargeBinary, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(180), index=True)
    category: Mapped[str] = mapped_column(String(40), index=True)
    marketplace: Mapped[str] = mapped_column(String(40), default="mercado_livre", index=True)
    external_product_id: Mapped[str] = mapped_column(String(120), default="", index=True)
    monthly_sold_quantity: Mapped[int] = mapped_column(Integer, default=0)
    trend_score: Mapped[float] = mapped_column(Float, default=0)
    source_metadata_json: Mapped[str] = mapped_column(Text, default="{}")
    price: Mapped[float] = mapped_column(Float)
    original_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    rating: Mapped[float] = mapped_column(Float, default=0)
    review_count: Mapped[int] = mapped_column(Integer, default=0)
    sold_quantity: Mapped[int] = mapped_column(Integer, default=0)
    seller_reputation: Mapped[float] = mapped_column(Float, default=0)
    commission_pct: Mapped[float] = mapped_column(Float, default=0)
    stock_available: Mapped[bool] = mapped_column(Boolean, default=True)
    visual_quality: Mapped[float] = mapped_column(Float, default=5)
    demonstration_ease: Mapped[float] = mapped_column(Float, default=5)
    novelty: Mapped[float] = mapped_column(Float, default=5)
    return_risk: Mapped[float] = mapped_column(Float, default=5)
    affiliate_url: Mapped[str] = mapped_column(Text)
    media_license: Mapped[str] = mapped_column(String(50), default="origem_nao_confirmada")
    original_description: Mapped[str] = mapped_column(Text, default="")
    media_urls: Mapped[str] = mapped_column(Text, default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    score: Mapped[float] = mapped_column(Float, default=0)
    classification: Mapped[str] = mapped_column(String(30), default="Em análise")
    status: Mapped[str] = mapped_column(String(30), default="em_analise", index=True)
    score_reasons: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    scripts: Mapped[list["Script"]] = relationship(back_populates="product", cascade="all, delete-orphan")



class Script(Base):
    __tablename__ = "scripts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    format: Mapped[str] = mapped_column(String(50), default="problema_solucao")
    duration_seconds: Mapped[int] = mapped_column(Integer, default=40)
    production_engine: Mapped[str] = mapped_column(String(30), default="free_editor")
    presenter_type: Mapped[str] = mapped_column(String(30), default="realista")
    presenter_gender: Mapped[str] = mapped_column(String(30), default="automatico")
    presenter_age: Mapped[str] = mapped_column(String(30), default="jovem")
    presenter_energy: Mapped[str] = mapped_column(String(30), default="alegre")
    presenter_style: Mapped[str] = mapped_column(String(40), default="creator")
    voice: Mapped[str] = mapped_column(String(30), default="coral")
    voice_instructions: Mapped[str] = mapped_column(Text, default="")
    variation_index: Mapped[int] = mapped_column(Integer, default=0)
    writer_engine: Mapped[str] = mapped_column(String(30), default="free_ai")
    creativity_level: Mapped[str] = mapped_column(String(30), default="equilibrado")
    target_platforms: Mapped[str] = mapped_column(String(40), default="all")
    heygen_avatar_id: Mapped[str] = mapped_column(String(180), default="")
    heygen_avatar_name: Mapped[str] = mapped_column(String(180), default="")
    heygen_avatar_preview_url: Mapped[str] = mapped_column(Text, default="")
    heygen_voice_id: Mapped[str] = mapped_column(String(180), default="")
    heygen_voice_name: Mapped[str] = mapped_column(String(180), default="")
    heygen_voice_preview_url: Mapped[str] = mapped_column(Text, default="")
    hook: Mapped[str] = mapped_column(Text)
    narration: Mapped[str] = mapped_column(Text)
    on_screen_text: Mapped[str] = mapped_column(Text)
    selected_media_urls: Mapped[str] = mapped_column(Text, default="")
    caption: Mapped[str] = mapped_column(Text)
    call_to_action: Mapped[str] = mapped_column(Text)
    hashtags: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="rascunho", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    product: Mapped[Product] = relationship(back_populates="scripts")


class ProductObservation(Base):
    __tablename__ = "product_observations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"), index=True)
    price: Mapped[float] = mapped_column(Float, default=0)
    rating: Mapped[float] = mapped_column(Float, default=0)
    review_count: Mapped[int] = mapped_column(Integer, default=0)
    sold_quantity: Mapped[int] = mapped_column(Integer, default=0)
    source_rank: Mapped[int | None] = mapped_column(Integer, nullable=True)
    stock_available: Mapped[bool] = mapped_column(Boolean, default=False)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class OAuthCredential(Base):
    __tablename__ = "oauth_credentials"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    access_token_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    refresh_token_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    token_type: Mapped[str] = mapped_column(String(30), default="Bearer")
    scope: Mapped[str | None] = mapped_column(Text, nullable=True)
    external_user_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class DiscoveryJob(Base):
    __tablename__ = "discovery_jobs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[str] = mapped_column(String(30), default="queued", index=True)
    source: Mapped[str] = mapped_column(String(30), default="mercado_livre", index=True)
    filters_json: Mapped[str] = mapped_column(Text, default="{}")
    stage: Mapped[str] = mapped_column(String(120), default="Aguardando início")
    progress: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[str] = mapped_column(Text, default="")
    result_json: Mapped[str] = mapped_column(Text, default="{}")
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Production(Base):
    __tablename__ = "productions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    script_id: Mapped[int] = mapped_column(ForeignKey("scripts.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(30), default="rascunho", index=True)
    media_source: Mapped[str] = mapped_column(String(50), default="gerada_por_ia")
    video_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    video_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_manifest: Mapped[str] = mapped_column(Text, default="{}")
    error: Mapped[str] = mapped_column(Text, default="")
    provider: Mapped[str] = mapped_column(String(30), default="local")
    external_job_id: Mapped[str] = mapped_column(String(180), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    script: Mapped[Script] = relationship()


class MediaAsset(Base):
    __tablename__ = "media_assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    production_id: Mapped[int] = mapped_column(ForeignKey("productions.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    content_type: Mapped[str] = mapped_column(String(80), default="application/octet-stream")
    data: Mapped[bytes] = mapped_column(LargeBinary)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    production: Mapped[Production] = relationship()


class SocialConnection(Base):
    __tablename__ = "social_connections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    account_name: Mapped[str] = mapped_column(String(120), default="")
    external_account_id: Mapped[str] = mapped_column(String(120), default="")
    access_token_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    refresh_token_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="desconectado")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Publication(Base):
    __tablename__ = "publications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    production_id: Mapped[int] = mapped_column(ForeignKey("productions.id", ondelete="CASCADE"), index=True)
    provider: Mapped[str] = mapped_column(String(30), index=True)
    status: Mapped[str] = mapped_column(String(30), default="aguardando", index=True)
    caption: Mapped[str] = mapped_column(Text, default="")
    remote_id: Mapped[str] = mapped_column(String(180), default="")
    remote_url: Mapped[str] = mapped_column(Text, default="")
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)

    production: Mapped[Production] = relationship()


class LinkClick(Base):
    __tablename__ = "link_clicks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    publication_id: Mapped[int] = mapped_column(ForeignKey("publications.id", ondelete="CASCADE"), index=True)
    user_agent: Mapped[str] = mapped_column(Text, default="")
    referrer: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

    publication: Mapped[Publication] = relationship()


class InstagramCommentEvent(Base):
    __tablename__ = "instagram_comment_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    comment_id: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    media_id: Mapped[str] = mapped_column(String(180), index=True)
    publication_id: Mapped[int | None] = mapped_column(ForeignKey("publications.id", ondelete="SET NULL"), nullable=True, index=True)
    username: Mapped[str] = mapped_column(String(180), default="")
    text: Mapped[str] = mapped_column(Text, default="")
    intent: Mapped[str] = mapped_column(String(40), default="ignorado", index=True)
    status: Mapped[str] = mapped_column(String(40), default="recebido", index=True)
    private_reply_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    public_reply_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    error: Mapped[str] = mapped_column(Text, default="")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    last_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    publication: Mapped[Publication | None] = relationship()


class SitePublication(Base):
    __tablename__ = "site_publications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[str] = mapped_column(String(40), default="aguardando", index=True)
    trigger: Mapped[str] = mapped_column(String(60), default="manual")
    product_count: Mapped[int] = mapped_column(Integer, default=0)
    commit_sha: Mapped[str] = mapped_column(String(180), default="")
    site_url: Mapped[str] = mapped_column(Text, default="https://www.zavomi.com.br")
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DataDeletionRequest(Base):
    __tablename__ = "data_deletion_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    confirmation_code: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    instagram_username: Mapped[str] = mapped_column(String(180), default="", index=True)
    status: Mapped[str] = mapped_column(String(40), default="recebida", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AdCampaign(Base):
    __tablename__ = "ad_campaigns"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    publication_id: Mapped[int] = mapped_column(ForeignKey("publications.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(40), default="rascunho", index=True)
    placements: Mapped[str] = mapped_column(String(80), default="instagram_reels,instagram_stories")
    budget_total_brl: Mapped[float] = mapped_column(Float, default=0)
    duration_days: Mapped[int] = mapped_column(Integer, default=3)
    destination_url: Mapped[str] = mapped_column(Text, default="")
    remote_campaign_id: Mapped[str] = mapped_column(String(180), default="")
    remote_adset_id: Mapped[str] = mapped_column(String(180), default="")
    remote_ad_id: Mapped[str] = mapped_column(String(180), default="")
    error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    publication: Mapped[Publication] = relationship()


class InitialCatalogState(Base):
    __tablename__ = "initial_catalog_state"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    status: Mapped[str] = mapped_column(String(40), default="idle", index=True)
    target_per_category: Mapped[int] = mapped_column(Integer, default=25)
    total_target: Mapped[int] = mapped_column(Integer, default=500)
    total_products: Mapped[int] = mapped_column(Integer, default=0)
    completed_categories: Mapped[int] = mapped_column(Integer, default=0)
    current_category: Mapped[str] = mapped_column(String(80), default="")
    progress_json: Mapped[str] = mapped_column(Text, default="{}")
    last_message: Mapped[str] = mapped_column(Text, default="")
    last_error: Mapped[str] = mapped_column(Text, default="")
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
