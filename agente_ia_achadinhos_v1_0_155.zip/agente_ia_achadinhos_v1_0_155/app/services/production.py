from __future__ import annotations

import asyncio
import base64
import json
import logging
import io
import hashlib
import os
import re
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Iterable

import httpx
from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageOps, ImageFilter
import imageio_ffmpeg

from app.core.config import settings
from app.services.scripts import product_visual_facts

logger = logging.getLogger(__name__)

# v1.0.146 — controle local de cota/retry do Gemini TTS.
# Evita martelar um modelo que acabou de responder 429 e tenta outro modelo
# compatível antes de desistir. O cache da prévia continua sendo a primeira
# linha de defesa para não repetir síntese já concluída.
_GEMINI_TTS_MODEL_COOLDOWN_UNTIL: dict[str, float] = {}
_GEMINI_TTS_LAST_GOOD_MODEL: str | None = None
_GEMINI_TTS_RETRY_DELAYS = (0.0, 2.5, 6.0)

VIDEO_SIZE = (720, 1280)
VIDEO_FPS = 25
RENDER_LOCK_MAX_AGE_SECONDS = 90
ALLOWED_VIDEO_TYPES = {"video/mp4"}
ALLOWED_IMAGE_TYPES = {"image/png", "image/jpeg", "image/webp"}


def storage_root() -> Path:
    root = Path(settings.storage_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    (root / "productions").mkdir(exist_ok=True)
    return root


def public_media_url(relative_path: str) -> str:
    return f"{settings.public_base_url.rstrip('/')}/media/{relative_path.lstrip('/')}"


def _font(size: int):
    for candidate in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
    ):
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size=size)
    return ImageFont.load_default()


def create_title_card(title: str, subtitle: str, output: Path) -> Path:
    canvas = Image.new("RGB", VIDEO_SIZE, "#071426")
    draw = ImageDraw.Draw(canvas)
    title_font = _font(74)
    sub_font = _font(42)
    margin = 90
    wrapped = _wrap_text(draw, title, title_font, VIDEO_SIZE[0] - 2 * margin)
    y = 500
    for line in wrapped:
        bbox = draw.textbbox((0, 0), line, font=title_font)
        x = (VIDEO_SIZE[0] - (bbox[2] - bbox[0])) // 2
        draw.text((x, y), line, font=title_font, fill="white")
        y += 92
    y += 80
    for line in _wrap_text(draw, subtitle, sub_font, VIDEO_SIZE[0] - 2 * margin):
        bbox = draw.textbbox((0, 0), line, font=sub_font)
        x = (VIDEO_SIZE[0] - (bbox[2] - bbox[0])) // 2
        draw.text((x, y), line, font=sub_font, fill="#8fb7ff")
        y += 58
    canvas.save(output, quality=95)
    return output


def _wrap_text(draw: ImageDraw.ImageDraw, text: str, font, max_width: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        bbox = draw.textbbox((0, 0), candidate, font=font)
        if current and bbox[2] - bbox[0] > max_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines[:8]


def _extract_dimension_text(title: str) -> str:
    match = re.search(r"(?<!\w)(\d{1,3})\s*[x×]\s*(\d+(?:[,\.]\d{1,2})?)(?:\s*(cm|m))?", title or "", re.I)
    if not match:
        return ""
    first = match.group(1)
    second = match.group(2).replace(".", ",")
    unit = (match.group(3) or "").lower()
    try:
        second_value = float(second.replace(",", "."))
    except ValueError:
        second_value = 0
    if unit == "cm":
        return f"{first} cm × {second} cm"
    if unit == "m":
        return f"{first} m × {second} m"
    if second_value and second_value < 10 and int(first) >= 10:
        return f"{first} cm × {second} m"
    return f"{first} × {second}"


def _fit_headline(draw: ImageDraw.ImageDraw, text: str, *, initial_size: int, max_width: int, max_lines: int) -> tuple[object, list[str], int]:
    clean = re.sub(r"\s+", " ", str(text or "")).strip().upper()
    if not clean:
        font = _font(initial_size)
        return font, [], max(34, int(initial_size * 1.18))
    best_font = _font(max(26, initial_size))
    best_lines = _wrap_text(draw, clean, best_font, max_width)[:max_lines]
    best_gap = max(34, int(best_font.size * 1.18))
    for size in range(initial_size, 25, -2):
        font = _font(size)
        wrapped = _wrap_text(draw, clean, font, max_width)
        if len(wrapped) <= max_lines:
            line_gap = max(34, int(size * 1.18))
            return font, wrapped, line_gap
        best_font = font
        best_lines = wrapped[:max_lines]
        best_gap = max(34, int(size * 1.18))
    return best_font, best_lines, best_gap


def normalize_vertical_image(source: Path, output: Path) -> Path:
    with Image.open(source) as image:
        image = image.convert("RGB")
        fitted = ImageOps.fit(image, VIDEO_SIZE, method=Image.Resampling.LANCZOS)
        fitted.save(output, quality=94)
    return output


def _pid_is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _acquire_render_lock() -> Path:
    """Evita renderizações simultâneas sem bloquear o sistema por um arquivo órfão."""
    lock = storage_root() / ".video-render.lock"
    if lock.exists():
        age = time.time() - lock.stat().st_mtime
        owner_pid = 0
        try:
            owner_pid = int((lock.read_text(encoding="utf-8") or "0").split("|", 1)[0])
        except Exception:
            owner_pid = 0
        stale = age >= RENDER_LOCK_MAX_AGE_SECONDS or (owner_pid and not _pid_is_alive(owner_pid))
        if stale:
            lock.unlink(missing_ok=True)
        else:
            remaining = max(1, int((RENDER_LOCK_MAX_AGE_SECONDS - age) / 60) + 1)
            raise RuntimeError(
                f"Há uma montagem realmente ativa. Aguarde cerca de {remaining} minuto(s) ou exclua a produção travada."
            )
    try:
        with lock.open("x", encoding="utf-8") as handle:
            handle.write(f"{os.getpid()}|{time.time()}")
    except FileExistsError as exc:
        raise RuntimeError("Outra montagem começou agora. Aguarde e tente novamente.") from exc
    return lock


def render_slideshow(images: Iterable[Path], duration_seconds: int, output: Path, audio: Path | None = None) -> Path:
    image_paths = list(images)
    if not image_paths:
        raise ValueError("Nenhuma imagem disponível para renderização")
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    per_image = max(1.0, duration_seconds / len(image_paths))
    render_lock = _acquire_render_lock()
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            concat_file = temp / "concat.txt"
            lines: list[str] = []
            # Cada imagem é normalizada e fechada antes da próxima, mantendo o pico
            # de RAM baixo no plano de 512 MB do Render.
            for index, source in enumerate(image_paths):
                normalized = temp / f"frame_{index:03d}.jpg"
                normalize_vertical_image(source, normalized)
                lines.append(f"file '{normalized.as_posix()}'")
                lines.append(f"duration {per_image:.3f}")
            lines.append(f"file '{(temp / f'frame_{len(image_paths)-1:03d}.jpg').as_posix()}'")
            concat_file.write_text("\n".join(lines), encoding="utf-8")
            cmd = [
                ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
            ]
            if audio and audio.exists():
                cmd += ["-i", str(audio)]
            cmd += [
                # Perfil anterior: "fps=15,format=yuv420p". O Diretor usa VIDEO_FPS.
                "-vf", f"fps={VIDEO_FPS},format=yuv420p",
                "-t", str(duration_seconds),
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-tune", "stillimage",
                "-threads", "1",
                "-crf", "27",
            ]
            if audio and audio.exists():
                cmd += ["-af", f"apad=pad_dur={duration_seconds}", "-c:a", "aac", "-b:a", "96k"]
            else:
                cmd += ["-an"]
            cmd += ["-movflags", "+faststart", str(output)]
            completed = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
            if completed.returncode != 0:
                logger.error("FFmpeg falhou: %s", completed.stderr[-4000:])
                raise RuntimeError("Não foi possível montar o MP4. As mídias geradas foram preservadas para uma nova tentativa.")
    finally:
        render_lock.unlink(missing_ok=True)
    return output


def generate_ai_image(prompt: str, output: Path) -> Path:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY não configurada")
    payload = {"model": settings.openai_image_model, "prompt": prompt, "size": "1024x1536", "quality": "medium"}
    headers = {"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"}
    with httpx.Client(timeout=180) as client:
        response = client.post("https://api.openai.com/v1/images/generations", json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()["data"][0]
        if data.get("b64_json"):
            output.write_bytes(base64.b64decode(data["b64_json"]))
        elif data.get("url"):
            image = client.get(data["url"])
            image.raise_for_status()
            output.write_bytes(image.content)
        else:
            raise RuntimeError("A API de imagem não retornou conteúdo")
    return output


def _hook_image_prompt(product_title: str, hook: str, original_description: str = "") -> str:
    product = re.sub(r"\s+", " ", str(product_title or "produto útil")).strip()
    hook_text = re.sub(r"\s+", " ", str(hook or "")).strip()
    description = re.sub(r"\s+", " ", str(original_description or "")).strip()[:900]
    return (
        "Crie uma imagem publicitária vertical 9:16, visualmente forte e fácil de entender em menos de um segundo. "
        f"A cena deve representar visualmente o gancho: {hook_text!r}. "
        f"Contexto do produto: {product}. Descrição de apoio: {description or 'não informada'}. "
        "Mostre a situação, problema, contraste ou benefício sugerido pelo gancho, sem inventar características técnicas, "
        "sem números, sem preços, sem avaliações, sem logotipos, sem embalagens copiadas, sem marcas, sem textos, sem letras, sem legendas e sem interface. "
        "Não substitua a foto real do produto: esta imagem é apenas uma abertura ilustrativa. "
        "Estilo comercial moderno, composição limpa, iluminação agradável, enquadramento central e espaço seguro nas bordas. "
        "Não use aparência de captura de tela e não inclua marca d'água."
    )


def _create_local_hook_fallback(product_image: Path, hook: str, output: Path) -> Path:
    """Cria abertura visual local quando a API de imagem não está disponível.

    O fallback não inventa um produto: usa a foto real aprovada, aplica tratamento
    editorial e destaca somente o gancho. Assim a produção nunca é bloqueada.
    """
    with Image.open(product_image) as source:
        base = ImageOps.fit(source.convert("RGB"), VIDEO_SIZE, method=Image.Resampling.LANCZOS)
    blurred = base.filter(ImageFilter.GaussianBlur(radius=24)).convert("RGBA")
    overlay = Image.new("RGBA", VIDEO_SIZE, (3, 12, 25, 82))
    canvas = Image.alpha_composite(blurred, overlay)
    product = ImageOps.contain(base, (610, 760), method=Image.Resampling.LANCZOS).convert("RGBA")
    x = (VIDEO_SIZE[0] - product.width) // 2
    y = 350
    canvas.alpha_composite(product, (x, y))
    draw = ImageDraw.Draw(canvas)
    font, lines, line_height = _fit_overlay_text(draw, hook, max_width=620, max_lines=3, start_size=54, min_size=30)
    box_h = 38 + len(lines) * line_height
    draw.rounded_rectangle((28, 70, 692, 70 + box_h), radius=28, fill=(3, 12, 25, 224))
    yy = 89
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        xx = (VIDEO_SIZE[0] - (bbox[2] - bbox[0])) // 2
        draw.text((xx, yy), line, font=font, fill="white")
        yy += line_height
    canvas.convert("RGB").save(output, "JPEG", quality=91, optimize=True)
    return output


def create_hook_image(product_title: str, hook: str, original_description: str, product_cover: Path, output: Path) -> tuple[Path, str]:
    """Gera uma imagem de abertura coerente com o gancho, com fallback seguro."""
    if settings.hook_image_generation_enabled and settings.openai_api_key and hook.strip():
        try:
            generate_ai_image(_hook_image_prompt(product_title, hook, original_description), output)
            with Image.open(output) as image:
                normalized = ImageOps.fit(image.convert("RGB"), VIDEO_SIZE, method=Image.Resampling.LANCZOS)
                normalized.save(output, "JPEG", quality=92, optimize=True)
            return output, "openai"
        except Exception as exc:
            logger.warning("Imagem de gancho por IA falhou; usando fallback local: %s", exc)
    _create_local_hook_fallback(product_cover, hook, output)
    return output, "local_fallback"


FREE_TTS_PROFILES = {
    # v1.0.121: cada perfil usa um LOCUTOR realmente diferente. Quando GEMINI_API_KEY
    # está configurada, Gemini 2.5 Flash TTS é a primeira opção por permitir direção
    # de interpretação em linguagem natural. Edge TTS fica como fallback gratuito.
    "feminina_natural": {"voice": "pt-BR-FranciscaNeural", "gemini_voice": "Aoede", "rate": "-2%", "pitch": "+0Hz", "gender": "feminino", "label": "Feminina — natural · timbre Aoede", "name": "feminina_natural", "style": "Voz feminina brasileira natural, espontânea e próxima, como uma criadora falando com a câmera. Ritmo conversado, sem voz de propaganda."},
    "feminina_suave": {"voice": "pt-BR-ThalitaNeural", "gemini_voice": "Achernar", "rate": "-7%", "pitch": "-1Hz", "gender": "feminino", "label": "Feminina — suave · timbre Achernar", "name": "feminina_suave", "style": "Voz feminina brasileira suave e acolhedora. Fale com calma, dicção clara e pausas naturais, sem teatralidade."},
    "feminina_alegre": {"voice": "pt-BR-BrendaNeural", "gemini_voice": "Laomedeia", "rate": "+4%", "pitch": "+1Hz", "gender": "feminino", "label": "Feminina — alegre · timbre Laomedeia", "name": "feminina_alegre", "style": "Voz feminina brasileira alegre e leve, com sorriso perceptível e energia de vídeo curto, mas sem gritar."},
    "feminina_energetica": {"voice": "pt-BR-GiovannaNeural", "gemini_voice": "Callirrhoe", "rate": "+7%", "pitch": "+1Hz", "gender": "feminino", "label": "Feminina — energética · timbre Callirrhoe", "name": "feminina_energetica", "style": "Voz feminina brasileira enérgica, rápida e segura. Dê ênfase nas palavras importantes e varie a cadência."},
    "feminina_engracada": {"voice": "pt-BR-YaraNeural", "gemini_voice": "Vindemiatrix", "rate": "+8%", "pitch": "+1Hz", "gender": "feminino", "label": "Feminina — humor · timbre Vindemiatrix", "name": "feminina_engracada", "style": "Interpretação cômica original em português brasileiro. Use timing de comédia, pequenas pausas antes da punchline, surpresa e ironia. Não imite nenhuma pessoa real."},
    "feminina_profissional": {"voice": "pt-BR-LeilaNeural", "gemini_voice": "Kore", "rate": "-3%", "pitch": "-1Hz", "gender": "feminino", "label": "Feminina — profissional · timbre Kore", "name": "feminina_profissional", "style": "Voz feminina brasileira profissional, confiante e limpa. Soe como review de produto bem produzido, não como locução de call center."},

    # v1.0.131 — paridade feminina: mesmas famílias de interpretação disponíveis nas masculinas.
    # Os timbres Gemini abaixo são deliberadamente variados; estilos que compartilham a mesma
    # família não são apresentados como "pessoas novas", e sim como interpretações.
    "feminina_encorpada": {"provider": "styled", "voice": "pt-BR-ManuelaNeural", "gemini_voice": "Despina", "rate": "-5%", "pitch": "-1Hz", "gender": "feminino", "label": "Feminina — encorpada/premium · Despina", "name": "feminina_encorpada", "style": "Voz feminina brasileira encorpada, segura e madura. Ritmo controlado, presença e naturalidade, sem caricatura."},
    "feminina_review": {"provider": "styled", "voice": "pt-BR-ThalitaNeural", "gemini_voice": "Erinome", "rate": "+0%", "pitch": "+0Hz", "gender": "feminino", "label": "Feminina — review natural · Erinome", "name": "feminina_review", "style": "Review feminino brasileiro claro, natural e confiável. Soe como uma criadora avaliando o produto com critério, sem tom de propaganda."},
    "feminina_oferta": {"provider": "styled", "voice": "pt-BR-GiovannaNeural", "gemini_voice": "Autonoe", "rate": "+5%", "pitch": "+0Hz", "gender": "feminino", "label": "Feminina — oferta dinâmica · Autonoe", "name": "feminina_oferta", "style": "Locução feminina brasileira dinâmica e moderna para oferta, persuasiva sem soar como telemarketing. Ritmo crescente e CTA firme."},
    "feminina_comica_zavomi": {"provider": "styled", "voice": "pt-BR-YaraNeural", "gemini_voice": "Laomedeia", "rate": "+9%", "pitch": "+1Hz", "gender": "feminino", "label": "⭐ Cômica Zavomi — expressiva · Laomedeia", "name": "feminina_comica_zavomi", "style": "Narração cômica feminina ORIGINAL de vídeos curtos em português brasileiro. Timing forte, micro-pausas, reação, ironia e mudanças rápidas de energia. Não imite nenhuma pessoa ou canal real."},
    "feminina_comica_caotica": {"provider": "styled", "voice": "pt-BR-BrendaNeural", "gemini_voice": "Zephyr", "rate": "+10%", "pitch": "+1Hz", "gender": "feminino", "label": "🤣 Cômica caótica — excêntrica · Zephyr", "name": "feminina_comica_caotica", "style": "Narração cômica feminina original, viva e imprevisível, com reações curtas, mudanças de intensidade e pausas dramáticas. Engraçada sem gritar o tempo todo."},
    "feminina_humor_seco": {"provider": "styled", "voice": "pt-BR-LeilaNeural", "gemini_voice": "Achernar", "rate": "-4%", "pitch": "-1Hz", "gender": "feminino", "label": "Feminina — humor seco · Achernar", "name": "feminina_humor_seco", "style": "Humor seco feminino brasileiro: interpretação séria, ironia contida e pausas curtas. A graça vem do contraste, não de exagerar a voz."},
    "feminina_documental": {"provider": "styled", "voice": "pt-BR-ManuelaNeural", "gemini_voice": "Kore", "rate": "-3%", "pitch": "-1Hz", "gender": "feminino", "label": "🎬 Feminina documental — firme · Kore", "name": "feminina_documental", "style": "Narração documental feminina moderna, curiosa, firme e precisa. Suspense leve antes de fatos interessantes e surpresa contida na revelação."},
    "feminina_jovem_social": {"provider": "styled", "voice": "pt-BR-GiovannaNeural", "gemini_voice": "Callirrhoe", "rate": "+6%", "pitch": "+1Hz", "gender": "feminino", "label": "📱 Feminina jovem social — espontânea · Callirrhoe", "name": "feminina_jovem_social", "style": "Voz feminina jovem brasileira para conteúdo social, espontânea, leve e rápida, com sorriso na voz e pequenas mudanças de ritmo."},
    "feminina_suspense": {"provider": "styled", "voice": "pt-BR-ThalitaNeural", "gemini_voice": "Sulafat", "rate": "-6%", "pitch": "-1Hz", "gender": "feminino", "label": "🕵️ Feminina suspense/revelação · Sulafat", "name": "feminina_suspense", "style": "Voz feminina brasileira controlada e intrigante. Use pausas maiores antes da revelação e acelere discretamente depois dela, sem teatralidade excessiva."},
    "feminina_radio_comercial": {"provider": "styled", "voice": "pt-BR-FranciscaNeural", "gemini_voice": "Aoede", "rate": "+2%", "pitch": "+0Hz", "gender": "feminino", "label": "📻 Feminina comercial moderna · Aoede", "name": "feminina_radio_comercial", "style": "Locução comercial feminina brasileira contemporânea, firme, polida e musical. Dê peso aos benefícios e mantenha o CTA curto e seguro."},
    "feminina_viral_risada": {"provider": "styled", "voice": "pt-BR-YaraNeural", "gemini_voice": "Vindemiatrix", "rate": "+10%", "pitch": "+1Hz", "gender": "feminino", "label": "😂 Feminina humor viral + risada histérica · Vindemiatrix", "name": "feminina_viral_risada", "style": "Comédia feminina ORIGINAL de vídeo curto brasileiro. Ritmo rápido, dicção marcada, ironia e quebra de expectativa. Ao terminar o GANCHO (a primeira frase), solte uma risada NÃO VERBAL intensa e descontrolada: começa como uma risada curta, cresce rapidamente até parecer que perdeu o controle por um instante, inclui uma pequena quebra de respiração e termina de forma abrupta. A risada deve ser histérica, genuinamente engraçada e parecer fora de controle por um instante, mas ser CURTA: alvo de cerca de 4 segundos e nunca dominar o vídeo. Termine abruptamente e então continue a narração normalmente. Não pronuncie 'haha', 'risos' ou qualquer palavra durante a risada. Não imite risada, timbre, bordão ou maneirismo exclusivo de nenhuma pessoa ou canal real.", "laugh_after_hook": True},

    "masculina_natural": {"voice": "pt-BR-AntonioNeural", "gemini_voice": "Achird", "rate": "-2%", "pitch": "+0Hz", "gender": "masculino", "label": "Masculina — natural · timbre Achird", "name": "masculina_natural", "style": "Voz masculina brasileira natural e casual. Fale como alguém recomendando um produto para um amigo, com variação espontânea de entonação."},
    "masculina_grave": {"voice": "pt-BR-DonatoNeural", "gemini_voice": "Algenib", "rate": "-5%", "pitch": "-2Hz", "gender": "masculino", "label": "Masculina — grave · timbre Algenib", "name": "masculina_grave", "style": "Voz masculina brasileira encorpada, mais grave e segura, com ritmo controlado e presença. Evite caricatura."},
    "masculina_profissional": {"voice": "pt-BR-FabioNeural", "gemini_voice": "Charon", "rate": "-3%", "pitch": "-1Hz", "gender": "masculino", "label": "Masculina — profissional · timbre Charon", "name": "masculina_profissional", "style": "Voz masculina brasileira profissional, clara e objetiva, no estilo review tecnológico moderno."},
    "masculina_energetica": {"voice": "pt-BR-HumbertoNeural", "gemini_voice": "Fenrir", "rate": "+6%", "pitch": "+0Hz", "gender": "masculino", "label": "Masculina — energética · timbre Fenrir", "name": "masculina_energetica", "style": "Voz masculina brasileira energética e entusiasmada. Acelere levemente em listas e destaque benefícios sem parecer vendedor de TV."},
    "masculina_engracada": {"voice": "pt-BR-JulioNeural", "gemini_voice": "Orus", "rate": "+7%", "pitch": "+0Hz", "gender": "masculino", "label": "Masculina — humor · timbre Orus", "name": "masculina_engracada", "style": "Narração cômica masculina original, com reação, ironia, pausa curta antes da piada e mudança de energia. Não imite voz ou bordões de pessoa real."},
    "narrador_comico_zavomi": {"voice": "pt-BR-NicolauNeural", "gemini_voice": "Puck", "rate": "+9%", "pitch": "+0Hz", "gender": "masculino", "label": "⭐ Cômico Zavomi — expressivo", "name": "narrador_comico_zavomi", "style": "Narre em português brasileiro como um narrador cômico ORIGINAL de vídeos curtos. Ritmo vivo, timing de comédia, micro-pausas, mudanças rápidas de energia, surpresa e indignação leve quando fizer sentido. A punchline deve receber uma pausa antes e uma ênfase depois. Não imite nenhum narrador, canal ou pessoa real."},
    "comico_caotico": {"voice": "pt-BR-ValerioNeural", "gemini_voice": "Sadachbia", "rate": "+10%", "pitch": "+1Hz", "gender": "masculino", "label": "🤣 Cômico caótico — excêntrico", "name": "comico_caotico", "style": "Narração cômica original muito viva, imprevisível e acelerada, com reações curtas, mudanças de intensidade e pausas dramáticas. Engraçado sem gritar o tempo todo e sem imitar pessoa real."},
    "review_natural": {"voice": "pt-BR-DonatoNeural", "gemini_voice": "Iapetus", "rate": "+0%", "pitch": "+0Hz", "gender": "masculino", "label": "Review — claro e natural", "name": "review_natural", "style": "Review brasileiro natural, claro e confiável. Tom de quem realmente testou/avaliou o produto, sem promessas exageradas."},
    "vendedor_dinamico": {"voice": "pt-BR-FabioNeural", "gemini_voice": "Pulcherrima", "rate": "+5%", "pitch": "+0Hz", "gender": "masculino", "label": "Oferta — dinâmico", "name": "vendedor_dinamico", "style": "Locução brasileira dinâmica e moderna para oferta. Seja convincente sem soar como telemarketing; use ritmo crescente e CTA firme."},
    "narrador_premium": {"voice": "pt-BR-HumbertoNeural", "gemini_voice": "Gacrux", "rate": "-4%", "pitch": "-1Hz", "gender": "masculino", "label": "Narrador — maduro/premium", "name": "narrador_premium", "style": "Narração brasileira madura, sofisticada e calma, com dicção precisa e pausas bem colocadas."},
    "humor_seco": {"voice": "pt-BR-JulioNeural", "gemini_voice": "Zubenelgenubi", "rate": "-4%", "pitch": "-1Hz", "gender": "masculino", "label": "Humor seco — casual", "name": "humor_seco", "style": "Humor seco brasileiro: fale sério como se nada fosse engraçado. Use pausas curtas e ironia contida; a graça vem do contraste com o texto."},

    # v1.0.122 — novos estilos com direção vocal realmente diferente. O perfil
    # viral aproxima a ENERGIA de narradores brasileiros de humor curto, mas
    # preserva uma identidade vocal própria e não imita uma pessoa real.
    "narrador_viral_br": {"voice": "pt-BR-NicolauNeural", "gemini_voice": "Enceladus", "rate": "+11%", "pitch": "+1Hz", "gender": "masculino", "label": "🔥 Narrador Viral BR — acelerado e irreverente", "name": "narrador_viral_br", "style": "Narração ORIGINAL de humor viral brasileiro. Voz masculina de registro médio, dicção muito marcada, ritmo rápido de verdade, micro-pausas antes de viradas, mudanças súbitas de energia, ironia e espanto controlado. Faça a interpretação, não apenas acelere o áudio. Alongue ocasionalmente uma palavra-chave, comprima listas e solte a punchline com contraste. Não imite, cite nem reproduza bordões, timbre ou maneirismos exclusivos de pessoa, canal ou narrador real."},
    "narrador_viral_risada": {"provider": "styled", "voice": "pt-BR-NicolauNeural", "gemini_voice": "Puck", "rate": "+11%", "pitch": "+1Hz", "gender": "masculino", "label": "😂 Humor viral + risada histérica — original", "name": "narrador_viral_risada", "style": "Comédia ORIGINAL de vídeo curto brasileiro. Ritmo muito vivo, dicção marcada, micro-pausas e quebra de expectativa. Ao terminar o GANCHO (a primeira frase), solte uma risada NÃO VERBAL intensa e descontrolada: começa curta, cresce rapidamente como se o narrador perdesse o controle por um instante, tem uma pequena quebra de respiração e termina abruptamente. A risada deve ser histérica, genuinamente engraçada e parecer fora de controle por um instante, mas ser CURTA: alvo de cerca de 4 segundos e nunca dominar o vídeo. Termine abruptamente e então continue a narração normalmente. Não pronuncie 'haha', 'risos' ou qualquer palavra durante a risada. A risada deve ser própria e não pode imitar a risada, voz, bordões ou maneirismos exclusivos de nenhuma pessoa ou canal real.", "laugh_after_hook": True},
    # v1.0.145 — novas vozes com risada. A narração usa timbres reais distintos da v136.
    # A risada é inserida por um motor separado e comprovado (Puck/Vindemiatrix),
    # com FX próprios, para não depender de cada timbre saber interpretar tags de riso.
    "risada_m_orus": {"provider":"styled","voice":"pt-BR-AntonioNeural","gemini_voice":"Orus","rate":"+10%","pitch":"+1Hz","gender":"masculino","label":"😆 Orus — humor + risada curta","name":"risada_m_orus","style":"Comédia rápida, espontânea e clara.","laugh_after_hook":True,"laugh_kind":"curta"},
    "risada_m_sadachbia": {"provider":"styled","voice":"pt-BR-AntonioNeural","gemini_voice":"Sadachbia","rate":"+10%","pitch":"+1Hz","gender":"masculino","label":"🤣 Sadachbia — humor + gargalhada caótica","name":"risada_m_sadachbia","style":"Comédia caótica, viva e imprevisível.","laugh_after_hook":True,"laugh_kind":"caótica"},
    "risada_m_fenrir": {"provider":"styled","voice":"pt-BR-AntonioNeural","gemini_voice":"Fenrir","rate":"+11%","pitch":"+1Hz","gender":"masculino","label":"😂 Fenrir — humor + risada explosiva","name":"risada_m_fenrir","style":"Comédia acelerada, energética e curta.","laugh_after_hook":True,"laugh_kind":"explosiva"},
    "risada_m_gacrux": {"provider":"styled","voice":"pt-BR-AntonioNeural","gemini_voice":"Gacrux","rate":"+7%","pitch":"-1Hz","gender":"masculino","label":"😄 Gacrux — humor + risada grave","name":"risada_m_gacrux","style":"Comédia encorpada, segura e irônica.","laugh_after_hook":True,"laugh_kind":"grave"},
    "risada_m_achird": {"provider":"styled","voice":"pt-BR-AntonioNeural","gemini_voice":"Achird","rate":"+8%","pitch":"+0Hz","gender":"masculino","label":"😏 Achird — humor + risada debochada","name":"risada_m_achird","style":"Comédia cúmplice, conversada e debochada.","laugh_after_hook":True,"laugh_kind":"debochada"},
    "risada_f_zephyr": {"provider":"styled","voice":"pt-BR-FranciscaNeural","gemini_voice":"Zephyr","rate":"+10%","pitch":"+1Hz","gender":"feminino","label":"🤣 Zephyr — humor + gargalhada caótica","name":"risada_f_zephyr","style":"Comédia feminina caótica, viva e espontânea.","laugh_after_hook":True,"laugh_kind":"caótica"},
    "risada_f_laomedeia": {"provider":"styled","voice":"pt-BR-FranciscaNeural","gemini_voice":"Laomedeia","rate":"+8%","pitch":"+1Hz","gender":"feminino","label":"😆 Laomedeia — humor + risada alegre","name":"risada_f_laomedeia","style":"Comédia feminina alegre, natural e rápida.","laugh_after_hook":True,"laugh_kind":"alegre"},
    "risada_f_erinome": {"provider":"styled","voice":"pt-BR-FranciscaNeural","gemini_voice":"Erinome","rate":"+7%","pitch":"+0Hz","gender":"feminino","label":"😏 Erinome — humor + risada debochada","name":"risada_f_erinome","style":"Comédia feminina cúmplice e debochada.","laugh_after_hook":True,"laugh_kind":"debochada"},
    "risada_f_despina": {"provider":"styled","voice":"pt-BR-FranciscaNeural","gemini_voice":"Despina","rate":"+6%","pitch":"-1Hz","gender":"feminino","label":"😄 Despina — humor + risada encorpada","name":"risada_f_despina","style":"Comédia feminina encorpada e segura.","laugh_after_hook":True,"laugh_kind":"encorpada"},
    "risada_f_callirrhoe": {"provider":"styled","voice":"pt-BR-FranciscaNeural","gemini_voice":"Callirrhoe","rate":"+11%","pitch":"+1Hz","gender":"feminino","label":"😂 Callirrhoe — humor + risada explosiva","name":"risada_f_callirrhoe","style":"Comédia feminina acelerada e energética.","laugh_after_hook":True,"laugh_kind":"explosiva"},

    "storyteller_casual": {"voice": "pt-BR-ValerioNeural", "gemini_voice": "Schedar", "rate": "-1%", "pitch": "+0Hz", "gender": "masculino", "label": "📖 Storyteller — conversa e mini-história", "name": "storyteller_casual", "style": "Conte como uma mini-história brasileira, íntima e espontânea. Comece conversando, faça pequenas pausas de curiosidade, varie o volume de forma natural e termine com sensação de descoberta. Nada de voz publicitária."},
    "documental_curioso": {"voice": "pt-BR-DonatoNeural", "gemini_voice": "Rasalgethi", "rate": "-3%", "pitch": "-1Hz", "gender": "masculino", "label": "🎬 Documental curioso — sério com surpresa", "name": "documental_curioso", "style": "Narração documental moderna em português brasileiro: observadora, curiosa e precisa. Use suspense leve, pausas antes de fatos interessantes e uma surpresa contida quando revelar o benefício principal."},
    "jovem_social": {"voice": "pt-BR-FabioNeural", "gemini_voice": "Leda", "rate": "+6%", "pitch": "+1Hz", "gender": "masculino", "label": "📱 Jovem social — espontâneo e leve", "name": "jovem_social", "style": "Voz jovem brasileira de conteúdo social, espontânea, leve e rápida. Soe como alguém mostrando um achado para amigos, com sorriso na voz e pequenas mudanças de ritmo, sem jargão forçado."},
    "suspense_revelacao": {"voice": "pt-BR-HumbertoNeural", "gemini_voice": "Alnilam", "rate": "-6%", "pitch": "-2Hz", "gender": "masculino", "label": "🕵️ Suspense/Revelação — grave e intrigante", "name": "suspense_revelacao", "style": "Crie curiosidade com voz brasileira mais grave, controlada e intrigante. Use pausas maiores antes da revelação e acelere discretamente depois dela. Evite dramatização exagerada."},
    "radio_comercial": {"voice": "pt-BR-JulioNeural", "gemini_voice": "Sadaltager", "rate": "+2%", "pitch": "+0Hz", "gender": "masculino", "label": "📻 Comercial moderno — firme e polido", "name": "radio_comercial", "style": "Locução comercial brasileira contemporânea, firme, polida e musical, sem cara de rádio antigo ou telemarketing. Dê peso aos benefícios e mantenha o CTA curto e seguro."},
    "feminina_storyteller": {"voice": "pt-BR-ManuelaNeural", "gemini_voice": "Sulafat", "rate": "-1%", "pitch": "+0Hz", "gender": "feminino", "label": "📖 Feminina storyteller — próxima e expressiva", "name": "feminina_storyteller", "style": "Voz feminina brasileira próxima e expressiva, conduzindo uma mini-história com curiosidade, sorriso discreto e mudanças naturais de ritmo. Evite voz de anúncio."},
    "feminina_viral": {"voice": "pt-BR-ThalitaNeural", "gemini_voice": "Zephyr", "rate": "+9%", "pitch": "+1Hz", "gender": "feminino", "label": "🔥 Feminina viral — rápida e irreverente", "name": "feminina_viral", "style": "Narração feminina ORIGINAL para humor viral brasileiro: rápida, articulada, imprevisível, com pausas de reação, ironia leve e punchlines bem marcadas. Não imite nenhuma pessoa real."},

    # v1.0.130 — completa o catálogo oficial de 30 timbres Gemini com os cinco
    # timbres que ainda não estavam expostos. Os perfis abaixo têm identidades
    # e direções diferentes; não são apenas alterações de velocidade.
    "conversacional_autonoe": {"voice": "pt-BR-AntonioNeural", "gemini_voice": "Autonoe", "rate": "+0%", "pitch": "+0Hz", "gender": "neutro", "label": "💬 Conversacional — timbre Autonoe", "name": "conversacional_autonoe", "style": "Português brasileiro conversacional, espontâneo e humano. Soe como uma recomendação casual, com hesitações naturais muito leves, pausas orgânicas e nenhuma cadência de locutor."},
    "narrador_umbriel": {"voice": "pt-BR-DonatoNeural", "gemini_voice": "Umbriel", "rate": "-2%", "pitch": "-1Hz", "gender": "masculino", "label": "🌘 Narrador profundo — timbre Umbriel", "name": "narrador_umbriel", "style": "Narração brasileira profunda e intimista, com ritmo calmo, presença grave, pausas controladas e sensação de descoberta. Evite soar solene demais."},
    "creator_algieba": {"voice": "pt-BR-FabioNeural", "gemini_voice": "Algieba", "rate": "+4%", "pitch": "+0Hz", "gender": "masculino", "label": "🎥 Creator moderno — timbre Algieba", "name": "creator_algieba", "style": "Voz brasileira de creator moderno: direta, carismática, ágil e próxima. Alterne frases curtas e médias, destaque descobertas e evite locução publicitária tradicional."},
    "feminina_despina": {"voice": "pt-BR-GiovannaNeural", "gemini_voice": "Despina", "rate": "+2%", "pitch": "+0Hz", "gender": "feminino", "label": "✨ Feminina carismática — timbre Despina", "name": "feminina_despina", "style": "Voz feminina brasileira carismática e moderna, com sorriso discreto, ritmo natural, pequenas mudanças de intensidade e sensação de conversa real."},
    "feminina_erinome": {"voice": "pt-BR-LeilaNeural", "gemini_voice": "Erinome", "rate": "-2%", "pitch": "-1Hz", "gender": "feminino", "label": "🎧 Feminina editorial — timbre Erinome", "name": "feminina_erinome", "style": "Voz feminina brasileira editorial e segura, com dicção precisa, pausas elegantes e interpretação de review premium sem soar formal demais."},

    # Estilos adicionais: reutilizam alguns timbres de propósito, mas mudam a
    # DIREÇÃO de atuação. A interface deixa claro que são estilos, não novas
    # pessoas. Isso amplia as possibilidades sem fingir diversidade de timbre.
    "estilo_confidencia": {"provider": "styled", "voice": "pt-BR-ValerioNeural", "gemini_voice": "Schedar", "rate": "-4%", "pitch": "+0Hz", "gender": "masculino", "label": "🎭 Estilo confidência — Schedar", "name": "estilo_confidencia", "style": "Fale como se estivesse contando um segredo útil para um amigo. Comece baixo e próximo, aumente a energia na descoberta principal e termine com naturalidade."},
    "estilo_reacao": {"provider": "styled", "voice": "pt-BR-NicolauNeural", "gemini_voice": "Puck", "rate": "+7%", "pitch": "+0Hz", "gender": "masculino", "label": "😮 Estilo reação — Puck", "name": "estilo_reacao", "style": "Interpretação de reação genuína: surpresa contida, incredulidade leve, pausas curtas e retomadas rápidas. Não grite e não transforme tudo em piada."},
    "estilo_lista_rapida": {"provider": "styled", "voice": "pt-BR-HumbertoNeural", "gemini_voice": "Fenrir", "rate": "+8%", "pitch": "+0Hz", "gender": "masculino", "label": "⚡ Estilo lista rápida — Fenrir", "name": "estilo_lista_rapida", "style": "Ritmo rápido e muito claro para listas e comparações. Faça micro-pausas entre itens, acelere transições e desacelere na conclusão para dar contraste."},
    "estilo_ironia": {"provider": "styled", "voice": "pt-BR-JulioNeural", "gemini_voice": "Zubenelgenubi", "rate": "-1%", "pitch": "-1Hz", "gender": "masculino", "label": "😏 Estilo ironia — Zubenelgenubi", "name": "estilo_ironia", "style": "Ironia brasileira sutil. Fale sério nas frases engraçadas, marque silêncios curtos e use contraste de intenção; nunca force risada nem caricatura."},
    "estilo_feminina_reacao": {"provider": "styled", "voice": "pt-BR-YaraNeural", "gemini_voice": "Vindemiatrix", "rate": "+5%", "pitch": "+0Hz", "gender": "feminino", "label": "😮 Feminina reação — Vindemiatrix", "name": "estilo_feminina_reacao", "style": "Voz feminina de reação espontânea, com curiosidade, surpresa e pequenas mudanças de ritmo. Mantenha a fala natural, como conteúdo social orgânico."},

    # v1.0.135 — novas opções CÔMICAS com timbres-base diferentes. Não são
    # clones: cada perfil combina outro timbre Gemini com outra atuação.
    "comico_incredulo": {"provider": "styled", "voice": "pt-BR-FabioNeural", "gemini_voice": "Algieba", "rate": "+8%", "pitch": "+0Hz", "gender": "masculino", "label": "😳 Cômico incrédulo — Algieba", "name": "comico_incredulo", "style": "Comédia brasileira de incredulidade. Comece tentando falar sério, reaja como quem não acredita no que está vendo, use pausas curtas e solte a punchline com espanto contido. Original, sem imitar pessoa real."},
    "comico_dramatico": {"provider": "styled", "voice": "pt-BR-DonatoNeural", "gemini_voice": "Umbriel", "rate": "+3%", "pitch": "-1Hz", "gender": "masculino", "label": "🎭 Cômico dramático — Umbriel", "name": "comico_dramatico", "style": "Humor dramático brasileiro. Trate um problema pequeno como se fosse uma tragédia épica por alguns segundos e quebre a tensão com uma conclusão simples e engraçada. Voz original e natural."},
    "comico_fofoca": {"provider": "styled", "voice": "pt-BR-AntonioNeural", "gemini_voice": "Achird", "rate": "+6%", "pitch": "+1Hz", "gender": "masculino", "label": "🤫 Cômico fofoca — Achird", "name": "comico_fofoca", "style": "Conte como uma fofoca urgente e divertida para um amigo: aproximação, segredo, aceleração e uma revelação ridícula no fim. Não use bordões conhecidos nem imite criadores reais."},
    "comico_desesperado": {"provider": "styled", "voice": "pt-BR-HumbertoNeural", "gemini_voice": "Rasalgethi", "rate": "+10%", "pitch": "+1Hz", "gender": "masculino", "label": "😵 Cômico desesperado — Rasalgethi", "name": "comico_desesperado", "style": "Comédia de caos controlado: narre como quem está tentando resolver uma pequena confusão doméstica e vai ficando cada vez mais desesperado, mas sem gritar continuamente. Termine a virada com alívio cômico."},
    "feminina_comica_debochada": {"provider": "styled", "voice": "pt-BR-ManuelaNeural", "gemini_voice": "Despina", "rate": "+5%", "pitch": "+0Hz", "gender": "feminino", "label": "😏 Feminina debochada — Despina", "name": "feminina_comica_debochada", "style": "Humor feminino brasileiro debochado e inteligente. Fale com confiança, ironia clara e silêncio curto antes das frases mais engraçadas. Não force caricatura."},
    "feminina_comica_fofoca": {"provider": "styled", "voice": "pt-BR-LeilaNeural", "gemini_voice": "Erinome", "rate": "+7%", "pitch": "+1Hz", "gender": "feminino", "label": "🤫 Feminina fofoca — Erinome", "name": "feminina_comica_fofoca", "style": "Conte como uma fofoca divertida e urgente entre amigas: comece próxima e conspiratória, acelere na descoberta e termine com uma virada engraçada. Voz original."},
    "feminina_comica_dramatica": {"provider": "styled", "voice": "pt-BR-ThalitaNeural", "gemini_voice": "Sulafat", "rate": "+2%", "pitch": "+0Hz", "gender": "feminino", "label": "🎭 Feminina dramática cômica — Sulafat", "name": "feminina_comica_dramatica", "style": "Comédia feminina teatral na medida: dramatize um problema banal como se fosse enorme e depois quebre a tensão de forma seca e engraçada. Sem imitar voz ou personagem conhecido."},
    "feminina_comica_incredula": {"provider": "styled", "voice": "pt-BR-GiovannaNeural", "gemini_voice": "Autonoe", "rate": "+8%", "pitch": "+1Hz", "gender": "feminino", "label": "😳 Feminina incrédula — Autonoe", "name": "feminina_comica_incredula", "style": "Reação cômica feminina de incredulidade, com pequenas pausas, mudanças rápidas de energia e uma punchline falada como quem ainda está tentando acreditar. Original e natural."},
    # v1.0.135 — lote extra de vozes cômicas. Os cinco masculinos abaixo
    # usam timbres-base diferentes entre si; o mesmo vale para as cinco femininas.
    # Alguns timbres já existem em famílias não-cômicas, mas nunca são anunciados
    # como uma nova pessoa quando o timbre é o mesmo: aqui a diferença adicional é
    # explicitamente uma INTERPRETAÇÃO cômica.
    "comico_sarcastico": {"provider": "styled", "voice": "pt-BR-ValerioNeural", "gemini_voice": "Charon", "rate": "+4%", "pitch": "-1Hz", "gender": "masculino", "label": "😈 Cômico sarcástico — Charon", "name": "comico_sarcastico", "style": "Humor brasileiro sarcástico e seco. Fale como quem percebeu o absurdo antes de todo mundo; segure meio segundo antes da punchline e entregue a frase final com falsa seriedade. Original, sem imitar pessoa real."},
    "comico_apressado": {"provider": "styled", "voice": "pt-BR-HumbertoNeural", "gemini_voice": "Fenrir", "rate": "+12%", "pitch": "+1Hz", "gender": "masculino", "label": "🏃 Cômico apressado — Fenrir", "name": "comico_apressado", "style": "Comédia acelerada de quem tenta explicar uma situação absurda antes que tudo dê errado. Ritmo vivo, pequenas atropeladas controladas e freada brusca na punchline. Não grite continuamente."},
    "comico_pseudoserio": {"provider": "styled", "voice": "pt-BR-FabioNeural", "gemini_voice": "Iapetus", "rate": "+1%", "pitch": "-1Hz", "gender": "masculino", "label": "🧐 Cômico pseudo-sério — Iapetus", "name": "comico_pseudoserio", "style": "Narre uma situação banal como se fosse uma análise técnica muito importante. Mantenha voz séria, precisão exagerada e quebre a formalidade apenas na conclusão engraçada."},
    "comico_surpreso": {"provider": "styled", "voice": "pt-BR-NicolauNeural", "gemini_voice": "Gacrux", "rate": "+6%", "pitch": "+0Hz", "gender": "masculino", "label": "🤯 Cômico surpreso — Gacrux", "name": "comico_surpreso", "style": "Humor de surpresa crescente. Comece normal, descubra algo inesperado no meio e deixe a incredulidade aumentar em duas etapas até a punchline, sem virar gritaria."},
    "comico_malandro": {"provider": "styled", "voice": "pt-BR-JulioNeural", "gemini_voice": "Pulcherrima", "rate": "+5%", "pitch": "+0Hz", "gender": "masculino", "label": "😎 Cômico malandro — Pulcherrima", "name": "comico_malandro", "style": "Humor brasileiro esperto e leve, com tom de quem encontrou uma saída simples para um problema chato. Use confiança, pequenas pausas e uma conclusão com sorriso na voz."},
    "feminina_comica_sarcastica": {"provider": "styled", "voice": "pt-BR-ManuelaNeural", "gemini_voice": "Kore", "rate": "+4%", "pitch": "+0Hz", "gender": "feminino", "label": "😈 Feminina sarcástica — Kore", "name": "feminina_comica_sarcastica", "style": "Humor feminino sarcástico e inteligente. Entregue a piada com falsa seriedade, pausa curta antes da virada e uma expressão de quem já sabia que aquilo daria errado."},
    "feminina_comica_apressada": {"provider": "styled", "voice": "pt-BR-BrendaNeural", "gemini_voice": "Callirrhoe", "rate": "+11%", "pitch": "+1Hz", "gender": "feminino", "label": "🏃 Feminina cômica apressada — Callirrhoe", "name": "feminina_comica_apressada", "style": "Comédia feminina rápida, energética e espontânea. Conte o caos em ritmo crescente, faça micro-pausas para respirar e freie de repente na punchline."},
    "feminina_comica_pseudoseria": {"provider": "styled", "voice": "pt-BR-LeilaNeural", "gemini_voice": "Aoede", "rate": "+1%", "pitch": "-1Hz", "gender": "feminino", "label": "🧐 Feminina pseudo-séria — Aoede", "name": "feminina_comica_pseudoseria", "style": "Trate uma situação doméstica boba como se fosse um relatório importantíssimo. Mantenha elegância e seriedade exageradas e solte a conclusão engraçada de forma seca."},
    "feminina_comica_surpresa": {"provider": "styled", "voice": "pt-BR-GiovannaNeural", "gemini_voice": "Leda", "rate": "+6%", "pitch": "+1Hz", "gender": "feminino", "label": "🤯 Feminina surpresa — Leda", "name": "feminina_comica_surpresa", "style": "Humor feminino de surpresa genuína. Comece conversando normalmente, aumente a incredulidade ao descobrir o detalhe principal e finalize com uma reação curta e divertida."},
    "feminina_comica_cumplice": {"provider": "styled", "voice": "pt-BR-YaraNeural", "gemini_voice": "Sadaltager", "rate": "+5%", "pitch": "+0Hz", "gender": "feminino", "label": "😉 Feminina cúmplice — Sadaltager", "name": "feminina_comica_cumplice", "style": "Humor feminino de cumplicidade, como quem divide uma descoberta engraçada com uma amiga. Fale próxima, use sorriso na voz, uma pequena pausa conspiratória e punchline natural."},
}
# v1.0.136 — variantes de timbre realmente modificadas por pós-processamento.
# Elas não são apresentadas como pessoas novas: o rótulo deixa claro que partem
# de um timbre Gemini e recebem transformação acústica adicional. Isso amplia as
# escolhas sem mascarar a mesma voz apenas com um nome diferente.
_MODIFIED_TIMBRE_PROFILES = {
    "masculina_mod_gravissima": {"provider":"styled","voice":"pt-BR-NicolauNeural","gemini_voice":"Gacrux","rate":"-5%","pitch":"-1Hz","gender":"masculino","label":"🎙️ Masculina modificada — muito grave/quente · Gacrux FX","name":"masculina_mod_gravissima","style":"Voz masculina brasileira profunda, calorosa e cinematográfica. Natural, sem caricatura.","timbre_fx":"deep_warm"},
    "masculina_mod_aveludada": {"provider":"styled","voice":"pt-BR-AntonioNeural","gemini_voice":"Achird","rate":"-2%","pitch":"+0Hz","gender":"masculino","label":"🟤 Masculina modificada — aveludada · Achird FX","name":"masculina_mod_aveludada","style":"Voz masculina brasileira macia, próxima e aveludada, como creator falando baixo e com confiança.","timbre_fx":"velvet"},
    "masculina_mod_brilhante": {"provider":"styled","voice":"pt-BR-JulioNeural","gemini_voice":"Puck","rate":"+5%","pitch":"+0Hz","gender":"masculino","label":"⚡ Masculina modificada — brilhante/irreverente · Puck FX","name":"masculina_mod_brilhante","style":"Voz masculina brasileira rápida, irreverente e muito nítida, com punchlines curtas.","timbre_fx":"bright"},
    "masculina_mod_radio": {"provider":"styled","voice":"pt-BR-FabioNeural","gemini_voice":"Charon","rate":"+0%","pitch":"+0Hz","gender":"masculino","label":"📻 Masculina modificada — rádio encorpado · Charon FX","name":"masculina_mod_radio","style":"Locução masculina brasileira moderna de rádio/podcast, firme e limpa.","timbre_fx":"radio"},
    "masculina_mod_cartoon": {"provider":"styled","voice":"pt-BR-HumbertoNeural","gemini_voice":"Fenrir","rate":"+8%","pitch":"+1Hz","gender":"masculino","label":"🌀 Masculina modificada — cartoon rápido · Fenrir FX","name":"masculina_mod_cartoon","style":"Voz masculina original de comédia rápida, exagerada na medida e com reações curtas. Não imite personagem real.","timbre_fx":"cartoon"},
    "masculina_mod_misteriosa": {"provider":"styled","voice":"pt-BR-DonatoNeural","gemini_voice":"Umbriel","rate":"-6%","pitch":"-1Hz","gender":"masculino","label":"🌑 Masculina modificada — escura/misteriosa · Umbriel FX","name":"masculina_mod_misteriosa","style":"Narração masculina baixa, intrigante e misteriosa, com pausas marcadas.","timbre_fx":"dark"},
    "masculina_mod_telefone": {"provider":"styled","voice":"pt-BR-ValerioNeural","gemini_voice":"Sadaltager","rate":"+3%","pitch":"+0Hz","gender":"masculino","label":"☎️ Masculina modificada — telefone cômico · Sadaltager FX","name":"masculina_mod_telefone","style":"Humor masculino seco e absurdo, como uma ligação inesperada, com timing de comédia.","timbre_fx":"telephone"},
    "masculina_mod_punch": {"provider":"styled","voice":"pt-BR-JulioNeural","gemini_voice":"Orus","rate":"+7%","pitch":"+0Hz","gender":"masculino","label":"💥 Masculina modificada — punch cômico · Orus FX","name":"masculina_mod_punch","style":"Narração masculina cômica com muita presença, contraste de energia e punchline seca.","timbre_fx":"punch"},

    "feminina_mod_grave": {"provider":"styled","voice":"pt-BR-ManuelaNeural","gemini_voice":"Kore","rate":"-5%","pitch":"-1Hz","gender":"feminino","label":"🎙️ Feminina modificada — grave/quente · Kore FX","name":"feminina_mod_grave","style":"Voz feminina brasileira mais grave, elegante e calorosa, com presença sem soar artificial.","timbre_fx":"deep_warm"},
    "feminina_mod_aveludada": {"provider":"styled","voice":"pt-BR-FranciscaNeural","gemini_voice":"Aoede","rate":"-3%","pitch":"+0Hz","gender":"feminino","label":"🟤 Feminina modificada — aveludada · Aoede FX","name":"feminina_mod_aveludada","style":"Voz feminina brasileira macia, íntima e aveludada, natural para review e storytelling.","timbre_fx":"velvet"},
    "feminina_mod_brilhante": {"provider":"styled","voice":"pt-BR-GiovannaNeural","gemini_voice":"Leda","rate":"+5%","pitch":"+1Hz","gender":"feminino","label":"✨ Feminina modificada — brilhante/social · Leda FX","name":"feminina_mod_brilhante","style":"Voz feminina brasileira jovem, brilhante, rápida e espontânea para vídeos curtos.","timbre_fx":"bright"},
    "feminina_mod_radio": {"provider":"styled","voice":"pt-BR-LeilaNeural","gemini_voice":"Kore","rate":"+0%","pitch":"+0Hz","gender":"feminino","label":"📻 Feminina modificada — rádio moderno · Kore FX","name":"feminina_mod_radio","style":"Locução feminina brasileira de rádio/podcast moderno, firme, clara e musical.","timbre_fx":"radio"},
    "feminina_mod_cartoon": {"provider":"styled","voice":"pt-BR-BrendaNeural","gemini_voice":"Zephyr","rate":"+8%","pitch":"+1Hz","gender":"feminino","label":"🌀 Feminina modificada — cartoon cômico · Zephyr FX","name":"feminina_mod_cartoon","style":"Voz feminina original de comédia rápida, expressiva e imprevisível, sem imitar personagem real.","timbre_fx":"cartoon"},
    "feminina_mod_misteriosa": {"provider":"styled","voice":"pt-BR-ThalitaNeural","gemini_voice":"Sulafat","rate":"-6%","pitch":"-1Hz","gender":"feminino","label":"🌑 Feminina modificada — escura/misteriosa · Sulafat FX","name":"feminina_mod_misteriosa","style":"Voz feminina brasileira misteriosa e controlada, com suspense e pausas antes da revelação.","timbre_fx":"dark"},
    "feminina_mod_telefone": {"provider":"styled","voice":"pt-BR-YaraNeural","gemini_voice":"Erinome","rate":"+3%","pitch":"+0Hz","gender":"feminino","label":"☎️ Feminina modificada — telefone cômico · Erinome FX","name":"feminina_mod_telefone","style":"Humor feminino seco e cúmplice, como uma ligação absurda, com pausa antes da punchline.","timbre_fx":"telephone"},
    "feminina_mod_punch": {"provider":"styled","voice":"pt-BR-YaraNeural","gemini_voice":"Vindemiatrix","rate":"+7%","pitch":"+1Hz","gender":"feminino","label":"💥 Feminina modificada — punch cômico · Vindemiatrix FX","name":"feminina_mod_punch","style":"Narração feminina cômica com reação, energia variável e punchline curta e forte.","timbre_fx":"punch"},
}
FREE_TTS_PROFILES.update(_MODIFIED_TIMBRE_PROFILES)

# Compatibilidade com versões anteriores.
FREE_TTS_VOICES = {
    "feminina": FREE_TTS_PROFILES["feminina_natural"]["voice"],
    "masculina": FREE_TTS_PROFILES["masculina_natural"]["voice"],
}


# v1.0.129 — perfis ricos são resilientes: com GEMINI_API_KEY usam o timbre
# Gemini indicado; sem a chave, tentam uma voz pt-BR Edge diferente e validada
# em tempo de execução. Se a voz preferida não estiver exposta pelo Edge naquele
# momento, escolhem outra voz REAL do mesmo gênero e informam qual foi usada.
for _profile_key, _profile in FREE_TTS_PROFILES.items():
    _profile.setdefault("provider", "gemini")
FREE_TTS_PROFILES["edge_masculina_basica"] = {
    "voice": "pt-BR-AntonioNeural", "gemini_voice": "", "rate": "+0%", "pitch": "+0Hz",
    "gender": "masculino", "label": "Edge — masculina básica (Antonio)",
    "name": "edge_masculina_basica", "provider": "edge",
    "style": "Voz masculina brasileira básica do fallback Edge."
}
FREE_TTS_PROFILES["edge_feminina_basica"] = {
    "voice": "pt-BR-FranciscaNeural", "gemini_voice": "", "rate": "+0%", "pitch": "+0Hz",
    "gender": "feminino", "label": "Edge — feminina básica (Francisca)",
    "name": "edge_feminina_basica", "provider": "edge",
    "style": "Voz feminina brasileira básica do fallback Edge."
}


AUTO_VOICE_GROUPS = {
    "humor_risada": ["narrador_viral_risada", "comico_incredulo", "comico_fofoca", "comico_desesperado", "narrador_comico_zavomi"],
    "humor_viral": ["narrador_viral_br", "narrador_comico_zavomi", "comico_caotico"],
    "humor_observacao": ["narrador_viral_br", "narrador_comico_zavomi", "masculina_engracada"],
    "expectativa_realidade": ["narrador_viral_br", "comico_caotico", "humor_seco"],
    "humor_seco": ["humor_seco", "documental_curioso"],
    "review": ["review_natural", "masculina_profissional", "documental_curioso"],
    "micro_review": ["review_natural", "jovem_social", "masculina_profissional"],
    "analise": ["review_natural", "documental_curioso", "narrador_premium"],
    "custo_beneficio": ["review_natural", "jovem_social", "vendedor_dinamico"],
    "oferta": ["vendedor_dinamico", "radio_comercial", "masculina_energetica"],
    "decisao_rapida": ["vendedor_dinamico", "jovem_social", "radio_comercial"],
    "beneficio": ["jovem_social", "masculina_natural", "vendedor_dinamico"],
    "lista": ["masculina_energetica", "jovem_social", "vendedor_dinamico"],
    "storytelling": ["storyteller_casual", "documental_curioso", "jovem_social"],
    "mini_historia": ["storyteller_casual", "documental_curioso", "jovem_social"],
    "surpresa": ["suspense_revelacao", "documental_curioso", "narrador_viral_br"],
}


def choose_free_voice_profile(selected: str | None, presenter_gender: str | None = None, narration_style: str | None = None, variation_seed: int | str | None = None) -> dict[str, str]:
    """Resolve perfil manual ou escolhe automaticamente por ESTILO do roteiro.

    ``variation_seed`` faz a seleção automática alternar de forma determinística
    entre vozes compatíveis, evitando que todos os vídeos do mesmo gênero usem o
    mesmo locutor. Seleção manual nunca é substituída.
    """
    raw = (selected or "auto").strip().lower()
    if raw != "auto":
        return resolve_free_voice_profile(raw, presenter_gender)
    style = (narration_style or "").strip().lower()
    gender = (presenter_gender or "").strip().lower()
    candidates = list(AUTO_VOICE_GROUPS.get(style) or [])
    if gender in {"feminino", "female", "mulher"}:
        female_by_style = {
            "humor_risada": ["feminina_viral_risada", "feminina_comica_debochada", "feminina_comica_fofoca", "feminina_comica_incredula", "feminina_comica_zavomi"],
            "humor_viral": ["feminina_viral", "feminina_comica_zavomi", "feminina_engracada"],
            "humor_observacao": ["feminina_comica_zavomi", "feminina_engracada", "feminina_alegre"],
            "humor_seco": ["feminina_humor_seco", "feminina_documental", "feminina_suave"],
            "expectativa_realidade": ["feminina_comica_caotica", "feminina_viral", "feminina_humor_seco"],
            "storytelling": ["feminina_storyteller", "feminina_natural", "feminina_suave"],
            "mini_historia": ["feminina_storyteller", "feminina_natural", "feminina_alegre"],
            "review": ["feminina_review", "feminina_profissional", "feminina_documental"],
            "micro_review": ["feminina_review", "feminina_jovem_social", "feminina_profissional"],
            "analise": ["feminina_review", "feminina_documental", "feminina_encorpada"],
            "custo_beneficio": ["feminina_review", "feminina_jovem_social", "feminina_oferta"],
            "oferta": ["feminina_oferta", "feminina_radio_comercial", "feminina_energetica"],
            "decisao_rapida": ["feminina_oferta", "feminina_jovem_social", "feminina_radio_comercial"],
            "beneficio": ["feminina_jovem_social", "feminina_natural", "feminina_oferta"],
            "lista": ["feminina_energetica", "feminina_jovem_social", "feminina_oferta"],
            "surpresa": ["feminina_suspense", "feminina_documental", "feminina_viral"],
        }
        candidates = female_by_style.get(style) or ["feminina_natural", "feminina_profissional", "feminina_alegre"]
    if not candidates:
        candidates = ["masculina_natural", "review_natural", "storyteller_casual"] if gender not in {"feminino", "female", "mulher"} else ["feminina_natural", "feminina_storyteller", "feminina_profissional"]
    if variation_seed is None:
        idx = 0
    else:
        token = str(variation_seed).encode("utf-8")
        idx = sum(token) % len(candidates)
    return dict(FREE_TTS_PROFILES[candidates[idx]])


def resolve_free_voice_profile(selected: str | None, presenter_gender: str | None = None) -> dict[str, str]:
    """Resolve a voz gratuita sem trocar o gênero escolhido silenciosamente.

    Uma seleção explícita sempre prevalece sobre o gênero do apresentador. Apenas
    ``auto`` usa o gênero do apresentador como referência.
    """
    raw = (selected or "auto").strip().lower()
    aliases = {
        "feminina": "feminina_natural",
        "female": "feminina_natural",
        "mulher": "feminina_natural",
        "masculina": "masculina_natural",
        "male": "masculina_natural",
        "homem": "masculina_natural",
    }
    value = aliases.get(raw, raw)
    if value != "auto":
        if value not in FREE_TTS_PROFILES:
            raise ValueError(f"Perfil de voz gratuita inválido: {selected}")
        return dict(FREE_TTS_PROFILES[value])
    gender = (presenter_gender or "").strip().lower()
    key = "masculina_natural" if gender in {"masculino", "male", "homem"} else "feminina_natural"
    return dict(FREE_TTS_PROFILES[key])


def resolve_free_voice(selected: str | None, presenter_gender: str | None = None) -> str:
    return resolve_free_voice_profile(selected, presenter_gender)["voice"]



_UNITS_PT = ("zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove")
_TEENS_PT = {10: "dez", 11: "onze", 12: "doze", 13: "treze", 14: "quatorze", 15: "quinze", 16: "dezesseis", 17: "dezessete", 18: "dezoito", 19: "dezenove"}
_TENS_PT = {20: "vinte", 30: "trinta", 40: "quarenta", 50: "cinquenta", 60: "sessenta", 70: "setenta", 80: "oitenta", 90: "noventa"}
_HUNDREDS_PT = {100: "cento", 200: "duzentos", 300: "trezentos", 400: "quatrocentos", 500: "quinhentos", 600: "seiscentos", 700: "setecentos", 800: "oitocentos", 900: "novecentos"}


def _integer_to_words_ptbr(number: int) -> str:
    number = int(number)
    if number < 0:
        return "menos " + _integer_to_words_ptbr(abs(number))
    if number < 10:
        return _UNITS_PT[number]
    if number < 20:
        return _TEENS_PT[number]
    if number < 100:
        ten = (number // 10) * 10
        rest = number % 10
        return _TENS_PT[ten] + (f" e {_UNITS_PT[rest]}" if rest else "")
    if number == 100:
        return "cem"
    if number < 1000:
        hundred = (number // 100) * 100
        rest = number % 100
        return _HUNDREDS_PT[hundred] + (f" e {_integer_to_words_ptbr(rest)}" if rest else "")
    if number < 1_000_000:
        thousands, rest = divmod(number, 1000)
        prefix = "mil" if thousands == 1 else f"{_integer_to_words_ptbr(thousands)} mil"
        if not rest:
            return prefix
        joiner = " e " if rest < 100 or rest % 100 == 0 else " "
        return prefix + joiner + _integer_to_words_ptbr(rest)
    millions, rest = divmod(number, 1_000_000)
    prefix = "um milhão" if millions == 1 else f"{_integer_to_words_ptbr(millions)} milhões"
    if not rest:
        return prefix
    joiner = " e " if rest < 100 or rest % 100 == 0 else " "
    return prefix + joiner + _integer_to_words_ptbr(rest)


def _money_to_words_ptbr(raw: str) -> str:
    normalized = raw.strip().replace(".", "").replace(",", ".")
    try:
        value = round(float(normalized) + 1e-9, 2)
    except ValueError:
        return f"R$ {raw}"
    reais = int(value)
    centavos = int(round((value - reais) * 100))
    if centavos == 100:
        reais += 1
        centavos = 0
    real_label = "real" if reais == 1 else "reais"
    spoken = f"{_integer_to_words_ptbr(reais)} {real_label}"
    if centavos:
        cent_label = "centavo" if centavos == 1 else "centavos"
        spoken += f" e {_integer_to_words_ptbr(centavos)} {cent_label}"
    return spoken


def normalize_spoken_text_ptbr(text: str) -> str:
    """Converte abreviações e valores de e-commerce em fala natural pt-BR."""
    value = str(text or "")
    # Converta moeda antes de qualquer tratamento de pontuação.
    value = re.sub(
        r"R\$\s*([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]{1,2})?|[0-9]+(?:,[0-9]{1,2})?)",
        lambda match: _money_to_words_ptbr(match.group(1)),
        value,
        flags=re.I,
    )
    # c/3, c / 3, c3 -> com 3 (o TTS verbaliza o número naturalmente).
    value = re.sub(r"\b[cC]\s*/\s*(\d+)\b", r"com \1", value)
    value = re.sub(r"\b[cC]\s+(\d+)\b", r"com \1", value)
    value = re.sub(r"\b[cC](\d+)\b", r"com \1", value)
    value = re.sub(r"\b(\d+)\s*(?:un\.?|unds?\.?|unidades?)\b", r"\1 unidades", value, flags=re.I)
    value = re.sub(r"(?<!\w)(\d{1,3})\s*[x×]\s*(\d+(?:[,\.]\d{1,2})?)(?!\w)", r"\1 por \2", value, flags=re.I)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _prepare_free_voice_text(text: str, profile_name: str) -> str:
    clean = normalize_spoken_text_ptbr(text)
    if profile_name in {"feminina_engracada", "masculina_engracada"}:
        clean = re.sub(r"([.!?])\s+", r"\1 ... ", clean)
    elif profile_name == "narrador_comico_zavomi":
        # Direção original Zavomi: frases curtas, pausas de reação e punchline.
        # Não imita timbre ou identidade vocal de uma pessoa real.
        clean = re.sub(r"\s*[—–-]\s*", ". ... ", clean)
        clean = re.sub(r"([!?])\s+", r"\1 ... ", clean)
        clean = re.sub(r"([.])\s+", r"\1  ", clean)
        clean = re.sub(r"\b(mas|só que|e aí|agora|olha|detalhe)\b", r"... \1", clean, flags=re.I)
    elif profile_name == "vendedor_dinamico":
        clean = re.sub(r"([.!?])\s+", r"\1 ", clean)
    elif profile_name == "narrador_premium":
        clean = re.sub(r"([.!?])\s+", r"\1  ", clean)
    elif profile_name == "humor_seco":
        clean = re.sub(r"([.!?])\s+", r"\1  ", clean)
    return clean

def _gemini_retry_after_seconds(response: httpx.Response | None, attempt: int) -> float:
    """Extrai Retry-After quando houver e limita a espera para caber na requisição web."""
    if response is not None:
        raw = str(response.headers.get("retry-after") or "").strip()
        try:
            value = float(raw)
            if value > 0:
                return min(max(value, 1.0), 12.0)
        except Exception:
            pass
    return _GEMINI_TTS_RETRY_DELAYS[min(attempt, len(_GEMINI_TTS_RETRY_DELAYS) - 1)]


def generate_gemini_tts(text: str, output: Path, voice_name: str, style_prompt: str = "") -> Path:
    """Gera TTS expressivo com Gemini com cache externo e retry consciente de 429.

    v1.0.146:
    - tenta primeiro o último modelo que funcionou neste processo;
    - ao receber 429, coloca aquele modelo em cooldown curto e tenta o próximo;
    - se todos estiverem limitados, espera poucos segundos e repete, no máximo 3 rodadas;
    - não troca silenciosamente para Edge nos perfis com risada (essa decisão continua no caller).
    """
    global _GEMINI_TTS_LAST_GOOD_MODEL
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY não configurada")
    clean = re.sub(r"\s+", " ", str(text or "")).strip()
    if not clean:
        raise ValueError("Não há texto válido para a narração")
    output.parent.mkdir(parents=True, exist_ok=True)
    direction = (style_prompt or "Voz brasileira natural, clara e expressiva.").strip()
    has_audio_tags = bool(re.search(r"\[(?:laughs|giggles|gasp|sighs|excited|sarcastic|whispers|shouting)[^]]*\]", clean, flags=re.I))
    transcript_rule = (
        "O transcript contém tags de áudio expressivas entre colchetes. Elas são COMANDOS NÃO VERBAIS da API, não palavras: execute o som/atuação e nunca leia o conteúdo dos colchetes. "
        if has_audio_tags else
        "Leia EXATAMENTE o texto abaixo, sem acrescentar, remover ou reescrever nenhuma palavra. "
    )
    prompt = (
        f"{direction}\n"
        "SINTETIZE FALA em português do Brasil. " + transcript_rule +
        "Preserve a intenção da pontuação e não explique instruções de direção.\n\n"
        f"TRANSCRIPT: {clean}"
    )
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {
                "voiceConfig": {
                    "prebuiltVoiceConfig": {"voiceName": voice_name}
                }
            },
        },
    }

    configured = str(settings.gemini_tts_model or "").strip()
    base_models: list[str] = []
    for model in (_GEMINI_TTS_LAST_GOOD_MODEL, configured, "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"):
        if model and model not in base_models:
            base_models.append(model)

    data = None
    errors: list[str] = []
    last_429: httpx.Response | None = None
    with httpx.Client(timeout=settings.gemini_tts_timeout_seconds) as client:
        for attempt in range(len(_GEMINI_TTS_RETRY_DELAYS)):
            now = time.time()
            attempted_this_round = False
            limited_this_round = False
            # Preferimos modelos fora de cooldown. Se todos estiverem em cooldown,
            # a rodada aguardará e tentará novamente em seguida.
            for model in base_models:
                cooldown_until = float(_GEMINI_TTS_MODEL_COOLDOWN_UNTIL.get(model, 0.0) or 0.0)
                if cooldown_until > now:
                    errors.append(f"{model}: cooldown por 429 ({cooldown_until-now:.1f}s)")
                    limited_this_round = True
                    continue
                attempted_this_round = True
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
                response = None
                try:
                    response = client.post(
                        url,
                        headers={"x-goog-api-key": settings.gemini_api_key, "Content-Type": "application/json"},
                        json=payload,
                    )
                    if response.status_code == 429:
                        limited_this_round = True
                        last_429 = response
                        wait_for = _gemini_retry_after_seconds(response, attempt + 1)
                        # Um cooldown um pouco maior que a espera desta rodada evita
                        # vários cliques consecutivos baterem no mesmo modelo.
                        _GEMINI_TTS_MODEL_COOLDOWN_UNTIL[model] = time.time() + max(wait_for, 8.0)
                        detail = ""
                        try:
                            detail = str(response.json())[:220]
                        except Exception:
                            detail = str(response.text or "")[:220]
                        errors.append(f"{model}: HTTP 429 {detail}")
                        continue
                    response.raise_for_status()
                    data = response.json()
                    _GEMINI_TTS_LAST_GOOD_MODEL = model
                    _GEMINI_TTS_MODEL_COOLDOWN_UNTIL.pop(model, None)
                    break
                except httpx.HTTPStatusError as exc:
                    status = exc.response.status_code if exc.response is not None else None
                    # 403/404/400 não melhoram repetindo a mesma chamada. Tentamos o
                    # próximo modelo; 5xx também pode ser resolvido pelo fallback.
                    errors.append(f"{model}: HTTP {status}: {str(exc)[:180]}")
                except Exception as exc:
                    errors.append(f"{model}: {type(exc).__name__}: {str(exc)[:180]}")
            if data is not None:
                break
            if attempt >= len(_GEMINI_TTS_RETRY_DELAYS) - 1:
                break
            # Se houve 429 (ou todos estavam em cooldown), damos uma espera curta
            # antes da próxima rodada. Isso evita falhar instantaneamente por pico de cota.
            if limited_this_round or not attempted_this_round:
                delay = _gemini_retry_after_seconds(last_429, attempt + 1)
                if delay > 0:
                    time.sleep(delay)
            else:
                # Em erro transitório de rede/5xx, uma pequena pausa basta.
                time.sleep(1.0 + attempt)

    if data is None:
        detail = " | ".join(errors[-8:])
        if any("HTTP 429" in item or "cooldown por 429" in item for item in errors):
            raise RuntimeError(
                "Gemini TTS temporariamente limitado (HTTP 429) mesmo após novas tentativas e fallback de modelo. "
                "Aguarde alguns segundos e tente novamente; a prévia será reutilizada pelo cache assim que uma geração concluir. "
                + detail
            )
        raise RuntimeError("Nenhum modelo Gemini TTS respondeu: " + detail)
    try:
        b64 = data["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
        pcm = base64.b64decode(b64)
    except Exception as exc:
        raise RuntimeError("Gemini TTS não retornou áudio válido") from exc
    if len(pcm) < 1024:
        raise RuntimeError("Gemini TTS retornou áudio vazio")
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    cmd = [ffmpeg, "-y", "-f", "s16le", "-ar", "24000", "-ac", "1", "-i", "pipe:0", "-codec:a", "libmp3lame", "-q:a", "3", str(output)]
    proc = subprocess.run(cmd, input=pcm, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    if proc.returncode != 0 or not output.exists() or output.stat().st_size < 1024:
        output.unlink(missing_ok=True)
        raise RuntimeError(f"Falha ao converter áudio Gemini: {proc.stderr.decode('utf-8', 'ignore')[-500:]}")
    return output


_EDGE_VOICE_CACHE: list[dict] | None = None
_EDGE_VOICE_CACHE_AT: float = 0.0


def _runtime_edge_voice(preferred: str, gender: str = "masculino", seed: str = "") -> str:
    """Resolve uma voz que o serviço Edge realmente expõe neste momento.

    A lista Azure é maior que a lista disponível pelo endpoint público usado por
    ``edge-tts``. Antes a aplicação aceitava nomes válidos no Azure, mas o Edge
    podia recusá-los no Render. Agora consultamos a lista real, cacheamos e,
    somente se o perfil pedido não existir, escolhemos outro pt-BR do mesmo
    gênero de forma determinística.
    """
    global _EDGE_VOICE_CACHE, _EDGE_VOICE_CACHE_AT
    try:
        import edge_tts
        now = time.time()
        if _EDGE_VOICE_CACHE is None or now - _EDGE_VOICE_CACHE_AT > 21600:
            voices = asyncio.run(edge_tts.list_voices())
            _EDGE_VOICE_CACHE = [v for v in voices if str(v.get("Locale") or "").lower() == "pt-br"]
            _EDGE_VOICE_CACHE_AT = now
        available = _EDGE_VOICE_CACHE or []
        names = {str(v.get("ShortName") or "") for v in available}
        if preferred in names:
            return preferred
        wanted = "female" if str(gender).lower().startswith("f") else "male"
        candidates = [str(v.get("ShortName") or "") for v in available if str(v.get("Gender") or "").lower() == wanted]
        candidates = [x for x in candidates if x]
        if candidates:
            idx = sum(ord(ch) for ch in str(seed or preferred)) % len(candidates)
            return candidates[idx]
    except Exception as exc:
        logger.warning("Não foi possível consultar vozes Edge em runtime: %s", exc)
    # Fallbacks conhecidos e amplamente disponíveis no Edge. A geração ainda
    # tem retry e reporta erro se o próprio serviço estiver fora do ar.
    return "pt-BR-FranciscaNeural" if str(gender).lower().startswith("f") else "pt-BR-AntonioNeural"


def _split_hook_and_rest(text: str) -> tuple[str, str]:
    """Separa o gancho (primeira frase) para aplicar a risada exatamente no ponto certo."""
    clean = re.sub(r"\s+", " ", str(text or "")).strip()
    if not clean:
        return "", ""
    match = re.search(r"^(.+?[.!?])(?:\s+|$)(.*)$", clean, flags=re.S)
    if match:
        return match.group(1).strip(), match.group(2).strip()
    # Se o roteiro não tiver pontuação cedo, usa uma quebra curta por palavras.
    words = clean.split()
    if len(words) <= 18:
        return clean, ""
    return " ".join(words[:18]).strip(), " ".join(words[18:]).strip()


def _concat_mp3(parts: list[Path], output: Path) -> Path:
    valid = [part for part in parts if part.exists() and part.stat().st_size > 1024]
    if not valid:
        raise RuntimeError("Nenhum trecho de áudio válido foi gerado")
    if len(valid) == 1:
        output.parent.mkdir(parents=True, exist_ok=True)
        if valid[0] != output:
            output.write_bytes(valid[0].read_bytes())
        return output
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temp_dir:
        concat = Path(temp_dir) / "audio_concat.txt"
        concat.write_text("\n".join(f"file '{part.resolve().as_posix()}'" for part in valid), encoding="utf-8")
        cmd = [
            ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat),
            "-c:a", "libmp3lame", "-q:a", "3", str(output),
        ]
        completed = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        if completed.returncode != 0:
            raise RuntimeError(f"Falha ao unir narração e risada: {completed.stderr[-1000:]}")
    if not output.exists() or output.stat().st_size <= 1024:
        raise RuntimeError("O áudio final com risada ficou vazio")
    return output


def _generate_gemini_laugh_after_hook(text: str, output: Path, profile: dict[str, str]) -> Path:
    """v1.0.147: mantém a estratégia simples da v136 e limita a risada a ~4 s.

    Uma única chamada Gemini sintetiza gancho + risada + continuação com o próprio
    timbre escolhido. Isso reduz de até 3 chamadas por prévia para 1 e, portanto,
    diminui muito a chance de HTTP 429. A posição é sempre gancho -> risada -> resto.
    """
    hook, rest = _split_hook_and_rest(text)
    if not hook:
        raise ValueError("Não há gancho válido para narrar")
    narration_voice = str(profile.get("gemini_voice") or "").strip()
    if not narration_voice:
        raise ValueError("Perfil sem timbre Gemini")
    base_style = str(profile.get("style") or "").strip()
    laugh_kind = str(profile.get("laugh_kind") or "histérica crescente").strip().lower()

    # v1.0.147 — uma única marca expressiva. A v146 encadeava várias tags
    # ([laughs] + [laughs uncontrollably] + [gasp] + [laughs]), o que fazia o
    # Gemini prolongar a gargalhada e consumir grande parte do vídeo.
    # Mantemos uma única chamada Gemini e uma única risada, imediatamente após
    # o gancho, com direção explícita para ~4 segundos e corte abrupto.
    tagged = f"{hook} [laughs]"
    if rest:
        tagged += f" {rest}"
    variations = {
        "curta": "Risada histérica curta: começa de surpresa, escapa do controle por um instante e corta seco. Mire em 3,5 a 4 segundos.",
        "caótica": "Gargalhada histérica e caótica, com 2 ou 3 explosões irregulares bem rápidas, como quem tenta se recompor e não consegue. Mire em cerca de 4 segundos.",
        "explosiva": "Risada histérica explosiva: ataque imediato, pico forte, uma pequena recaída e corte abrupto. Mire em cerca de 4 segundos.",
        "grave": "Gargalhada grave, histérica e descontrolada, com corpo e uma quebra curta de fôlego, mas sem se prolongar. Mire em cerca de 4 segundos.",
        "debochada": "Risada debochada que rapidamente vira uma gargalhada histérica curta, como se o absurdo do gancho fizesse perder o controle. Mire em cerca de 4 segundos.",
        "alegre": "Risada aberta e contagiante que perde o controle por um instante, muito engraçada, rápida e abrupta. Mire em cerca de 4 segundos.",
        "encorpada": "Gargalhada cheia e histérica, com presença e uma pequena falha de fôlego, mas corte rígido por volta de 4 segundos.",
        "histérica": "Risada humana histérica e sem controle: começa curta, explode, falha o fôlego por um instante e termina abruptamente. Mire em cerca de 4 segundos.",
    }
    extra = ""
    for key, instruction in variations.items():
        if key in laugh_kind:
            extra = instruction
            break
    if not extra:
        extra = variations["histérica"]
    direction = (
        f"{base_style} SINTETIZE FALA em português brasileiro. "
        "Há UMA ÚNICA tag [laughs] logo após o gancho. Nesse ponto faça UMA RISADA HUMANA NÃO VERBAL, "
        "histérica, espontânea, realmente engraçada e com sensação de perda de controle, mas CURTA. "
        "A duração-alvo é cerca de 4 segundos (ideal entre 3,5 e 4,5 s); NÃO prolongue a risada, NÃO repita ciclos de riso "
        "e NÃO deixe a risada ocupar grande parte do vídeo. Faça uma pequena quebra natural de fôlego dentro da própria risada e corte abruptamente. "
        f"{extra} Não leia a tag, não diga 'haha', 'risos' ou palavras durante a risada. "
        "Depois do corte, continue imediatamente a narração e não ria novamente."
    )
    return generate_gemini_tts(tagged, output, narration_voice, direction)


def _apply_timbre_fx(path: Path, fx_name: str) -> Path:
    """Aplica uma transformação acústica explícita ao timbre já sintetizado.

    O objetivo é criar variantes audivelmente diferentes sem fingir que são
    novos locutores-base. Mantemos a duração aproximada e evitamos efeitos
    extremos que prejudiquem a inteligibilidade.
    """
    fx = str(fx_name or "").strip().lower()
    if not fx:
        return path
    filters = {
        "deep_warm": "asetrate=24000*0.90,aresample=24000,atempo=1.1111,equalizer=f=180:t=q:w=1:g=3,equalizer=f=3200:t=q:w=1:g=-2",
        "velvet": "equalizer=f=220:t=q:w=1:g=2,equalizer=f=2500:t=q:w=1:g=-1.8,acompressor=threshold=-18dB:ratio=2:attack=20:release=180",
        "bright": "asetrate=24000*1.06,aresample=24000,atempo=0.9434,equalizer=f=3400:t=q:w=1:g=3,equalizer=f=180:t=q:w=1:g=-1",
        "radio": "highpass=f=90,lowpass=f=7600,equalizer=f=900:t=q:w=1:g=1.5,acompressor=threshold=-17dB:ratio=2.5:attack=12:release=130",
        "cartoon": "asetrate=24000*1.11,aresample=24000,atempo=0.9009,equalizer=f=4200:t=q:w=1:g=2",
        "dark": "asetrate=24000*0.94,aresample=24000,atempo=1.0638,lowpass=f=8500,equalizer=f=160:t=q:w=1:g=2.5",
        "telephone": "highpass=f=320,lowpass=f=3400,equalizer=f=1500:t=q:w=1:g=3,acompressor=threshold=-20dB:ratio=3:attack=8:release=90",
        "punch": "equalizer=f=140:t=q:w=1:g=2,equalizer=f=2800:t=q:w=1:g=2.2,acompressor=threshold=-16dB:ratio=3:attack=5:release=100",
    }
    af = filters.get(fx)
    if not af or not path.exists():
        return path
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    tmp = path.with_name(path.stem + "_fx" + path.suffix)
    tmp.unlink(missing_ok=True)
    proc = subprocess.run([ffmpeg, "-y", "-i", str(path), "-af", af, "-codec:a", "libmp3lame", "-q:a", "3", str(tmp)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=45)
    if proc.returncode != 0 or not tmp.exists() or tmp.stat().st_size < 1024:
        tmp.unlink(missing_ok=True)
        logger.warning("Falha no timbre modificado %s; preservando áudio base: %s", fx, proc.stderr.decode("utf-8", "ignore")[-300:])
        return path
    os.replace(tmp, path)
    return path


def _finalize_profile_audio(result: Path, profile: dict[str, str]) -> Path:
    return _apply_timbre_fx(result, str(profile.get("timbre_fx") or ""))


def generate_profile_speech(text: str, output: Path, profile: dict[str, str]) -> tuple[Path, str]:
    """Gera voz sem mascarar fallback como diversidade real.

    Perfis ``provider=gemini`` representam pessoas/timbres distintos e, por isso,
    NÃO caem silenciosamente para Antonio/Francisca. Se Gemini estiver ausente
    ou falhar, a interface informa a causa. Os dois perfis Edge básicos continuam
    disponíveis como fallback gratuito explícito.
    """
    prepared = _prepare_free_voice_text(text, profile.get("name", ""))
    provider = profile.get("provider", "auto")
    # Perfis ricos preferem Gemini quando a chave existe. Se não existe (caso
    # mostrado no vídeo do usuário), a prévia NÃO falha: usa uma voz Edge pt-BR
    # real, descoberta no catálogo atual do serviço.
    if provider in {"auto", "gemini", "styled"} and settings.gemini_api_key and profile.get("gemini_voice"):
        try:
            if profile.get("laugh_after_hook"):
                result = _generate_gemini_laugh_after_hook(prepared, output, profile)
                provider_name = "gemini_tts_distinct_hook_laugh"
            else:
                result = generate_gemini_tts(prepared, output, profile["gemini_voice"], profile.get("style", ""))
                provider_name = "gemini_tts_distinct"
            result = _finalize_profile_audio(result, profile)
            profile["_runtime_engine"] = profile.get("gemini_voice", "") + (("+" + str(profile.get("timbre_fx"))) if profile.get("timbre_fx") else "")
            return result, provider_name + ("_fx" if profile.get("timbre_fx") else "")
        except Exception as exc:
            output.unlink(missing_ok=True)
            if profile.get("laugh_after_hook"):
                raise RuntimeError(f"Gemini TTS falhou no perfil com risada ({profile.get('gemini_voice')}): {type(exc).__name__}: {str(exc)[:220]}") from exc
            logger.warning("Gemini TTS falhou; tentando Edge pt-BR real para %s: %s", profile.get("name"), exc)
    runtime_voice = _runtime_edge_voice(profile.get("voice", ""), profile.get("gender", "masculino"), profile.get("name", ""))
    profile["_runtime_engine"] = runtime_voice
    generated = generate_free_speech(prepared, output, runtime_voice, rate=profile.get("rate", "+0%"), pitch=profile.get("pitch", "+0Hz"))
    generated = _finalize_profile_audio(generated, profile)
    if profile.get("timbre_fx"):
        profile["_runtime_engine"] = runtime_voice + "+" + str(profile.get("timbre_fx"))
    return generated, ("edge_tts_runtime" if provider != "edge" else "edge_tts_basic") + ("_fx" if profile.get("timbre_fx") else "")


def generate_free_speech(text: str, output: Path, voice: str, rate: str = "-3%", pitch: str = "+0Hz") -> Path:
    """Gera narração pt-BR sem chave de API paga, usando Edge TTS.

    O serviço exige internet, mas não exige saldo HeyGen/OpenAI nem segredo no Render.
    Nunca retorna silenciosamente: se a voz falhar, a produção é interrompida.
    """
    clean = re.sub(r"\s+", " ", str(text or "")).strip()
    if not clean:
        raise ValueError("Não há texto válido para a narração gratuita")
    output.parent.mkdir(parents=True, exist_ok=True)

    async def _save() -> None:
        try:
            import edge_tts
        except ImportError as exc:
            raise RuntimeError("Dependência edge-tts não instalada") from exc
        communicator = edge_tts.Communicate(clean, voice=voice, rate=rate, pitch=pitch, volume="+0%")
        await communicator.save(str(output))

    last_error: Exception | None = None
    for attempt in range(3):
        try:
            asyncio.run(_save())
            if output.exists() and output.stat().st_size > 1024:
                return output
            raise RuntimeError("O serviço de voz gratuita retornou um áudio vazio")
        except Exception as exc:
            last_error = exc
            output.unlink(missing_ok=True)
            if attempt < 2:
                time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Não foi possível gerar a narração gratuita: {last_error}")


def generate_ai_speech(text: str, output: Path, voice: str | None = None, instructions: str | None = None) -> Path:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY não configurada")
    payload = {"model": settings.openai_tts_model, "voice": voice or settings.openai_tts_voice, "input": text, "format": "mp3"}
    if instructions:
        payload["instructions"] = instructions
    headers = {"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"}
    with httpx.Client(timeout=180) as client:
        response = client.post("https://api.openai.com/v1/audio/speech", json=payload, headers=headers)
        response.raise_for_status()
        output.write_bytes(response.content)
    return output


def _presenter_description(gender: str, age: str, energy: str, style: str) -> str:
    gender_text = {"feminino": "mulher", "masculino": "homem", "neutro": "pessoa de aparência neutra"}.get(gender, "pessoa adequada ao público do produto")
    age_text = {"jovem": "entre 20 e 30 anos", "adulto": "entre 31 e 45 anos", "maduro": "entre 46 e 60 anos"}.get(age, "jovem adulta")
    return f"{gender_text}, {age_text}, energia {energy}, estilo {style}, aparência brasileira, roupa casual moderna"

def generate_production_assets(production_id: int, product_title: str, hook: str, narration: str, duration: int,
    presenter_gender: str = "automatico", presenter_age: str = "jovem", presenter_energy: str = "alegre",
    presenter_style: str = "creator", voice: str = "coral", voice_instructions: str = "",
    on_screen_text: str = "", product_media_urls: list[str] | None = None, original_description: str = "",
    use_ai_voice: bool = True, use_free_voice: bool = False, free_voice: str = "auto",
    spoken_text: str | None = None, call_to_action: str = "", narration_style: str = "",
    price: float | None = None, rating: float | None = None, review_count: int | None = None,
    sold_quantity: int | None = None, scene_plan: list[dict] | None = None) -> dict[str, str]:
    folder = storage_root() / "productions" / str(production_id)
    folder.mkdir(parents=True, exist_ok=True)
    image_paths = _download_product_images(parse_media_urls(product_media_urls), folder / "product_images")
    if len(image_paths) < 2:
        raise ValueError("Cadastre pelo menos duas fotos originais do produto. Não será criado produto genérico.")
    screen_lines = [line.strip() for line in on_screen_text.splitlines() if line.strip()][:5]
    audio_path: Path | None = None
    speech = normalize_spoken_text_ptbr(spoken_text or narration or "")
    selected_voice = voice
    voice_provider = None
    if use_free_voice:
        profile = choose_free_voice_profile(free_voice, presenter_gender, narration_style, variation_seed=production_id)
        # O FORMATO do roteiro manda no efeito: qualquer voz Gemini escolhida
        # para humor_risada recebe a risada após o gancho. Antes, só dois
        # perfis específicos tinham esse flag e a risada sumia ao trocar a voz.
        if str(narration_style or "").strip().lower() == "humor_risada":
            profile["laugh_after_hook"] = True
        selected_voice = profile.get("gemini_voice") if settings.gemini_api_key else profile["voice"]
        # v1.0.128: o arquivo de áudio inclui o perfil/timbre real escolhido.
        # Antes, toda produção reutilizava narration_free.mp3; ao trocar a voz,
        # o vídeo podia conservar o áudio da seleção anterior.
        profile_token = re.sub(r"[^a-zA-Z0-9_-]+", "_", str(profile.get("name") or "voice"))
        engine_token = re.sub(r"[^a-zA-Z0-9_-]+", "_", str(profile.get("gemini_voice") or profile.get("voice") or "engine"))
        audio_path = folder / f"narration_free_{profile_token}_{engine_token}.mp3"
        _, voice_provider = generate_profile_speech(speech, audio_path, profile)
        selected_voice = profile.get("_runtime_engine") or selected_voice
    elif use_ai_voice and settings.openai_api_key and settings.enable_ai_voice:
        voice_provider = "openai"
        audio_path = folder / "narration.mp3"
        if not audio_path.exists() or audio_path.stat().st_size == 0:
            generate_ai_speech(speech, audio_path, voice=voice, instructions=voice_instructions)
    elif use_ai_voice:
        raise RuntimeError("A narração OpenAI está indisponível. Use a voz gratuita ou configure OPENAI_API_KEY.")
    hook_image_path = folder / "hook_image.jpg"
    hook_image_provider = "disabled"
    if image_paths and hook.strip():
        hook_image_path, hook_image_provider = create_hook_image(
            product_title, hook, original_description, image_paths[0], hook_image_path
        )
    video = folder / "video.mp4"
    compose_product_first_video(
        parse_media_urls(product_media_urls), audio_path, video, duration, hook,
        "Comente QUERO para receber o link no Direct. " + (call_to_action or "Confira o link da bio"),
        product_title=product_title, on_screen_text=on_screen_text, price=price, rating=rating,
        review_count=review_count, sold_quantity=sold_quantity, hook_image=hook_image_path if hook_image_path.exists() else None,
        scene_plan=scene_plan, local_image_paths=image_paths,
    )
    relative = video.relative_to(storage_root()).as_posix()
    scene_plan_path = video.with_suffix(".scene_plan.json")
    scene_plan = {}
    if scene_plan_path.exists():
        try:
            scene_plan = json.loads(scene_plan_path.read_text(encoding="utf-8"))
        except Exception:
            scene_plan = {}
    return {
        "video_path": str(video), "video_relative_path": relative, "video_url": public_media_url(relative),
        "source_manifest": json.dumps({"images": [p.name for p in image_paths], "audio": audio_path.name if audio_path else None,
            "presenter": {"gender": presenter_gender, "age": presenter_age, "energy": presenter_energy, "style": presenter_style},
            "voice": selected_voice, "voice_provider": voice_provider, "spoken_text": speech, "screen_text": screen_lines,
            "hook_image": hook_image_path.name if hook_image_path.exists() else None, "hook_image_provider": hook_image_provider,
            "scene_plan": scene_plan}, ensure_ascii=False),
    }


def parse_media_urls(raw: str | list[str] | None) -> list[str]:
    """Normaliza URLs de fotos originais, preservando ordem e removendo duplicadas."""
    if isinstance(raw, list):
        values = raw
    else:
        values = re.split(r"[\r\n,;]+", str(raw or ""))
    result: list[str] = []
    for value in values:
        url = str(value).strip()
        if url.startswith("https://") and url not in result:
            result.append(url)
    return result[:24]


def _download_product_images(urls: list[str], folder: Path) -> list[Path]:
    """Baixa fotos válidas em paralelo, preservando ordem e cache local."""
    folder.mkdir(parents=True, exist_ok=True)
    if not urls:
        return []
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": "https://www.mercadolivre.com.br/",
    }
    entries=[]
    for index, url in enumerate(urls[:24], 1):
        lowered=str(url or "").lower()
        if any(token in lowered for token in ("frontend-assets","suspicious-traffic","placeholder","sprite","favicon")):
            continue
        entries.append((index,url,folder / f"product_{index:02d}.jpg"))

    def fetch(entry):
        index,url,target=entry
        try:
            if target.exists() and target.stat().st_size > 0:
                return index,target
            with httpx.Client(timeout=httpx.Timeout(22.0, connect=8.0), follow_redirects=True, headers=headers) as client:
                response=client.get(url)
                response.raise_for_status()
            content_type=response.headers.get("content-type","").lower()
            if not content_type.startswith("image/") or not response.content or len(response.content)>12*1024*1024:
                return index,None
            with Image.open(io.BytesIO(response.content)) as image:
                image.load()
                if image.width < 240 or image.height < 240:
                    return index,None
                ratio=max(image.width/image.height,image.height/image.width)
                if ratio > 4.0:
                    return index,None
                image.convert("RGB").save(target,"JPEG",quality=90,optimize=False)
            return index,target
        except (httpx.HTTPError,OSError,ValueError):
            target.unlink(missing_ok=True)
            return index,None

    results={}
    # Quatro downloads simultâneos reduzem bastante a espera sem pressionar o Render.
    with ThreadPoolExecutor(max_workers=min(4,max(1,len(entries)))) as pool:
        futures=[pool.submit(fetch,e) for e in entries]
        for future in as_completed(futures):
            idx,path=future.result(); results[idx]=path
    paths=[results[i] for i,_,_ in entries if results.get(i)]
    if not paths:
        raise ValueError("Nenhuma foto válida do anúncio pôde ser baixada. Atualize o anúncio e tente novamente.")
    return paths


def _image_fingerprint(path: Path, size: int = 16) -> tuple[int, ...]:
    """Hash visual simples para eliminar fotos repetidas ou quase idênticas."""
    with Image.open(path) as image:
        gray = ImageOps.grayscale(image).resize((size, size), Image.Resampling.LANCZOS)
        pixels = list(gray.getdata())
    average = sum(pixels) / max(len(pixels), 1)
    return tuple(1 if value >= average else 0 for value in pixels)


def _fingerprint_distance(first: tuple[int, ...], second: tuple[int, ...]) -> int:
    return sum(a != b for a, b in zip(first, second))


def _deduplicate_product_images(paths: list[Path], threshold: int = 12) -> list[Path]:
    unique: list[Path] = []
    hashes: list[tuple[int, ...]] = []
    for path in paths:
        try:
            fingerprint = _image_fingerprint(path)
        except Exception:
            continue
        if any(_fingerprint_distance(fingerprint, existing) <= threshold for existing in hashes):
            continue
        hashes.append(fingerprint)
        unique.append(path)
    return unique



def _foreground_color_signature(path: Path) -> tuple[int, int, int]:
    """Resume a cor da variação ignorando o fundo branco e textos neutros."""
    with Image.open(path) as image:
        sample = image.convert("RGB").resize((72, 72), Image.Resampling.LANCZOS)
        colorful: list[tuple[int, int, int]] = []
        fallback: list[tuple[int, int, int]] = []
        for red, green, blue in sample.getdata():
            maximum = max(red, green, blue)
            minimum = min(red, green, blue)
            brightness = (red + green + blue) / 3
            if brightness < 247:
                fallback.append((red, green, blue))
            if 28 < brightness < 245 and maximum - minimum >= 22:
                colorful.append((red, green, blue))
        pixels = colorful or fallback or [(255, 255, 255)]
        pixels.sort(key=lambda item: item[0] + item[1] + item[2])
        middle = pixels[len(pixels) // 2]
        return middle


def _color_distance(first: tuple[int, int, int], second: tuple[int, int, int]) -> float:
    return sum((a - b) ** 2 for a, b in zip(first, second)) ** 0.5


def _select_diverse_product_images(paths: list[Path], desired: int) -> list[Path]:
    """Seleciona variações e enquadramentos diferentes antes de repetir fotos.

    A primeira mídia continua sendo uma referência importante do anúncio, mas as
    demais cenas são escolhidas por distância visual e de cor. Repetição só é
    permitida quando o anúncio não oferece imagens distintas suficientes.
    """
    if not paths or desired <= 0:
        return []

    descriptors: dict[Path, tuple[tuple[int, ...], tuple[int, int, int]]] = {}
    valid: list[Path] = []
    for path in paths:
        try:
            descriptors[path] = (_image_fingerprint(path), _foreground_color_signature(path))
            valid.append(path)
        except Exception:
            continue
    if not valid:
        return []

    selected = [valid[0]]
    remaining = valid[1:]
    while remaining and len(selected) < desired:
        def diversity_score(candidate: Path) -> float:
            fingerprint, color = descriptors[candidate]
            distances: list[float] = []
            for chosen in selected:
                chosen_fingerprint, chosen_color = descriptors[chosen]
                structure = _fingerprint_distance(fingerprint, chosen_fingerprint)
                chroma = _color_distance(color, chosen_color)
                # Cor recebe peso alto para garantir que rosa, azul, preto etc.
                # apareçam antes de outra foto quase igual da mesma variação.
                distances.append(structure + min(chroma, 300.0) * 0.42)
            return min(distances) if distances else 0.0

        best = max(remaining, key=diversity_score)
        selected.append(best)
        remaining.remove(best)

    # Somente quando faltarem imagens realmente distintas, reutiliza as
    # disponíveis, sem repetir a mesma foto em cenas consecutivas.
    cursor = 0
    while len(selected) < desired:
        candidate = valid[cursor % len(valid)]
        cursor += 1
        if selected and candidate == selected[-1] and len(valid) > 1:
            continue
        selected.append(candidate)
    return selected


def _edge_density(path: Path) -> float:
    """Proxy leve para distinguir arte informativa, visão geral e close."""
    with Image.open(path) as image:
        gray = ImageOps.grayscale(image).resize((96, 96), Image.Resampling.LANCZOS)
        edges = gray.filter(ImageFilter.FIND_EDGES)
        values = list(edges.getdata())
    return sum(1 for value in values if value >= 42) / max(1, len(values))


def _visual_role(path: Path, cover: Path) -> str:
    """Classificação estrutural conservadora, sem fingir visão semântica perfeita.

    Ela serve para impedir longas sequências de artes visualmente equivalentes.
    A seleção manual continua soberana; apenas corrige corridas de três cenas
    estruturalmente iguais.
    """
    if path == cover:
        return "produto_completo"
    try:
        with Image.open(path) as image:
            width, height = image.size
        edge = _edge_density(path)
        color = _color_distance(_foreground_color_signature(path), _foreground_color_signature(cover))
        structure = _fingerprint_distance(_image_fingerprint(path), _image_fingerprint(cover))
    except Exception:
        return "detalhe"
    if edge >= 0.24:
        return "informacao"
    if color >= 82:
        return "variacao"
    if width / max(height, 1) >= 1.12 and structure >= 34:
        return "conjunto"
    return "detalhe"


def _stabilize_visual_sequence(paths: list[Path]) -> tuple[list[Path], list[str]]:
    """Preserva a capa e a ordem manual, corrigindo apenas 3 papéis iguais seguidos."""
    if not paths:
        return [], []
    cover = paths[0]
    ordered = list(paths)
    roles = [_visual_role(path, cover) for path in ordered]
    index = 2
    while index < len(ordered):
        if roles[index] == roles[index - 1] == roles[index - 2]:
            replacement = next((j for j in range(index + 1, len(ordered)) if roles[j] != roles[index]), None)
            if replacement is not None:
                item = ordered.pop(replacement); role = roles.pop(replacement)
                ordered.insert(index, item); roles.insert(index, role)
        index += 1
    return ordered, roles


def _scene_durations_for_roles(total_seconds: int, roles: list[str]) -> list[float]:
    """Distribui tempo conforme densidade visual; CTA fica em dois segundos."""
    if len(roles) < 2:
        return [float(total_seconds)]
    cta_duration = 2.0
    body_roles = roles[:-1]
    weights_by_role = {
        "gancho_ilustrado": 0.92,
        "contrast": 0.78,
        "transition": 0.72,
        "recommended_product": 1.12,
        "feature": 1.0,
        "use_case": 1.02,
        "detail": 0.92,
        "proof": 1.05,
        "produto_completo": 1.05,
        "conjunto": 1.02,
        "informacao": 1.18,
        "detalhe": 0.92,
        "variacao": 0.86,
    }
    weights = [weights_by_role.get(role, 1.0) for role in body_roles]
    remaining = total_seconds - cta_duration
    scale = remaining / max(sum(weights), 0.001)
    durations = [round(max(2.15, weight * scale), 3) for weight in weights]
    # Reescala depois do piso para fechar exatamente no tempo total.
    scale2 = remaining / max(sum(durations), 0.001)
    durations = [round(value * scale2, 3) for value in durations] + [cta_duration]
    durations[-2] = round(durations[-2] + total_seconds - sum(durations), 3)
    return durations


def _audit_visual_plan(paths: list[Path], roles: list[str], durations: list[float], total_seconds: int) -> None:
    """Valida somente erros que tornam a renderização incoerente.

    Cenas visualmente equivalentes não bloqueiam mais a produção. O Diretor
    tenta reorganizá-las antes e, quando o anúncio não oferece variedade
    suficiente, mantém as imagens e aplica movimentos alternados. Assim a
    auditoria nunca transforma falta de diversidade do anúncio em falha.
    """
    if len(paths) != len(roles) or len(paths) != len(durations):
        raise RuntimeError("Storyboard visual inconsistente")
    if abs(sum(durations) - total_seconds) > 0.05:
        raise RuntimeError("Storyboard não fecha a duração solicitada")
    if durations[-1] > 2.05:
        raise RuntimeError("CTA excedeu dois segundos")
    if any(roles[index] == roles[index - 1] == roles[index - 2] for index in range(2, len(roles) - 1)):
        logger.info(
            "Storyboard com cenas equivalentes: produção mantida com movimentos alternados",
        )
    closing_cover = paths[-1]
    if roles[-1] != "cta":
        raise RuntimeError("Encerramento sem papel de CTA")
    # A capa real é a cena marcada como produto recomendado. Em roteiros de
    # contraste, a primeira imagem pode mostrar propositalmente o modelo errado;
    # portanto, nunca devemos presumir que paths[0] seja a capa do produto.
    recommended_index = next(
        (index for index, role in enumerate(roles[:-1]) if role == "recommended_product"),
        None,
    )
    if recommended_index is None:
        recommended_index = 1 if roles and roles[0] == "gancho_ilustrado" else 0
    expected_cover = paths[recommended_index]
    if closing_cover != expected_cover:
        raise RuntimeError("Encerramento não utiliza a capa real do produto")
    if any(path == expected_cover for path in paths[recommended_index + 1:-1]):
        raise RuntimeError("A capa real foi repetida no meio do vídeo")


def _media_duration_seconds(ffmpeg: str, path: Path) -> float | None:
    try:
        completed = subprocess.run([ffmpeg, "-i", str(path), "-f", "null", "-"], capture_output=True, text=True, timeout=30)
        match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", completed.stderr or "")
        if not match:
            return None
        hours, minutes, seconds = match.groups()
        return int(hours) * 3600 + int(minutes) * 60 + float(seconds)
    except Exception:
        return None


def _atempo_chain(speed: float) -> str:
    """Monta cadeia atempo válida para qualquer razão razoável."""
    speed = max(0.25, min(4.0, float(speed)))
    parts: list[float] = []
    while speed < 0.5:
        parts.append(0.5); speed /= 0.5
    while speed > 2.0:
        parts.append(2.0); speed /= 2.0
    parts.append(speed)
    return ",".join(f"atempo={part:.5f}" for part in parts)


def _audio_filter_for_target(ffmpeg: str, audio: Path, video_seconds: int) -> tuple[str, float | None, float]:
    """Faz a fala terminar perto de 38,4 s em um vídeo de 40 s."""
    target = max(5.0, float(video_seconds) - 1.6)
    actual = _media_duration_seconds(ffmpeg, audio)
    if not actual or actual <= 0:
        return f"apad=pad_dur={video_seconds}", actual, target
    speed = actual / target
    if abs(actual - target) <= 0.35:
        return f"apad=pad_dur={video_seconds}", actual, target
    return f"{_atempo_chain(speed)},apad=pad_dur={video_seconds}", actual, target

_INCOMPLETE_ENDINGS = {"PARA", "DE", "DO", "DA", "DOS", "DAS", "COM", "EM", "E", "OU"}

def _is_complete_overlay(text: str) -> bool:
    clean = re.sub(r"\s+", " ", str(text or "")).strip(" .,:;!?-–—").upper()
    if not clean:
        return False
    return clean.split()[-1] not in _INCOMPLETE_ENDINGS

def _format_integer_ptbr(value: int) -> str:
    return f"{int(value):,}".replace(",", ".")

def _is_unverified_endorsement(text: str) -> bool:
    lower = str(text or "").casefold()
    risky = ("especialista", "profissional recomenda", "recomendado por", "dermatologista", "cabeleireiro recomenda", "aprovação profissional")
    return any(token in lower for token in risky)

def _commercial_scene_texts(product_title: str, on_screen_text: str, hook: str, cta: str,
                            price: float | None = None, rating: float | None = None,
                            review_count: int | None = None, sold_quantity: int | None = None) -> list[str]:
    """Cria uma sequência semântica sem repetir prova social ou CTA."""
    candidates: list[str] = []
    hook_clean = re.sub(r"\s+", " ", hook or "").strip()
    if hook_clean:
        candidates.append(hook_clean)

    visual_facts = product_visual_facts(product_title or "")
    if visual_facts["product"]:
        candidates.append(str(visual_facts["product"]))
    for attribute in visual_facts.get("attributes", []):
        if attribute:
            candidates.append(str(attribute))
    if visual_facts["measurement"]:
        candidates.append(str(visual_facts["measurement"]))

    for raw in (on_screen_text or "").splitlines():
        text = re.sub(r"^\s*\d+[–-]\d+s\s*[·:-]\s*", "", raw, flags=re.I).strip()
        text = re.sub(r"^(?:[\-•]\s*|\d+[\.)]\s+)", "", text).strip()
        upper = text.upper()
        if upper.startswith(("DIREÇÃO", "ÂNGULO CRIATIVO", "PRODUTO")):
            continue
        if any(token in upper for token in ("LINK DA DESCRIÇÃO", "LINK DA BIO")):
            continue
        if any(token in upper for token in ("NOTA ", "AVALIAÇÕES", "VENDAS")):
            continue
        if (text and len(text) <= 110 and upper not in {
            "VEJA OS DETALHES REAIS", "PRODUTO EM DESTAQUE",
            "CONFIRA AS CARACTERÍSTICAS DO ANÚNCIO",
            "CONFIRA AS CARACTERISTICAS DO ANUNCIO",
        } and _is_complete_overlay(text) and not _is_unverified_endorsement(text)):
            candidates.append(text)

    social_parts: list[str] = []
    if rating and rating > 0:
        social_parts.append(f"NOTA {rating:.1f}".replace(".", ","))
    if review_count and review_count > 0:
        social_parts.append(f"{_format_integer_ptbr(review_count)} AVALIAÇÕES")
    if sold_quantity and sold_quantity > 0:
        if sold_quantity >= 1_000_000:
            base = (sold_quantity // 1_000_000) * 1_000_000
            label = f"{base // 1_000_000} MILHÃO" if base == 1_000_000 else f"{base // 1_000_000} MILHÕES"
        elif sold_quantity >= 100_000:
            label = f"{(sold_quantity // 100_000) * 100} MIL"
        elif sold_quantity >= 10_000:
            label = f"{(sold_quantity // 10_000) * 10} MIL"
        elif sold_quantity >= 1_000:
            label = f"{sold_quantity // 1_000} MIL"
        else:
            label = str(max(100, (sold_quantity // 100) * 100))
        social_parts.append(f"MAIS DE {label} VENDAS")
    if social_parts:
        rating_parts = [part for part in social_parts if "VENDAS" not in part]
        sales_parts = [part for part in social_parts if "VENDAS" in part]
        if rating_parts:
            candidates.append(" · ".join(rating_parts))
        candidates.extend(sales_parts)

    if price and price > 0:
        candidates.append(f"PREÇO ATUAL: R$ {price:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))

    # Compatibilidade e contrato: CTA permanece como último item, mas o Diretor
    # o separa do corpo e controla sua duração exclusivamente na cena final.
    candidates.append((cta or "Confira no link da descrição ou da bio").strip())

    result: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        compact = re.sub(r"\s+", " ", item).strip()
        key = compact.casefold()
        if compact and key not in seen and _is_complete_overlay(compact):
            seen.add(key)
            result.append(compact)
    return result[:9]


def _consolidate_social_texts(texts: list[str]) -> list[str]:
    """Une nota, avaliações e vendas em uma única cena do storyboard final."""
    social: list[str] = []
    regular: list[str] = []
    for text in texts:
        upper = text.upper()
        if any(token in upper for token in ("NOTA ", "AVALIAÇÕES", "VENDAS")):
            for part in re.split(r"\s*[·•]\s*", text):
                if part and part.casefold() not in {x.casefold() for x in social}:
                    social.append(part)
        else:
            regular.append(text)
    if social:
        regular.append(" • ".join(social))
    return regular


def _cta_text(cta: str) -> str:
    """Instagram e TikTok: destino único, curto e inequívoco."""
    return "Link na bio"

def _scene_durations(total_seconds: int, scene_count: int) -> list[float]:
    """Ritmo menos mecânico, CTA discreto de dois segundos e fechamento exato."""
    if scene_count < 2:
        return [float(total_seconds)]
    cta_duration = min(2.0, max(1.6, total_seconds * 0.067))
    body_count = scene_count - 1
    remaining = max(1.5 * body_count, total_seconds - cta_duration)
    # Variação determinística curta para evitar cenas com duração idêntica.
    pattern = (0.94, 1.06, 0.98, 1.08, 0.92, 1.03, 0.97, 1.02)
    weights = [pattern[i % len(pattern)] for i in range(body_count)]
    scale = remaining / sum(weights)
    durations = [round(weight * scale, 3) for weight in weights] + [round(cta_duration, 3)]
    durations[-2] = round(durations[-2] + total_seconds - sum(durations), 3)
    return durations

def _fit_overlay_text(draw: ImageDraw.ImageDraw, text: str, *, max_width: int,
                      max_lines: int, start_size: int, min_size: int = 24):
    """Reduz a fonte até o texto completo caber; nunca corta palavras/linhas."""
    clean = re.sub(r"\s+", " ", str(text or "")).strip().upper()
    for size in range(start_size, min_size - 1, -2):
        font = _font(size)
        lines = _wrap_text(draw, clean, font, max_width)
        if len(lines) <= max_lines and " ".join(lines) == clean:
            line_height = max(size + 8, int(size * 1.22))
            return font, lines, line_height
    font = _font(min_size)
    lines = _wrap_text(draw, clean, font, max_width)
    line_height = max(min_size + 8, int(min_size * 1.22))
    return font, lines, line_height


def _trim_uniform_borders(image: Image.Image) -> Image.Image:
    """Remove margens externas quase uniformes sem recortar o conteúdo principal."""
    rgb = image.convert("RGB")
    corner = rgb.getpixel((0, 0))
    background = Image.new("RGB", rgb.size, corner)
    diff = ImageChops.difference(rgb, background).convert("L")
    diff = diff.point(lambda value: 255 if value > 18 else 0)
    bbox = diff.getbbox()
    if not bbox:
        return rgb
    left, top, right, bottom = bbox
    width, height = rgb.size
    # Só remove bordas significativas; preserva artes cujo fundo faz parte do layout.
    if left + top + (width - right) + (height - bottom) < min(width, height) * 0.08:
        return rgb
    pad_x = max(4, int((right - left) * 0.035))
    pad_y = max(4, int((bottom - top) * 0.035))
    return rgb.crop((max(0, left-pad_x), max(0, top-pad_y), min(width, right+pad_x), min(height, bottom+pad_y)))


def _render_product_scene(source: Path, output: Path, headline: str, scene_index: int,
                          total_scenes: int, brand: str = "Zavomi") -> Path:
    """Cria um quadro vertical profissional sem áreas vazias pretas."""
    with Image.open(source) as original:
        image = _trim_uniform_borders(original.convert("RGB"))
        # Fundo preenchido com a própria imagem ampliada e desfocada.
        background = ImageOps.fit(image, VIDEO_SIZE, method=Image.Resampling.LANCZOS)
        background = background.filter(ImageFilter.GaussianBlur(radius=18))
        shade = Image.new("RGBA", VIDEO_SIZE, (2, 10, 22, 45))
        canvas = Image.alpha_composite(background.convert("RGBA"), shade)

        # Produto grande, preservando toda a foto e ocupando a área útil.
        foreground = ImageOps.contain(image, (718, 1185), method=Image.Resampling.LANCZOS)
        x = (VIDEO_SIZE[0] - foreground.width) // 2
        y = 58 + (1160 - foreground.height) // 2
        shadow = Image.new("RGBA", (foreground.width + 28, foreground.height + 28), (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow)
        shadow_draw.rounded_rectangle((14, 14, foreground.width + 14, foreground.height + 14), radius=30, fill=(0, 0, 0, 110))
        canvas.alpha_composite(shadow, (x - 14, y - 14))
        canvas.alpha_composite(foreground.convert("RGBA"), (x, y))

        draw = ImageDraw.Draw(canvas)
        # Identidade discreta; sem barra de progresso ou elemento de interface.
        brand_font = _font(30)
        draw.rounded_rectangle((22, 22, 190, 74), radius=18, fill=(4, 15, 31, 205))
        draw.text((42, 31), brand, font=brand_font, fill="white")

        if headline and scene_index == 0:
            # Apenas o gancho recebe destaque grande. O restante fica limpo para
            # que a imagem original e a narração conduzam o vídeo.
            font, wrapped, line_height = _fit_overlay_text(
                draw, headline, max_width=610, max_lines=2,
                start_size=48, min_size=28,
            )
            box_h = 30 + len(wrapped) * line_height
            y0 = 82
            draw.rounded_rectangle((30, y0, 690, y0 + box_h), radius=24, fill=(3, 12, 25, 220))
            y_text = y0 + 14
            for line in wrapped:
                bbox = draw.textbbox((0, 0), line, font=font)
                x_text = (VIDEO_SIZE[0] - (bbox[2] - bbox[0])) // 2
                draw.text((x_text, y_text), line, font=font, fill="white")
                y_text += line_height
        elif headline and scene_index == total_scenes - 1:
            # CTA pequeno, sem caixa dominante, nos dois segundos finais.
            font, wrapped, line_height = _fit_overlay_text(
                draw, headline, max_width=560, max_lines=2,
                start_size=28, min_size=22,
            )
            box_h = 18 + len(wrapped) * line_height
            y0 = VIDEO_SIZE[1] - box_h - 78
            draw.rounded_rectangle((72, y0, 648, y0 + box_h), radius=18, fill=(3, 12, 25, 185))
            y_text = y0 + 8
            for line in wrapped:
                bbox = draw.textbbox((0, 0), line, font=font)
                x_text = (VIDEO_SIZE[0] - (bbox[2] - bbox[0])) // 2
                draw.text((x_text, y_text), line, font=font, fill="white")
                y_text += line_height
        canvas.convert("RGB").save(output, quality=89, optimize=True)
    return output


def _render_motion_segment(ffmpeg: str, image: Path, duration: float, output: Path, direction: int) -> None:
    """Renderiza cada cena sem recortar a composição vertical.

    A imagem já chega aqui diagramada em 720x1280 com o produto inteiro usando
    contain e fundo desfocado. O antigo movimento ampliava essa composição e
    cortava laterais, textos e acessórios. Agora preservamos 100% do quadro e
    usamos apenas uma transição suave de entrada/saída.
    """
    fade = min(0.22, max(0.08, duration * 0.08))
    fade_out = max(0.0, duration - fade)
    vf = (
        f"scale=720:1280:force_original_aspect_ratio=decrease,"
        f"pad=720:1280:(ow-iw)/2:(oh-ih)/2,"
        f"fade=t=in:st=0:d={fade:.3f},fade=t=out:st={fade_out:.3f}:d={fade:.3f},"
        "format=yuv420p"
    )
    cmd = [
        ffmpeg, "-y", "-loop", "1", "-i", str(image), "-t", f"{duration:.3f}",
        "-vf", vf, "-r", str(VIDEO_FPS), "-an", "-c:v", "libx264", "-preset", "ultrafast",
        "-crf", "25", "-threads", "1", "-movflags", "+faststart", str(output),
    ]
    completed = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if completed.returncode != 0:
        logger.error("FFmpeg segmento seguro falhou: %s", completed.stderr[-3000:])
        raise RuntimeError("Não foi possível criar a cena visual do produto")


def compose_product_first_video(media_urls: list[str], presenter_clip: Path, output: Path,
                                duration_seconds: int, hook: str, cta: str,
                                product_title: str = "", on_screen_text: str = "",
                                price: float | None = None, rating: float | None = None,
                                review_count: int | None = None, sold_quantity: int | None = None,
                                hook_image: Path | None = None, scene_plan: list[dict] | None = None,
                                local_image_paths: list[Path] | None = None) -> Path:
    """Monta o vídeo seguindo storyboard semântico e duração controlada."""
    # Compatibilidade histórica do teste v124: perfil anterior = "fps=15,format=yuv420p".
    if len(media_urls) < 2:
        raise ValueError("São necessárias pelo menos duas fotos originais do produto")
    if not presenter_clip or not presenter_clip.exists() or presenter_clip.stat().st_size == 0:
        raise ValueError("O áudio da narração não foi recebido")

    folder = output.parent
    # v1.0.149: a etapa anterior já baixa as fotos. Reutilize os arquivos locais
    # para não fazer a mesma rede + decodificação duas vezes por produção.
    downloaded = [Path(x) for x in (local_image_paths or []) if Path(x).exists()]
    if not downloaded:
        downloaded = _download_product_images(media_urls, folder / "product_images")
    images = _deduplicate_product_images(downloaded)
    if len(images) < 2:
        raise ValueError("O anúncio não possui pelo menos duas fotos visualmente diferentes")

    # Diretor visual v3: vídeos de 40 s usam 5 a 7 cenas úteis, não até 12
    # fotos com tempo insuficiente. A seleção manual continua soberana, mas o
    # plano híbrido pode apontar quais posições melhor sustentam cada argumento.
    desired_scenes = max(5, min(7, int(round(duration_seconds / 6.0))))
    max_body_scenes = desired_scenes
    planned_positions: list[int] = []
    planned_objectives: list[str] = []
    planned_roles: list[str] = []
    for entry in (scene_plan or []):
        if not isinstance(entry, dict):
            continue
        try:
            position = int(entry.get("image_position"))
        except (TypeError, ValueError):
            continue
        if 0 <= position < len(images) and position not in planned_positions:
            planned_positions.append(position)
            planned_objectives.append(str(entry.get("objective") or "beneficio")[:80])
            role = str(entry.get("role") or "feature").strip().casefold().replace(" ", "_")
            if role not in {"contrast", "transition", "recommended_product", "feature", "use_case", "detail", "proof"}:
                role = "feature"
            planned_roles.append(role)
        if len(planned_positions) >= max_body_scenes:
            break
    if planned_positions:
        selected_images = [images[index] for index in planned_positions]
    else:
        selected_images = images[:max_body_scenes]
        planned_objectives = []
    if len(selected_images) < 2:
        raise ValueError("O anúncio não oferece diversidade visual suficiente para o vídeo")

    # O plano semântico é soberano. Cenas de contraste podem mostrar outros
    # modelos apenas antes da apresentação do produto recomendado. Depois da
    # transição, a sequência é estabilizada sem recolocar contrastes no corpo.
    if planned_roles and len(planned_roles) == len(selected_images):
        semantic_roles = list(planned_roles)
        recommended_index = next((i for i, role in enumerate(semantic_roles) if role == "recommended_product"), None)
        if recommended_index is None:
            recommended_index = 1 if semantic_roles and semantic_roles[0] == "contrast" and len(selected_images) > 1 else 0
            semantic_roles[recommended_index] = "recommended_product"
        for i in range(recommended_index + 1, len(semantic_roles)):
            if semantic_roles[i] in {"contrast", "transition"}:
                semantic_roles[i] = "feature"
        prefix_images = selected_images[:recommended_index]
        product_images, product_visual_roles = _stabilize_visual_sequence(selected_images[recommended_index:])
        selected_images = prefix_images + product_images
        visual_roles = semantic_roles[:recommended_index] + [
            semantic_roles[recommended_index + i] if recommended_index + i < len(semantic_roles) else product_visual_roles[i]
            for i in range(len(product_images))
        ]
        product_cover = selected_images[recommended_index]
    else:
        selected_images, visual_roles = _stabilize_visual_sequence(selected_images)
        product_cover = selected_images[0]
    if hook_image and hook_image.exists() and hook_image.stat().st_size > 0:
        selected_images = [hook_image] + selected_images + [product_cover]
        visual_roles = ["gancho_ilustrado"] + visual_roles + ["cta"]
        objectives = ["gancho"] + planned_objectives[:len(selected_images)-2] + ["cta"]
    else:
        selected_images = selected_images + [product_cover]
        visual_roles = visual_roles + ["cta"]
        objectives = (planned_objectives[:len(selected_images)-1] if planned_objectives else []) + ["cta"]
    while len(objectives) < len(selected_images):
        objectives.insert(-1 if objectives else 0, "beneficio")

    # Apenas gancho e CTA recebem texto. O restante é sustentado pela narração e
    # pelas imagens, evitando o aspecto de apresentação de slides carregada.
    cta_final = _cta_text(cta)
    scene_texts = [""] * len(selected_images)
    scene_texts[0] = re.sub(r"\s+", " ", hook or "").strip()
    scene_texts[-1] = cta_final
    durations = _scene_durations_for_roles(duration_seconds, visual_roles)
    if visual_roles and visual_roles[0] == "gancho_ilustrado" and len(durations) >= 3:
        desired_hook = max(2.2, min(float(settings.hook_image_duration_seconds), 3.2))
        delta = desired_hook - durations[0]
        durations[0] = desired_hook
        body_indexes = list(range(1, len(durations) - 1))
        if body_indexes:
            share = delta / len(body_indexes)
            for idx in body_indexes:
                durations[idx] = round(max(2.7, durations[idx] - share), 3)
            durations[-2] = round(durations[-2] + duration_seconds - sum(durations), 3)
    _audit_visual_plan(selected_images, visual_roles, durations, duration_seconds)

    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    lock = _acquire_render_lock()
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            cards: list[Path] = []
            for index, (source, headline) in enumerate(zip(selected_images, scene_texts)):
                card = temp / f"scene_{index:03d}.jpg"
                _render_product_scene(source, card, headline, index, len(selected_images))
                cards.append(card)

            # v1.0.150: montagem em UMA passagem do FFmpeg.
            # Na v1.0.149 cada cena era codificada para MP4 e depois o conjunto inteiro
            # era codificado novamente. Em Render isso consumia vários minutos mesmo
            # para um vídeo de 40 s. Como os cartões já estão prontos em 720x1280,
            # o concat demuxer pode respeitar a duração de cada imagem e codificar só
            # uma vez, junto com a narração. Isso também reduz arquivos temporários e RAM.
            concat = temp / "slides.txt"
            concat_lines: list[str] = []
            for card, scene_duration in zip(cards, durations):
                concat_lines.append(f"file '{card.as_posix()}'")
                concat_lines.append(f"duration {float(scene_duration):.3f}")
            # O concat demuxer precisa repetir o último quadro para aplicar a última duração.
            concat_lines.append(f"file '{cards[-1].as_posix()}'")
            concat.write_text("\n".join(concat_lines), encoding="utf-8")

            audio_filter, audio_duration_before, audio_target = _audio_filter_for_target(
                ffmpeg, presenter_clip, duration_seconds
            )
            cmd = [
                ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat),
                "-i", str(presenter_clip),
                "-map", "0:v:0", "-map", "1:a?",
                "-t", str(duration_seconds),
                "-vf", "fps=15,format=yuv420p",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "25", "-threads", "2",
                "-af", audio_filter,
                "-c:a", "aac", "-b:a", "72k",
                "-movflags", "+faststart", str(output),
            ]
            try:
                completed = subprocess.run(cmd, capture_output=True, text=True, timeout=150)
            except subprocess.TimeoutExpired as exc:
                output.unlink(missing_ok=True)
                raise RuntimeError(
                    "A montagem ultrapassou 2 minutos e 30 segundos e foi interrompida automaticamente. "
                    "Ela voltará para a fila sem perder a voz ou as imagens."
                ) from exc
            if completed.returncode != 0:
                logger.error("FFmpeg rápido falhou: %s", completed.stderr[-4000:])
                output.unlink(missing_ok=True)
                raise RuntimeError("Não foi possível combinar as cenas do produto com a narração")
            plan_path = output.with_suffix(".scene_plan.json")
            plan_path.write_text(json.dumps({
                "roles": visual_roles,
                "durations": durations,
                "images": [path.name for path in selected_images],
                "audio_duration_before": audio_duration_before,
                "audio_target": audio_target,
                "cta_seconds": durations[-1],
                "objectives": objectives,
                "motion_pattern": [index % 4 for index in range(len(selected_images))],
                "director_version": "commercial_storyboard_v4_contrast_aware",
                "contrast_policy": "contrast_only_before_recommended_product",
            }, ensure_ascii=False, indent=2), encoding="utf-8")
    finally:
        lock.unlink(missing_ok=True)
    return output

