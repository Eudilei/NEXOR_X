from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import logging
from typing import Any
import re

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Product
from app.services.zavomi_site import refresh_product_from_source, source_metadata, save_source_metadata

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse_datetime(value: object) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except (TypeError, ValueError):
        return None


def missing_fields(product: Product, meta: dict[str, Any] | None = None) -> list[str]:
    meta = meta or source_metadata(product)
    fields: list[str] = []
    if int(product.sold_quantity or 0) <= 0:
        fields.append("sold_quantity")
    if float(product.commission_pct or 0) <= 0:
        fields.append("commission_pct")
    if not bool(meta.get("stock_confirmed")):
        fields.append("stock_available")
    if float(product.rating or 0) <= 0 or int(product.review_count or 0) <= 0:
        fields.append("reviews")
    if not product.original_price or float(product.original_price or 0) <= float(product.price or 0):
        fields.append("original_price")
    if not bool(meta.get("affiliate_link_confirmed")):
        fields.append("affiliate_link")
    return fields


def _source_rank(product: Product, meta: dict[str, Any]) -> int:
    for key in ("source_rank", "ranking_position", "rank"):
        try:
            value = int(meta.get(key) or 0)
            if value > 0:
                return value
        except (TypeError, ValueError):
            pass
    match = re.search(r"posição\s*#(\d+)", str(product.notes or ""), flags=re.IGNORECASE)
    return int(match.group(1)) if match else 9999


def _priority(product: Product, meta: dict[str, Any]) -> tuple[int, int, int]:
    missing = set(missing_fields(product, meta))
    # Ordem solicitada: vendas > comissão > estoque > avaliações > preço anterior > afiliado.
    weights = {
        "sold_quantity": 100,
        "commission_pct": 80,
        "stock_available": 60,
        "reviews": 50,
        "original_price": 30,
        "affiliate_link": 20,
    }
    score = sum(weights.get(field, 0) for field in missing)
    # Produtos pré-selecionados pelo ranking oficial são enriquecidos primeiro.
    # Dentro deles, respeitamos a melhor posição no ranking antes do volume de
    # campos faltantes. Isso concentra as consultas nos candidatos de maior
    # potencial comercial e evita gastar orçamento nos itens fracos.
    preselected_bucket = 0 if product.status == "pre_selecionado" else 1
    rank = _source_rank(product, meta) if preselected_bucket == 0 else 9999
    return (preselected_bucket, rank, -score, int(product.id or 0))


def _is_due(meta: dict[str, Any], now: datetime) -> bool:
    next_at = _parse_datetime(meta.get("enrichment_next_attempt_at"))
    return next_at is None or next_at <= now


def _has_source(product: Product, meta: dict[str, Any]) -> bool:
    url = str(meta.get("listing_url") or product.affiliate_url or "").strip()
    return bool(url.startswith("https://") or product.external_product_id or meta.get("catalog_product_id"))


def enrich_incomplete_products(db: Session, *, batch_size: int = 8, preselected_only: bool = False, ignore_schedule: bool = False) -> dict[str, Any]:
    """Reconsulta produtos incompletos sem inventar métricas.

    O processo é incremental: escolhe os campos de maior impacto comercial,
    preserva valores confirmados e aplica backoff quando a fonte não expõe um dado.
    """
    now = _utcnow()
    products = db.scalars(
        select(Product)
        .where(Product.marketplace == "mercado_livre")
        .order_by(Product.updated_at.asc(), Product.id.asc())
        .limit(500)
    ).all()

    candidates: list[tuple[Product, dict[str, Any]]] = []
    for product in products:
        meta = source_metadata(product)
        current_missing = missing_fields(product, meta)
        if preselected_only and product.status != "pre_selecionado":
            continue
        if not current_missing or (not ignore_schedule and not _is_due(meta, now)) or not _has_source(product, meta):
            continue
        candidates.append((product, meta))
    candidates.sort(key=lambda row: _priority(row[0], row[1]))
    selected = candidates[: max(1, int(batch_size or 1))]

    results: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    for product, before_meta in selected:
        before_missing = missing_fields(product, before_meta)
        try:
            refresh_product_from_source(db, product)
            meta = source_metadata(product)
            after_missing = missing_fields(product, meta)
            improved = len(after_missing) < len(before_missing)
            attempts = int(meta.get("enrichment_attempts") or 0)
            # Se houve ganho, tenta de novo mais cedo; se a fonte não trouxe nada,
            # amplia o intervalo para evitar chamadas repetitivas inúteis.
            wait_hours = 6 if improved else min(48, 12 + max(0, attempts - 1) * 4)
            meta["enrichment_next_attempt_at"] = (now + timedelta(hours=wait_hours)).isoformat()
            meta["enrichment_missing_fields"] = after_missing
            meta["enrichment_complete"] = not after_missing
            meta["enrichment_last_error"] = ""
            meta["enrichment_priority"] = "ranking_preselected" if product.status == "pre_selecionado" else "standard"
            meta["enrichment_source_rank"] = _source_rank(product, meta)
            save_source_metadata(product, meta)
            db.add(product)
            db.commit()
            results.append({
                "product_id": product.id,
                "before": before_missing,
                "after": after_missing,
                "improved": improved,
            })
        except Exception as exc:
            db.rollback()
            current = db.get(Product, product.id)
            if current:
                meta = source_metadata(current)
                attempts = int(meta.get("enrichment_attempts") or 0) + 1
                meta["enrichment_attempts"] = attempts
                meta["enrichment_last_attempt_at"] = now.isoformat()
                meta["enrichment_last_error"] = str(exc)[:500]
                meta["enrichment_next_attempt_at"] = (now + timedelta(hours=min(48, 6 + attempts * 4))).isoformat()
                meta["enrichment_missing_fields"] = missing_fields(current, meta)
                save_source_metadata(current, meta)
                db.add(current)
                db.commit()
            errors.append({"product_id": product.id, "error": str(exc)[:300]})
            logger.warning("Falha ao enriquecer produto %s: %s", product.id, exc)

    return {
        "eligible": len(candidates),
        "processed": len(selected),
        "updated": sum(1 for row in results if row["improved"]),
        "results": results,
        "errors": errors,
    }
