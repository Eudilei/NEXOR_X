from __future__ import annotations

from datetime import datetime, timezone
import json
from time import perf_counter
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.models import Product, ProductObservation
from app.services.marketplace import MarketplaceRequestError, MIN_ZAVOMI_RATING, MIN_ZAVOMI_REVIEWS
import app.services.autonomous as legacy
from app.services.scoring import score_product
from app.services.discovery.ranking import quality_level
from app.services.discovery.history import previous_confirmed_price
from app.services.autonomous import (_metadata, _confirmed_affiliate_url, _automatic_affiliate, _apply_candidate_content, candidate_to_product_input, _classification, _status, _existing_product, _apply_product, _save_preselected)

def run_professional_discovery(db: Session, max_products: int = 25, progress_callback=None, categories: list[str] | None = None) -> dict[str, object]:
    started_at = perf_counter()
    if progress_callback:
        progress_callback(5, "Preparando conexão com o Mercado Livre")
    timeout = max(3.0, float(getattr(settings, "mercado_livre_http_timeout_seconds", 8.0) or 8.0))
    try:
        client = legacy.MercadoLivreClient(db=db, timeout=timeout)
    except TypeError as exc:
        # Compatibilidade com provedores/doubles antigos que ainda não recebem timeout.
        if "timeout" not in str(exc):
            raise
        client = legacy.MercadoLivreClient(db=db)
    if not client.configured:
        return {"found": 0, "saved": 0, "updated": 0, "scripts": 0, "status": "aguardando_token"}

    try:
        if progress_callback:
            progress_callback(15, "Consultando rankings oficiais do Mercado Livre")
        per_query = max(8, min(30, max_products)) if categories else 8
        try:
            candidates = client.discover(limit_per_query=per_query, categories=categories, progress_callback=progress_callback)
        except TypeError as exc:
            # Compatibilidade com provedores antigos/doubles de teste. Primeiro
            # remove o callback novo; se necessário remove também categories.
            message = str(exc)
            if "progress_callback" in message:
                try:
                    candidates = client.discover(limit_per_query=per_query, categories=categories)
                except TypeError as inner:
                    if "categories" not in str(inner):
                        raise
                    candidates = client.discover(limit_per_query=per_query)
            elif "categories" in message:
                try:
                    candidates = client.discover(limit_per_query=per_query, progress_callback=progress_callback)
                except TypeError as inner:
                    if "progress_callback" not in str(inner):
                        raise
                    candidates = client.discover(limit_per_query=per_query)
            else:
                raise
    except MarketplaceRequestError as exc:
        db.rollback()
        return {"found": 0, "saved": 0, "updated": 0, "scripts": 0, "status": "api_indisponivel", "message": f"A API do Mercado Livre recusou a varredura ({exc.status_code or 'erro de rede'}).", "warnings": [exc.detail]}
    except Exception as exc:
        db.rollback()
        return {"found": 0, "saved": 0, "updated": 0, "scripts": 0, "status": "erro_controlado", "message": "A varredura não foi concluída, mas o painel permaneceu estável.", "warnings": [str(exc)[:300]]}

    run_at = datetime.now(timezone.utc)
    run_marker = run_at.isoformat()
    current_keys = {
        str(c.item_id or c.catalog_product_id or c.external_id or c.listing_url).strip()
        for c in candidates
    }

    # Remove somente registros legados fictícios. Pré-selecionados atuais com
    # preço desconhecido são preservados porque representam posições reais no ranking.
    legacy_rows = db.scalars(select(Product).where(
        Product.price < 1.0,
        Product.status.in_(["aguardando_oferta", "em_analise"]),
    )).all()
    removed_invalid = len(legacy_rows)
    for row in legacy_rows:
        db.delete(row)
    if removed_invalid:
        db.flush()

    confirmed = [c for c in candidates if c.offer_available and c.price >= 1 and c.stock_available]
    preselected = [c for c in candidates if not c.offer_available]

    ranked: list[tuple[float, Candidate, ProductInput, object]] = []
    rejected_low_rating = rejected_few_reviews = metrics_pending_count = 0
    for candidate in confirmed:
        # Métricas ausentes por bloqueio da fonte não invalidam uma oferta com
        # preço, estoque e mídia confirmados. Só rejeitamos valores conhecidos
        # que estejam abaixo do padrão comercial.
        if candidate.rating > 0 and candidate.rating < MIN_ZAVOMI_RATING:
            rejected_low_rating += 1
            continue
        if candidate.review_count > 0 and candidate.review_count < MIN_ZAVOMI_REVIEWS:
            rejected_few_reviews += 1
            continue
        metrics_pending = candidate.rating <= 0 or candidate.review_count <= 0
        if metrics_pending:
            has_media_evidence = bool(candidate.picture_urls or candidate.thumbnail)
            ranked_demand = bool(candidate.source_rank and candidate.source_rank <= 20)
            if not (has_media_evidence and ranked_demand):
                rejected_few_reviews += 1
                continue
        metrics_pending_count += int(metrics_pending)
        existing = _existing_product(db, candidate)
        affiliate = _automatic_affiliate(candidate, existing)
        product_input = candidate_to_product_input(candidate, affiliate.url if affiliate.confirmed else candidate.listing_url)
        result = score_product(product_input)
        bonus = max(0.0, 20.0 - min(candidate.source_rank or 20, 20) * 0.75)
        result.reasons.append(f"Demanda confirmada pela posição #{candidate.source_rank} no ranking oficial")
        final_score = min(100.0, result.total + bonus)
        ranked.append((-final_score, candidate, product_input, result, metrics_pending))
    ranked.sort(key=lambda item: (item[0], item[1].source_rank or 9999))

    saved = updated = unchanged = scripts_created = qualified_processed = 0
    if progress_callback:
        progress_callback(78, "Salvando qualificados e pré-selecionados do ranking")

    for negative_score, candidate, input_data, result, metrics_pending in ranked[:max_products]:
        existing = _existing_product(db, candidate)
        affiliate = _automatic_affiliate(candidate, existing)
        final_score = -negative_score
        qualified_processed += 1
        media_ready = input_data.media_license != "origem_nao_confirmada"
        status = _status(final_score, media_ready)
        classification = _classification(final_score, candidate.source_rank, metrics_pending=metrics_pending)
        marker = f" catalog_product_id={candidate.catalog_product_id}." if candidate.catalog_product_id else ""
        metric_text = "nota e avaliações ainda em atualização pela fonte" if metrics_pending else "nota e avaliações validadas"
        notes = f"Produto confirmado pelo ranking oficial, com preço e disponibilidade validados; {metric_text}.{marker} Comissão deve ser confirmada na Central de Afiliados."
        if existing:
            confirmed_link = _confirmed_affiliate_url(existing)
            changed = any((existing.status != status, abs((existing.score or 0)-final_score)>0.01, existing.price != input_data.price, existing.rating != input_data.rating, existing.review_count != input_data.review_count, existing.sold_quantity != input_data.sold_quantity, existing.original_description != candidate.description))
            _apply_product(existing, input_data, score=final_score, classification=classification, status=status, notes=notes, reasons="\n".join(result.reasons))
            if affiliate.confirmed:
                existing.affiliate_url = affiliate.url
            elif confirmed_link:
                existing.affiliate_url = confirmed_link
            else:
                existing.affiliate_url = ""
            _apply_candidate_content(existing, candidate)
            product = existing
            updated += int(changed); unchanged += int(not changed)
        else:
            product = Product(); _apply_product(product, input_data, score=final_score, classification=classification, status=status, notes=notes, reasons="\n".join(result.reasons)); _apply_candidate_content(product, candidate)
            if not affiliate.confirmed:
                product.affiliate_url = ""
            db.add(product); db.flush(); saved += 1
        product_meta = _metadata(product)
        if affiliate.confirmed:
            product.affiliate_url = affiliate.url
        prior_price = previous_confirmed_price(db, product.id, input_data.price)
        if input_data.original_price is None and prior_price:
            product.original_price = prior_price
            product_meta["original_price_source"] = "zavomi_price_history"
        elif input_data.original_price:
            product_meta["original_price_source"] = "mercado_livre"
        product_meta["quality_level"] = quality_level(
            price=input_data.price, stock=input_data.stock_available,
            pictures=bool(candidate.picture_urls), description=bool(candidate.description),
            rating=input_data.rating, reviews=input_data.review_count,
            affiliate_confirmed=bool(affiliate.confirmed or product_meta.get("affiliate_link_confirmed")),
        )
        product_meta["field_sources"] = {
            "price": {"source": candidate.price_source or "listing_or_buy_box", "confidence": "confirmed" if input_data.price >= 1 else "unavailable"},
            "original_price": {"source": candidate.original_price_source or product_meta.get("original_price_source", "unavailable"), "confidence": "confirmed" if product.original_price else "unavailable"},
            "rating": {"source": candidate.rating_source or "unavailable", "confidence": "confirmed" if input_data.rating > 0 else "unavailable"},
            "review_count": {"source": candidate.rating_source or "unavailable", "confidence": "confirmed" if input_data.review_count > 0 else "unavailable"},
            "sold_quantity": {"source": candidate.sold_quantity_source or "unavailable", "confidence": "confirmed" if input_data.sold_quantity > 0 else "unavailable"},
            "affiliate_url": {"source": affiliate.source, "confidence": "confirmed" if affiliate.confirmed else "unavailable"},
        }
        product_meta["affiliate_link_confirmed"] = bool(affiliate.confirmed or product_meta.get("affiliate_link_confirmed"))
        product_meta["affiliate_link_source"] = affiliate.source
        product_meta["affiliate_link_error"] = affiliate.error
        product_meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
        product_meta["listing_url"] = candidate.listing_url
        product_meta["discovery_run_at"] = run_marker
        product_meta["discovery_key"] = str(candidate.item_id or candidate.catalog_product_id or candidate.external_id or candidate.listing_url).strip()
        product.source_metadata_json = json.dumps(product_meta, ensure_ascii=False, sort_keys=True)
        db.add(ProductObservation(product_id=product.id, price=input_data.price, rating=input_data.rating, review_count=input_data.review_count, sold_quantity=input_data.sold_quantity, source_rank=candidate.source_rank, stock_available=input_data.stock_available))

    remaining = max(0, max_products - qualified_processed)
    kept_preselected = sorted(preselected, key=lambda c: c.source_rank or 9999)[:remaining]
    for candidate in kept_preselected:
        was_saved, was_updated = _save_preselected(db, candidate)
        saved += int(was_saved); updated += int(was_updated); unchanged += int(not was_saved and not was_updated)
        row = _existing_product(db, candidate)
        if row:
            meta = _metadata(row)
            meta["discovery_run_at"] = run_marker
            meta["discovery_key"] = str(candidate.item_id or candidate.catalog_product_id or candidate.external_id or candidate.listing_url).strip()
            row.source_metadata_json = json.dumps(meta, ensure_ascii=False, sort_keys=True)

    # Pendências de varreduras antigas não permanecem acumuladas no painel.
    # Elas são arquivadas, preservando o histórico e qualquer link afiliado já
    # confirmado, e podem voltar automaticamente em uma próxima descoberta.
    archived_stale = 0
    stale_query = select(Product).where(Product.status == "pre_selecionado")
    if categories:
        stale_query = stale_query.where(Product.category.in_(categories))
    stale_rows = db.scalars(stale_query).all()
    kept_ids = {id(_existing_product(db, c)) for c in kept_preselected if _existing_product(db, c)}
    for row in stale_rows:
        meta = _metadata(row)
        key = str(meta.get("discovery_key") or meta.get("item_id") or meta.get("catalog_product_id") or meta.get("listing_url") or "").strip()
        if id(row) in kept_ids or key in current_keys and meta.get("discovery_run_at") == run_marker:
            continue
        row.status = "arquivado_varredura"
        row.classification = "Fora da seleção atual"
        meta["archived_at"] = run_marker
        meta["archive_reason"] = "not_selected_in_latest_discovery"
        row.source_metadata_json = json.dumps(meta, ensure_ascii=False, sort_keys=True)
        archived_stale += 1

    db.commit()
    elapsed_seconds = round(perf_counter() - started_at, 1)
    total_kept = qualified_processed + min(len(preselected), remaining)
    stats = dict(getattr(client, "discovery_stats", {}))
    stats.update({
        "elapsed_seconds": elapsed_seconds,
        "qualified_products": qualified_processed,
        "preselected_products": min(len(preselected), remaining),
        "rejected_low_rating": rejected_low_rating,
        "rejected_few_reviews": rejected_few_reviews,
        "qualified_metrics_pending": metrics_pending_count,
        "minimum_rating": MIN_ZAVOMI_RATING,
        "minimum_reviews": MIN_ZAVOMI_REVIEWS,
        "saved": saved,
        "updated": updated,
        "unchanged": unchanged,
        "scripts_created": scripts_created,
        "complete_search": True,
        "affiliate_links_preserved": sum(1 for _, c, _, _, _ in ranked[:max_products] if _confirmed_affiliate_url(_existing_product(db, c))),
        "removed_invalid": removed_invalid,
        "archived_stale_preselected": archived_stale,
        "pipeline_version": "professional_v2",
    })
    if qualified_processed:
        message = f"Varredura concluída: {qualified_processed} produtos qualificados automaticamente ({metrics_pending_count} com métricas não obrigatórias em atualização) e {stats['preselected_products']} pendentes de dados essenciais."
    else:
        message = f"Varredura concluída: o Mercado Livre não expôs dados comerciais suficientes para qualificação automática, mas {stats['preselected_products']} produtos foram pré-selecionados pelo ranking oficial para confirmação rápida."
    if progress_callback:
        progress_callback(96, "Finalizando resultados")
    return {"found": total_kept, "saved": saved, "updated": updated, "scripts": scripts_created, "status": "concluido", "message": message, "warnings": list(dict.fromkeys(client.warnings))[:6], "infos": list(dict.fromkeys(client.infos))[:6], "sources": client.sources_used, "stats": stats, "at": datetime.now(timezone.utc).isoformat()}
