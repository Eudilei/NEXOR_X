from __future__ import annotations

def quality_level(*, price: float, stock: bool, pictures: bool, description: bool, rating: float, reviews: int, affiliate_confirmed: bool) -> str:
    essentials = price >= 1 and stock and pictures and description
    metrics = rating > 0 and reviews > 0
    if essentials and metrics and affiliate_confirmed:
        return "A"
    if essentials:
        return "B"
    if price >= 1 or stock or pictures:
        return "C"
    return "D"
