from __future__ import annotations

from sqlalchemy import select
from app.db.models import ProductObservation

def previous_confirmed_price(db, product_id: int, current_price: float) -> float | None:
    rows = db.scalars(select(ProductObservation).where(ProductObservation.product_id == product_id, ProductObservation.price > 0).order_by(ProductObservation.observed_at.desc()).limit(30)).all()
    for row in rows:
        value = float(row.price or 0)
        if value > 0 and abs(value - float(current_price or 0)) > 0.009:
            return value
    return None
