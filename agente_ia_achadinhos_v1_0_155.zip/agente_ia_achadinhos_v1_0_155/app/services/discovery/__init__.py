"""Núcleo consolidado de descoberta e enriquecimento Zavomi."""
from .pipeline import run_professional_discovery

__all__ = ["run_professional_discovery"]
