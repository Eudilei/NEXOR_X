from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

@dataclass(slots=True)
class FieldEvidence:
    value: Any
    source: str
    confidence: str = "unavailable"
    checked_at: str = ""

@dataclass(slots=True)
class EnrichmentReport:
    fields: dict[str, FieldEvidence] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def put(self, name: str, value: Any, source: str, confidence: str) -> None:
        from datetime import datetime, timezone
        self.fields[name] = FieldEvidence(value, source, confidence, datetime.now(timezone.utc).isoformat())

    def metadata(self) -> dict[str, Any]:
        return {name: {"source": item.source, "confidence": item.confidence, "checked_at": item.checked_at} for name, item in self.fields.items()}
