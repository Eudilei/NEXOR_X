"""Coletor especializado: pictures.

A coleta HTTP permanece centralizada em MercadoLivreClient; este módulo define
a responsabilidade única e evita duplicar regras de fonte no restante do sistema.
"""

FIELD = "pictures"
