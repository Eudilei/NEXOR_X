FIELDS = ("price", "description", "pictures", "reviews", "sales", "affiliate")
