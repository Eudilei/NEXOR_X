from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

from app.core.config import settings

_INTERNAL_PHRASES = (
    "roteiro em estrutura",
    "anúncio analisado",
    "tese editorial",
    "motor gratuito",
    "roteirista openai",
    "estratégia humor",
)


def naturalize_title(title: str) -> str:
    value = re.sub(r"\b[cC]\s*/\s*(\d+)\b", r"com \1", str(title or ""))
    value = re.sub(r"\b[cC]\s+(\d+)\b", r"com \1", value)
    value = re.sub(r"\b(\d+)\s+Toalha\b", r"\1 toalhas", value, flags=re.I)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _number_br(value: int) -> str:
    return f"{int(value):,}".replace(",", ".")


def _money_br(value: float) -> str:
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return ""
    return f"R$ {amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def category_hashtags(category: str) -> list[str]:
    common = ["#achadinhos", "#zavomi", "#utilidades", "#dicas"]
    groups = {
        "casa": ["#casa", "#decoracao", "#lar"],
        "cozinha": ["#cozinha", "#cozinhapratica", "#utensilios"],
        "organizacao": ["#organizacao", "#casaorganizada", "#rotina"],
        "beleza": ["#beleza", "#cuidadospessoais", "#autocuidado"],
        "cuidados_pessoais": ["#cuidadospessoais", "#autocuidado", "#rotina"],
    }
    return common + groups.get(str(category or "").lower(), ["#produtosuteis"])


def build_instagram_caption(product, script=None) -> str:
    title = naturalize_title(product.title)
    parts = [title]

    hook = str(getattr(script, "hook", "") or "").strip()
    if hook and len(hook) <= 180:
        parts.append(hook)

    facts: list[str] = []
    if float(getattr(product, "rating", 0) or 0) > 0:
        rating = str(round(float(product.rating), 1)).replace(".", ",")
        facts.append(f"nota {rating}")
    if int(getattr(product, "review_count", 0) or 0) > 0:
        facts.append(f"{_number_br(product.review_count)} avaliações")
    if int(getattr(product, "sold_quantity", 0) or 0) > 0:
        facts.append(f"mais de {_number_br(product.sold_quantity)} vendas")
    if facts:
        parts.append("O anúncio informa " + ", ".join(facts) + ".")

    price = float(getattr(product, "price", 0) or 0)
    if price > 0:
        parts.append(f"Preço observado: {_money_br(price)}. Preço, estoque e frete podem mudar.")

    parts.append("Confira as opções, medidas, compatibilidade e condições diretamente na oferta.")
    parts.append("💬 Comente QUERO e receba o link deste produto no Direct.\n🔗 Veja também outros achadinhos pelo link na bio.")
    parts.append("Publicidade: este conteúdo contém link de afiliado. Podemos receber comissão sem custo adicional para você.")
    parts.append(" ".join(category_hashtags(getattr(product, "category", ""))))
    return "\n\n".join(part for part in parts if part).strip()


def caption_issues(caption: str, product) -> list[str]:
    text = str(caption or "").strip()
    lower = text.lower()
    issues: list[str] = []
    if not text:
        issues.append("Legenda vazia.")
    for phrase in _INTERNAL_PHRASES:
        if phrase in lower:
            issues.append(f"A legenda contém texto interno: {phrase}.")
    if re.search(r"\b[cC]\s*/\s*\d+\b", text):
        issues.append("Use 'com' no lugar de 'c/'.")
    if settings.public_base_url.rstrip("/") in text or re.search(r"https?://\S+", text):
        issues.append("Não coloque URL completa na legenda; use apenas o CTA de link na bio.")
    if "link na bio" not in lower:
        issues.append("A legenda precisa orientar para o link da bio.")
    if "comente quero" not in lower:
        issues.append("A legenda precisa orientar a pessoa a comentar QUERO.")
    return issues


def build_tiktok_caption(product, script=None) -> str:
    """Legenda própria do TikTok, preservando o link afiliado informado pelo produto."""
    title = naturalize_title(product.title)
    hook = str(getattr(script, "hook", "") or "").strip()
    parts = [hook if hook else title]
    price = float(getattr(product, "price", 0) or 0)
    if price > 0:
        parts.append(f"Preço observado: {_money_br(price)}. Preço e disponibilidade podem mudar.")
    affiliate_url = str(getattr(product, "affiliate_url", "") or "").strip()
    if affiliate_url:
        parts.append(f"Confira o produto: {affiliate_url}")
    parts.append("Publicidade: link de afiliado. Podemos receber comissão sem custo adicional para você.")
    parts.append(" ".join(category_hashtags(getattr(product, "category", "")) + ["#tiktokmademebuyit"]))
    return "\n\n".join(x for x in parts if x).strip()[:2200]


def tiktok_caption_issues(caption: str, product) -> list[str]:
    text = str(caption or "").strip()
    issues = []
    if not text:
        issues.append("Legenda vazia.")
    expected = str(getattr(product, "affiliate_url", "") or "").strip()
    if expected and expected not in text:
        issues.append("A legenda precisa conter o link afiliado exato deste produto.")
    if len(text) > 2200:
        issues.append("A legenda excede o limite de 2.200 caracteres do TikTok.")
    return issues
