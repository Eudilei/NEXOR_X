from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import OAuthCredential


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _fernet() -> Fernet:
    digest = hashlib.sha256(settings.session_secret.encode("utf-8")).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


def encrypt_value(value: str) -> str:
    return _fernet().encrypt(value.encode("utf-8")).decode("utf-8")


def decrypt_value(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return _fernet().decrypt(value.encode("utf-8")).decode("utf-8")
    except InvalidToken as exc:
        raise RuntimeError("Não foi possível descriptografar as credenciais OAuth.") from exc


class MercadoLivreOAuthService:
    authorize_url = "https://auth.mercadolivre.com.br/authorization"
    token_url = "https://api.mercadolibre.com/oauth/token"

    def __init__(self, timeout: float = 25.0):
        self.timeout = timeout

    @property
    def configured(self) -> bool:
        return settings.mercado_livre_oauth_configured

    def authorization_url(self, state: str, code_challenge: str) -> str:
        if not self.configured:
            raise RuntimeError("Credenciais OAuth do Mercado Livre não configuradas.")
        params = {
            "response_type": "code",
            "client_id": settings.mercado_livre_client_id,
            "redirect_uri": settings.mercado_livre_redirect_uri,
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        return str(httpx.URL(self.authorize_url, params=params))

    def exchange_code(self, code: str, code_verifier: str) -> dict[str, Any]:
        payload = {
            "grant_type": "authorization_code",
            "client_id": settings.mercado_livre_client_id,
            "client_secret": settings.mercado_livre_client_secret,
            "code": code,
            "redirect_uri": settings.mercado_livre_redirect_uri,
            "code_verifier": code_verifier,
        }
        return self._token_request(payload)

    def refresh(self, refresh_token: str) -> dict[str, Any]:
        payload = {
            "grant_type": "refresh_token",
            "client_id": settings.mercado_livre_client_id,
            "client_secret": settings.mercado_livre_client_secret,
            "refresh_token": refresh_token,
        }
        return self._token_request(payload)

    def _token_request(self, payload: dict[str, Any]) -> dict[str, Any]:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                self.token_url,
                data=payload,
                headers={"Accept": "application/json", "Content-Type": "application/x-www-form-urlencoded"},
            )
        if response.status_code >= 400:
            detail = response.text[:500]
            raise RuntimeError(f"Falha OAuth Mercado Livre ({response.status_code}): {detail}")
        data = response.json()
        if not data.get("access_token"):
            raise RuntimeError("Resposta OAuth sem access_token.")
        return data

    def save_tokens(self, db: Session, data: dict[str, Any]) -> OAuthCredential:
        credential = db.scalar(select(OAuthCredential).where(OAuthCredential.provider == "mercado_livre"))
        if credential is None:
            credential = OAuthCredential(provider="mercado_livre")
            db.add(credential)

        expires_in = int(data.get("expires_in") or 21600)
        credential.access_token_encrypted = encrypt_value(str(data["access_token"]))
        if data.get("refresh_token"):
            credential.refresh_token_encrypted = encrypt_value(str(data["refresh_token"]))
        credential.token_type = str(data.get("token_type") or "Bearer")
        credential.scope = json.dumps(data.get("scope"), ensure_ascii=False) if data.get("scope") is not None else None
        credential.external_user_id = str(data.get("user_id")) if data.get("user_id") is not None else credential.external_user_id
        credential.expires_at = _utcnow() + timedelta(seconds=max(expires_in - 60, 60))
        credential.updated_at = _utcnow()
        db.commit()
        db.refresh(credential)
        return credential

    def get_credential(self, db: Session) -> OAuthCredential | None:
        return db.scalar(select(OAuthCredential).where(OAuthCredential.provider == "mercado_livre"))

    def connection_status(self, db: Session) -> dict[str, Any]:
        credential = self.get_credential(db)
        if not credential:
            return {"connected": False, "user_id": None, "expires_at": None}
        return {
            "connected": bool(credential.access_token_encrypted),
            "user_id": credential.external_user_id,
            "expires_at": credential.expires_at,
        }

    def get_valid_access_token(self, db: Session) -> str | None:
        credential = self.get_credential(db)
        if credential is None:
            return settings.mercado_livre_access_token

        now = _utcnow()
        expires_at = credential.expires_at
        if expires_at and expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)

        if expires_at and expires_at > now + timedelta(minutes=5):
            return decrypt_value(credential.access_token_encrypted)

        refresh_token = decrypt_value(credential.refresh_token_encrypted)
        if not refresh_token:
            return decrypt_value(credential.access_token_encrypted)
        refreshed = self.refresh(refresh_token)
        self.save_tokens(db, refreshed)
        return str(refreshed["access_token"])

    def disconnect(self, db: Session) -> None:
        credential = self.get_credential(db)
        if credential:
            db.delete(credential)
            db.commit()
