from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from sqlalchemy import func, select

from app.core.config import settings
from app.db.database import SessionLocal
from app.db.models import InitialCatalogState, Product
from app.models.schemas import ProductCategory
from app.services.discovery.pipeline import run_professional_discovery
from app.services.zavomi_site import publish_catalog

logger = logging.getLogger(__name__)
_thread: threading.Thread | None = None
_stop = threading.Event()
_lock = threading.Lock()


def _eligible_count(db, category: str) -> int:
    stmt = select(func.count(Product.id)).where(
        Product.category == category,
        Product.status.notin_(["pausado", "arquivado_varredura", "reprovado"]),
    )
    return int(db.scalar(stmt) or 0)


def _state(db) -> InitialCatalogState:
    item = db.get(InitialCatalogState, 1)
    if not item:
        item = InitialCatalogState(id=1)
        db.add(item)
        db.commit()
        db.refresh(item)
    return item


def _save(db, **values) -> None:
    item = _state(db)
    for key, value in values.items():
        setattr(item, key, value)
    item.updated_at = datetime.now(timezone.utc)
    db.commit()


def _database_progress(db, target: int) -> dict[str, dict[str, object]]:
    progress: dict[str, dict[str, object]] = {}
    for item in ProductCategory:
        count = _eligible_count(db, item.value)
        progress[item.value] = {
            "count": count,
            "complete": count >= target,
            "attempts": 0,
            "last_status": "complete" if count >= target else "pending",
            "error": "",
        }
    return progress


def _persist_progress(db, progress: dict[str, dict[str, object]], *, message: str = "", error: str = "") -> None:
    target = max(1, int(settings.initial_catalog_products_per_category or 25))
    total = sum(int(v.get("count", 0)) for v in progress.values())
    complete = sum(1 for v in progress.values() if bool(v.get("complete")))
    _save(
        db,
        target_per_category=target,
        total_target=target * len(progress),
        total_products=total,
        completed_categories=complete,
        progress_json=json.dumps(progress, ensure_ascii=False),
        last_message=message,
        last_error=error[:1000],
    )


def catalog_status(db=None) -> dict[str, object]:
    own = db is None
    db = db or SessionLocal()
    try:
        item = _state(db)
        target = max(1, int(item.target_per_category or settings.initial_catalog_products_per_category or 25))
        # O banco é a fonte de verdade. Isso impede o contador de voltar a zero
        # quando o Render dorme, reinicia ou troca o processo web.
        progress = _database_progress(db, target)
        total = sum(int(v["count"]) for v in progress.values())
        complete = sum(1 for v in progress.values() if bool(v["complete"]))
        running = bool(_thread and _thread.is_alive())
        status = item.status
        if status == "running" and not running:
            status = "interrupted"
        return {
            "status": status,
            "target_per_category": target,
            "total_target": target * len(progress),
            "total_products": total,
            "completed_categories": complete,
            "current_category": item.current_category,
            "progress": progress,
            "last_message": item.last_message,
            "last_error": item.last_error,
            "started_at": item.started_at,
            "finished_at": item.finished_at,
            "updated_at": item.updated_at,
            "running": running,
        }
    finally:
        if own:
            db.close()


def bootstrap_initial_catalog() -> dict[str, object]:
    target = max(1, int(settings.initial_catalog_products_per_category or 25))
    rounds = max(1, int(settings.initial_catalog_max_rounds or 4))
    categories = [item.value for item in ProductCategory]
    db = SessionLocal()
    started = datetime.now(timezone.utc)
    summary: dict[str, object] = {"target_per_category": target, "categories": {}}
    try:
        progress = _database_progress(db, target)
        _persist_progress(db, progress, message="Carga inicial retomada pelo banco de dados.")
        _save(db, status="running", last_error="", started_at=started, finished_at=None)

        for category in categories:
            if _stop.is_set():
                _save(db, status="paused", last_message="Carga pausada pelo usuário.")
                break

            # Recalcula antes de cada categoria: categorias completas nunca são refeitas.
            before = _eligible_count(db, category)
            progress[category]["count"] = before
            progress[category]["complete"] = before >= target
            if before >= target:
                progress[category]["last_status"] = "complete"
                _persist_progress(db, progress, message=f"{category}: já completa ({before}/{target}); avançando.")
                continue

            _save(db, current_category=category, last_message=f"Buscando produtos em {category}...")
            attempts = 0
            latest: dict[str, object] = {}
            while before < target and attempts < rounds and not _stop.is_set():
                attempts += 1
                try:
                    latest = run_professional_discovery(
                        db,
                        max_products=max(1, min(target, target - before)),
                        categories=[category],
                    )
                except Exception as exc:
                    latest = {"status": "failed", "error": str(exc)[:500]}
                    logger.exception("Falha na categoria %s", category)
                    break

                after = _eligible_count(db, category)
                progress[category].update({
                    "count": after,
                    "complete": after >= target,
                    "attempts": attempts,
                    "last_status": str(latest.get("status", "running")),
                    "error": str(latest.get("error", ""))[:500],
                })
                _persist_progress(
                    db,
                    progress,
                    message=f"{category}: {after}/{target} produtos cadastrados.",
                    error=str(latest.get("error", "")),
                )
                if after <= before:
                    break
                before = after
                if settings.initial_catalog_pause_seconds > 0:
                    time.sleep(settings.initial_catalog_pause_seconds)

            summary["categories"][category] = dict(progress[category])
            # Publica somente quando houve avanço real na categoria.
            if int(progress[category]["count"]) > 0:
                try:
                    publish_catalog(db, trigger=f"initial_catalog:{category}")
                except Exception as exc:
                    _save(db, last_error=f"Sincronização do site pendente: {str(exc)[:400]}")

        else:
            progress = _database_progress(db, target)
            _persist_progress(db, progress, message="Recalculando resultado final pelo banco.")
            complete = sum(1 for v in progress.values() if bool(v["complete"]))
            try:
                pub = publish_catalog(db, trigger="initial_catalog_complete")
                summary["site_sync"] = {"status": "published", "publication_id": pub.id}
            except Exception as exc:
                summary["site_sync"] = {"status": "pending", "error": str(exc)[:240]}
            status = "completed" if complete == len(categories) else "partial"
            _save(
                db,
                status=status,
                current_category="",
                completed_categories=complete,
                last_message=f"Carga finalizada: {complete}/{len(categories)} categorias completas.",
                finished_at=datetime.now(timezone.utc),
            )
        return summary
    except Exception as exc:
        _save(
            db,
            status="failed",
            last_error=str(exc)[:1000],
            last_message="A carga inicial falhou.",
            finished_at=datetime.now(timezone.utc),
        )
        raise
    finally:
        db.close()


def _runner() -> None:
    try:
        bootstrap_initial_catalog()
    except Exception:
        logger.exception("Falha controlada na carga inicial Zavomi")


def start_initial_catalog_bootstrap(force: bool = False) -> bool:
    global _thread
    with _lock:
        if not force and not settings.initial_catalog_bootstrap_enabled:
            return False
        if _thread and _thread.is_alive():
            return False
        _stop.clear()
        _thread = threading.Thread(target=_runner, name="zavomi-initial-catalog", daemon=True)
        _thread.start()
        return True


def stop_initial_catalog_bootstrap() -> None:
    _stop.set()
