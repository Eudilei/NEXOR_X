from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from sqlalchemy import select
from app.db.models import DiscoveryJob


def _utcnow():
    return datetime.now(timezone.utc)


def latest_job(db):
    return db.scalar(select(DiscoveryJob).order_by(DiscoveryJob.id.desc()).limit(1))


def active_job(db, source: str | None = None):
    query = select(DiscoveryJob).where(DiscoveryJob.status.in_(["queued", "running"]))
    if source:
        query = query.where(DiscoveryJob.source == source)
    return db.scalar(query.order_by(DiscoveryJob.id.desc()).limit(1))


def start_job(db, source: str = "mercado_livre", filters: dict | None = None):
    existing = active_job(db, source)
    if existing:
        return existing, False
    job = DiscoveryJob(status="queued", source=source, filters_json=json.dumps(filters or {}, ensure_ascii=False), stage="Aguardando processamento", progress=0)
    db.add(job); db.commit(); db.refresh(job)
    return job, True


def claim_next_job(db):
    job = db.scalar(select(DiscoveryJob).where(DiscoveryJob.status == "queued").order_by(DiscoveryJob.id.asc()).limit(1).with_for_update(skip_locked=True))
    if not job:
        return None
    job.status = "running"; job.started_at = _utcnow(); job.progress = 2; job.stage = "Iniciando varredura"; job.updated_at = _utcnow()
    db.commit(); db.refresh(job)
    return job


def job_payload(job: DiscoveryJob | None):
    if not job:
        return {"exists": False, "status": "idle", "progress": 0, "stage": ""}
    try: result = json.loads(job.result_json or "{}")
    except Exception: result = {}
    return {"exists": True, "id": job.id, "source": job.source, "status": job.status, "progress": job.progress, "stage": job.stage, "message": job.message, "error": job.error, "created_at": job.created_at.isoformat() if job.created_at else None, "started_at": job.started_at.isoformat() if job.started_at else None, "finished_at": job.finished_at.isoformat() if job.finished_at else None, "result": result}


def recover_stale_jobs(db, stale_after_minutes: int = 20) -> int:
    """Recoloca jobs presos na fila após reinício ou interrupção do processo."""
    cutoff = _utcnow() - timedelta(minutes=max(1, stale_after_minutes))
    jobs = db.scalars(
        select(DiscoveryJob).where(
            DiscoveryJob.status == "running",
            DiscoveryJob.updated_at < cutoff,
        )
    ).all()
    for job in jobs:
        job.status = "queued"
        job.stage = "Retomando após interrupção"
        job.progress = 0
        job.error = ""
        job.started_at = None
        job.updated_at = _utcnow()
    if jobs:
        db.commit()
    return len(jobs)
