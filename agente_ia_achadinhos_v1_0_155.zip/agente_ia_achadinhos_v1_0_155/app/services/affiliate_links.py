from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
from urllib.parse import urlparse

import httpx

from app.core.config import settings


@dataclass(frozen=True)
class AffiliateLinkResult:
    url: str = ""
    confirmed: bool = False
    source: str = "unavailable"
    error: str = ""
    commission_pct: float = 0.0


def _https(value: object) -> str:
    url = str(value or "").strip()
    if not url.startswith("https://"):
        return ""
    host = (urlparse(url).hostname or "").lower()
    if not host:
        return ""
    return url


def _mapping() -> dict[str, str]:
    raw = str(settings.mercado_livre_affiliate_links_json or "").strip()
    if not raw:
        return {}
    try:
        payload = json.loads(raw)
    except Exception:
        return {}
    if not isinstance(payload, dict):
        return {}
    return {str(k).strip(): _https(v) for k, v in payload.items() if _https(v)}


def _mapping_keys(*, listing_url: str, item_id: str = "", catalog_product_id: str = "") -> list[str]:
    keys = []
    for value in (item_id, catalog_product_id, listing_url):
        value = str(value or "").strip()
        if value and value not in keys:
            keys.append(value)
    return keys


def resolve_affiliate_link(
    *,
    listing_url: str,
    item_id: str = "",
    catalog_product_id: str = "",
    existing_url: str = "",
    existing_confirmed: bool = False,
) -> AffiliateLinkResult:
    """Obtém um link de afiliado somente de uma fonte explicitamente confiável.

    A função nunca converte nem renomeia o link comum como afiliado. A ordem é:
    link confirmado já salvo, mapa oficial importado e endpoint de integração
    configurado. Sem uma dessas fontes, retorna pendente.
    """
    if existing_confirmed and _https(existing_url):
        return AffiliateLinkResult(_https(existing_url), True, "existing_confirmed")

    mapping = _mapping()
    for key in _mapping_keys(listing_url=listing_url, item_id=item_id, catalog_product_id=catalog_product_id):
        if mapping.get(key):
            return AffiliateLinkResult(mapping[key], True, "official_mapping")

    endpoint = _https(settings.mercado_livre_affiliate_api_url)
    if not endpoint:
        return AffiliateLinkResult(error="Gerador oficial de links afiliados não configurado")

    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    token = str(settings.mercado_livre_affiliate_api_token or "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    payload = {
        "product_url": listing_url,
        "listing_url": listing_url,
        "item_id": item_id or None,
        "catalog_product_id": catalog_product_id or None,
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        with httpx.Client(timeout=max(3, settings.mercado_livre_affiliate_api_timeout_seconds), follow_redirects=True) as client:
            response = client.post(endpoint, headers=headers, json=payload)
        response.raise_for_status()
        body = response.json()
        if not isinstance(body, dict):
            return AffiliateLinkResult(error="Resposta inválida do gerador de links")
        url = _https(body.get("affiliate_url") or body.get("url") or body.get("short_url") or body.get("promotion_link"))
        if not url:
            return AffiliateLinkResult(error=str(body.get("error") or "O gerador não retornou um link afiliado"))
        # Alguns geradores/feeds oficiais também retornam a comissão da oferta.
        # Só aceitamos um número explícito entre 0 e 100; nunca estimamos comissão.
        raw_commission = body.get("commission_pct")
        if raw_commission is None:
            raw_commission = body.get("commission_rate")
        if raw_commission is None:
            raw_commission = body.get("commission")
        try:
            commission = float(str(raw_commission or "0").replace("%", "").replace(",", "."))
        except (TypeError, ValueError):
            commission = 0.0
        if commission < 0 or commission > 100:
            commission = 0.0
        return AffiliateLinkResult(url, True, "configured_official_api", commission_pct=commission)
    except Exception as exc:
        return AffiliateLinkResult(error=f"Falha ao gerar link afiliado: {str(exc)[:180]}")
