from __future__ import annotations

from datetime import datetime, timedelta, timezone
import httpx
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import AdCampaign, Publication


class MetaAdsError(RuntimeError):
    pass


class MetaAdsService:
    graph_url = "https://graph.facebook.com/v23.0"

    @property
    def configured(self) -> bool:
        return bool(settings.meta_ads_access_token and settings.meta_ad_account_id and settings.meta_page_id)

    def create_campaign(self, db: Session, campaign: AdCampaign) -> None:
        if not self.configured:
            raise MetaAdsError("Configure META_ADS_ACCESS_TOKEN, META_AD_ACCOUNT_ID e META_PAGE_ID antes de ativar campanhas.")
        publication = db.get(Publication, campaign.publication_id)
        if not publication or publication.status != "publicado" or not publication.remote_id:
            raise MetaAdsError("Publique o Reel organicamente antes de criar a campanha.")
        if campaign.budget_total_brl <= 0 or campaign.budget_total_brl > settings.meta_ads_max_total_brl:
            raise MetaAdsError(f"O orçamento deve ser maior que zero e no máximo R$ {settings.meta_ads_max_total_brl:.2f}.")
        token = settings.meta_ads_access_token
        account = settings.meta_ad_account_id.removeprefix("act_")
        base = f"{self.graph_url}/act_{account}"
        try:
            with httpx.Client(timeout=45) as client:
                c = client.post(f"{base}/campaigns", data={
                    "name": f"Zavomi Reel {publication.id}", "objective": "OUTCOME_TRAFFIC",
                    "status": "PAUSED", "special_ad_categories": "[]", "access_token": token,
                }).json()
                if not c.get("id"): raise MetaAdsError(str(c))
                campaign.remote_campaign_id = str(c["id"]); db.commit()
                end = datetime.now(timezone.utc) + timedelta(days=max(campaign.duration_days, 1))
                a = client.post(f"{base}/adsets", data={
                    "name": f"Zavomi Reels e Stories {publication.id}", "campaign_id": campaign.remote_campaign_id,
                    "billing_event": "IMPRESSIONS", "optimization_goal": "LINK_CLICKS",
                    "lifetime_budget": str(int(campaign.budget_total_brl * 100)),
                    "start_time": datetime.now(timezone.utc).isoformat(), "end_time": end.isoformat(),
                    "bid_strategy": "LOWEST_COST_WITHOUT_CAP", "destination_type": "WEBSITE",
                    "promoted_object": "{}",
                    "targeting": '{"geo_locations":{"countries":["BR"]},"publisher_platforms":["instagram"],"instagram_positions":["stream","story","reels"]}',
                    "status": "PAUSED", "access_token": token,
                }).json()
                if not a.get("id"): raise MetaAdsError(str(a))
                campaign.remote_adset_id = str(a["id"]); db.commit()
                creative = client.post(f"{base}/adcreatives", data={
                    "name": f"Zavomi Criativo {publication.id}",
                    "source_instagram_media_id": publication.remote_id,
                    "object_story_spec": '{"page_id":"%s"}' % settings.meta_page_id,
                    "degrees_of_freedom_spec": '{"creative_features_spec":{"standard_enhancements":{"enroll_status":"OPT_OUT"}}}',
                    "access_token": token,
                }).json()
                if not creative.get("id"): raise MetaAdsError(str(creative))
                ad = client.post(f"{base}/ads", data={
                    "name": f"Zavomi Anúncio {publication.id}", "adset_id": campaign.remote_adset_id,
                    "creative": '{"creative_id":"%s"}' % creative["id"], "status": "PAUSED", "access_token": token,
                }).json()
                if not ad.get("id"): raise MetaAdsError(str(ad))
                campaign.remote_ad_id = str(ad["id"]); campaign.status = "pausado_pronto"; campaign.error = ""; db.commit()
        except Exception as exc:
            campaign.status = "falhou"; campaign.error = str(exc)[:2000]; db.commit(); raise
