from __future__ import annotations

import re
from collections import OrderedDict
from typing import Any

import httpx

from app.core.config import settings

BASE = "https://api.heygen.com"


class HeyGenError(RuntimeError):
    pass


def friendly_error(exc: Exception) -> str:
    """Return a short, safe message suitable for the mobile UI."""
    text = str(exc or "").lower()
    if "invalid_parameter" in text or "extra inputs are not permitted" in text:
        return "A biblioteca HeyGen recusou um parâmetro da consulta. Atualize o agente e tente novamente."
    if "401" in text or "unauthorized" in text or "api key" in text:
        return "A chave da HeyGen não foi aceita. Confira HEYGEN_API_KEY no Render."
    if "402" in text or "balance" in text or "credit" in text:
        return "A conta HeyGen está sem saldo suficiente para esta operação."
    if "timeout" in text or "timed out" in text:
        return "A HeyGen demorou para responder. Tente novamente em alguns instantes."
    return "Não foi possível carregar a biblioteca HeyGen agora. Tente novamente em alguns instantes."


def configured() -> bool:
    return bool(settings.heygen_api_key)


def _headers() -> dict[str, str]:
    if not settings.heygen_api_key:
        raise HeyGenError("HEYGEN_API_KEY não configurada no Render")
    return {"x-api-key": settings.heygen_api_key, "Content-Type": "application/json"}


def _extract_page(body: dict[str, Any]) -> tuple[list[dict[str, Any]], str | None]:
    data = body.get("data")
    if isinstance(data, list):
        items = data
        token = body.get("next_token") or body.get("next_page_token")
    elif isinstance(data, dict):
        candidates = data.get("items") or data.get("avatars") or data.get("avatar_groups") or data.get("groups") or data.get("looks") or data.get("voices") or []
        items = candidates if isinstance(candidates, list) else []
        token = data.get("next_token") or data.get("next_page_token") or body.get("next_token")
    else:
        items = []
        token = body.get("next_token")
    return [x for x in items if isinstance(x, dict)], str(token) if token else None


def _request_pages(path: str, params: dict[str, Any], *, max_items: int) -> list[dict[str, Any]]:
    collected: list[dict[str, Any]] = []
    next_token: str | None = None
    with httpx.Client(timeout=45) as client:
        for _ in range(20):
            page_params = dict(params)
            if next_token:
                page_params["token"] = next_token
            r = client.get(f"{BASE}{path}", headers=_headers(), params=page_params)
            if r.status_code >= 400:
                raise HeyGenError(f"HeyGen recusou a consulta ({r.status_code}): {r.text[:500]}")
            body = r.json()
            items, next_token = _extract_page(body)
            collected.extend(items)
            if len(collected) >= max_items or not next_token or not items:
                break
    return collected[:max_items]


def _normalize_gender(value: str | None) -> str:
    raw = str(value or "").strip().lower()
    return {
        "feminino": "female", "woman": "female", "women": "female", "f": "female",
        "masculino": "male", "man": "male", "men": "male", "m": "male",
        "neutro": "neutral", "non-binary": "neutral", "nonbinary": "neutral",
    }.get(raw, raw)


def _age_bucket(item: dict[str, Any]) -> str:
    explicit = str(
        item.get("age_group") or item.get("age") or item.get("apparent_age")
        or item.get("age_range") or ""
    ).lower()
    searchable = " ".join(
        str(item.get(key) or "")
        for key in ("name", "description", "tags", "persona", "category")
    ).lower()
    text = f"{explicit} {searchable}"
    if any(token in text for token in ("senior", "elder", "elderly", "old", "idos", "60+", "65+", "70+")):
        return "idoso"
    if any(token in text for token in ("mature", "middle age", "middle-aged", "46-60", "50s", "55+")):
        return "maduro"
    if any(token in text for token in ("young", "youth", "20-30", "20s", "gen z")):
        return "jovem"
    if any(token in text for token in ("adult", "31-45", "30s", "40s")):
        return "adulto"
    # A API nem sempre informa idade. Nesses casos, marcamos como não classificado
    # para não apresentar uma pessoa incompatível silenciosamente.
    return "nao_informado"


def _clean_person_name(name: str) -> str:
    cleaned = re.sub(r"\b(?:P\d+|R\d+|S\d+|A\d+)\b", "", name, flags=re.IGNORECASE)
    cleaned = re.sub(r"\b(?:Kitchen|Office|Livingroom|Bedroom|Studio)\d*\b", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"[_-]+", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned or name or "Apresentador HeyGen"


def _avatar_kind(*items: dict[str, Any]) -> str:
    text = " ".join(str(value) for item in items for value in (
        item.get("name"), item.get("description"), item.get("tags"), item.get("category"), item.get("avatar_type")
    ) if value).lower()
    animated_tokens = ("cartoon", "animated", "animation", "anime", "3d character", "mascot", "illustration", "comic", "toon")
    return "animado" if any(token in text for token in animated_tokens) else "realista"


def list_avatars(gender: str | None = None, age: str | None = None, limit: int = 250) -> list[dict[str, Any]]:
    """Lista personagens públicos e associa seus visuais.

    A resposta da HeyGen varia entre contas/versões: algumas retornam grupos em
    ``/v3/avatars``; outras expõem somente os looks com ``group_id``. Por isso,
    os looks são a fonte mínima garantida e os metadados do endpoint de grupos
    apenas enriquecem nome, gênero e prévia.
    """
    max_items = min(max(limit, 1), 500)
    # O endpoint de grupos pode vir vazio em algumas contas. Isso não deve
    # impedir a biblioteca, pois cada look já carrega group_id e gênero.
    try:
        group_items = _request_pages(
            "/v3/avatars", {"ownership": "public", "limit": 50}, max_items=max_items
        )
    except Exception:
        group_items = []
    look_items = _request_pages(
        "/v3/avatars/looks", {"ownership": "public", "limit": 50}, max_items=500
    )

    normalized_gender = _normalize_gender(gender)
    group_meta: dict[str, dict[str, Any]] = {}
    for item in group_items:
        gid = str(item.get("id") or item.get("group_id") or item.get("avatar_group_id") or "")
        if gid:
            group_meta[gid] = item

    grouped_looks: OrderedDict[str, list[dict[str, Any]]] = OrderedDict()
    raw_by_group: dict[str, list[dict[str, Any]]] = {}
    for item in look_items:
        if item.get("status") not in {None, "completed"}:
            continue
        engines = item.get("supported_api_engines") or []
        if settings.heygen_engine and engines and settings.heygen_engine not in engines:
            continue
        look_id = str(item.get("id") or item.get("avatar_id") or "")
        group_id = str(item.get("group_id") or item.get("avatar_group_id") or "")
        if not look_id:
            continue
        # Alguns registros antigos não trazem group_id. Mantemos o próprio ID
        # como grupo para que o avatar continue selecionável em vez de sumir.
        group_id = group_id or look_id
        grouped_looks.setdefault(group_id, []).append({
            "id": look_id,
            "name": str(item.get("name") or "Visual HeyGen"),
            "preview_image_url": str(item.get("preview_image_url") or ""),
            "preview_video_url": str(item.get("preview_video_url") or ""),
            "default_voice_id": str(item.get("default_voice_id") or ""),
            "supported_api_engines": engines,
            "tags": item.get("tags") or [],
        })
        raw_by_group.setdefault(group_id, []).append(item)

    result: list[dict[str, Any]] = []
    for group_id, looks in grouped_looks.items():
        meta = group_meta.get(group_id, {})
        raws = raw_by_group.get(group_id, [])
        first = raws[0] if raws else {}
        if meta.get("status") not in {None, "completed"}:
            continue

        item_gender = _normalize_gender(meta.get("gender") or first.get("gender"))
        if normalized_gender and normalized_gender not in {"automatico", "neutral", "neutro"} and item_gender != normalized_gender:
            continue

        age_probe = dict(meta or first)
        age_probe["tags"] = [tag for raw in raws for tag in (raw.get("tags") or [])]
        # Inclui nomes de todos os looks para detectar apenas indicações explícitas
        # como Senior, Young, 20s etc.; sem indício, a idade fica não informada.
        age_probe["description"] = " ".join(str(raw.get("name") or "") for raw in raws)
        item_age = _age_bucket(age_probe)
        if age and item_age not in {age, "nao_informado"}:
            continue

        raw_name = str(meta.get("name") or first.get("name") or "Apresentador HeyGen")
        result.append({
            "group_id": group_id,
            "name": _clean_person_name(raw_name),
            "gender": item_gender or "unknown",
            "age": item_age,
            "age_match": "exact" if age and item_age == age else ("unknown" if item_age == "nao_informado" else "unfiltered"),
            "preview_image_url": str(meta.get("preview_image_url") or first.get("preview_image_url") or looks[0].get("preview_image_url") or ""),
            "preview_video_url": str(meta.get("preview_video_url") or first.get("preview_video_url") or looks[0].get("preview_video_url") or ""),
            "kind": _avatar_kind(meta, first, *raws),
            "looks": looks,
        })
        if len(result) >= max_items:
            break
    return result


def find_avatar_look(avatar_id: str, limit: int = 500) -> dict[str, Any] | None:
    for group in list_avatars(limit=limit):
        for look in group.get("looks", []):
            if look.get("id") == avatar_id:
                return {
                    **look,
                    "group_id": group.get("group_id", ""),
                    "person_name": group.get("name", ""),
                    "gender": group.get("gender", ""),
                    "age": group.get("age", ""),
                }
    return None


def list_voices(gender: str | None = None, language: str = "Portuguese", limit: int = 100) -> list[dict[str, Any]]:
    params: dict[str, Any] = {"type": "public", "limit": min(max(limit, 1), 100), "language": language}
    normalized_gender = _normalize_gender(gender)
    if normalized_gender in {"female", "male"}:
        params["gender"] = normalized_gender
    items = _request_pages("/v3/voices", params, max_items=min(max(limit, 1), 300))
    if not items and language:
        params.pop("language", None)
        items = _request_pages("/v3/voices", params, max_items=min(max(limit, 1), 300))
    result = []
    for item in items:
        lang = str(item.get("language") or "")
        if language and not any(token in lang.lower() for token in ("portugu", "pt-br", "brazil")):
            continue
        item_gender = _normalize_gender(item.get("gender"))
        if normalized_gender in {"female", "male"} and item_gender != normalized_gender:
            continue
        result.append({
            "id": str(item.get("voice_id") or item.get("id") or ""),
            "name": str(item.get("name") or "Voz HeyGen"),
            "gender": item_gender,
            "language": lang,
            "preview_audio_url": str(item.get("preview_audio_url") or ""),
            "type": str(item.get("type") or "public"),
        })
    return [x for x in result if x["id"]]




def sanitize_spoken_text(text: str) -> str:
    """Remove instruções de cena/direção antes de enviar texto à fala."""
    import re
    raw = " ".join(str(text or "").replace("\n", " ").split())
    if not raw:
        return ""
    blocked = (
        "mostre ", "mostrar ", "corte ", "cortes ", "zoom ", "close ",
        "apresente ", "apareça ", "aparecer ", "enquadramento", "cena ",
        "direção ", "gestos ", "movimentos ", "texto na tela", "produto em tela",
    )
    sentences = re.split(r"(?<=[.!?])\s+", raw)
    clean = [sentence.strip() for sentence in sentences if sentence.strip() and not sentence.strip().lower().startswith(blocked)]
    result = " ".join(clean).strip()
    return result[:5000]


def create_avatar_video(*, title: str, script: str, avatar_id: str, voice_id: str,
                        energy: str, style: str, duration: int) -> dict[str, Any]:
    if not avatar_id or not voice_id:
        raise HeyGenError("Escolha um apresentador e uma voz da biblioteca HeyGen antes de gerar o vídeo")
    script = sanitize_spoken_text(script)
    if not script:
        raise HeyGenError("O texto falado ficou vazio após remover instruções técnicas")
    expressiveness = "low"
    motion = (
        "Fale como uma pessoa real em uma conversa curta. Mantenha postura relaxada, respiração natural, "
        "contato visual suave e pequenas mudanças de expressão. Use no máximo gestos curtos abaixo do peito, "
        "com pausas entre eles. Não aponte, não simule segurar objetos, não balance o corpo, não repita gestos "
        "e não faça movimentos amplos. Evite sorriso fixo e entusiasmo teatral. "
        f"Estilo {style}; energia percebida {energy}, porém contida e orgânica."
    )
    payload: dict[str, Any] = {
        "type": "avatar", "avatar_id": avatar_id, "script": script, "voice_id": voice_id,
        "title": title[:120], "resolution": "720p", "aspect_ratio": "9:16",
        "engine": {"type": settings.heygen_engine},
        "voice_settings": {"speed": (0.98 if energy in {"alegre", "engracada", "energetica"} else 0.94), "locale": "pt-BR", "pitch": 0},
    }
    if settings.heygen_engine == "avatar_iv":
        payload["motion_prompt"] = motion
        payload["expressiveness"] = expressiveness
    with httpx.Client(timeout=60) as client:
        r = client.post(f"{BASE}/v3/videos", headers=_headers(), json=payload)
        if r.status_code >= 400:
            raise HeyGenError(f"HeyGen recusou a geração ({r.status_code}): {r.text[:500]}")
        body = r.json()
    data = body.get("data") or body
    video_id = data.get("video_id") or data.get("id")
    if not video_id:
        raise HeyGenError("A HeyGen não retornou o identificador do vídeo")
    return {"video_id": video_id, "payload": payload}


def get_video(video_id: str) -> dict[str, Any]:
    with httpx.Client(timeout=45) as client:
        r = client.get(f"{BASE}/v3/videos/{video_id}", headers=_headers())
        if r.status_code >= 400:
            raise HeyGenError(f"Falha ao consultar HeyGen ({r.status_code}): {r.text[:500]}")
        body = r.json()
    return body.get("data") or body


def download_video(url: str) -> bytes:
    with httpx.Client(timeout=180, follow_redirects=True) as client:
        r = client.get(url)
        r.raise_for_status()
        return r.content
