from app.db.models import Product
from app.models.schemas import ProductCategory, ProductInput


def product_to_input(product: Product) -> ProductInput:
    return ProductInput(
        title=product.title,
        category=ProductCategory(product.category),
        marketplace=product.marketplace,
        price=product.price,
        original_price=product.original_price,
        rating=product.rating,
        review_count=product.review_count,
        sold_quantity=product.sold_quantity,
        seller_reputation=product.seller_reputation,
        commission_pct=product.commission_pct,
        stock_available=product.stock_available,
        visual_quality=product.visual_quality,
        demonstration_ease=product.demonstration_ease,
        novelty=product.novelty,
        return_risk=product.return_risk,
        affiliate_url=product.affiliate_url,
        media_license=product.media_license,
    )
