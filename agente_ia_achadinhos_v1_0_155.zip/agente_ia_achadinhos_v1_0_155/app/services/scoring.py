from app.models.schemas import ProductInput, ProductScore

ALLOWED_MEDIA_LICENSES = {
    "oficial_marketplace", "fabricante", "autorizado_vendedor",
    "licenciado_comercialmente", "produzido_por_nos",
}

MIN_REVIEWS = 500
STANDARD_MIN_RATING = 4.0


def meets_commercial_gate(product: ProductInput) -> tuple[bool, str]:
    if not product.stock_available:
        return False, "Disponibilidade não confirmada ou produto sem estoque"
    if product.price < 1:
        return False, "Preço inválido"
    if product.review_count < MIN_REVIEWS:
        return False, "Menos de 500 avaliações"
    if product.rating >= STANDARD_MIN_RATING:
        return True, "Produto atende à nota mínima de 4,0; vendas não são requisito de aprovação"
    return False, "Avaliação abaixo de 4,0"


def score_product(product: ProductInput) -> ProductScore:
    reasons: list[str] = []
    gate_ok, gate_reason = meets_commercial_gate(product)
    if not gate_ok:
        return ProductScore(total=0, classification="Reprovado", approved=False, reasons=[gate_reason])

    score = 0.0
    score += min(20 + max((product.rating - STANDARD_MIN_RATING) / 1.0, 0) * 15, 35)
    score += min(15 + max(product.review_count - MIN_REVIEWS, 0) / 4500 * 15, 30)
    score += min(product.sold_quantity / 10000 * 20, 20)
    if product.seller_reputation > 0:
        score += min(product.seller_reputation / 100 * 5, 5)
    if product.commission_pct > 0:
        score += min(product.commission_pct / 20 * 5, 5)
    editorial = (product.visual_quality + product.demonstration_ease + product.novelty + (10 - product.return_risk)) / 40
    score += max(0, min(editorial * 5, 5))

    reasons.append(gate_reason)
    if product.sold_quantity <= 0:
        reasons.append("Vendas recentes não foram informadas; demanda apoiada por ranking e avaliações")
    if product.seller_reputation <= 0:
        reasons.append("Reputação do vendedor não informada")
    if product.commission_pct <= 0:
        reasons.append("Comissão não informada; confirmar na Central de Afiliados")
    media_ready = product.media_license in ALLOWED_MEDIA_LICENSES
    if not media_ready:
        reasons.append("Aguardando mídia autorizada para publicação")

    score = round(max(0, min(score, 100)), 2)
    classification = "Excelente" if score >= 85 else "Forte" if score >= 70 else "Boa oportunidade" if score >= 50 else "Reprovado"
    approved = score >= 50
    return ProductScore(total=score, classification=classification, approved=approved, reasons=reasons)
