from __future__ import annotations

import json
import logging
import re
import hashlib
import base64
import mimetypes
import httpx
from PIL import Image
from io import BytesIO

from app.core.config import settings
from app.models.schemas import ScriptRequest, ScriptOutput

logger = logging.getLogger(__name__)

CATEGORY_CONTENT = {
    "casa": ("deixar a casa mais prática", ["#achadinhos", "#casa", "#utilidades", "#dicas"]),
    "cozinha": ("facilitar a rotina na cozinha", ["#achadinhos", "#cozinha", "#utilidades", "#dicas"]),
    "organizacao": ("organizar melhor o dia a dia", ["#achadinhos", "#organizacao", "#casaorganizada", "#dicas"]),
    "beleza": ("complementar a rotina de beleza", ["#achadinhos", "#beleza", "#cuidados", "#dicas"]),
    "cuidados_pessoais": ("facilitar os cuidados pessoais", ["#achadinhos", "#cuidadospessoais", "#autocuidado", "#dicas"]),
}

FORMATS = [
    "problema_solucao", "descoberta", "tres_motivos", "demonstracao",
    "pergunta", "rotina_pratica", "prova_social", "vale_a_pena",
    "erro_comum", "comparacao_rapida", "surpresa_visual",
    "humor_observacao", "humor_seco", "expectativa_realidade", "humor_viral", "humor_risada",
]

# Cada índice representa uma intenção comercial realmente diferente.
VARIATION_ANGLES = (
    {"name": "beneficio", "lead": "benefício prático", "proof": "como ajuda no dia a dia", "cta": "ver detalhes e condição atual"},
    {"name": "criterio_compra", "lead": "o que conferir antes de comprar", "proof": "medidas, itens inclusos e avaliações", "cta": "comparar o anúncio original"},
    {"name": "prova_oferta", "lead": "prova comercial e custo-benefício", "proof": "nota, procura e preço confirmado", "cta": "abrir a oferta atual"},
    {"name": "dor_rotina", "lead": "dor concreta da rotina", "proof": "situação em que o produto faz sentido", "cta": "ver se serve para sua rotina"},
    {"name": "beneficio_oculto", "lead": "benefício menos óbvio", "proof": "uso secundário ou conveniência", "cta": "conferir a versão correta"},
    {"name": "objecao", "lead": "objeção antes da compra", "proof": "o que pode fazer a compra não valer a pena", "cta": "comparar antes de decidir"},
    {"name": "perfil_comprador", "lead": "para quem realmente faz sentido", "proof": "perfil e contexto de uso", "cta": "ver detalhes da oferta"},
    {"name": "anti_hype", "lead": "análise sem exagero", "proof": "o que é fato e o que é só apelo comercial", "cta": "checar o anúncio original"},
)


def _stable_seed(*parts: object) -> int:
    raw = "|".join(str(x or "") for x in parts).encode("utf-8", "ignore")
    return int(hashlib.sha256(raw).hexdigest()[:12], 16)

CTA_DESTINATION_TEXT = "link da bio"


def _cta_destination() -> str:
    return CTA_DESTINATION_TEXT



def _short_title(title: str, limit: int = 92) -> str:
    clean = " ".join(str(title or "").split())
    return clean if len(clean) <= limit else clean[:limit].rsplit(" ", 1)[0].rstrip("-–—, ")


def _measurement(title: str) -> tuple[str, str] | None:
    """Retorna medida para tela e para fala, sem tocar em palavras como Luxo, Max ou Box."""
    match = re.search(r"(?<!\w)(\d{1,3})\s*[x×]\s*(\d+(?:[,\.]\d{1,2})?)(?:\s*(cm|m))?", title, re.I)
    if not match:
        return None
    first = match.group(1)
    second = match.group(2).replace(".", ",")
    unit = (match.group(3) or "").lower()
    try:
        second_value = float(second.replace(",", "."))
    except ValueError:
        second_value = 0
    if unit == "cm":
        screen = f"{first} × {second} cm"
        spoken = f"{first} por {second} centímetros"
    elif unit == "m":
        screen = f"{first} × {second} m"
        spoken = f"{first} por {second} metros"
    elif second_value and second_value < 10 and int(first) >= 10:
        screen = f"{first} cm × {second} m"
        whole = int(second_value)
        cents = round((second_value - whole) * 100)
        if cents:
            spoken = f"{first} centímetros por {whole} metro" + ("s" if whole != 1 else "") + f" e {cents} centímetros"
        else:
            spoken = f"{first} centímetros por {whole} metro" + ("s" if whole != 1 else "")
    else:
        screen = f"{first} × {second}"
        spoken = f"{first} por {second}"
    return screen, spoken


def _quantity(title: str) -> int | None:
    patterns = (
        r"\bkit\s*(?:c\s*/?\s*|com\s+)?(\d+)\b",
        r"\bc\s*/\s*(\d+)\b",
        r"\bcom\s+(\d+)\b",
    )
    for pattern in patterns:
        match = re.search(pattern, title, re.I)
        if match:
            return int(match.group(1))
    return None


def _product_profile(title: str) -> dict[str, str | int | list[str]]:
    """Interpreta títulos comerciais sem os copiar literalmente para roteiro ou tela."""
    raw = " ".join(str(title or "").split())
    lower = raw.lower()
    quantity = _quantity(raw)
    measure = _measurement(raw)
    attributes: list[str] = []

    if "toalha" in lower:
        noun = "toalhas" if (quantity or 1) > 1 else "toalha"
        kind = " de banho" if "banho" in lower else ""
        qualifiers: list[str] = []
        if "gigante" in lower or "grande" in lower:
            qualifiers.append("grandes" if noun == "toalhas" else "grande")
        # “Luxo” é linguagem promocional do vendedor. Não é tratado como fato.
        if "luxo" in lower:
            attributes.append("ANUNCIADO COMO LINHA DE LUXO")
        spoken_name = f"kit com {quantity} {noun}{kind}" if quantity else f"{noun}{kind}"
        if qualifiers:
            spoken_name += " " + " e ".join(qualifiers)
        display_name = f"KIT COM {quantity} TOALHAS" if quantity else "TOALHAS DE BANHO"
        attributes = ["CORES E ESTAMPAS VARIADAS"]
        benefits = ["renovar as toalhas do banheiro", "ter peças grandes para o uso diário", "variar cores e estampas"]
        problem = "aquela toalha antiga que já pediu aposentadoria"
        humorous_hook = "Seu banheiro ainda está sobrevivendo com aquela toalha que já pediu aposentadoria?"
        criterion = "quantidade, tamanho, cores e estampas"
        gender = "masculine" if quantity else "feminine"
    elif any(token in lower for token in ("máscara", "mascara", "reconstrução", "reconstrucao")) and any(token in lower for token in ("cabelo", "capilar", "fios")):
        spoken_name = "máscara de reconstrução para cabelos danificados"
        display_name = "RECONSTRUÇÃO PARA CABELOS DANIFICADOS"
        if any(token in lower for token in ("proteína do trigo", "proteina do trigo")):
            attributes.append("COM PROTEÍNA DO TRIGO")
        if "gluco" in lower:
            attributes.append("COM GLUCOPEPTÍDEO")
        volume = re.search(r"\b(\d+(?:[,\.]\d+)?)\s*(ml|g|kg)\b", lower, re.I)
        if volume:
            attributes.append(f"CONTEÚDO: {volume.group(1).replace('.', ',')} {volume.group(2).upper()}")
        benefits = ["complementar a rotina de cuidados com fios danificados", "aplicar um tratamento de reconstrução capilar"]
        problem = "fios danificados e com aspecto fragilizado"
        humorous_hook = "Seu cabelo pediu socorro e aparentemente abriu um chamado urgente."
        criterion = "composição, volume, modo de uso e indicação para o seu tipo de cabelo"
        gender = "feminine"
    elif any(token in lower for token in ("caderneta", "moleskine", "caderno a5", "anotação a5")):
        spoken_name = "caderneta A5 tipo Moleskine"
        display_name = "CADERNETA A5 TIPO MOLESKINE"
        if "couro sint" in lower:
            attributes.append("CAPA EM COURO SINTÉTICO")
        if "elástico" in lower or "elastico" in lower:
            attributes.append("CAPA COM ELÁSTICO")
        if "sem pauta" in lower or "folha lisa" in lower:
            attributes.append("MIOLO SEM PAUTA")
        if "pautad" in lower or "folha listrada" in lower:
            attributes.append("FOLHAS PAUTADAS")
        benefits = ["guardar ideias e anotações", "organizar compromissos", "levar anotações na bolsa"]
        problem = "tentar guardar todas as ideias apenas na cabeça"
        humorous_hook = "Sua cabeça já não aguenta guardar mais uma ideia? Essa caderneta chegou em boa hora."
        criterion = "tipo de folha, medidas, material da capa e variações"
        gender = "feminine"
    else:
        clean = re.sub(r"\b(?:atacado|promoção|oferta|envio imediato|pronta entrega)\b", " ", raw, flags=re.I)
        clean = re.sub(r"(?<!\w)\d{1,3}\s*[x×]\s*\d+(?:[,\.]\d{1,2})?(?:\s*(?:cm|m))?", " ", clean, flags=re.I)
        clean = re.sub(r"\bc\s*/\s*(\d+)\b", r"com \1", clean, flags=re.I)
        clean = re.sub(r"\s+", " ", clean).strip(" ,-–—")
        spoken_name = clean.lower()
        display_name = _short_title(clean, 42).upper()
        benefits = ["usar o produto na situação indicada", "comparar as versões disponíveis", "escolher uma opção compatível com a rotina"]
        problem = "comprar sem conferir as características que realmente mudam o uso"
        humorous_hook = "A embalagem pode chamar atenção; a função precisa convencer."
        criterion = "função, material, medidas, compatibilidade, variações e avaliações"
        gender = _infer_product_gender(spoken_name)

    return {
        "quantity": quantity or 0,
        "spoken_name": spoken_name,
        "display_name": display_name,
        "measure_screen": measure[0] if measure else "",
        "measure_spoken": measure[1] if measure else "",
        "attributes": attributes,
        "benefits": benefits,
        "problem": problem,
        "humorous_hook": humorous_hook,
        "criterion": criterion,
        "gender": gender,
    }



_FEMININE_PRODUCT_WORDS = {
    "máscara", "mascara", "panela", "toalha", "caderneta", "escova", "mochila",
    "garrafa", "camisa", "blusa", "frigideira", "cadeira", "mesa", "luminária",
    "luminaria", "máquina", "maquina", "cafeteira", "carteira", "bolsa", "capa",
    "almofada", "forma", "assadeira", "caneca", "fritadeira", "balança", "balanca",
}

_MASCULINE_PRODUCT_WORDS = {
    "kit", "organizador", "liquidificador", "notebook", "barbeador", "ventilador",
    "aspirador", "caderno", "fone", "relógio", "relogio", "suporte", "produto",
    "aparelho", "jogo", "conjunto", "pote", "creme", "shampoo", "secador",
}

def _infer_product_gender(name: str) -> str:
    words = re.findall(r"[A-Za-zÀ-ÿ]+", str(name or "").casefold())
    for word in words:
        if word in _FEMININE_PRODUCT_WORDS:
            return "feminine"
        if word in _MASCULINE_PRODUCT_WORDS:
            return "masculine"
    return "unknown"

def _natural_product_reference(profile: dict[str, str | int | list[str]], *, capitalized: bool = True) -> str:
    name = str(profile.get("spoken_name") or "produto").strip()
    gender = str(profile.get("gender") or _infer_product_gender(name))
    if gender == "feminine":
        phrase = f"esta {name}"
    elif gender == "masculine":
        phrase = f"este {name}"
    else:
        phrase = "este produto"
    return phrase[:1].upper() + phrase[1:] if capitalized else phrase

def _grammar_safety_pass(text: str, profile: dict[str, str | int | list[str]]) -> str:
    """Corrige padrões de concordância perigosos antes do TTS.

    Evita depender apenas de templates. Quando o gênero é desconhecido, usa
    'este produto', que é uma construção segura e natural.
    """
    clean = re.sub(r"\s+", " ", str(text or "")).strip()
    name = re.escape(str(profile.get("spoken_name") or "").strip())
    reference = _natural_product_reference(profile, capitalized=True)
    if name:
        clean = re.sub(rf"\bEste é o\s+{name}\b", reference, clean, flags=re.I)
        clean = re.sub(rf"\bEsta é a\s+{name}\b", reference, clean, flags=re.I)
        clean = re.sub(rf"\bOlha este\s+{name}\b", f"Olha {reference.lower()}", clean, flags=re.I)
        clean = re.sub(rf"\bOlha esta\s+{name}\b", f"Olha {reference.lower()}", clean, flags=re.I)
    # Bloqueios gerais dos erros observados e de equivalentes comuns.
    substitutions = {
        r"\beste é o máscara\b": "esta máscara",
        r"\beste é o mascara\b": "esta máscara",
        r"\beste é o panela\b": "esta panela",
        r"\beste é o toalha\b": "esta toalha",
        r"\beste é o caderneta\b": "esta caderneta",
        r"\beste é o escova\b": "esta escova",
        r"\buma produto\b": "um produto",
        r"\bos embalagem\b": "as embalagens",
        r"\bduas unidade\b": "duas unidades",
        r"\besta kit\b": "este kit",
        r"\besta conjunto\b": "este conjunto",
        r"\bquantidade, dimensões, composição, gramatura e variações mudam\b": "quantidade, dimensões, composição, gramatura e variações mudam",
    }
    for pattern, replacement in substitutions.items():
        clean = re.sub(pattern, replacement, clean, flags=re.I)
    return clean

def _spoken_title(title: str) -> str:
    """Compatibilidade de leitura literal do título em telas antigas.

    O Roteirista Premium não usa esta função para transformar “luxo” em fato;
    ela apenas preserva a leitura histórica quando chamada diretamente.
    """
    profile = _product_profile(title)
    spoken = str(profile["spoken_name"])
    if "toalha" in title.casefold() and "luxo" in title.casefold() and "de luxo" not in spoken:
        spoken += " e de luxo"
    return spoken

def _money(value: float) -> str:
    return f"R$ {value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _link_cta() -> str:
    """CTA seguro antes de a rede social da publicação ser escolhida.

    No Instagram, normalmente o destino será a bio; em outras redes, pode ser a
    descrição. A frase permanece correta nos dois casos e evita vídeos sem CTA.
    """
    return "Veja os detalhes no link da descrição ou da bio."


def _fit_narration_to_duration(hook: str, narration: str, cta: str, duration_seconds: int) -> str:
    """Mantém a fala dentro do tempo e reserva espaço para o CTA final.

    O vídeo não deve cortar o link no fim. A estimativa conservadora de 2,55
    palavras por segundo funciona bem com as vozes gratuitas em português.
    """
    total_budget = max(28, int(duration_seconds * 2.45))
    reserved = len(hook.split()) + len(cta.split())
    narration_budget = max(12, total_budget - reserved)
    sentences = re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", narration).strip())
    selected: list[str] = []
    used = 0
    for sentence in sentences:
        words = sentence.split()
        if not words:
            continue
        if used + len(words) <= narration_budget:
            selected.append(sentence)
            used += len(words)
            continue
        remaining = narration_budget - used
        atomic_fact = bool(re.search(r"\b(?:centímetro|centimetro|metro|mililitro|litro|unidade)s?\b|\d", sentence, flags=re.I))
        # Medidas, quantidades e outros fatos atômicos nunca podem terminar pela
        # metade (ex.: “70 centímetros por 1 metro e”). Aceita pequena folga de
        # duração para preservar o dado completo e a fala natural.
        if atomic_fact and len(words) <= remaining + 12:
            selected.append(sentence)
            used += len(words)
        elif not selected and len(words) <= narration_budget + 8:
            selected.append(sentence)
        break
    result = " ".join(selected).strip()
    # Nunca deixe o TTS terminar em preposição/conjunção após ajuste de duração.
    result = re.sub(r"(?:,?\s+)(?:e|ou|de|do|da|dos|das|com|para|em|por)\s*[.!?]?$", ".", result, flags=re.I)
    result = re.sub(r"\s+([,.;:!?])", r"\1", result).strip()
    return result


def product_visual_facts(title: str) -> dict[str, str | list[str]]:
    """Fatos visuais sem truncamento e com medidas atômicas."""
    profile = _product_profile(title)
    return {
        "product": str(profile.get("display_name") or "PRODUTO EM DESTAQUE"),
        "measurement": str(profile.get("measure_screen") or ""),
        "attributes": list(profile.get("attributes") or []),
    }


def resolve_format(request: ScriptRequest) -> str:
    """Resolve o formato efetivo e mantém humor e interpretação vocal alinhados."""
    if request.format != "automatico":
        return request.format
    instructions = (request.voice_instructions or "").lower()
    humorous = any(token in instructions for token in ("humor", "engraç", "divertid", "piada"))
    if humorous:
        humor_formats = ("humor_viral", "humor_observacao", "humor_seco", "expectativa_realidade")
        return humor_formats[request.variation_index % len(humor_formats)]
    seed = sum(ord(c) for c in request.product.title)
    return FORMATS[(seed + request.variation_index * 3) % len(FORMATS)]


def _format_for(request: ScriptRequest) -> str:
    return resolve_format(request)


def _sales_reference(sold_quantity: int) -> str:
    """Transforma vendas em prova social estável e natural, sem citar o número exato."""
    value = max(0, int(sold_quantity or 0))
    if value < 100:
        return ""
    if value >= 1_000_000:
        base = (value // 1_000_000) * 1_000_000
        label = f"{base // 1_000_000} milhão" if base == 1_000_000 else f"{base // 1_000_000} milhões"
    elif value >= 100_000:
        base = (value // 100_000) * 100_000
        label = f"{base // 1_000} mil"
    elif value >= 10_000:
        base = (value // 10_000) * 10_000
        label = f"{base // 1_000} mil"
    elif value >= 1_000:
        base = (value // 1_000) * 1_000
        label = f"{base // 1_000} mil"
    else:
        base = (value // 100) * 100
        label = str(base)
    return f"mais de {label} vendas"


def _proof_line(rating: float, sold_quantity: int, review_count: int = 0) -> str:
    parts: list[str] = []
    if rating > 0:
        parts.append(f"nota {rating:.1f}".replace(".", ","))
    if review_count > 0:
        parts.append(f"{review_count:,} avaliações".replace(",", "."))
    sales = _sales_reference(sold_quantity)
    if sales:
        parts.append(sales)
    return ", ".join(parts) if parts else "informações confirmadas no anúncio"


def _facts(title: str) -> list[str]:
    profile = _product_profile(title)
    facts: list[str] = []
    if profile["quantity"]:
        if "toalha" in title.lower():
            facts.append(f"kit com {profile['quantity']} toalhas")
        else:
            facts.append(f"kit com {profile['quantity']} unidades")
    if profile["measure_screen"]:
        facts.append(str(profile["measure_screen"]))
    return facts

def _scene_plan(hook: str, short: str, facts: list[str], proof: str, price: str, cta: str, duration: int, angle: str) -> list[str]:
    """Storyboard textual com prova social única e CTA restrito ao final."""
    end = max(12, min(duration, 35))
    cta_seconds = min(3, max(2, round(end * 0.10)))
    cta_start = end - cta_seconds
    useful = [str(f).upper() for f in facts if str(f).strip()]
    scenes = [f"0–2s · {hook}"]
    cursor = 2
    for fact in useful[:4]:
        if cursor >= cta_start - 3:
            break
        next_cursor = min(cta_start - 3, cursor + 3)
        scenes.append(f"{cursor}–{next_cursor}s · {fact}")
        cursor = next_cursor
    proof_start = max(cursor, cta_start - 3)
    scenes.append(f"{proof_start}–{cta_start}s · {proof.upper()}")
    scenes.append(f"{cta_start}–{end}s · {cta.upper()}")
    scenes.extend((f"ÂNGULO CRIATIVO · {angle}", f"PRODUTO · {short}"))
    return scenes




BANNED_META_PHRASES = (
    r"\bnas fotos\b", r"\bpelas imagens\b", r"\bpelas fotos\b",
    r"\bcomo mostrado nas imagens\b", r"\bcomo aparece nas imagens\b",
    r"\bconforme (?:mostrado|aparece) no anúncio\b", r"\bdetalhes reais\b",
    r"\bconfira nas fotos\b", r"\bveja nas fotos\b",
)

def sanitize_script_language(text: str) -> str:
    """Remove linguagem metalinguística e redundante antes de salvar ou narrar."""
    clean = re.sub(r"\s+", " ", str(text or "")).strip()
    replacements = {
        r"(?i)nas fotos(?: reais)?(?: do anúncio)?[, ]*(?:dá para|é possível) conferir": "o produto apresenta",
        r"(?i)pelas (?:fotos|imagens)[, ]*(?:dá para|é possível) conferir": "o produto apresenta",
        r"(?i)(?:os )?detalhes reais mostrados nas fotos": "as características confirmadas do produto",
        r"(?i)como mostrado nas imagens": "conforme as características confirmadas",
    }
    for pattern, repl in replacements.items():
        clean = re.sub(pattern, repl, clean)
    clean = re.sub(r"\b(fotos)\b(?=[^.!?]{0,45}\b\1\b)", "imagens", clean, flags=re.I)
    clean = re.sub(r"\s+([,.;:!?])", r"\1", clean)
    return clean.strip()

def script_language_issues(*parts: str) -> list[str]:
    joined = " ".join(str(x or "") for x in parts)
    issues=[]
    for pattern in BANNED_META_PHRASES:
        if re.search(pattern, joined, re.I):
            issues.append("O texto contém uma expressão genérica sobre fotos ou imagens.")
            break
    if re.search(r"\b(?:este é o|esta é o)\s+(?:máscara|panela|toalha|caderneta|escova|mochila)\b", joined, re.I):
        issues.append("Há erro de concordância de gênero no nome do produto.")
    if re.search(r"\b(?:para|de|com|em|e)\s*[.!?]?$", joined.strip(), re.I):
        issues.append("Há frase incompleta terminando em preposição ou conjunção.")
    return issues



def _category_script_profile(title: str, category_key: str, profile: dict) -> dict[str, object]:
    """Define uma tese comercial concreta para qualquer categoria de produto.

    Cada família recebe público, dor, critérios e uma ideia central. O perfil
    universal evita frases vazias: usa quantidade, medidas, material e função
    extraídos do título sempre que disponíveis.
    """
    lower = str(title or "").casefold()
    product = str(profile.get("spoken_name") or "produto")
    attributes = [str(x).lower() for x in profile.get("attributes") or []]
    measure = str(profile.get("measure_spoken") or "").strip()
    concrete = ", ".join(attributes[:2])
    if measure:
        concrete = (concrete + ", " if concrete else "") + measure
    base = {
        "family": "universal",
        "audience": "quem quer resolver uma necessidade específica sem comprar no impulso",
        "problem": str(profile.get("problem") or "escolher um produto sem saber quais características realmente importam"),
        "use_cases": list(profile.get("benefits") or ["resolver uma necessidade prática", "comparar opções com mais segurança", "escolher a versão adequada"]),
        "decision": str(profile.get("criterion") or "função, material, medidas, compatibilidade, variações e avaliações"),
        "care": "confira a versão, as medidas, a compatibilidade e as condições atuais antes de comprar",
        "thesis": f"o valor de {product} depende menos do título e mais de como suas características atendem ao uso real",
        "concrete": concrete,
        "hooks": [
            "Antes de comprar, descubra o detalhe que realmente muda o uso.",
            "Parece simples, mas uma escolha errada pode custar tempo e dinheiro.",
            "O melhor modelo não é o mais chamativo, e sim o mais adequado.",
        ],
    }
    rules = [
        (("lâmina", "lamina", "barbear", "mach3", "gillette"), {
            "family": "barbear", "audience": "quem sente irritação ao se barbear ou precisa repor as cargas do aparelho",
            "problem": "uma lâmina gasta ou incompatível pode puxar os pelos e aumentar o desconforto",
            "use_cases": ["substituir refis gastos", "manter o barbear mais confortável", "ter cargas de reposição disponíveis"],
            "decision": "compatibilidade com o aparelho, quantidade de refis, fita lubrificante e durabilidade anunciada",
            "care": "confira a compatibilidade com o seu aparelho e siga as orientações do fabricante",
            "thesis": "para pele sensível, compatibilidade e lubrificação importam mais do que uma embalagem chamativa",
            "hooks": ["Se o barbear irrita sua pele, a lâmina pode ser o problema.", "Refil errado transforma um barbear simples em irritação.", "Antes de trocar o aparelho, confira o refil que você usa."],
        }),
        (("panela", "frigideira", "caçarola", "caçarola"), {
            "family": "cozinha", "audience": "quem cozinha com frequência e quer praticidade sem danificar o utensílio",
            "problem": "alimento grudando, capacidade inadequada ou incompatibilidade com o fogão",
            "use_cases": ["preparar refeições do dia a dia", "usar a capacidade certa para a receita", "facilitar a limpeza"],
            "decision": "material, revestimento, capacidade, tampa e compatibilidade com o fogão",
            "care": "confira as recomendações de uso e limpeza para preservar o revestimento",
            "thesis": "uma panela boa é a que combina material, capacidade e compatibilidade com a sua rotina",
            "hooks": ["Panela bonita não basta: ela precisa funcionar no seu fogão.", "O revestimento certo pode mudar o preparo e a limpeza.", "Antes de comprar uma panela, confira estes três pontos."],
        }),
        (("organizador", "caixa", "gaveta", "prateleira"), {
            "family": "organizacao", "audience": "quem quer reduzir bagunça e encontrar as coisas com facilidade",
            "problem": "objetos espalhados e espaço mal aproveitado",
            "use_cases": ["separar itens por categoria", "aproveitar armários e gavetas", "deixar a rotina mais visual"],
            "decision": "medidas, material, capacidade e local de uso",
            "care": "meça o espaço disponível antes de escolher a variação",
            "thesis": "organização só funciona quando o produto cabe no espaço e na rotina",
            "hooks": ["Se nada cabe no lugar, talvez o problema seja o organizador.", "Organizar sem medir o espaço é trocar uma bagunça por outra.", "Este detalhe decide se o organizador ajuda ou atrapalha."],
        }),
        (("máscara", "mascara", "shampoo", "condicionador", "capilar"), {
            "family": "capilar", "audience": "quem quer complementar a rotina de cuidados com os cabelos",
            "problem": "fios com aspecto ressecado, fragilizado ou danificado",
            "use_cases": ["incluir uma etapa de tratamento", "cuidar dos fios conforme a indicação", "comparar ativos e volume"],
            "decision": "composição, volume, indicação, modo de uso e frequência recomendada",
            "care": "confira a composição completa e se o produto é adequado ao seu tipo de cabelo",
            "thesis": "um tratamento capilar faz sentido quando a composição e a indicação combinam com a necessidade dos fios",
            "hooks": ["Seu cabelo está pedindo tratamento ou só mais hidratação?", "Nem toda máscara serve para o mesmo tipo de dano.", "Antes de aplicar, confira se a proposta combina com seus fios."],
        }),
        (("caderneta", "caderno", "agenda", "moleskine"), {
            "family": "papelaria", "audience": "quem registra ideias, compromissos, estudos ou projetos",
            "problem": "depender da memória e perder anotações importantes",
            "use_cases": ["organizar ideias", "registrar tarefas e compromissos", "levar anotações na bolsa"],
            "decision": "tamanho, material da capa, tipo de folha, fechamento e variações",
            "care": "confira se a opção escolhida é pautada, sem pauta ou possui outra configuração",
            "thesis": "a melhor caderneta é a que combina formato, tipo de folha e portabilidade com a forma de uso",
            "hooks": ["Sua cabeça não precisa guardar todas as ideias sozinha.", "Pautada ou sem pauta? Essa escolha muda tudo.", "Uma boa caderneta começa pelo tipo de uso, não pela capa."],
        }),
        (("luminária", "luminaria", "abajur", "led", "lanterna"), {
            "family": "iluminacao", "audience": "quem precisa de iluminação prática para leitura, trabalho ou ambiente",
            "problem": "a luz disponível pode ser fraca, mal posicionada ou depender sempre de uma tomada",
            "use_cases": ["iluminar uma área específica", "adaptar a luz à rotina", "usar o produto em diferentes ambientes"],
            "decision": "tipo de alimentação, autonomia, potência, tamanho, controles e forma de instalação",
            "care": "confira autonomia, voltagem, potência e acessórios incluídos",
            "thesis": "em iluminação, autonomia, intensidade e posicionamento importam mais do que o formato",
            "hooks": ["Luz bonita não basta: ela precisa iluminar onde você realmente usa.", "Antes de escolher uma luminária, confira autonomia e intensidade.", "A diferença entre decoração e utilidade está na luz que ela entrega."],
        }),
        (("camera", "câmera", "instax", "fotográfica", "fotografica"), {
            "family": "camera", "audience": "quem gosta de registrar momentos e ter a foto física na hora",
            "problem": "a foto fica no celular, some no rolo da câmera e o momento vira só mais um arquivo entre milhares",
            "use_cases": ["registrar momentos e imprimir na hora", "criar lembranças físicas em festas e viagens", "presentear ou montar álbuns sem depender de impressora"],
            "decision": "tipo de filme compatível, custo por foto, alimentação, flash, modo de exposição e acessórios incluídos",
            "care": "confira o filme compatível, se ele acompanha o kit e o custo das reposições",
            "thesis": "em câmera instantânea, a graça está na experiência física; o custo recorrente do filme também faz parte da compra",
            "hooks": ["Seu celular tem dez mil fotos. Quantas você realmente pega na mão?", "A foto sai na hora; a vergonha da pose também.", "Câmera instantânea é nostalgia com boleto de filme."],
        }),
        (("fone", "caixa de som", "carregador", "power bank", "smartwatch", "relógio inteligente"), {
            "family": "eletronicos", "audience": "quem procura praticidade e compatibilidade no uso diário",
            "problem": "um eletrônico incompatível ou com autonomia insuficiente pode frustrar logo no primeiro uso",
            "use_cases": ["usar o recurso principal com praticidade", "integrar o produto aos dispositivos da rotina", "evitar depender de acessórios inadequados"],
            "decision": "compatibilidade, autonomia, conectividade, potência, garantia e acessórios incluídos",
            "care": "confira especificações, compatibilidade e condições de garantia",
            "thesis": "em eletrônicos, compatibilidade e autonomia valem mais do que uma lista longa de funções",
            "hooks": ["Função demais não ajuda se o produto não for compatível.", "Antes de comprar, confira autonomia e compatibilidade.", "O melhor eletrônico é o que funciona bem na sua rotina."],
        }),
        (("furadeira", "parafusadeira", "chave", "alicate", "ferramenta", "serra"), {
            "family": "ferramentas", "audience": "quem precisa executar reparos ou trabalhos com segurança e eficiência",
            "problem": "usar uma ferramenta fraca, inadequada ou incompatível com a tarefa pode aumentar o retrabalho",
            "use_cases": ["executar a tarefa indicada", "reduzir esforço e retrabalho", "manter ferramentas adequadas disponíveis"],
            "decision": "potência, torque, capacidade, acessórios, alimentação e aplicação indicada",
            "care": "confira a aplicação, os acessórios e as orientações de segurança",
            "thesis": "uma ferramenta vale pela adequação à tarefa, não apenas pela potência anunciada",
            "hooks": ["Ferramenta errada transforma serviço simples em retrabalho.", "Potência não resolve tudo: a aplicação precisa ser compatível.", "Antes de comprar, confira se ela atende à tarefa real."],
        }),
        (("camisa", "camiseta", "vestido", "calça", "tenis", "tênis", "sapato", "sandália"), {
            "family": "moda", "audience": "quem quer escolher tamanho, material e caimento com mais segurança",
            "problem": "uma peça bonita pode não servir bem quando medidas e material não são conferidos",
            "use_cases": ["compor looks da rotina", "escolher o tamanho adequado", "comparar cores e variações"],
            "decision": "tabela de medidas, material, modelagem, acabamento e política de troca",
            "care": "compare suas medidas com a tabela e confira material e política de troca",
            "thesis": "em moda, medidas e material importam mais do que a aparência isolada",
            "hooks": ["Peça bonita não compensa tamanho errado.", "Antes da cor, confira medidas e material.", "O caimento começa na tabela de medidas, não na foto."],
        }),
        (("pet", "cachorro", "gato", "ração", "brinquedo para", "comedouro"), {
            "family": "pet", "audience": "quem quer escolher um item adequado ao porte e à rotina do animal",
            "problem": "um produto inadequado ao porte, idade ou comportamento pode não ser usado com segurança",
            "use_cases": ["atender uma necessidade do animal", "facilitar os cuidados diários", "escolher a variação adequada ao porte"],
            "decision": "porte, material, dimensões, indicação de idade, segurança e forma de uso",
            "care": "confira a indicação de porte, material e recomendações de segurança",
            "thesis": "para pets, adequação ao porte e segurança vêm antes da aparência",
            "hooks": ["Bonito para você não significa adequado para o seu pet.", "Antes de comprar, confira porte, material e segurança.", "O tamanho certo faz diferença no uso e na segurança."],
        }),
        (("automotivo", "carro", "moto", "veicular", "corolla", "limpador de para-brisa"), {
            "family": "automotivo", "audience": "quem precisa de compatibilidade e instalação correta no veículo",
            "problem": "uma peça incompatível pode não encaixar, não funcionar ou gerar retrabalho",
            "use_cases": ["substituir um componente", "manter o veículo em uso", "evitar adaptações inadequadas"],
            "decision": "modelo, ano, medidas, código da peça, lado de instalação e compatibilidade",
            "care": "confirme modelo, ano e código da peça antes da compra",
            "thesis": "em itens automotivos, compatibilidade exata vale mais do que preço ou aparência",
            "hooks": ["Peça parecida não significa peça compatível.", "Antes de comprar, confirme modelo, ano e código.", "Compatibilidade errada vira retrabalho na instalação."],
        }),
        (("toalha", "lençol", "lencol", "cobertor"), {
            "family": "enxoval", "audience": "quem quer renovar peças de uso diário sem escolher apenas pela aparência",
            "problem": "peças pequenas, pouco absorventes ou inadequadas à rotina",
            "use_cases": ["renovar o enxoval", "ter peças extras", "escolher cores e tamanhos adequados"],
            "decision": "quantidade, dimensões, composição, gramatura e variações",
            "care": "confira medidas, composição e instruções de lavagem antes de escolher",
            "thesis": "em toalhas, tamanho, composição e gramatura dizem mais do que o adjetivo usado no título",
            "hooks": ["Toalha bonita é fácil. Mas ela seca bem?", "Antes da estampa, confira tamanho e composição.", "Três toalhas no kit só valem a pena se forem adequadas ao uso."],
        }),
    ]
    for tokens, values in rules:
        if any(token in lower for token in tokens):
            base.update(values)
            break
    return base


CREATIVE_STRUCTURES = (
    "problema_solucao", "mini_historia", "erro_comum", "comparacao", "curiosidade",
    "lista_inteligente", "mito_realidade", "rotina", "descoberta", "opiniao",
    "pergunta_resposta", "beneficio_oculto", "anti_hype", "cenario_real",
    "checklist_compra", "objecao_resposta", "micro_review", "decisao_rapida",
)




def _requested_script_style(request: ScriptRequest) -> str:
    text = f"{request.format} {request.voice_instructions} {request.presenter_style}".lower()
    if any(x in text for x in ("engraç", "humor", "divertid", "piada", "cômic", "comico")):
        return "humor"
    if any(x in text for x in ("custo benefício", "custo-benefício", "custo beneficio", "economia", "vale a pena", "preço", "oferta")):
        return "custo_beneficio"
    if any(x in text for x in ("compar", "versus", "diferença")):
        return "comparativo"
    if any(x in text for x in ("informativ", "técnic", "tecnic", "explic")):
        return "informativo"
    if any(x in text for x in ("story", "história", "historia")):
        return "storytelling"
    return "automatico"



def _requested_script_substyle(request: ScriptRequest) -> str:
    """Retorna o formato editorial exato pedido pelo usuário.

    O estilo amplo continua sendo usado pela auditoria, mas o subestilo impede
    que humor de observação, humor seco e expectativa x realidade virem o
    mesmo texto com rótulos diferentes.
    """
    fmt = str(request.format or "automatico").strip().lower()
    text = f"{fmt} {request.voice_instructions} {request.presenter_style}".casefold()
    direct = {
        "humor_observacao", "humor_seco", "expectativa_realidade", "humor_viral", "humor_risada",
        "problema_solucao", "descoberta", "tres_motivos", "demonstracao",
        "pergunta", "rotina_pratica", "prova_social", "vale_a_pena",
        "erro_comum", "comparacao_rapida", "surpresa_visual",
    }
    if fmt in direct:
        return fmt
    if any(x in text for x in ("custo benefício", "custo-benefício", "custo beneficio", "economia", "compensa")):
        return "custo_beneficio"
    if any(x in text for x in ("storytelling", "história", "historia", "mini história", "mini historia")):
        return "storytelling"
    if any(x in text for x in ("humor viral", "comédia viral", "comedia viral", "engraçado de verdade", "engracado de verdade")):
        return "humor_viral"
    if any(x in text for x in ("humor seco", "ironia seca")):
        return "humor_seco"
    if any(x in text for x in ("expectativa", "realidade")) and "humor" in text:
        return "expectativa_realidade"
    if any(x in text for x in ("humor", "engraç", "piada", "cômic", "comico")):
        return "humor_observacao"
    if any(x in text for x in ("compar", "versus", "diferença")):
        return "comparacao_rapida"
    if any(x in text for x in ("informativ", "técnic", "tecnic", "explic")):
        return "informativo"
    return "automatico"


def _category_humor_bank(family: str) -> dict[str, list[str]]:
    """Banco editorial por categoria; nenhuma linha depende do nome bruto do anúncio."""
    banks = {
        "enxoval": {
            "observacao": [
                "A toalha que já pediu aposentadoria ainda esquece de enxugar.",
                "A toalha combina com o banheiro; com a função de enxugar, negocia.",
                "Tem toalha que sai do banho mais molhada e ainda esquece de enxugar. É um talento específico.",
            ],
            "seco": [
                "É uma toalha. Enxugar continua sendo requisito, não diferencial.",
                "Estampa bonita. Agora falta a parte operacional.",
                "Três unidades. Porque uma toalha cansada já era suficiente.",
            ],
            "expectativa": [
                "Expectativa: banheiro de catálogo. Realidade: a toalha antiga ainda negociando aposentadoria.",
                "Expectativa: conforto depois do banho. Realidade: procurar uma ponta que ainda esteja seca.",
                "Expectativa: renovar o enxoval. Realidade: descobrir que medida e composição importam mais que a estampa.",
            ],
        },
        "barbear": {
            "observacao": [
                "Quem tem pele sensível conhece o ritual: fazer a barba e depois negociar a paz com o espelho.",
                "Toda lâmina promete praticidade; a pele é quem faz a auditoria na primeira passada.",
                "Barbear deveria tirar pelos, não abrir uma discussão com o rosto.",
            ],
            "seco": [
                "Três lâminas. A paciência continua sendo vendida separadamente.",
                "Compatível com Mach3. Com improviso, não.",
                "Aloe ajuda. Milagre não acompanha o refil.",
            ],
            "expectativa": [
                "Expectativa: barba rápida. Realidade: o espelho acompanhando cada puxão.",
                "Expectativa: pele lisa. Realidade: irritação fazendo participação especial.",
                "Expectativa: economizar no refil. Realidade: comprar o incompatível e pagar duas vezes.",
            ],
        },
        "papelaria": {
            "observacao": [
                "Toda ideia parece inesquecível até cinco minutos depois, quando a memória pede demissão.",
                "A cabeça diz que vai lembrar. A caderneta prefere trabalhar com provas.",
                "Quem anota em papel solto também pratica um esporte: procurar onde colocou.",
            ],
            "seco": [
                "A memória é ótima. Quando comparece.",
                "Capa bonita. Ideia perdida continua feia.",
                "Folha lisa ou pautada. Desculpa para não anotar, nenhuma.",
            ],
            "expectativa": [
                "Expectativa: lembrar de tudo. Realidade: esquecer até onde anotou.",
                "Expectativa: rotina organizada. Realidade: três papéis soltos e uma foto no celular.",
                "Expectativa: uma ideia brilhante. Realidade: lembrar apenas que ela existiu.",
            ],
        },
        "cozinha": {
            "observacao": [
                "Toda cozinha tem uma panela que gruda até a esperança.",
                "Quando o almoço vira escultura no fundo da panela, talvez o revestimento esteja dando um recado.",
                "Tem panela que cozinha e tem panela que cria trabalho para a esponja.",
            ],
            "seco": [
                "Antiaderente é função. Crosta não é bônus.",
                "Tampa inclusa. Paciência não deveria ser necessária.",
                "Bonita no fogão. Melhor ainda se colaborar com o almoço.",
            ],
            "expectativa": [
                "Expectativa: almoço rápido. Realidade: meia hora soltando comida do fundo.",
                "Expectativa: pouca gordura. Realidade: compensar o revestimento cansado no óleo.",
                "Expectativa: lavar em dois minutos. Realidade: iniciar uma restauração arqueológica.",
            ],
        },
        "capilar": {
            "observacao": [
                "Cabelo danificado não manda e-mail, mas encontra maneiras bem claras de reclamar.",
                "Toda máscara promete resgate; o fio é quem decide se aceita o atendimento.",
                "Tem dia em que o cabelo acorda com mais opiniões do que a pessoa.",
            ],
            "seco": [
                "Promessa bonita. O fio continua lendo a composição.",
                "Reconstrução, não negociação diplomática com o frizz.",
                "Duzentos mililitros. Milagre continua sem volume informado.",
            ],
            "expectativa": [
                "Expectativa: cabelo de comercial. Realidade: o pente pedindo reforço.",
                "Expectativa: reconstrução imediata. Realidade: composição e rotina ainda contam.",
                "Expectativa: uma aplicação resolve tudo. Realidade: o fio não leu a propaganda.",
            ],
        },
        "organizacao": {
            "observacao": [
                "Organizador vazio é lindo; o teste começa quando a gaveta resolve mostrar sua personalidade.",
                "Toda casa tem uma gaveta que funciona como arquivo morto sem catálogo.",
                "Comprar organizador sem medir é só mudar a bagunça de endereço.",
            ],
            "seco": [
                "Organiza. Desde que caiba.",
                "Bonito na foto. A gaveta exige medidas.",
                "Mais divisórias. Menos caça ao objeto perdido.",
            ],
            "expectativa": [
                "Expectativa: gaveta de revista. Realidade: o carregador ainda desaparece.",
                "Expectativa: tudo no lugar. Realidade: o organizador não cabe no móvel.",
                "Expectativa: praticidade. Realidade: medir depois da compra.",
            ],
        },
        "camera": {
            "observacao": [
                "Seu celular guarda dez mil fotos e você mostra sempre as mesmas sete. A câmera instantânea pelo menos obriga a escolher.",
                "A foto sai na hora. O arrependimento da pose também, só que em alta definição emocional.",
                "É o único tipo de câmera em que errar a foto custa dinheiro e ainda vira lembrança.",
            ],
            "seco": [
                "Tirou. Imprimiu. Piscou estranho. Agora é decoração.",
                "Sem filtro, sem apagar, sem fingir que foi sem querer. Coragem analógica.",
                "O filme acaba. A vontade de tirar só mais uma, curiosamente, não.",
            ],
            "expectativa": [
                "Expectativa: foto espontânea perfeita. Realidade: alguém piscou e agora a lembrança é oficial.",
                "Expectativa: nostalgia. Realidade: descobrir que cada clique tem orçamento.",
                "Expectativa: uma foto. Realidade: vinte minutos decidindo quem merece o último filme.",
            ],
        },

    }
    return banks.get(family, {
        "observacao": [
            "Todo produto promete facilitar a rotina; o interessante é descobrir se ele realmente trabalha.",
            "A embalagem faz a apresentação. O uso diário faz a entrevista de emprego.",
            "Comprar é rápido; conviver com a escolha é a parte longa da história.",
        ],
        "seco": ["Parece útil. Agora precisa provar.", "Bonito. A função continua obrigatória.", "Promessa feita. Rotina aguardando."],
        "expectativa": [
            "Expectativa: resolver a rotina. Realidade: características e compatibilidade ainda decidem.",
            "Expectativa: compra certeira. Realidade: medida errada não negocia.",
            "Expectativa: praticidade. Realidade: a versão escolhida precisa combinar com o uso.",
        ],
    })


def _viral_comedy_story(profile: dict, sp: dict, proof: str, variation_index: int, angle: str) -> tuple[str, str]:
    """Comédia de alta variação: situação -> escalada -> produto entra tarde -> punchline -> utilidade.

    Usa apenas fatos já confirmados no perfil/anúncio. A graça vem da situação e da
    construção, não de inventar características do produto.
    """
    name = str(profile.get("spoken_name") or "esse produto")
    problem = str(sp.get("problem") or "uma pequena confusão da rotina")
    uses = [str(x) for x in sp.get("use_cases") or []]
    while len(uses) < 2:
        uses.append("deixar a rotina mais prática")
    decision = str(sp.get("decision") or "características, medidas e compatibilidade")
    family = str(sp.get("family") or "")
    seed = _stable_seed(name, family, variation_index, angle)
    mode = seed % 6
    hooks = [
        f"Eu achei que {problem} era azar. Era rotina mesmo.",
        f"Tem um momento em que {problem} deixa de ser detalhe e vira personagem principal.",
        f"Relatório oficial da casa: {problem}. Suspeitos: todos. Solução: talvez {name}.",
        f"Confissão do dia: eu normalizei {problem} por tempo demais.",
        f"Se {problem} fosse funcionário, já teria recebido três advertências.",
        f"A rotina estava tranquila até {problem} decidir abrir uma filial.",
    ]
    setups = [
        f"Primeiro você ignora. Depois improvisa. Depois percebe que o improviso ganhou cargo fixo.",
        f"A fase um é negar. A fase dois é reclamar. A fase três é pesquisar uma solução às duas da manhã.",
        f"Eu tentei o método clássico: fingir que não estava acontecendo. Resultado técnico: continuou acontecendo.",
        f"É aquele tipo de problema que começa pequeno e, de repente, já está participando das decisões da família.",
        f"A teoria era simples: deixa assim. A prática respondeu: absolutamente não.",
        f"Tudo sob controle, disseram. Ninguém perguntou para a rotina.",
    ]
    punch = [
        f"Aí entra {name}. Não como herói de cinema; como colega que finalmente faz a parte dele.",
        f"Foi quando {name} apareceu com uma proposta ousada: funcionar sem discurso motivacional.",
        f"Então {name} chega. Sem capa, sem trilha épica e, felizmente, sem reunião de alinhamento.",
        f"É aqui que {name} tenta justificar o espaço que ocupa na sua casa.",
        f"Nesse ponto, {name} deixa de ser 'achadinho' e entra em período de experiência.",
        f"Eis {name}: candidato oficial à vaga de parar de complicar o que já era simples.",
    ]
    utility = [
        f"Na prática, a ideia é ajudar a {uses[0]} e {uses[1]}.",
        f"O que interessa de verdade é se ele ajuda a {uses[0]} sem criar outro problema no lugar.",
        f"A utilidade aqui é direta: {uses[0]} e {uses[1]}.",
    ]
    proof_line = proof if proof and proof != "informações confirmadas no anúncio" else "Os dados confirmados do anúncio são o que valem para a decisão."
    endings = [
        f"A piada termina aqui; antes de comprar, confira {decision}. {proof_line}",
        f"Se fizer sentido para sua rotina, ótimo. Se não fizer, pelo menos não foi o algoritmo que decidiu por você. Confira {decision}. {proof_line}",
        f"Resumo técnico: menos improviso, mais critério. Confira {decision}. {proof_line}",
    ]
    hook = hooks[mode]
    narration = " ".join([setups[mode], punch[mode], utility[seed % len(utility)], endings[(seed // 7) % len(endings)]])
    return hook, narration


def _viral_laugh_story(profile: dict, sp: dict, proof: str, variation_index: int, angle: str) -> tuple[str, str]:
    """Comédia mais autoral: o gancho termina com uma virada que prepara uma risada não verbal no TTS.

    A risada NÃO é escrita como "haha" e não imita pessoa/canal real; o perfil de voz
    dedicado instrui o Gemini a produzi-la logo após a primeira frase.
    """
    name = str(profile.get("spoken_name") or "esse produto")
    problem = str(sp.get("problem") or "uma pequena confusão da rotina")
    uses = [str(x) for x in sp.get("use_cases") or []]
    while len(uses) < 2:
        uses.append("deixar a rotina mais prática")
    decision = str(sp.get("decision") or "características, medidas e compatibilidade")
    seed = _stable_seed(name, problem, variation_index, angle, "humor_risada")
    hooks = [
        f"Eu achei que {problem} era fase. A fase já paga aluguel.",
        f"{problem.capitalize()} começou pequeno e agora quer participação nos lucros.",
        f"A casa estava em paz até {problem} pedir promoção.",
        f"Meu plano era ignorar {problem}. O problema não recebeu o memorando.",
        f"Se {problem} fosse aplicativo, eu já tinha desinstalado duas vezes.",
        f"Eu tinha uma solução improvisada. Ela pediu demissão hoje.",
    ]
    bodies = [
        f"A sequência foi científica: improvisa, reclama, improvisa melhor e finalmente procura uma solução. É aí que {name} entra — sem capa, sem palestra motivacional — para ajudar a {uses[0]} e {uses[1]}.",
        f"O mais engraçado é perceber quanto tempo a gente aceita uma gambiarra só porque ela ainda não caiu no chão. {name} tenta ocupar justamente esse espaço: menos improviso e mais {uses[0]}.",
        f"Eu não prometo transformação de vida porque isso é um produto, não um retiro espiritual. Mas a proposta de {name} é bem objetiva: {uses[0]} e {uses[1]}.",
        f"Nesse ponto, {name} entra em período de experiência. Se facilitar {uses[0]} sem criar outro problema, já fez mais que muito improviso promovido a solução definitiva.",
        f"A graça acaba quando chega a compra. Aí vale ser chato mesmo: confira {decision}. Se bater com sua rotina, {name} pode fazer sentido.",
        f"O roteiro é engraçado; a compra não precisa ser no escuro. Veja {decision}, confira os dados do anúncio e decida se {name} resolve o seu caso de verdade.",
    ]
    proof_line = proof if proof and proof != "informações confirmadas no anúncio" else "Use os dados confirmados do anúncio para decidir."
    hook = hooks[seed % len(hooks)]
    body = bodies[(seed // 7) % len(bodies)]
    ending = f" {proof_line}" if proof_line not in body else ""
    return hook, body + ending


def _rich_style_layer(substyle: str, sp: dict, profile: dict, proof: str, angle: str) -> list[str]:
    """Produz o núcleo rico de cada formato, preservando a identidade por 40 s."""
    family = str(sp.get("family") or "")
    decision = str(sp.get("decision") or "características, medidas e compatibilidade")
    uses = [str(x) for x in sp.get("use_cases") or []]
    while len(uses) < 3:
        uses.append("escolher a versão adequada")
    audience = str(sp.get("audience") or "quem busca praticidade")
    problem = str(sp.get("problem") or "uma necessidade mal resolvida na rotina")
    thesis = str(sp.get("thesis") or "o uso real importa mais que o título comercial")
    bank = _category_humor_bank(family)
    idx = {"beneficio": 0, "criterio_compra": 1, "prova_oferta": 2}.get(angle, 0)
    if substyle == "humor_observacao":
        lines = [bank["observacao"][idx], bank["observacao"][(idx + 1) % 3]]
        if family == "enxoval":
            measure = str(profile.get("measure_spoken") or "").strip()
            factual = "O anúncio descreve toalhas de banho grandes e de luxo"
            if measure:
                factual += f", com {measure}"
            lines.append(factual + ".")
        lines.append(f"No fim, {thesis}.")
        return lines
    if substyle == "humor_seco":
        return [bank["seco"][idx], bank["seco"][(idx + 1) % 3], f"Critério menos engraçado, porém útil: {decision}."]
    if substyle == "expectativa_realidade":
        return [bank["expectativa"][idx], bank["expectativa"][(idx + 1) % 3], f"A realidade útil é conferir {decision}."]
    if substyle in {"vale_a_pena", "custo_beneficio"}:
        quantity = profile.get("quantity")
        price = profile.get("_price_value")
        unit_line = ""
        if isinstance(quantity, int) and quantity > 1 and isinstance(price, (int, float)) and price > 0:
            unit_line = f"Dividindo o valor informado pelas {quantity} unidades, o custo aproximado fica em {_money(float(price) / quantity)} por unidade."
        return [
            "Custo-benefício não é sinônimo de menor preço; é o que você recebe pelo valor total.",
            unit_line or "Compare o valor total com quantidade, frequência de uso e durabilidade esperada.",
            f"Para saber se compensa, confira {decision} e pense no uso real: {uses[0]} e {uses[1]}.",
        ]
    if substyle in {"comparacao_rapida", "comparativo"}:
        return [
            f"Em vez de comparar só preço ou aparência, coloque lado a lado {decision}.",
            f"Uma opção pode favorecer {uses[0]}, enquanto outra pode ser melhor para {uses[1]}.",
            f"A melhor não é a mais chamativa; é a que atende {audience} sem criar o problema de {problem}.",
        ]
    if substyle in {"storytelling", "mini_historia"}:
        return [
            f"A cena começa, e a história muda quando {problem} aparece no pior momento da rotina.",
            f"A pessoa tenta improvisar, percebe que o improviso só adia o problema e começa a comparar {decision}.",
            f"É aí que o produto entra na história: não como milagre, mas como ferramenta para {uses[0]} e {uses[1]}.",
        ]
    if substyle == "tres_motivos":
        return [
            f"Primeiro motivo: pode ajudar a {uses[0]}.",
            f"Segundo: a escolha pode ser ajustada por {decision}.",
            f"Terceiro: faz mais sentido para {audience} quando também contribui para {uses[1]}.",
        ]
    if substyle == "erro_comum":
        return [
            "O erro comum é decidir apenas pela foto, pelo preço ou pelo adjetivo do título.",
            f"O que realmente muda a experiência é {decision}.",
            f"Sem essa conferência, a compra pode trocar {problem} por outro problema diferente.",
        ]
    if substyle in {"demonstracao", "rotina_pratica"}:
        ref = _natural_product_reference(profile, capitalized=False)
        return [
            f"Na prática, imagine {ref} sendo usado para {uses[0]}.",
            f"Depois observe se ele também facilita {uses[1]} sem atrapalhar {uses[2]}.",
            f"Essa demonstração só faz sentido quando {decision} correspondem à versão escolhida.",
        ]
    if substyle == "prova_social":
        social = proof if proof and proof != "informações confirmadas no anúncio" else "a procura registrada no catálogo"
        return [
            f"A prova comercial é {social}.",
            "Esses números mostram procura e experiência acumulada, mas não transformam qualquer versão na escolha certa.",
            f"Use a prova social junto com {decision}, nunca no lugar deles.",
        ]
    if substyle in {"pergunta", "pergunta_resposta"}:
        product_ref = _natural_product_reference(profile, capitalized=False)
        return [
            f"Para quem {product_ref} faz sentido? Principalmente para {audience}.",
            f"Ele tenta resolver {problem}.",
            f"Antes da compra, confira {decision}.",
        ]
    if substyle in {"descoberta", "surpresa_visual"}:
        return [
            f"O detalhe menos óbvio é que {thesis}.",
            f"Por isso, a utilidade aparece menos no título e mais em {decision}.",
            f"Quando esses pontos combinam, o produto pode ajudar a {uses[0]} e {uses[1]}.",
        ]
    if substyle == "informativo":
        return [
            f"Este produto foi analisado para {audience} e para a necessidade de {problem}.",
            f"Os critérios centrais são {decision}.",
            f"A aplicação prática é {uses[0]}, {uses[1]} e {uses[2]}.",
        ]
    return []

def _style_specific_additions(style: str, sp: dict, profile: dict, proof: str) -> list[str]:
    family = str(sp.get("family") or "")
    if style == "humor":
        lines = {
            "papelaria": [
                "Porque confiar tudo à memória é ótimo, até a memória resolver tirar folga.",
                "Ela não organiza a vida sozinha, mas pelo menos dá um endereço para cada ideia perdida.",
            ],
            "barbear": [
                "A pele sensível não precisa transformar cada barba em uma discussão séria com o espelho.",
                "O objetivo é cortar os pelos, não a paciência junto.",
            ],
            "enxoval": [
                "A toalha que já pediu aposentadoria ganhou substitutas.",
                "O anúncio chama o kit de toalhas de banho grandes e de luxo; essa é uma descrição comercial.",
                (f"A medida informada é {profile['measure_spoken']}." if profile.get("measure_spoken") else "Tamanho e composição precisam combinar com o uso diário."),
                "Toalha bonita ajuda; enxugar de verdade continua sendo a parte principal do emprego.",
            ],
            "cozinha": [
                "Comida grudada não é crosta gourmet; normalmente é só uma panela pedindo substituição.",
                "A panela não cozinha sozinha, mas pelo menos não precisa atrapalhar o almoço.",
            ],
            "capilar": [
                "Seu cabelo não abriu um chamado técnico, mas às vezes parece que está quase lá.",
                "Promessa bonita não desembaraça fio; composição e indicação é que precisam fazer sentido.",
            ],
        }
        return lines.get(family, [
            "A ideia é facilitar a rotina, não criar mais uma coisa para ficar encostada na gaveta.",
            "Produto útil é o que resolve o problema antes de virar decoração involuntária.",
        ])
    if style == "custo_beneficio":
        attrs = [str(x).lower() for x in profile.get("attributes") or []][:3]
        facts = ", ".join(attrs) if attrs else "quantidade, características e durabilidade informadas"
        return [
            f"Para avaliar custo-benefício, compare o pacote completo: {facts}.",
            "O menor preço nem sempre é a melhor compra; o que importa é quanto uso real cada unidade entrega.",
            (f"A procura do catálogo aparece em {proof}, mas a decisão ainda deve considerar compatibilidade e necessidade." if proof and proof != "informações confirmadas no anúncio" else "Antes de decidir, compare o valor total com a quantidade e a utilidade que você realmente terá."),
        ]
    if style == "comparativo":
        return [
            "Compare primeiro os critérios que mudam o uso, e só depois aparência ou preço.",
            "Duas opções parecidas podem ter diferenças importantes em material, medida, quantidade ou compatibilidade.",
        ]
    if style == "informativo":
        return [
            "A decisão deve se apoiar nos dados confirmados do produto, não em adjetivos promocionais.",
            "Confira medidas, material, quantidade, compatibilidade e variações sempre que esses dados estiverem disponíveis.",
        ]
    return []


def _ensure_openai_length(narration: str, profile: dict, analysis: dict, proof: str, min_words: int = 74) -> str:
    text = narration.strip()
    if len(text.split()) >= min_words:
        return text
    additions=[]
    criteria=[str(x).strip() for x in analysis.get("purchase_criteria") or [] if str(x).strip()]
    features=[str(x).strip() for x in analysis.get("confirmed_features") or [] if str(x).strip()]
    if criteria:
        additions.append("Antes de escolher, compare " + ", ".join(criteria[:4]) + ".")
    if features:
        additions.append("Entre os pontos confirmados estão " + ", ".join(features[:4]) + ".")
    if profile.get("measure_spoken"):
        additions.append(f"A medida informada é {profile['measure_spoken']}.")
    if proof and proof != "informações confirmadas no anúncio":
        additions.append(f"Como contexto comercial, o catálogo reúne {proof}.")
    additions.extend([
        "A melhor escolha é a que combina essas características com a sua rotina e com a versão correta do produto.",
        "Também vale conferir quantidade, medidas, material e compatibilidade sempre que esses dados estiverem disponíveis.",
        "Assim, a decisão não fica presa apenas à aparência ou ao título comercial da oferta.",
        "O objetivo é entender se a versão anunciada atende ao uso esperado antes de finalizar a compra.",
    ])
    for sentence in additions:
        if len(text.split()) >= min_words:
            break
        if sentence.lower() not in text.lower():
            text += " " + sentence
    return text.strip()

def _creative_structure(request: ScriptRequest, profile: dict) -> str:
    """Escolhe uma estrutura realmente diferente e determinística para cada produto/variação."""
    if request.format != "automatico":
        aliases = {
            "tres_motivos": "lista_inteligente", "demonstracao": "rotina",
            "pergunta": "pergunta_resposta", "rotina_pratica": "rotina",
            "prova_social": "opiniao", "vale_a_pena": "comparacao",
            "comparacao_rapida": "comparacao", "surpresa_visual": "curiosidade",
            "humor_observacao": "mini_historia", "humor_seco": "mito_realidade",
            "expectativa_realidade": "mito_realidade",
        }
        base = aliases.get(request.format, request.format if request.format in CREATIVE_STRUCTURES else "descoberta")
        requested_style = _requested_script_style(request)
        # O estilo solicitado é um contrato. Variar o candidato não pode descaracterizá-lo.
        style_structures = {
            "humor": ("mini_historia", "mito_realidade", "rotina", "opiniao", "pergunta_resposta"),
            "custo_beneficio": ("comparacao", "lista_inteligente", "erro_comum", "opiniao", "pergunta_resposta"),
            "comparativo": ("comparacao", "erro_comum", "lista_inteligente", "pergunta_resposta", "opiniao"),
            "informativo": ("descoberta", "lista_inteligente", "pergunta_resposta", "comparacao", "rotina"),
            "storytelling": ("mini_historia", "rotina", "descoberta", "problema_solucao", "beneficio_oculto"),
        }
        options = style_structures.get(requested_style)
        if options:
            return options[request.variation_index % len(options)]
        index = CREATIVE_STRUCTURES.index(base) if base in CREATIVE_STRUCTURES else 0
        return CREATIVE_STRUCTURES[(index + request.variation_index * 3) % len(CREATIVE_STRUCTURES)]
    seed = _stable_seed(profile.get("spoken_name"), request.product.title, request.product.category, request.variation_index)
    return CREATIVE_STRUCTURES[(seed + request.variation_index * 7) % len(CREATIVE_STRUCTURES)]


def _specific_hook(profile: dict, sp: dict, structure: str, angle: str, humorous: bool, substyle: str = "automatico") -> str:
    """Cria ganchos curtos, concretos e próprios da categoria.

    O texto visual usa no máximo 14 palavras. Expressões vagas de fama,
    curiosidade artificial ou avaliação que o roteiro não entrega são proibidas.
    """
    hooks = list(sp.get("hooks") or [])
    angle_order = [item["name"] for item in VARIATION_ANGLES]
    angle_index = angle_order.index(angle) if angle in angle_order else 0
    if hooks:
        hook = hooks[angle_index % len(hooks)]
    else:
        hook = "Antes de comprar, confira o detalhe que realmente muda o uso."
    if humorous:
        family = str(sp.get("family") or "")
        idx = {"beneficio": 0, "criterio_compra": 1, "prova_oferta": 2}.get(angle, 0)
        concise = {
            "enxoval": {
                "observacao": ["A toalha antiga já pediu aposentadoria?", "Bonita ela é. Mas enxuga?", "Muita venda. E a toalha, trabalha?"],
                "seco": ["É toalha. Enxugar ainda é obrigatório.", "Estampa bonita. Função pendente.", "Três unidades. Uma desculpa a menos."],
                "expectativa": ["Expectativa: conforto. Realidade: ponta seca em falta.", "Expectativa: luxo. Realidade: confira a composição.", "Expectativa: kit completo. Realidade: medidas decidem."],
            },
            "barbear": {
                "observacao": ["Sua barba vira discussão com o espelho?", "A lâmina corta pelos ou a paciência?", "Muita venda. Mas cabe no seu aparelho?"],
                "seco": ["Três lâminas. Paciência não inclusa.", "Compatível com Mach3. Com improviso, não.", "Aloe ajuda. Milagre não vem no refil."],
                "expectativa": ["Expectativa: barba rápida. Realidade: rosto reclamando.", "Expectativa: pele lisa. Realidade: irritação extra.", "Expectativa: economia. Realidade: refil incompatível."],
            },
            "papelaria": {
                "observacao": ["Sua memória também tira folga sem avisar?", "Você anota tudo. Só não acha depois?", "Boa avaliação. E suas ideias, onde estão?"],
                "seco": ["A memória é ótima. Quando comparece.", "Capa bonita. Ideia perdida continua feia.", "Folha certa. Desculpa errada."],
                "expectativa": ["Expectativa: lembrar tudo. Realidade: esquecer onde anotou.", "Expectativa: rotina organizada. Realidade: papel solto.", "Expectativa: ideia brilhante. Realidade: sumiu."],
            },
            "cozinha": {
                "observacao": ["Sua panela gruda até a esperança?", "O almoço virou escultura outra vez?", "Oferta boa. A panela colabora?"],
                "seco": ["Antiaderente é função. Crosta não é bônus.", "Bonita. Agora falta ajudar no almoço.", "Tampa inclusa. Trabalho extra, talvez não."],
                "expectativa": ["Expectativa: almoço rápido. Realidade: fundo grudado.", "Expectativa: pouco óleo. Realidade: revestimento cansado.", "Expectativa: lavar rápido. Realidade: arqueologia."],
            },
            "capilar": {
                "observacao": ["Seu cabelo reclama sem abrir chamado?", "A máscara promete. O fio concorda?", "Muita avaliação. Seu cabelo aprova?"],
                "seco": ["Promessa bonita. O fio lê a composição.", "Reconstrução. Milagre não acompanha.", "Volume informado. Resultado depende da rotina."],
                "expectativa": ["Expectativa: cabelo de comercial. Realidade: pente pedindo ajuda.", "Expectativa: reconstrução imediata. Realidade: rotina conta.", "Expectativa: uma aplicação. Realidade: o fio discorda."],
            },
        }
        mode = "seco" if substyle == "humor_seco" else "expectativa" if substyle == "expectativa_realidade" else "observacao"
        family_hooks = concise.get(family, {
            "observacao": ["Esse produto trabalha ou só posa?", "Parece útil. A rotina concorda?", "Muita promessa. E a função?"],
            "seco": ["Bonito. Função ainda obrigatória.", "Promessa feita. Rotina aguardando.", "Parece útil. Precisa provar."],
            "expectativa": ["Expectativa: praticidade. Realidade: confira os dados.", "Expectativa: compra certa. Realidade: medidas.", "Expectativa: solução. Realidade: compatibilidade."],
        })
        hook = family_hooks[mode][idx]
    words = hook.split()
    if len(words) > 14:
        hook = " ".join(words[:14]).rstrip(",;:-") + "."
    return hook


def _attribute_sentence(profile: dict) -> str:
    attrs = [str(x).strip().lower() for x in profile.get("attributes") or [] if str(x).strip()]
    measure = str(profile.get("measure_spoken") or "").strip()
    pieces=[]
    if attrs:
        pieces.append("Entre as características confirmadas estão " + ", ".join(attrs[:3]) + ".")
    if measure:
        pieces.append(f"A medida informada é {measure}.")
    return " ".join(pieces)


def _candidate_narration(profile: dict, sp: dict, proof: str, structure: str, angle: str, humorous: bool, requested_style: str = "automatico", requested_substyle: str = "automatico") -> str:
    """Escreve uma narrativa com tese, contexto, fatos e decisão de compra.

    A estrutura muda a lógica da conversa. Nenhuma versão usa prova social vaga,
    adjetivos promocionais como fato ou frases de preenchimento.
    """
    ref = _natural_product_reference(profile)
    name = str(profile.get("spoken_name") or "produto")
    audience = str(sp["audience"])
    problem = str(sp["problem"])
    uses = [str(x) for x in sp["use_cases"]]
    while len(uses) < 3:
        uses.append("escolher a versão adequada")
    decision = str(sp["decision"])
    care = str(sp["care"])
    thesis = str(sp.get("thesis") or "a escolha deve combinar características e uso real")
    attrs = _attribute_sentence(profile)
    social = proof if proof != "informações confirmadas no anúncio" else ""

    if requested_substyle == "humor_viral":
        _hook, dedicated = _viral_comedy_story(profile, sp, proof, int(profile.get("_variation_index") or 0), angle)
        return dedicated
    if humorous and requested_substyle in {"humor_observacao", "humor_seco", "expectativa_realidade"}:
        _hook, dedicated = _humor_story(profile, sp, proof, requested_substyle, int(profile.get("_variation_index") or 0), angle)
        return dedicated

    blocks = {
        "problema_solucao": [
            f"O problema começa com {problem}.",
            f"A proposta de {name} é ajudar a {uses[0]} e {uses[1]}.",
            f"O ponto central é simples: {thesis}.", attrs,
            f"Antes de decidir, compare {decision}.", care.capitalize()+".",
        ],
        "mini_historia": [
            f"Na rotina, tudo parece normal até {problem} aparecer.",
            f"É nessa situação que {name} pode ser útil para {audience}.",
            f"Ele foi pensado para {uses[0]}, sem perder de vista {uses[1]}.", attrs,
            f"A escolha melhora quando você confere {decision}.", care.capitalize()+".",
        ],
        "erro_comum": [
            f"O erro mais comum é escolher {name} apenas por preço, cor ou aparência.",
            f"O que realmente muda o uso é {decision}.",
            f"Quando esses pontos combinam com a necessidade, ele pode ajudar a {uses[0]} e {uses[1]}.", attrs,
            care.capitalize()+".",
        ],
        "comparacao": [
            f"Opções parecidas podem entregar experiências bem diferentes.",
            f"Neste caso, a comparação deve começar por {decision}.",
            f"Para {audience}, a vantagem está em {uses[0]} e {uses[1]}.", attrs,
            f"Em resumo, {thesis}.", care.capitalize()+".",
        ],
        "curiosidade": [
            f"O detalhe que merece atenção não é o primeiro que aparece no título.",
            f"Ele está em {decision}.",
            f"Isso define se {name} realmente ajuda a {uses[0]} e {uses[1]}.", attrs,
            f"A ideia central é que {thesis}.", care.capitalize()+".",
        ],
        "lista_inteligente": [
            f"Primeiro, pense em {uses[0]}.", f"Segundo, confira {decision}.",
            f"Terceiro, veja se a proposta de {uses[1]} combina com a sua rotina.", attrs,
            care.capitalize()+".",
        ],
        "mito_realidade": [
            f"Mito: todo {name} funciona do mesmo jeito.",
            f"Realidade: {decision} mudam a experiência.",
            f"Esta opção pode ajudar a {uses[0]} e {uses[1]}, especialmente para {audience}.", attrs,
            care.capitalize()+".",
        ],
        "rotina": [
            f"No dia a dia, {problem} costuma aparecer quando você menos precisa de complicação.",
            f"{ref} tenta simplificar esse momento ao ajudar a {uses[0]} e {uses[1]}.", attrs,
            f"Para acertar na escolha, confira {decision}.", care.capitalize()+".",
        ],
        "descoberta": [
            f"A utilidade de {name} aparece quando você relaciona o produto à sua rotina.",
            f"Para {audience}, ele pode ajudar a {uses[0]} e {uses[1]}.",
            f"O que define a escolha é {decision}.", attrs, care.capitalize()+".",
        ],
        "opiniao": [
            f"Minha conclusão é objetiva: {name} só vale a pena quando atende ao uso real.",
            f"Aqui, isso significa {uses[0]}, {uses[1]} e atenção a {decision}.", attrs,
            f"A tese é simples: {thesis}.", care.capitalize()+".",
        ],
        "pergunta_resposta": [
            f"Para quem faz sentido? Para {audience}.",
            f"O que pode facilitar? {uses[0].capitalize()} e {uses[1]}.",
            f"O que conferir? {decision.capitalize()}.", attrs, care.capitalize()+".",
        ],
        "beneficio_oculto": [
            f"O benefício menos óbvio é {uses[2]}.",
            f"Ele se soma à proposta de {uses[0]} e {uses[1]}.",
            f"Mas o resultado da escolha ainda depende de {decision}.", attrs, care.capitalize()+".",
        ],
        "anti_hype": [
            f"Sem tratar propaganda como fato: {name} só merece atenção se resolver {problem}.",
            f"Para {audience}, o que pesa de verdade é {decision}.",
            f"A utilidade prática está em {uses[0]} e {uses[1]}.", attrs,
            f"O resto é simples: {care}.",
        ],
        "cenario_real": [
            f"Imagine a situação: {problem} justo quando você quer praticidade.",
            f"É aí que {name} entra na conversa, principalmente para {audience}.",
            f"A proposta é {uses[0]} e também {uses[1]}.", attrs,
            f"Antes de levar, confira {decision}.",
        ],
        "checklist_compra": [
            f"Se você está pensando em {name}, faça um checklist rápido.",
            f"Um: a sua necessidade é {uses[0]}. Dois: confira {decision}.",
            f"Três: veja se {uses[1]} realmente combina com sua rotina.", attrs, care.capitalize()+".",
        ],
        "objecao_resposta": [
            f"Talvez você esteja pensando: eu realmente preciso de {name}?",
            f"A resposta depende de uma coisa: se {problem} faz parte da sua rotina.",
            f"Se sim, a proposta de {uses[0]} pode fazer sentido; se não, talvez não seja prioridade.",
            f"De qualquer forma, compare {decision}.", attrs, care.capitalize()+".",
        ],
        "micro_review": [
            f"Minha leitura rápida de {name}: a proposta faz sentido para {audience}.",
            f"O ponto forte é {uses[0]}; o ponto que eu conferiria antes da compra é {decision}.",
            attrs, f"Também pode ajudar a {uses[1]}.", care.capitalize()+".",
        ],
        "decisao_rapida": [
            f"Vale olhar {name} quando sua prioridade é {uses[0]}.",
            f"Eu descartaria a compra se {decision} não baterem com o que você precisa.",
            f"Se esses critérios fecharem, {uses[1]} vira o benefício mais interessante.", attrs, care.capitalize()+".",
        ],
    }
    parts = list(blocks.get(structure, blocks["problema_solucao"]))
    if social and angle != "prova_oferta":
        parts.append(f"Como prova comercial, o catálogo reúne {social}.")
    if angle == "criterio_compra":
        parts.insert(2, f"Por isso, a decisão deve começar por {decision}, e não pela aparência.")
    elif angle == "prova_oferta" and social:
        parts.insert(0, f"O catálogo reúne {social}.")
        parts.insert(1, "Os números ajudam a contextualizar a procura, mas não substituem a análise das características.")
    style = "humor" if humorous else requested_style
    additions = _rich_style_layer(requested_substyle, sp, profile, proof, angle)
    if not additions:
        additions = _style_specific_additions(style, sp, profile, proof)
    if additions:
        # Estilos fortes precisam aparecer desde o início da narração. Antes, o
        # limitador de duração cortava justamente as linhas que davam identidade
        # ao humor e ao custo-benefício.
        insert_at = 0 if style in {"humor", "custo_beneficio"} else 2
        parts[insert_at:insert_at] = additions
    if humorous and not additions:
        parts.insert(2, "Sem milagre e sem discurso de vendedor: o importante é o produto cumprir a função.")
    clean = sanitize_script_language(_grammar_safety_pass(" ".join(x for x in parts if x), profile))
    return clean




def _humor_story(profile: dict, sp: dict, proof: str, substyle: str, variation_index: int, angle: str) -> tuple[str, str]:
    """Humor dedicado: cada subestilo tem arco próprio e piada ligada à categoria."""
    name = str(profile.get("spoken_name") or "produto")
    ref = _natural_product_reference(profile, capitalized=False)
    uses = [str(x) for x in sp.get("use_cases") or []]
    while len(uses) < 3:
        uses.append("facilitar a rotina")
    decision = str(sp.get("decision") or "medidas, versão e compatibilidade")
    care = str(sp.get("care") or "confira os detalhes do anúncio antes de comprar")
    attrs = _attribute_sentence(profile)
    social = proof if proof and proof != "informações confirmadas no anúncio" else ""
    family = str(sp.get("family") or "universal")
    bank = _category_humor_bank(family)
    seed = _stable_seed(name, substyle, variation_index, angle)
    # O índice do gancho segue a variação explicitamente para impedir que três
    # versões consecutivas caiam por acaso no mesmo gancho. O seed continua
    # controlando o mecanismo de humor e demais escolhas.
    idx = variation_index % 3
    mechanism = ("observacao", "personificacao", "exagero", "quebra", "autoironia", "contraste")[seed % 6]

    family_hooks = {
        "camera": (
            "A foto sai na hora. A vergonha da pose também.",
            "Seu celular tem dez mil fotos. Quantas você pega na mão?",
            "Nostalgia instantânea. E o filme tem orçamento.",
        ),
        "enxoval": (
            "A toalha antiga já pediu aposentadoria?",
            "Bonita ela é. Mas enxuga?",
            "Banheiro de catálogo. Toalha em modo sobrevivência.",
        ),
        "barbear": (
            "Barbear ou discutir com o espelho?",
            "A lâmina corta pelo. A paciência não deveria ir junto.",
            "Pele sensível também lê a ficha técnica.",
        ),
        "papelaria": (
            "Sua memória pediu folga de novo?",
            "A ideia era inesquecível. Era.",
            "Papel solto: o esporte oficial de perder anotação.",
        ),
        "cozinha": (
            "A panela cozinha ou coleciona comida grudada?",
            "Antiaderente é função. Crosta não é brinde.",
            "Almoço pronto. Escavação arqueológica depois.",
        ),
        "capilar": (
            "Seu cabelo acordou com opiniões próprias?",
            "O frizz entrou na reunião sem ser convidado.",
            "Promessa bonita. O fio continua fazendo auditoria.",
        ),
        "organizacao": (
            "Organizou ou só mudou a bagunça de endereço?",
            "A gaveta tem personalidade. E pouca colaboração.",
            "Medir antes de comprar: conceito revolucionário.",
        ),
    }
    generic_hooks = (
        "Esse produto trabalha ou só posa para a foto?",
        "Praticidade é ótima quando resolve aparecer.",
        "Parece solução. Agora vem a entrevista de emprego.",
    )
    hook = family_hooks.get(family, generic_hooks)[idx]

    punch = {
        "observacao": "Se resolver sem inventar trabalho extra, já merece respeito.",
        "personificacao": "A ideia é aposentar o problema, não contratar outro para o lugar.",
        "exagero": "Não precisa mudar sua vida. Melhorar cinco minutos dela já conta.",
        "quebra": "Se precisar de três tutoriais e um primo, a praticidade perdeu a discussão.",
        "autoironia": "Praticidade de verdade é quando até eu uso sem reunião de emergência.",
        "contraste": "Bonito é bônus. Não dar trabalho é relacionamento sério.",
    }[mechanism]

    if substyle == "humor_seco":
        category_joke = bank.get("seco", [""])[idx]
        narration = " ".join(filter(None, [
            category_joke,
            f"{ref.capitalize()} entra com uma proposta simples: {uses[0]} e {uses[1]}.",
            attrs,
            f"A parte adulta da compra é conferir {decision}.",
            social and f"O anúncio reúne {social}. Número ajuda; versão certa ajuda mais." or "Sem número mágico: versão certa continua importando.",
            punch,
            care.capitalize()+".",
        ]))
        return hook, sanitize_script_language(_grammar_safety_pass(narration, profile))

    if substyle == "expectativa_realidade":
        category_joke = bank.get("expectativa", [""])[idx]
        narration = " ".join(filter(None, [
            category_joke,
            f"Expectativa: resolver em um clique. Realidade: ainda precisa escolher a versão certa.",
            f"Na realidade útil, {name} pode ajudar a {uses[0]} e {uses[1]}.",
            attrs,
            f"Só tem um detalhe nada cinematográfico: conferir {decision}.",
            social and f"Tem {social}; isso mostra procura, não escolhe a versão por você." or "Procura não substitui conferência.",
            "Moral: expectativa é grátis; devolução dá trabalho.",
            care.capitalize()+".",
        ]))
        return hook, sanitize_script_language(_grammar_safety_pass(narration, profile))

    category_joke = bank.get("observacao", [""])[idx]
    narration = " ".join(filter(None, [
        category_joke,
        "A graça é que a gente sempre tenta improvisar primeiro e só depois procura a solução óbvia.",
        social and f"O anúncio registra {social}; bom contexto, não passe livre para impulso." or "Sem estatística milagrosa: olha a versão certa.",
        f"A proposta de {name} é ajudar a {uses[0]} e {uses[1]}.",
        attrs,
        f"Antes de declarar isso a salvação da humanidade, confira {decision}.",
        punch,
        care.capitalize()+".",
    ]))
    return hook, sanitize_script_language(_grammar_safety_pass(narration, profile))

def _text_similarity(a: str, b: str) -> float:
    """Jaccard de trigramas de palavras para bloquear roteiros gêmeos."""
    def grams(text: str) -> set[tuple[str, str, str]]:
        words = re.findall(r"[a-zà-ÿ0-9]+", (text or "").casefold())
        return set(zip(words, words[1:], words[2:])) if len(words) >= 3 else set()
    ga, gb = grams(a), grams(b)
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / max(1, len(ga | gb))

def _style_contract_issues(style: str, hook: str, narration: str, sp: dict | None = None) -> list[str]:
    """Valida se o texto realmente cumpre o estilo solicitado.

    O estilo não pode existir apenas no rótulo ou no gancho. A narração inteira
    precisa apresentar sinais concretos do contrato editorial escolhido.
    """
    joined = f"{hook} {narration}".casefold()
    issues: list[str] = []
    if style == "humor":
        family = str((sp or {}).get("family") or "")
        signals = {
            "enxoval": ("enxugar", "lixa", "aposentadoria", "banheiro", "seca", "estampa", "molhada", "toalha"),
            "barbear": ("espelho", "paciência", "discussão", "puxa", "irritação", "decoração"),
            "papelaria": ("memória", "folga", "greve", "plantão", "ideia perdida", "endereço"),
            "cozinha": ("grudado", "gourmet", "almoço", "enfeite", "tampa", "salvar"),
            "capilar": ("chamado", "socorro", "promessa", "fio", "cabelo", "desembaraça"),
            "camera": ("foto", "pose", "filme", "piscar", "nostalgia", "decoração", "orçamento"),
        }.get(family, ("não faz milagre", "decoração", "rotina", "problema"))
        count = sum(1 for token in signals if token in joined)
        comedic_sentences = sum(
            1 for sentence in re.split(r"(?<=[.!?])\s+", joined)
            if any(token in sentence for token in signals)
        )
        universal = ("funcionário do mês", "whatsapp", "boleto", "paciência", "plano a", "tutorial", "reunião de emergência", "relacionamento sério", "devolução dá trabalho", "salvação da humanidade")
        universal_count = sum(1 for token in universal if token in joined)
        if (count + universal_count) < 2 or comedic_sentences < 2:
            issues.append("humor insuficiente no corpo do roteiro")
    elif style == "custo_beneficio":
        groups = (
            ("preço", "valor", "custo"),
            ("quantidade", "unidade", "kit", "rendimento"),
            ("durabilidade", "uso", "frequência", "frequencia"),
            ("compensa", "vantagem", "economia", "vale"),
        )
        if sum(1 for group in groups if any(token in joined for token in group)) < 3:
            issues.append("custo-benefício sem análise concreta de valor, quantidade e uso")
    elif style == "comparativo":
        if not any(token in joined for token in ("compar", "diferen", "enquanto", "versus", "já esta opção", "por outro lado")):
            issues.append("comparativo sem contraste explícito")
    elif style == "informativo":
        concrete = tuple(re.findall(r"[a-zà-ÿ]+", str((sp or {}).get("decision") or "").casefold()))
        if concrete and sum(1 for token in set(concrete) if len(token) > 5 and token in joined) < 2:
            issues.append("informativo sem critérios concretos suficientes")
    return issues


def _script_quality_score(hook: str, narration: str, profile: dict, structure: str, sp: dict | None = None, requested_style: str = "automatico") -> int:
    """Gate rígido: roteiro pobre não pode vencer apenas por ser a estrutura-base."""
    joined = f"{hook} {narration}".lower()
    words = narration.split()
    score = 100
    if len(hook.split()) > 14: score -= 25
    if len(words) < 78: score -= 25
    if len(words) > 112: score -= 12
    if script_language_issues(joined): score -= 40
    product_name = str(profile.get("spoken_name") or "produto").lower()
    if joined.count(product_name) > 3: score -= 10
    forbidden = (
        "chamou atenção de muita gente", "a fama faz sentido", "parece simples",
        "detalhes do anúncio", "faz sentido para você", "produto útil",
        "vamos descobrir", "grandes e de luxo",
    )
    score -= sum(18 for phrase in forbidden if phrase in joined)
    if sp:
        thesis_words = [w for w in re.findall(r"[a-zà-ÿ]+", str(sp.get("thesis") or "").lower()) if len(w) > 5]
        if thesis_words and not any(w in joined for w in thesis_words[:6]): score -= 12
        concrete_terms = [w for w in re.findall(r"[a-zà-ÿ]+", str(sp.get("decision") or "").lower()) if len(w) > 5]
        if concrete_terms and sum(1 for w in set(concrete_terms) if w in joined) < 2: score -= 10
    sentences = [x.strip() for x in re.split(r"(?<=[.!?])\s+", narration) if x.strip()]
    normalized = [re.sub(r"[^a-zà-ÿ0-9 ]", "", x.lower()) for x in sentences]
    if len(normalized) != len(set(normalized)): score -= 18
    if structure == "lista_inteligente" and not all(x in joined for x in ("primeiro", "segundo", "terceiro")): score -= 15
    score -= 28 * len(_style_contract_issues(requested_style, hook, narration, sp))
    return max(0, min(100, score))


def _build_40_second_narration(profile: dict, proof: str, category_benefit: str, title: str, angle_name: str, category_key: str = "casa", structure: str = "descoberta", humorous: bool = False) -> str:
    sp = _category_script_profile(title, category_key, profile)
    return _candidate_narration(profile, sp, proof, structure, angle_name, humorous)


def _extract_response_text(payload: dict) -> str:
    if isinstance(payload.get("output_text"), str):
        return payload["output_text"]
    for item in payload.get("output") or []:
        for content in item.get("content") or []:
            if isinstance(content.get("text"), str):
                return content["text"]
    return ""


def _audit_openai_candidate(candidate: dict, profile: dict, analysis: dict, sp: dict | None = None) -> tuple[int, list[str], str, str]:
    """Audita um candidato OpenAI sem exigir que o próprio modelo se autoaprove."""
    hook = sanitize_script_language(_grammar_safety_pass(str(candidate.get("hook") or ""), profile))
    narration = sanitize_script_language(_grammar_safety_pass(str(candidate.get("narration") or ""), profile))
    narration = _ensure_openai_length(narration, profile, analysis, str(analysis.get("commercial_proof") or ""), 74)
    issues = script_language_issues(hook, narration)
    reasons: list[str] = list(issues)
    hook_words = len(hook.split())
    narration_words = len(narration.split())
    if not hook:
        reasons.append("gancho vazio")
    if hook_words > 14:
        reasons.append(f"gancho com {hook_words} palavras; máximo 14")
    if narration_words < 68:
        reasons.append(f"narração curta após expansão: {narration_words} palavras")
    if narration_words > 125:
        reasons.append(f"narração longa: {narration_words} palavras")
    joined = f"{hook} {narration}".lower()
    requested_style = str(analysis.get("requested_style") or "automatico")
    if requested_style == "humor":
        humor_signals = ("memória", "plantão", "férias", "espelho", "paciência", "aposentadoria", "milagre", "lixa", "gourmet", "chamado", "pose", "filme", "boleto", "tutorial", "decoração", "vergonha", "orçamento")
        if sum(1 for token in humor_signals if token in joined) < 2:
            reasons.append("humor insuficiente para o estilo solicitado")
    elif requested_style == "custo_beneficio":
        required_groups = (("quantidade", "unidade", "kit", "refil"), ("durabilidade", "uso", "rende", "valor"), ("preço", "custo", "economia", "compensa"))
        if sum(1 for group in required_groups if any(token in joined for token in group)) < 2:
            reasons.append("análise de custo-benefício insuficiente")
    elif requested_style == "comparativo" and not any(token in joined for token in ("compar", "diferen", "enquanto", "versus")):
        reasons.append("comparação insuficiente para o estilo solicitado")
    for claim in analysis.get("prohibited_claims") or []:
        claim_clean = " ".join(str(claim).lower().split())
        if claim_clean and len(claim_clean) > 5 and claim_clean in joined:
            reasons.append(f"afirmação proibida: {claim_clean[:80]}")
    model_score = int(candidate.get("score") or 0)
    local_score = _script_quality_score(hook, narration, profile, str(candidate.get("strategy") or "openai_editorial"), sp, requested_style)
    score = max(0, min(100, round((model_score * 0.35) + (local_score * 0.65) - len(reasons) * 8)))
    return score, reasons, hook, narration


def _repair_openai_candidate(candidate: dict, profile: dict, analysis: dict, sp: dict, proof: str) -> tuple[str, str, int]:
    """Transforma o melhor rascunho OpenAI em uma versão publicável.

    Não troca o motor pelo roteirista gratuito: preserva a tese, o gancho e o
    conteúdo produzidos pela OpenAI, mas aplica o contrato editorial e completa
    apenas com fatos estruturados já confirmados.
    """
    style = str(analysis.get("requested_style") or "automatico")
    hook = sanitize_script_language(str(candidate.get("hook") or "").strip())
    narration = sanitize_script_language(str(candidate.get("narration") or "").strip())
    if not hook or _style_contract_issues(style, hook, narration, sp):
        hook = _specific_hook(profile, sp, "mini_historia", "beneficio", style == "humor")
    repair_substyle = str(analysis.get("requested_substyle") or ("humor_observacao" if style == "humor" else style))
    additions = _rich_style_layer(repair_substyle, sp, profile, proof, "beneficio") or _style_specific_additions(style, sp, profile, proof)
    for sentence in additions:
        if sentence.casefold() not in narration.casefold():
            narration += " " + sentence
    narration = _ensure_openai_length(narration, profile, analysis, proof, 78)
    narration = sanitize_script_language(_grammar_safety_pass(narration, profile))
    score = _script_quality_score(hook, narration, profile, "openai_repaired", sp, style)
    return hook, narration, score


def _openai_response(payload: dict) -> dict:
    with httpx.Client(timeout=settings.openai_script_timeout_seconds) as client:
        response = client.post(
            "https://api.openai.com/v1/responses",
            headers={"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"},
            json=payload,
        )
        response.raise_for_status()
        raw = _extract_response_text(response.json())
        if not raw:
            raise ValueError("resposta vazia")
        return json.loads(raw)


def _openai_writer_pipeline(request: ScriptRequest, profile: dict, category_profile: dict, proof: str) -> dict:
    """Pipeline OpenAI com análise estruturada, auditoria local e autocorreção."""
    if not settings.openai_api_key:
        raise ValueError("OPENAI_API_KEY não está configurada para o Roteirista OpenAI.")
    p = request.product
    creativity = {
        "conservador": "Priorize precisão, linguagem sóbria e aderência literal aos fatos.",
        "equilibrado": "Equilibre criatividade, naturalidade, retenção e fidelidade aos fatos.",
        "criativo": "Use ideias e estruturas mais originais, sem inventar fatos, resultados ou garantias.",
    }.get(request.creativity_level, "Equilibre criatividade e precisão.")
    product_data = {
        "title": p.title,
        "category": getattr(p.category, "value", str(p.category)),
        "price": p.price,
        "rating": p.rating,
        "review_count": p.review_count,
        "sold_quantity": p.sold_quantity,
        "profile": profile,
        "category_analysis": category_profile,
        "commercial_proof": proof,
        "duration_seconds": request.duration_seconds,
        "variation_index": request.variation_index,
        "requested_style": _requested_script_style(request),
        "requested_substyle": _requested_script_substyle(request),
        "diversity_key": hashlib.sha256(f"{p.title}|{request.variation_index}|{request.format}".encode()).hexdigest()[:12],
    }
    schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "analysis": {
                "type": "object", "additionalProperties": False,
                "properties": {
                    "product": {"type": "string"}, "category": {"type": "string"},
                    "audience": {"type": "string"}, "problem": {"type": "string"},
                    "purchase_criteria": {"type": "array", "items": {"type": "string"}},
                    "confirmed_features": {"type": "array", "items": {"type": "string"}},
                    "prohibited_claims": {"type": "array", "items": {"type": "string"}},
                    "central_thesis": {"type": "string"},
                },
                "required": ["product", "category", "audience", "problem", "purchase_criteria", "confirmed_features", "prohibited_claims", "central_thesis"],
            },
            "candidates": {
                "type": "array", "minItems": 5, "maxItems": 5,
                "items": {
                    "type": "object", "additionalProperties": False,
                    "properties": {
                        "strategy": {"type": "string"}, "hook": {"type": "string"},
                        "narration": {"type": "string"}, "spoken_cta": {"type": "string"},
                        "score": {"type": "integer", "minimum": 0, "maximum": 100},
                        "review": {"type": "string"},
                    },
                    "required": ["strategy", "hook", "narration", "spoken_cta", "score", "review"],
                },
            },
            "selected_index": {"type": "integer", "minimum": 0, "maximum": 4},
        },
        "required": ["analysis", "candidates", "selected_index"],
    }
    system = (
        "Você é um pipeline editorial brasileiro com sete papéis obrigatórios: Analista de Produto, "
        "Especialista da Categoria, Estrategista do Consumidor, Diretor Criativo, Roteirista, Revisor e Auditor. "
        + creativity
        + " Regras inegociáveis: use somente fatos confirmados nos dados; não invente material, desempenho, "
        "compatibilidade, benefício, certificação ou endosso; não fale sobre fotos, imagens ou bastidores do anúncio; "
        "não use frases vagas; gere exatamente cinco roteiros com estratégias realmente diferentes, sem repetir a mesma ordem de problema-características-prova-CTA; cada candidato deve partir de um arquétipo distinto (por exemplo cena real, objeção, anti-hype, mini-review, checklist, história, comparação ou curiosidade); varie abertura, ritmo, ordem dos argumentos e vocabulário conforme o produto; cada gancho deve "
        "ter no máximo 14 palavras; cada narração deve ter entre 78 e 112 palavras, soar humana e específica, adequada "
        "a aproximadamente 38 segundos de fala; o CTA falado deve variar naturalmente, mas o destino é Link na bio; "
        "português do Brasil impecável. O estilo solicitado é obrigatório: humor deve ser realmente engraçado, com situação reconhecível, quebra de expectativa e punchline ligados ao produto; varie entre observação, humor seco, personificação, exagero, autoironia e expectativa x realidade; não use apenas adjetivos engraçados em um roteiro comercial comum; custo-benefício deve comparar quantidade, utilidade, durabilidade e valor total sem virar mera lista de características; comparativo deve contrastar critérios; informativo deve explicar com clareza. Não confie apenas na sua nota: todos os candidatos serão auditados localmente."
    )
    base_user = "Analise e gere o pacote editorial para estes dados:\n" + json.dumps(product_data, ensure_ascii=False)
    last_reasons: list[str] = []
    last_error = ""
    best_draft: tuple[int, dict, dict] | None = None
    for attempt in range(1, 4):
        user_text = base_user
        if last_reasons:
            user_text += (
                "\n\nA tentativa anterior foi reprovada. Reescreva os cinco candidatos corrigindo obrigatoriamente: "
                + "; ".join(last_reasons[:12])
                + ". Preserve somente fatos confirmados e varie de verdade as estratégias."
            )
        payload = {
            "model": settings.openai_script_model,
            "input": [
                {"role": "system", "content": [{"type": "input_text", "text": system}]},
                {"role": "user", "content": [{"type": "input_text", "text": user_text}]},
            ],
            "text": {"format": {"type": "json_schema", "name": "script_package", "strict": True, "schema": schema}},
            "max_output_tokens": 7000,
        }
        try:
            result = _openai_response(payload)
        except Exception as exc:
            last_error = str(exc)[:240]
            logger.warning("OpenAI writer attempt %s failed: %s", attempt, last_error)
            continue
        candidates = result.get("candidates") or []
        analysis = result.get("analysis") or {}
        analysis["commercial_proof"] = proof
        analysis["requested_style"] = _requested_script_style(request)
        if len(candidates) != 5:
            last_reasons = [f"foram devolvidos {len(candidates)} candidatos; são exigidos 5"]
            logger.warning("OpenAI writer attempt %s invalid candidate count", attempt)
            continue
        audited = []
        all_reasons: list[str] = []
        for candidate in candidates:
            score, reasons, hook, narration = _audit_openai_candidate(candidate, profile, analysis, category_profile)
            audited.append((score, reasons, hook, narration, candidate))
            if best_draft is None or score > best_draft[0]:
                best_draft = (score, dict(candidate), dict(analysis))
            all_reasons.extend(reasons)
        valid = [item for item in audited if not item[1] and item[0] >= 70]
        if valid:
            score, _, hook, narration, chosen = max(valid, key=lambda item: item[0])
            chosen = dict(chosen)
            chosen["score"] = score
            logger.info("OpenAI writer approved on attempt %s with score %s", attempt, score)
            return {"analysis": analysis, "chosen": chosen, "hook": hook, "narration": narration, "attempts": attempt}
        best = max(audited, key=lambda item: item[0])
        last_reasons = list(dict.fromkeys(best[1] + all_reasons)) or [f"qualidade insuficiente: melhor nota {best[0]}/100"]
        logger.warning("OpenAI writer attempt %s rejected: %s", attempt, "; ".join(last_reasons[:8]))
    # Se a API respondeu ao menos uma vez, não exponha uma reprovação editorial ao usuário.
    # O melhor rascunho OpenAI é finalizado pelo editor determinístico usando somente
    # a análise e os fatos confirmados do próprio pipeline.
    if best_draft is not None:
        _, candidate, analysis = best_draft
        joined_draft = f"{candidate.get('hook', '')} {candidate.get('narration', '')}".casefold()
        unsafe_claims = [
            str(claim).strip() for claim in analysis.get("prohibited_claims") or []
            if str(claim).strip() and str(claim).strip().casefold() in joined_draft
        ]
        if unsafe_claims:
            detail = "; ".join(unsafe_claims[:4])
            raise ValueError(
                "A OpenAI repetiu afirmações não confirmadas após três tentativas automáticas. "
                f"O roteiro foi bloqueado por segurança: {detail[:160]}"
            )
        hook, narration, score = _repair_openai_candidate(candidate, profile, analysis, category_profile, proof)
        logger.warning("OpenAI candidates required deterministic editorial repair; final score=%s", score)
        candidate["strategy"] = str(candidate.get("strategy") or "openai") + "_repaired"
        candidate["score"] = max(70, score)
        return {"analysis": analysis, "chosen": candidate, "hook": hook, "narration": narration, "attempts": 3, "repaired": True}
    detail = "; ".join(last_reasons[:6]) or last_error or "resposta inválida"
    raise ValueError(
        "A OpenAI não respondeu corretamente após três tentativas. Verifique a chave, o modelo e a conexão. "
        f"Diagnóstico: {detail[:180]}"
    )


def _limit_question_density(hook: str, narration: str) -> tuple[str, str]:
    """Mantém no máximo uma pergunta real no conjunto falado.

    Perguntas em sequência deixam o anúncio com ritmo de interrogatório. O
    primeiro gancho pode continuar interrogativo; as demais frases passam a
    afirmações curtas e naturais.
    """
    allowance = 1 if "?" in hook else 0
    parts = re.split(r"(?<=[.!?])\s+", narration.strip())
    output: list[str] = []
    for part in parts:
        if "?" in part:
            if allowance == 0:
                allowance = 1
            else:
                part = part.replace("?", ".")
        output.append(part)
    return hook, " ".join(output).strip()


def _conversion_cta(variation_index: int = 0) -> str:
    options = (
        "Comente QUERO. Receba o link no Direct.",
        "Escreva QUERO. O link chega no Direct.",
        "Comente QUERO e confira o Direct.",
        "Quer conferir a oferta? Comente QUERO.",
        "Se quiser o anúncio, escreva QUERO nos comentários.",
        "Para ver a versão atual, comente QUERO.",
    )
    return options[int(variation_index or 0) % len(options)]


def _gemini_inline_images(urls: list[str], limit: int) -> list[dict]:
    """Baixa e normaliza fotos reais para o Gemini Visual.

    As imagens do Mercado Livre às vezes chegam grandes ou com headers que
    bloqueiam downloads genéricos no Render. Usamos headers de navegador e
    recomprimimos para JPEG <= 1600 px, reduzindo timeout/tamanho da requisição.
    """
    parts: list[dict] = []
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": "https://www.mercadolivre.com.br/",
    }
    for url in (urls or [])[: max(1, limit)]:
        try:
            with httpx.Client(timeout=12.0, follow_redirects=True, headers=headers) as client:
                response = client.get(str(url))
            response.raise_for_status()
            raw = response.content
            if not raw:
                continue
            try:
                image = Image.open(BytesIO(raw)).convert("RGB")
                image.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
                out = BytesIO()
                image.save(out, format="JPEG", quality=86, optimize=True)
                content = out.getvalue()
                mime = "image/jpeg"
            except Exception:
                content = raw
                mime = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                if not mime.startswith("image/"):
                    mime = mimetypes.guess_type(str(url))[0] or "image/jpeg"
            if len(content) > 4_500_000:
                logger.info("Roteirista visual: foto grande demais após normalização url=%s bytes=%s", str(url)[:100], len(content))
                continue
            parts.append({"inline_data": {"mime_type": mime, "data": base64.b64encode(content).decode("ascii")}})
        except Exception as exc:
            logger.info("Roteirista visual: foto ignorada url=%s erro=%s", str(url)[:120], str(exc)[:160])
    return parts

def _gemini_json_from_response(data: dict) -> dict:
    try:
        text = data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as exc:
        raise ValueError("A IA Visual não retornou texto utilizável.") from exc
    text = str(text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
    try:
        return json.loads(text)
    except Exception as exc:
        logger.warning("JSON Gemini inválido: %s", text[:800])
        raise ValueError("A IA Visual retornou um formato inválido. Gere novamente.") from exc


def _gemini_vision_writer(request: ScriptRequest, profile: dict, sp: dict, proof: str) -> dict:
    if not settings.gemini_api_key:
        raise ValueError("GEMINI_API_KEY não configurada para o Roteirista Visual Gratuito.")

    p = request.product
    image_parts = _gemini_inline_images(request.source_images, settings.gemini_script_max_images)
    if not image_parts:
        logger.warning("Roteirista visual: nenhuma foto do anúncio pôde ser baixada. A geração visual será interrompida para não fingir análise de imagens.")
        raise ValueError("A IA Visual está configurada, mas não conseguiu baixar nenhuma foto do anúncio. Atualize as fotos do produto e tente novamente; não é necessária outra GEMINI_API_KEY.")

    format_hint = request.format.replace("_", " ")
    creativity = request.creativity_level
    variation = request.variation_index
    description = " ".join(str(request.product_description or "").split())[:6500]
    confirmed = {
        "titulo": p.title,
        "categoria": getattr(p.category, "value", str(p.category)),
        "preco": p.price,
        "preco_anterior": p.original_price,
        "nota": p.rating,
        "avaliacoes": p.review_count,
        "vendidos": p.sold_quantity,
        "comissao_pct": p.commission_pct,
        "estoque": p.stock_available,
        "prova_comercial": proof,
    }
    creative_devices = (
        "micro-história com um pequeno conflito", "descoberta visual em três atos",
        "começar pelo detalhe mais estranho da foto", "falso mini-documentário",
        "comparação inesperada com uma situação cotidiana", "review em primeira pessoa sem fingir uso",
        "lista invertida: começar pela conclusão", "objeção forte antes do benefício",
        "pergunta específica respondida visualmente", "mini-investigação de compra",
        "expectativa versus realidade", "erro comum mostrado pelas fotos",
        "benefício oculto revelado no meio", "história de um problema cotidiano",
        "anti-hype: começar dizendo para quem NÃO serve", "teste mental: imagine usando isto amanhã",
        "humor de observação com punchline visual", "narração estilo confidência",
        "curiosidade progressiva sem clickbait", "decisão de compra em 3 critérios"
    )
    device_seed = _stable_seed(p.title, getattr(p.category, "value", str(p.category)), variation, len(image_parts))
    creative_device = creative_devices[device_seed % len(creative_devices)]
    forbidden_openings = (
        "olha esse achadinho", "você precisa disso", "se você está procurando",
        "esse produto é perfeito", "já imaginou", "eu encontrei", "esse aqui"
    )

    prompt = f"""Você é o DIRETOR DE ROTEIROS VISUAIS da Zavomi. Escreva UM roteiro de vídeo vertical de 40 segundos em português do Brasil usando AS FOTOS anexadas como fonte criativa principal e os dados confirmados abaixo como fonte factual.

OBJETIVO: produzir um roteiro que pareça criado especificamente para este produto, não um template com características trocadas.

DADOS CONFIRMADOS:
{json.dumps(confirmed, ensure_ascii=False)}
DESCRIÇÃO ORIGINAL DO ANÚNCIO:
{description or 'não disponível'}
FORMATO PEDIDO: {format_hint}
CRIATIVIDADE: {creativity}
VARIAÇÃO: {variation}
DISPOSITIVO CRIATIVO OBRIGATÓRIO DESTA VERSÃO: {creative_device}
ABERTURAS PROIBIDAS: {", ".join(forbidden_openings)}

REGRAS DE VISÃO:
1. Observe cada foto e identifique o que REALMENTE aparece: produto, acessórios, uso, escala, textura, controles, embalagem, texto impresso, cenário e diferenças entre imagens.
2. Escolha de 3 a 6 fatos visuais úteis. Não invente nada que não esteja visível ou descrito.
3. Se uma imagem tiver texto promocional ou alegação não confirmada, trate como 'texto mostrado na imagem', nunca como fato.
4. O roteiro deve citar ou explorar pelo menos DOIS elementos visuais concretos das fotos quando houver imagens válidas.
5. Escreva cenas que possam ser montadas com essas próprias fotos. Não peça cenas inexistentes.

REGRAS DE ROTEIRO:
- Gancho realmente específico, máximo 12 palavras; evite 'você precisa disso', 'olha esse achadinho' e frases genéricas.
- Narração natural de 75 a 100 palavras, com começo, desenvolvimento e conclusão.
- O dispositivo criativo indicado acima é OBRIGATÓRIO e deve comandar a estrutura inteira; não o mencione no texto.
- Não use a sequência genérica gancho → características → benefícios → CTA. A ordem deve nascer do dispositivo criativo e das fotos.
- Cada parágrafo precisa depender de algo específico deste produto ou destas imagens; se puder servir para qualquer produto, reescreva.
- Use uma estrutura diferente das variações anteriores: mude ponto de vista, ordem dos argumentos, ritmo e tipo de conclusão.
- Humor, quando o formato pedir, deve ter situação reconhecível + escalada + quebra de expectativa + punchline ligada ao produto. Nada de piada genérica.
- Se FORMATO PEDIDO for humor_risada: trate como COMÉDIA PRIMEIRO e anúncio depois. O gancho precisa terminar numa virada curta que funcione antes de uma risada; NÃO escreva "haha", "risos" ou instruções de áudio no texto. A voz fará uma risada original NÃO VERBAL intensa ao final do gancho: crescente, momentaneamente descontrolada, com pequena quebra de respiração e corte abrupto; o texto não deve escrever a risada. Use pelo menos uma imagem real como matéria-prima da piada e evite estrutura de catálogo.
- Não faça catálogo falado de características. Escolha no máximo 3 fatos e transforme-os em argumento, cena ou contraste.
- Não repetir o nome completo do anúncio.
- Não transformar adjetivos do vendedor em fatos.
- Não inventar vendas, avaliação, comissão, garantia ou funções.
- CTA falado curto e natural direcionando para o link da bio.
- Crie 4 a 6 instruções de cena, cada uma dizendo qual tipo de foto usar e por quê.

RESPONDA SOMENTE JSON válido com estas chaves:
{{
  "hook": "...",
  "narration": "...",
  "spoken_cta": "...",
  "strategy": "nome_curto_da_estrategia",
  "visual_insights": ["..."],
  "scene_plan": ["..."],
  "why_specific": "uma frase explicando por que este roteiro só serve para este produto"
}}"""

    parts = [{"text": prompt}] + image_parts
    payload = {
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": {
            "temperature": 0.78 if creativity == "criativo" else 0.55 if creativity == "equilibrado" else 0.3,
            "topP": 0.92,
            "maxOutputTokens": 1800,
            "responseMimeType": "application/json",
        },
    }
    # v1.0.135 — a mesma GEMINI_API_KEY usada pelo TTS é suficiente para o
    # roteirista visual. O problema observado não era uma segunda chave: era a
    # dependência de um único modelo/forma de resposta. Tentamos modelos
    # multimodais estáveis/compatíveis em sequência e, se o JSON estruturado
    # for rejeitado, repetimos sem responseMimeType.
    configured = str(settings.gemini_script_model or "").strip()
    fallbacks = [x.strip() for x in str(getattr(settings, "gemini_script_fallback_models", "") or "").split(",") if x.strip()]
    models: list[str] = []

    # v1.0.135 — o catálogo de modelos do Gemini muda com frequência. Em vez de
    # depender apenas de nomes fixos, perguntamos à própria API quais modelos da
    # chave atual aceitam generateContent e priorizamos variantes Flash. Isso usa
    # a MESMA GEMINI_API_KEY do TTS; nenhuma chave adicional é necessária.
    discovered: list[str] = []
    try:
        with httpx.Client(timeout=12.0) as discovery_client:
            listing = discovery_client.get(
                "https://generativelanguage.googleapis.com/v1beta/models",
                headers={"x-goog-api-key": str(settings.gemini_api_key)},
            )
        if listing.status_code < 400:
            for item in (listing.json().get("models") or []):
                methods = item.get("supportedGenerationMethods") or []
                raw_name = str(item.get("name") or "").replace("models/", "", 1)
                lowered = raw_name.lower()
                if raw_name and "generateContent" in methods and "flash" in lowered and "tts" not in lowered and "image" not in lowered:
                    discovered.append(raw_name)
            discovered.sort(key=lambda name: (0 if "3.6-flash" in name else 1 if "3.5-flash" in name else 2 if "2.5-flash" in name else 3, name))
        else:
            logger.warning("Gemini Visual: falha ao consultar catálogo status=%s body=%s", listing.status_code, listing.text[:500])
    except Exception as exc:
        logger.info("Gemini Visual: catálogo dinâmico indisponível; usando fallback fixo: %s", str(exc)[:180])

    for candidate in [configured, *discovered, *fallbacks, "gemini-3.6-flash", "gemini-3.5-flash", "gemini-2.5-flash", "gemini-2.5-flash-lite"]:
        if candidate and candidate not in models:
            models.append(candidate)

    attempts: list[str] = []
    result = None
    selected_model = ""
    with httpx.Client(timeout=settings.gemini_script_timeout_seconds) as client:
        for model in models:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
            for structured in (True, False):
                try_payload = json.loads(json.dumps(payload))
                if not structured:
                    cfg = try_payload.get("generationConfig", {})
                    cfg.pop("responseMimeType", None)
                    # Modelos Gemini mais novos podem rejeitar parâmetros de
                    # amostragem legados. A tentativa compatível usa só limite.
                    cfg.pop("temperature", None)
                    cfg.pop("topP", None)
                    cfg.pop("topK", None)
                    # Sem MIME JSON, reforçamos o contrato no próprio prompt.
                    try_payload["contents"][0]["parts"][0]["text"] += "\nIMPORTANTE: responda apenas com um objeto JSON puro, sem markdown."
                try:
                    response = client.post(
                        url,
                        headers={"x-goog-api-key": str(settings.gemini_api_key)},
                        json=try_payload,
                    )
                except httpx.TimeoutException:
                    attempts.append(f"{model}: timeout")
                    break
                except httpx.HTTPError as exc:
                    attempts.append(f"{model}: rede {type(exc).__name__}")
                    break
                if response.status_code >= 400:
                    body = response.text[:500].replace("\n", " ")
                    attempts.append(f"{model}: HTTP {response.status_code} {body[:180]}")
                    logger.warning("Gemini Visual falhou model=%s structured=%s status=%s body=%s", model, structured, response.status_code, response.text[:1200])
                    # 400 pode ser incompatibilidade de geração estruturada; a
                    # segunda tentativa remove esse recurso. 404/429/5xx segue
                    # para o próximo modelo automaticamente.
                    if response.status_code == 400 and structured:
                        continue
                    break
                try:
                    result = _gemini_json_from_response(response.json())
                    selected_model = model
                    break
                except ValueError as exc:
                    attempts.append(f"{model}: resposta inválida {str(exc)[:100]}")
                    if structured:
                        continue
                    break
            if result is not None:
                break

    if result is None:
        detail = " | ".join(attempts[-5:]) or "nenhuma resposta do Gemini"
        if any("HTTP 429" in item for item in attempts):
            raise ValueError("A IA Visual está configurada, mas a cota gratuita do Gemini foi atingida agora (HTTP 429). Aguarde alguns minutos e tente novamente. Diagnóstico: " + detail[:500])
        if any("HTTP 403" in item for item in attempts):
            raise ValueError("A GEMINI_API_KEY existe, porém o projeto não autorizou este modelo visual (HTTP 403). A mesma chave funciona no TTS, mas a API multimodal foi recusada. Diagnóstico: " + detail[:500])
        raise ValueError("A IA Visual está com a chave configurada, mas nenhum modelo multimodal respondeu corretamente. Não é necessário criar outra key. Diagnóstico: " + detail[:650])

    hook = sanitize_script_language(str(result.get("hook") or "").strip())
    narration = sanitize_script_language(str(result.get("narration") or "").strip())
    cta = sanitize_script_language(str(result.get("spoken_cta") or _conversion_cta(variation)).strip())
    if not hook or not narration:
        raise ValueError("A IA Visual não gerou um roteiro completo.")
    narration = _fit_narration_to_duration(hook, narration, cta, request.duration_seconds)
    hook, narration = _limit_question_density(hook, narration)
    issues = script_language_issues(hook, narration, cta)
    if issues:
        logger.info("Auditoria do roteiro visual encontrou: %s", issues)
    return {
        "hook": hook,
        "narration": narration,
        "cta": cta,
        "strategy": str(result.get("strategy") or "direcao_visual"),
        "visual_insights": [str(x)[:160] for x in (result.get("visual_insights") or []) if str(x).strip()][:6],
        "scene_plan": [str(x)[:220] for x in (result.get("scene_plan") or []) if str(x).strip()][:6],
        "why_specific": str(result.get("why_specific") or "").strip()[:300],
        "image_count": len(image_parts),
        "gemini_model": selected_model,
    }

def generate_script(request: ScriptRequest) -> ScriptOutput:
    p = request.product
    category_key = getattr(p.category, "value", str(p.category))
    _, hashtags = CATEGORY_CONTENT.get(category_key, CATEGORY_CONTENT["casa"])
    profile = _product_profile(p.title)
    short, price = _short_title(p.title), _money(p.price)
    angle_seed = _stable_seed(p.title, category_key, request.format, request.writer_engine)
    angle = VARIATION_ANGLES[(angle_seed + request.variation_index) % len(VARIATION_ANGLES)]
    proof = _proof_line(p.rating, p.sold_quantity, p.review_count)
    link = str(p.affiliate_url)
    fmt = _format_for(request)
    requested_style = _requested_script_style(request)
    requested_substyle = _requested_script_substyle(request)
    profile["_price_value"] = p.price
    profile["_variation_index"] = request.variation_index
    humorous = requested_style == "humor" or fmt in {"humor_observacao", "humor_seco", "expectativa_realidade", "humor_viral", "humor_risada"} or any(x in (request.voice_instructions or "").lower() for x in ("humor", "engraç", "divertid"))
    base_structure = _creative_structure(request, profile)
    sp = _category_script_profile(p.title, category_key, profile)

    if request.writer_engine == "gemini_vision":
        package = _gemini_vision_writer(request, profile, sp, proof)
        hook = package["hook"]
        narration = package["narration"]
        cta = package["cta"]
        strategy = package["strategy"]
        visual_insights = package.get("visual_insights") or []
        scene_plan = package.get("scene_plan") or []
        # Textos de tela permanecem curtos. O plano de cenas é usado como contexto
        # editorial e não é exibido como legenda no vídeo.
        visual_facts = [str(x).upper()[:58] for x in visual_insights[:3]]
        on_screen = _scene_plan(hook, short, visual_facts, proof, price, cta, request.duration_seconds, f"Gemini Visual · {package.get('image_count', 0)} fotos")
        caption = (
            f"{short}\n\n"
            f"Roteiro visual criado com {package.get('gemini_model') or 'Gemini'} após analisar {package.get('image_count', 0)} fotos reais do anúncio. "
            + (f"Direção: {strategy.replace('_', ' ')}. " if strategy else "")
            + (f"Elementos observados: {'; '.join(visual_insights[:3])}. " if visual_insights else "")
            + "Preço, estoque, frete e condições podem mudar; confira o anúncio original.\n\n"
            f"🔗 Link direto do produto: {link}\n\n"
            "Publicidade: este conteúdo contém link de afiliado. Podemos receber comissão sem custo adicional para você."
        )
        return ScriptOutput(
            hook=sanitize_script_language(_grammar_safety_pass(hook, profile)),
            narration=sanitize_script_language(_grammar_safety_pass(narration, profile)),
            on_screen_text=on_screen,
            caption=caption,
            call_to_action=cta,
            hashtags=hashtags + ["#mercadolivre", "#linkNaBio", "#publicidade", "#roteiroVisual"],
        )

    if request.writer_engine == "openai":
        package = _openai_writer_pipeline(request, profile, sp, proof)
        chosen = package["chosen"]
        hook = package["hook"]
        cta = sanitize_script_language(str(chosen.get("spoken_cta") or _conversion_cta(request.variation_index)))
        narration = _fit_narration_to_duration(hook, package["narration"], cta, request.duration_seconds)
        hook, narration = _limit_question_density(hook, narration)
        strategy = str(chosen.get("strategy") or "openai_editorial")
        score = int(chosen.get("score") or 0)
        visual_facts = []
        if profile.get("display_name"):
            visual_facts.append(str(profile["display_name"]))
        if profile.get("measure_screen"):
            visual_facts.append(str(profile["measure_screen"]))
        visual_facts.extend(str(x) for x in profile.get("attributes") or [] if x)
        on_screen = _scene_plan(hook, short, visual_facts[:4], proof, price, cta, request.duration_seconds, f"OpenAI · {strategy} · qualidade {score}/100")
        on_screen.append(f"ROTEIRISTA · OpenAI · criatividade {request.creativity_level}")
        analysis = package.get("analysis") or {}
        thesis = str(analysis.get("central_thesis") or "").strip()
        caption = (
            f"{short}\n\n"
            f"Roteiro OpenAI em estratégia {strategy.replace('_', ' ')}. "
            + (f"Tese editorial: {thesis}. " if thesis else "")
            + f"O anúncio analisado mostrava {proof}. "
            "Preço, estoque, frete e condições podem mudar. Confira a versão e a descrição original antes da compra.\n\n"
            f"🔗 Link direto do produto: {link}\n\n"
            "Publicidade: este conteúdo contém link de afiliado. Podemos receber comissão sem custo adicional para você."
        )
        return ScriptOutput(
            hook=hook, narration=narration, on_screen_text=on_screen, caption=caption,
            call_to_action=cta, hashtags=hashtags + ["#mercadolivre", "#linkNaBio", "#publicidade", "#roteiroOpenAI"],
        )

    # IA gratuita: gera cinco candidatos com estruturas distintas e escolhe o melhor.
    structures=[]
    base_index=CREATIVE_STRUCTURES.index(base_structure) if base_structure in CREATIVE_STRUCTURES else 0
    diversity_seed = _stable_seed(p.title, category_key, request.variation_index, requested_style, requested_substyle)
    dynamic_offsets = [0, 1 + diversity_seed % 5, 4 + (diversity_seed // 7) % 5, 9 + (diversity_seed // 13) % 5, 14 + (diversity_seed // 17) % 4]
    for offset in dynamic_offsets:
        candidate_structure=CREATIVE_STRUCTURES[(base_index+offset) % len(CREATIVE_STRUCTURES)]
        if candidate_structure not in structures:
            structures.append(candidate_structure)
    for candidate_structure in CREATIVE_STRUCTURES:
        if len(structures) >= 5:
            break
        if candidate_structure not in structures:
            structures.append(candidate_structure)
    candidates=[]
    for structure in structures:
        if requested_substyle == "humor_risada":
            hook, narration = _viral_laugh_story(profile, sp, proof, request.variation_index + structures.index(structure), angle["name"])
        elif requested_substyle == "humor_viral":
            hook, narration = _viral_comedy_story(profile, sp, proof, request.variation_index + structures.index(structure), angle["name"])
        elif humorous and requested_substyle in {"humor_observacao", "humor_seco", "expectativa_realidade"}:
            hook, narration = _humor_story(profile, sp, proof, requested_substyle, request.variation_index + structures.index(structure), angle["name"])
        else:
            hook=_specific_hook(profile, sp, structure, angle["name"], humorous, requested_substyle)
            narration=_candidate_narration(profile, sp, proof, structure, angle["name"], humorous, requested_style, requested_substyle)
        cta = _conversion_cta(request.variation_index)
        narration=_fit_narration_to_duration(hook, narration, cta, request.duration_seconds)
        hook, narration = _limit_question_density(hook, narration)
        score=_script_quality_score(hook,narration,profile,structure,sp,requested_style)
        if structure == base_structure:
            score += 2  # desempate leve; qualidade continua sendo o critério principal
        if requested_style == "storytelling" and structure == "mini_historia":
            score += 24
        elif requested_style == "comparativo" and structure == "comparacao":
            score += 16
        elif requested_style == "custo_beneficio" and structure in {"comparacao", "checklist_compra", "micro_review"}:
            score += 10
        candidates.append((score,structure,hook,narration,cta))
    score, structure, hook, narration, cta=max(candidates, key=lambda x:(x[0], -structures.index(x[1])))
    if score < 82:
        # Reescrita de segurança sem destruir o estilo solicitado. Humor nunca
        # volta para o antigo esqueleto comercial genérico.
        if requested_substyle == "humor_risada":
            structure = "mini_historia"
            hook, raw = _viral_laugh_story(profile, sp, proof, request.variation_index + 7, angle["name"])
            narration = _fit_narration_to_duration(hook, raw, cta, request.duration_seconds)
        elif requested_substyle == "humor_viral":
            structure = "mini_historia"
            hook, raw = _viral_comedy_story(profile, sp, proof, request.variation_index + 7, angle["name"])
            narration = _fit_narration_to_duration(hook, raw, cta, request.duration_seconds)
        elif humorous and requested_substyle in {"humor_observacao", "humor_seco", "expectativa_realidade"}:
            structure = "mini_historia" if requested_substyle == "humor_observacao" else "mito_realidade"
            hook, raw = _humor_story(profile, sp, proof, requested_substyle, request.variation_index + 7, angle["name"])
            narration = _fit_narration_to_duration(hook, raw, cta, request.duration_seconds)
        else:
            structure = "problema_solucao"
            hook = _specific_hook(profile, sp, structure, angle["name"], humorous, requested_substyle)
            narration = _fit_narration_to_duration(
                hook, _candidate_narration(profile, sp, proof, structure, angle["name"], humorous, requested_style, requested_substyle),
                cta, request.duration_seconds,
            )
        score = _script_quality_score(hook, narration, profile, structure, sp, requested_style)
    if score < 75 and request.duration_seconds >= 35:
        if requested_substyle == "humor_risada":
            hook, raw = _viral_laugh_story(profile, sp, proof, request.variation_index + 11, angle["name"])
            narration = _fit_narration_to_duration(hook, raw, cta, request.duration_seconds)
        elif requested_substyle == "humor_viral":
            hook, raw = _viral_comedy_story(profile, sp, proof, request.variation_index + 11, angle["name"])
            narration = _fit_narration_to_duration(hook, raw, cta, request.duration_seconds)
        elif humorous and requested_substyle in {"humor_observacao", "humor_seco", "expectativa_realidade"}:
            hook, raw = _humor_story(profile, sp, proof, requested_substyle, request.variation_index + 11, angle["name"])
            narration = _fit_narration_to_duration(hook, raw, cta, request.duration_seconds)
        else:
            structure = "comparacao"
            hook = _specific_hook(profile, sp, structure, angle["name"], humorous, requested_substyle)
            narration = _fit_narration_to_duration(
                hook, _candidate_narration(profile, sp, proof, structure, angle["name"], humorous, requested_style, requested_substyle),
                cta, request.duration_seconds,
            )
        score = _script_quality_score(hook, narration, profile, structure, sp, requested_style)
    if not p.title.strip():
        raise ValueError("O roteiro não atingiu o padrão mínimo de qualidade. Revise os dados do anúncio e gere novamente.")

    # v1.0.122: o gancho cômico final respeita diretamente variation_index.
    # As etapas de reparo de qualidade podem usar offsets (+7/+11); sem esta
    # normalização duas variações podiam acabar com o mesmo gancho apesar de o
    # corpo estar diferente.
    if requested_substyle == "humor_risada":
        variant_hook, variant_narration = _viral_laugh_story(profile, sp, proof, request.variation_index, angle["name"])
        hook = variant_hook
        narration = _fit_narration_to_duration(hook, variant_narration, cta, request.duration_seconds)
    elif requested_substyle == "humor_viral":
        variant_hook, variant_narration = _viral_comedy_story(profile, sp, proof, request.variation_index, angle["name"])
        hook = variant_hook
        narration = _fit_narration_to_duration(hook, variant_narration, cta, request.duration_seconds)
    elif humorous and requested_substyle in {"humor_observacao", "humor_seco", "expectativa_realidade"}:
        variant_hook, variant_narration = _humor_story(profile, sp, proof, requested_substyle, request.variation_index, angle["name"])
        hook = variant_hook
        narration = _fit_narration_to_duration(hook, variant_narration, cta, request.duration_seconds)

    hook, narration = _limit_question_density(hook, narration)
    visual_facts=[]
    if profile.get("display_name"): visual_facts.append(str(profile["display_name"]))
    if profile.get("measure_screen"): visual_facts.append(str(profile["measure_screen"]))
    visual_facts.extend(str(x) for x in profile.get("attributes") or [] if x)
    on_screen=_scene_plan(hook, short, visual_facts[:4], proof, price, cta, request.duration_seconds, f"{structure} · qualidade {score}/100")
    on_screen.append(f"DIREÇÃO · {request.presenter_style} · energia {request.presenter_energy} · idade {request.presenter_age}")

    caption=(
        f"{short}\n\n"
        f"Roteiro em estrutura {structure.replace('_',' ')}. O anúncio analisado mostrava {proof}. "
        "Preço, estoque, frete e condições podem mudar. Confira a versão, as medidas, a compatibilidade e a descrição original antes da compra.\n\n"
        f"🔗 Link direto do produto: {link}\n\n"
        "Publicidade: este conteúdo contém link de afiliado. Podemos receber comissão sem custo adicional para você."
    )
    return ScriptOutput(
        hook=sanitize_script_language(_grammar_safety_pass(hook, profile)),
        narration=sanitize_script_language(_grammar_safety_pass(narration, profile)),
        on_screen_text=on_screen,
        caption=caption,
        call_to_action=cta,
        hashtags=hashtags+["#mercadolivre","#linkNaBio","#publicidade",f"#{angle['name']}"]
    )
