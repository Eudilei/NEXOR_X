from __future__ import annotations

from datetime import datetime, timezone
import json
from time import perf_counter

from sqlalchemy import delete, or_, select
from sqlalchemy.orm import Session

from app.db.models import Product, ProductObservation, Script
from app.models.schemas import ProductCategory, ProductInput, ScriptRequest
from app.services.marketplace import (
    Candidate, MercadoLivreClient, MarketplaceRequestError,
    MIN_ZAVOMI_RATING, MIN_ZAVOMI_REVIEWS,
)
from app.services.scoring import score_product
from app.services.affiliate_links import resolve_affiliate_link
from app.services.scripts import generate_script


def _metadata(product: Product) -> dict[str, object]:
    try:
        value = json.loads(product.source_metadata_json or "{}")
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}




def _completed_record_is_protected(product: Product | None) -> bool:
    """Preserva cadastros já concluídos contra regressões de uma varredura parcial.

    A proteção também reconhece registros concluídos em versões anteriores, que
    ainda não possuem a marca ``manual_completed_at`` no metadata.
    """
    if not product:
        return False
    meta = _metadata(product)
    if meta.get("manual_fields_protected") or meta.get("manual_completed_at"):
        return True
    return str(getattr(product, "status", "") or "") in {"pronto_publicacao", "aprovado_comercial", "aprovado"}

def _confirmed_affiliate_url(product: Product | None) -> str:
    if not product:
        return ""
    meta = _metadata(product)
    return str(product.affiliate_url or "") if meta.get("affiliate_link_confirmed") else ""


def _automatic_affiliate(candidate: Candidate, existing: Product | None = None):
    meta = _metadata(existing) if existing else {}
    result = resolve_affiliate_link(
        listing_url=candidate.listing_url,
        item_id=candidate.item_id or candidate.external_id or "",
        catalog_product_id=candidate.catalog_product_id or "",
        existing_url=str(existing.affiliate_url or "") if existing else "",
        existing_confirmed=bool(meta.get("affiliate_link_confirmed")),
    )
    return result


def _apply_candidate_content(product: Product, candidate: Candidate) -> None:
    meta = _metadata(product)
    protected = _completed_record_is_protected(product)
    if not (protected and meta.get("manual_listing_url_override")):
        meta["listing_url"] = candidate.listing_url
    meta.update({
        "item_id": candidate.item_id or candidate.external_id,
        "catalog_product_id": candidate.catalog_product_id or "",
        "rating_source": candidate.rating_source,
        "sold_quantity_source": candidate.sold_quantity_source,
        "discovery_complete": bool(candidate.price > 0 and candidate.stock_available and candidate.picture_urls),
        "discovery_checked_at": datetime.now(timezone.utc).isoformat(),
    })
    product.source_metadata_json = json.dumps(meta, ensure_ascii=False, sort_keys=True)
    # Uma nova varredura pode preencher lacunas, mas nunca substituir conteúdo
    # já concluído pelo usuário por dados parciais/automáticos.
    if candidate.description and (not protected or not str(product.original_description or "").strip()):
        product.original_description = candidate.description[:12000]
    if candidate.picture_urls and (not protected or not str(product.media_urls or "").strip()):
        product.media_urls = "\n".join(candidate.picture_urls)
    if candidate.item_id:
        product.external_product_id = candidate.item_id


def estimate_content_scores(candidate: Candidate) -> tuple[float, float, float, float]:
    # Sem análise visual real, não inferimos qualidade pelo título. Valores
    # neutros deixam a decisão editorial para revisão humana.
    return 5.0, 5.0, 5.0, 5.0


def candidate_to_product_input(candidate: Candidate, affiliate_url: str | None = None) -> ProductInput:
    if candidate.price < 1.0 or not candidate.stock_available:
        raise ValueError("Candidato sem preço real ou indisponível")
    visual, demo, novelty, risk = estimate_content_scores(candidate)
    return ProductInput(
        title=candidate.title,
        category=ProductCategory(candidate.category),
        marketplace="mercado_livre",
        price=candidate.price,
        original_price=candidate.original_price,
        rating=candidate.rating,
        review_count=candidate.review_count,
        sold_quantity=candidate.sold_quantity,
        seller_reputation=candidate.seller_reputation,
        commission_pct=0.0,
        stock_available=candidate.stock_available,
        visual_quality=visual,
        demonstration_ease=demo,
        novelty=novelty,
        return_risk=risk,
        affiliate_url=affiliate_url or candidate.listing_url,
        media_license="oficial_marketplace" if candidate.picture_urls else "origem_nao_confirmada",
    )


def _classification(score: float, source_rank: int | None, *, metrics_pending: bool = False) -> str:
    if metrics_pending:
        return "Qualificado — métricas em atualização"
    if source_rank and source_rank <= 5:
        return "Mais vendido"
    if score >= 85:
        return "Alta demanda"
    if score >= 70:
        return "Boa oportunidade"
    if score >= 60:
        return "Potencial comercial"
    return "Reprovado"


def _status(score: float, media_ready: bool) -> str:
    if score < 50:
        return "reprovado"
    return "pronto_publicacao" if media_ready else "aprovado_comercial"


def _existing_product(db: Session, candidate: Candidate) -> Product | None:
    conditions = [Product.affiliate_url == candidate.listing_url]
    if candidate.catalog_product_id:
        marker = f"catalog_product_id={candidate.catalog_product_id}"
        conditions.append(Product.notes.contains(marker))
        # Cadastros concluídos normalmente passam a usar um link curto de
        # afiliado e podem ter título editado. O identificador estável fica no
        # metadata; ele deve ser a principal proteção contra criar outro registro.
        conditions.append(Product.source_metadata_json.contains(candidate.catalog_product_id))
    if candidate.parent_catalog_product_id:
        parent_marker = f"catalog_product_id={candidate.parent_catalog_product_id}"
        conditions.append(Product.notes.contains(parent_marker))
        conditions.append(Product.source_metadata_json.contains(candidate.parent_catalog_product_id))
    if candidate.item_id:
        conditions.append(Product.external_product_id == candidate.item_id)
        conditions.append(Product.source_metadata_json.contains(candidate.item_id))
    # O título é somente contingência para registros antigos sem IDs persistidos.
    conditions.append(Product.title == candidate.title)
    return db.scalar(select(Product).where(or_(*conditions)).order_by(Product.id.asc()).limit(1))


def _apply_product(product: Product, data: ProductInput, *, score: float, classification: str, status: str, notes: str, reasons: str) -> None:
    values = data.model_dump(mode="json")
    if _completed_record_is_protected(product):
        # Cadastros concluídos continuam recebendo métricas comerciais novas,
        # porém campos preenchidos/revisados e o estado de publicação não são
        # apagados ou rebaixados por uma descoberta posterior.
        if float(values.get("price") or 0) >= 1:
            product.price = values["price"]
        original_price = values.get("original_price")
        if original_price and float(original_price) > float(product.price or 0):
            product.original_price = original_price
        if float(values.get("rating") or 0) > 0:
            product.rating = values["rating"]
        if int(values.get("review_count") or 0) > 0:
            product.review_count = values["review_count"]
        if int(values.get("sold_quantity") or 0) > 0:
            product.sold_quantity = values["sold_quantity"]
        product.stock_available = bool(product.stock_available or values.get("stock_available"))
        return
    for key, value in values.items():
        setattr(product, key, value)
    product.notes = notes
    product.score = round(score, 2)
    product.classification = classification
    product.status = status
    product.score_reasons = reasons


def _save_preselected(db: Session, candidate: Candidate) -> tuple[bool, bool]:
    """Salva um produto ranqueado sem inventar dados comerciais ausentes."""
    existing = _existing_product(db, candidate)
    affiliate = _automatic_affiliate(candidate, existing)
    score = max(35.0, 70.0 - (min(candidate.source_rank or 20, 20) - 1) * 1.5)
    classification = "Pré-selecionado pelo ranking"
    status = "pre_selecionado"
    marker = f" catalog_product_id={candidate.catalog_product_id}." if candidate.catalog_product_id else ""
    missing = []
    if candidate.price < 1: missing.append("preço")
    if not candidate.stock_available: missing.append("disponibilidade")
    if candidate.rating <= 0: missing.append("nota")
    if candidate.review_count <= 0: missing.append("quantidade de avaliações")
    if not candidate.description: missing.append("descrição")
    if not candidate.picture_urls: missing.append("fotos")
    pending_text = ", ".join(missing) if missing else "dados finais de aprovação"
    notes = (
        f"Produto pré-selecionado pelo ranking oficial de mais vendidos na posição #{candidate.source_rank or 0}."
        f"{marker} Dados ainda pendentes: {pending_text}. Os campos já obtidos foram preservados no cadastro."
    )
    reasons = (
        f"Demanda comprovada pela posição #{candidate.source_rank or 0} no ranking oficial.\n"
        "Dados comerciais pendentes de confirmação; este registro não está aprovado para publicação."
    )
    if existing:
        current_meta = _metadata(existing)
        if _completed_record_is_protected(existing):
            before = (existing.price, existing.original_price, existing.rating, existing.review_count, existing.sold_quantity, existing.stock_available, existing.affiliate_url, existing.original_description, existing.media_urls, existing.status, existing.commission_pct)
            # Só incorpora valores novos quando a varredura realmente os trouxe.
            # Nunca transforma novamente um cadastro concluído em pre_selecionado.
            if candidate.price >= 1:
                existing.price = candidate.price
            if candidate.original_price is not None and candidate.original_price > float(existing.price or 0):
                existing.original_price = candidate.original_price
            if candidate.rating > 0:
                existing.rating = candidate.rating
            if candidate.review_count > 0:
                existing.review_count = candidate.review_count
            if candidate.sold_quantity > 0:
                existing.sold_quantity = candidate.sold_quantity
            existing.stock_available = bool(existing.stock_available or candidate.stock_available)
            if affiliate.confirmed and not current_meta.get("manual_affiliate_url_override"):
                existing.affiliate_url = affiliate.url
                current_meta["affiliate_link_confirmed"] = True
                current_meta["affiliate_link_source"] = affiliate.source
                current_meta["affiliate_link_error"] = ""
            if not current_meta.get("manual_listing_url_override"):
                current_meta["listing_url"] = candidate.listing_url
            current_meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
            existing.source_metadata_json = json.dumps(current_meta, ensure_ascii=False, sort_keys=True)
            _apply_candidate_content(existing, candidate)
            after = (existing.price, existing.original_price, existing.rating, existing.review_count, existing.sold_quantity, existing.stock_available, existing.affiliate_url, existing.original_description, existing.media_urls, existing.status, existing.commission_pct)
            return False, before != after
        changed = any((
            existing.title != candidate.title,
            str(current_meta.get("listing_url") or "") != candidate.listing_url,
            existing.status != status,
            abs((existing.score or 0) - score) > 0.01,
            existing.notes != notes,
        ))
        existing.title = candidate.title
        existing.category = candidate.category
        existing.marketplace = "mercado_livre"
        # Uma varredura parcial nunca deve apagar dados confirmados anteriormente.
        if candidate.price >= 1:
            existing.price = candidate.price
        if candidate.original_price is not None and candidate.original_price > candidate.price:
            existing.original_price = candidate.original_price
        if candidate.rating > 0:
            existing.rating = candidate.rating
        if candidate.review_count > 0:
            existing.review_count = candidate.review_count
        if candidate.sold_quantity > 0:
            existing.sold_quantity = candidate.sold_quantity
        existing.seller_reputation = 0.0
        existing.commission_pct = 0.0
        # Nunca apaga uma confirmação anterior de estoque. Quando a nova
        # varredura possui evidência positiva, atualiza para disponível.
        existing.stock_available = bool(existing.stock_available or candidate.stock_available)
        existing.visual_quality = 5.0
        existing.demonstration_ease = 5.0
        existing.novelty = 5.0
        existing.return_risk = 5.0
        if affiliate.confirmed:
            existing.affiliate_url = affiliate.url
        elif not current_meta.get("affiliate_link_confirmed"):
            existing.affiliate_url = ""
        current_meta["listing_url"] = candidate.listing_url
        current_meta["affiliate_link_confirmed"] = bool(affiliate.confirmed or current_meta.get("affiliate_link_confirmed"))
        current_meta["affiliate_link_source"] = affiliate.source
        current_meta["affiliate_link_error"] = affiliate.error
        current_meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
        existing.source_metadata_json = json.dumps(current_meta, ensure_ascii=False, sort_keys=True)
        if candidate.picture_urls:
            existing.media_license = "oficial_marketplace"
        existing.notes = notes
        existing.score = round(score, 2)
        existing.classification = classification
        existing.status = status
        existing.score_reasons = reasons
        _apply_candidate_content(existing, candidate)
        current_meta = _metadata(existing)
        current_meta["price_source"] = candidate.price_source or current_meta.get("price_source", "")
        current_meta["original_price_source"] = candidate.original_price_source or current_meta.get("original_price_source", "")
        current_meta["rating_source"] = candidate.rating_source or current_meta.get("rating_source", "")
        current_meta["sold_quantity_source"] = candidate.sold_quantity_source or current_meta.get("sold_quantity_source", "")
        existing.source_metadata_json = json.dumps(current_meta, ensure_ascii=False, sort_keys=True)
        return False, changed
    product = Product(
        title=candidate.title,
        category=candidate.category,
        marketplace="mercado_livre",
        price=candidate.price if candidate.price >= 1 else 0.0,
        original_price=candidate.original_price,
        rating=candidate.rating,
        review_count=candidate.review_count,
        sold_quantity=candidate.sold_quantity,
        seller_reputation=0.0,
        commission_pct=0.0,
        stock_available=bool(candidate.stock_available),
        visual_quality=5.0,
        demonstration_ease=5.0,
        novelty=5.0,
        return_risk=5.0,
        affiliate_url=affiliate.url if affiliate.confirmed else "",
        media_license="oficial_marketplace" if candidate.picture_urls else "origem_nao_confirmada",
        notes=notes,
        score=round(score, 2),
        classification=classification,
        status=status,
        score_reasons=reasons,
    )
    product.source_metadata_json = json.dumps({
        "listing_url": candidate.listing_url,
        "item_id": candidate.item_id or candidate.external_id or "",
        "catalog_product_id": candidate.catalog_product_id or "",
        "affiliate_link_confirmed": bool(affiliate.confirmed),
        "affiliate_link_source": affiliate.source,
        "affiliate_link_error": affiliate.error,
        "affiliate_link_checked_at": datetime.now(timezone.utc).isoformat(),
        "price_source": candidate.price_source or "",
        "original_price_source": candidate.original_price_source or "",
        "rating_source": candidate.rating_source or "",
        "sold_quantity_source": candidate.sold_quantity_source or "",
    }, ensure_ascii=False, sort_keys=True)
    _apply_candidate_content(product, candidate)
    db.add(product)
    return True, False


def run_discovery(db: Session, max_products: int = 25, progress_callback=None) -> dict[str, object]:
    """Compatibilidade pública para o núcleo consolidado de descoberta."""
    from app.services.discovery.pipeline import run_professional_discovery
    return run_professional_discovery(db, max_products=max_products, progress_callback=progress_callback)
