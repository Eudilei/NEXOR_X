from __future__ import annotations

import base64
import io
import json
import logging
import re
from dataclasses import dataclass, asdict
from typing import Any

import httpx
from PIL import Image, ImageOps

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class HybridDirection:
    image_order: list[int]
    hook: str
    narration: str
    on_screen_text: str
    scene_plan: list[dict[str, Any]]
    provider: str
    fallback_used: bool
    warning: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _clean(value: Any, limit: int) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


_ALLOWED_SCENE_ROLES = {
    "contrast", "transition", "recommended_product", "feature", "use_case",
    "detail", "proof", "cta",
}


def _has_contrast_intent(hook: str, narration: str) -> bool:
    text = f"{hook} {narration}".casefold()
    markers = (
        "erro comum", "não escolha", "nao escolha", "evite", "modelos que",
        "não são os melhores", "nao sao os melhores", "mais adequado",
        "melhor opção", "melhor opcao", "em vez de", "ao contrário", "ao contrario",
    )
    return any(marker in text for marker in markers)


def _fallback_scene_plan(image_count: int, *, contrast_intent: bool = False) -> list[dict[str, Any]]:
    if image_count <= 0:
        return []
    count = min(max(4, image_count), 7)
    if contrast_intent and count >= 2:
        roles = ["contrast", "recommended_product", "feature", "use_case", "detail", "proof", "feature"]
        objectives = ["erro comum", "produto recomendado", "benefício", "uso real", "detalhe", "prova visual", "diferencial"]
    else:
        roles = ["recommended_product", "feature", "use_case", "detail", "proof", "feature", "detail"]
        objectives = ["gancho", "benefício", "uso real", "detalhe", "prova visual", "diferencial", "reforço"]
    return [
        {"image_position": index, "objective": objectives[min(index, len(objectives) - 1)],
         "role": roles[min(index, len(roles) - 1)]}
        for index in range(count)
    ]


def _fallback_direction(*, image_count: int, hook: str, narration: str, on_screen_text: str, warning: str = "") -> HybridDirection:
    return HybridDirection(
        image_order=list(range(image_count)),
        hook=_clean(hook, 240),
        narration=_clean(narration, 1800),
        on_screen_text="\n".join([line.strip() for line in str(on_screen_text or "").splitlines() if line.strip()][:3]),
        scene_plan=_fallback_scene_plan(image_count, contrast_intent=_has_contrast_intent(hook, narration)),
        provider="zavomi_free_director_v2",
        fallback_used=True,
        warning=warning,
    )


def _image_part(content: bytes) -> dict[str, Any] | None:
    try:
        with Image.open(io.BytesIO(content)) as source:
            source.load()
            image = ImageOps.exif_transpose(source).convert("RGB")
            image.thumbnail((640, 640), Image.Resampling.LANCZOS)
            output = io.BytesIO()
            image.save(output, "JPEG", quality=82, optimize=True)
            data = output.getvalue()
            if not data:
                return None
            return {"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(data).decode("ascii")}}
    except Exception:
        return None


def _download_image_parts(urls: list[str], max_images: int = 6) -> tuple[list[dict[str, Any]], list[int]]:
    parts: list[dict[str, Any]] = []
    source_indexes: list[int] = []
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        "Referer": "https://www.mercadolivre.com.br/",
    }
    with httpx.Client(timeout=25, follow_redirects=True, headers=headers) as client:
        for index, url in enumerate(urls):
            if len(parts) >= max_images:
                break
            try:
                response = client.get(url)
                response.raise_for_status()
                if not response.headers.get("content-type", "").lower().startswith("image/"):
                    continue
                part = _image_part(response.content)
                if part:
                    parts.append(part)
                    source_indexes.append(index)
            except Exception:
                continue
    return parts, source_indexes


def _extract_json(response: httpx.Response) -> dict[str, Any]:
    payload = response.json()
    candidates = payload.get("candidates") if isinstance(payload, dict) else None
    if not candidates:
        raise RuntimeError("O Gemini não retornou uma direção de vídeo")
    parts = (((candidates[0] or {}).get("content") or {}).get("parts") or [])
    text = "".join(str(part.get("text") or "") for part in parts if isinstance(part, dict)).strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
    result = json.loads(text)
    if not isinstance(result, dict):
        raise RuntimeError("A direção retornada pelo Gemini não está em formato válido")
    return result


def create_hybrid_direction(
    *,
    product_title: str,
    description: str,
    hook: str,
    narration: str,
    on_screen_text: str,
    media_urls: list[str],
    duration_seconds: int,
) -> HybridDirection:
    """Combina o roteiro gratuito Zavomi com direção visual multimodal do Gemini.

    A função é fail-safe: qualquer indisponibilidade, limite ou resposta inválida
    mantém o roteiro e a ordem originais. Assim o motor híbrido nunca bloqueia a
    produção gratuita já existente.
    """
    fallback = _fallback_direction(
        image_count=len(media_urls), hook=hook, narration=narration, on_screen_text=on_screen_text
    )
    if not settings.gemini_api_key:
        return _fallback_direction(
            image_count=len(media_urls), hook=hook, narration=narration, on_screen_text=on_screen_text,
            warning="GEMINI_API_KEY não configurada; usado Diretor Zavomi gratuito.",
        )
    image_parts, source_indexes = _download_image_parts(media_urls)
    if not image_parts:
        return _fallback_direction(
            image_count=len(media_urls), hook=hook, narration=narration, on_screen_text=on_screen_text,
            warning="Nenhuma foto pôde ser analisada pelo Gemini; usada ordem original.",
        )

    facts = _clean(description, 2400)
    prompt = f"""
Você é o diretor de vídeos curtos da Zavomi. Analise as fotos numeradas de 1 a {len(image_parts)} e combine sua análise com o roteiro-base já aprovado.
Produto: {_clean(product_title, 300)}
Descrição factual confirmada: {facts or 'Sem descrição adicional.'}
Duração: {int(duration_seconds)} segundos.
Gancho-base: {_clean(hook, 300)}
Narração-base: {_clean(narration, 2200)}
Textos de tela-base: {_clean(on_screen_text, 700)}

Regras obrigatórias:
- Use somente características presentes na descrição ou claramente visíveis nas fotos.
- Não invente vendas, avaliações, preço, material, medidas, eficácia ou variações.
- Preserve o sentido comercial do roteiro-base e escreva em português do Brasil.
- O gancho deve ser curto e forte, sem promessas enganosas.
- A narração deve caber em aproximadamente {int(duration_seconds)} segundos.
- Escolha no máximo 7 fotos realmente diferentes e úteis; não use imagens quase iguais em sequência.
- A primeira cena deve sustentar o gancho. Se o roteiro for sobre "erro comum", ela PODE mostrar modelos inadequados como contraste intencional.
- Quando houver contraste, use no máximo 2 cenas iniciais com role "contrast" e depois uma cena "recommended_product" que apresente claramente o produto indicado.
- Depois da primeira cena "recommended_product", não volte a usar imagens de outros modelos, cores ou produtos. Mantenha o mesmo produto recomendado até o CTA.
- Se não houver contraste intencional, comece diretamente com role "recommended_product".
- A última foto do corpo deve mostrar o produto recomendado de forma clara.
- Estruture a narração em: problema, solução, benefícios verificáveis, prova visual e CTA.
- Evite repetir o nome do produto e evite frases genéricas como "produto incrível".
- Textos de tela: no máximo 3 linhas curtas, somente gancho e reforços essenciais.
- scene_plan deve usar posições da lista image_order (começando em 1), objetivos curtos e um role permitido.
- Roles permitidos: contrast, transition, recommended_product, feature, use_case, detail, proof, cta.

Responda APENAS com JSON neste formato:
{{"image_order":[1,2],"hook":"...","narration":"...","on_screen_text":["..."],"scene_plan":[{{"image_position":1,"objective":"erro comum","role":"contrast"}},{{"image_position":2,"objective":"produto recomendado","role":"recommended_product"}}]}}
""".strip()
    parts: list[dict[str, Any]] = []
    for position, part in enumerate(image_parts, 1):
        parts.append({"text": f"Foto {position}:"})
        parts.append(part)
    parts.append({"text": prompt})
    endpoint = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{settings.gemini_video_model}:generateContent"
    )
    payload = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "temperature": 0.35,
            "responseMimeType": "application/json",
            "maxOutputTokens": 1400,
        },
    }
    try:
        with httpx.Client(timeout=settings.gemini_timeout_seconds) as client:
            response = client.post(
                endpoint,
                headers={"x-goog-api-key": settings.gemini_api_key, "Content-Type": "application/json"},
                json=payload,
            )
            response.raise_for_status()
        data = _extract_json(response)
        raw_order = data.get("image_order") or []
        normalized_positions: list[int] = []
        for value in raw_order:
            try:
                position = int(value) - 1
            except (TypeError, ValueError):
                continue
            if 0 <= position < len(source_indexes) and position not in normalized_positions:
                normalized_positions.append(position)
        normalized_positions.extend(i for i in range(len(source_indexes)) if i not in normalized_positions)
        ordered_original_indexes = [source_indexes[i] for i in normalized_positions]
        ordered_original_indexes.extend(i for i in range(len(media_urls)) if i not in ordered_original_indexes)
        screen = data.get("on_screen_text")
        if isinstance(screen, list):
            screen_text = "\n".join(_clean(line, 90) for line in screen if _clean(line, 90))
        else:
            screen_text = _clean(screen, 500).replace(" | ", "\n")
        refined_hook = _clean(data.get("hook"), 240) or fallback.hook
        refined_narration = _clean(data.get("narration"), 1800) or fallback.narration
        raw_scene_plan = data.get("scene_plan") if isinstance(data.get("scene_plan"), list) else []
        scene_plan: list[dict[str, Any]] = []
        contrast_count = 0
        recommended_seen = False
        contrast_intent = _has_contrast_intent(refined_hook, refined_narration)
        for scene in raw_scene_plan[:7]:
            if not isinstance(scene, dict):
                continue
            try:
                position = int(scene.get("image_position") or 0) - 1
            except (TypeError, ValueError):
                continue
            role = _clean(scene.get("role"), 40).casefold().replace(" ", "_")
            if role not in _ALLOWED_SCENE_ROLES:
                objective_key = _clean(scene.get("objective"), 80).casefold()
                role = "contrast" if any(x in objective_key for x in ("erro", "evitar", "contraste")) else "recommended_product" if any(x in objective_key for x in ("recomend", "produto principal", "solução", "solucao")) else "feature"
            if role == "contrast":
                if not contrast_intent or recommended_seen or contrast_count >= 2:
                    continue
                contrast_count += 1
            elif role == "recommended_product":
                recommended_seen = True
            elif not recommended_seen and contrast_intent:
                role = "transition"
            if 0 <= position < len(ordered_original_indexes):
                scene_plan.append({
                    "image_position": position,
                    "objective": _clean(scene.get("objective"), 80) or "benefício",
                    "role": role,
                })
        if contrast_intent and not any(x.get("role") == "recommended_product" for x in scene_plan):
            scene_plan = _fallback_scene_plan(len(ordered_original_indexes), contrast_intent=True)
        elif len(scene_plan) < min(4, len(ordered_original_indexes)):
            scene_plan = _fallback_scene_plan(len(ordered_original_indexes), contrast_intent=contrast_intent)
        return HybridDirection(
            image_order=ordered_original_indexes,
            hook=refined_hook,
            narration=refined_narration,
            on_screen_text=screen_text or fallback.on_screen_text,
            scene_plan=scene_plan,
            provider=f"gemini:{settings.gemini_video_model}+zavomi_free_director_v2",
            fallback_used=False,
        )
    except Exception as exc:
        logger.warning("Diretor híbrido caiu para fallback: %s", exc)
        return _fallback_direction(
            image_count=len(media_urls), hook=hook, narration=narration, on_screen_text=on_screen_text,
            warning=f"Gemini indisponível; produção continuou com Diretor Zavomi: {str(exc)[:240]}",
        )
