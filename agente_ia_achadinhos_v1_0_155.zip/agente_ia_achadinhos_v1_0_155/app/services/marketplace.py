from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
from dataclasses import dataclass
import logging
import unicodedata
import json
import re
import threading
from html import unescape
from urllib.parse import parse_qs, unquote, urlparse
from typing import Any, Iterable, Literal

import httpx
from sqlalchemy.orm import Session

from app.core.config import settings
from app.services.oauth_tokens import MercadoLivreOAuthService
from app.services.categories import CATEGORY_DEFINITIONS, classify_product_category

logger = logging.getLogger(__name__)

# Estado global do runtime do navegador. Um executável ausente é uma condição do
# ambiente, não do produto; portanto detectamos uma vez por processo para não
# repetir dezenas de launches do Playwright em cada MercadoLivreClient.
_BROWSER_RUNTIME_LOCK = threading.Lock()
_BROWSER_RUNTIME_AVAILABLE: bool | None = None
_BROWSER_RUNTIME_REASON = ""


def _browser_runtime_available() -> tuple[bool, str]:
    global _BROWSER_RUNTIME_AVAILABLE, _BROWSER_RUNTIME_REASON
    if _BROWSER_RUNTIME_AVAILABLE is not None:
        return _BROWSER_RUNTIME_AVAILABLE, _BROWSER_RUNTIME_REASON
    with _BROWSER_RUNTIME_LOCK:
        if _BROWSER_RUNTIME_AVAILABLE is not None:
            return _BROWSER_RUNTIME_AVAILABLE, _BROWSER_RUNTIME_REASON
        try:
            import os
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                executable = str(pw.chromium.executable_path or "")
            if not executable or not os.path.exists(executable):
                _BROWSER_RUNTIME_AVAILABLE = False
                _BROWSER_RUNTIME_REASON = "chromium não instalado no ambiente"
            else:
                _BROWSER_RUNTIME_AVAILABLE = True
                _BROWSER_RUNTIME_REASON = ""
        except Exception as exc:
            _BROWSER_RUNTIME_AVAILABLE = False
            _BROWSER_RUNTIME_REASON = f"playwright indisponível: {exc}"[:300]
        return _BROWSER_RUNTIME_AVAILABLE, _BROWSER_RUNTIME_REASON


class MarketplaceRequestError(RuntimeError):
    """Erro controlado de acesso à API do marketplace."""

    def __init__(self, *, status_code: int | None, endpoint: str, detail: str):
        self.status_code = status_code
        self.endpoint = endpoint
        self.detail = detail[:800]
        super().__init__(f"Mercado Livre respondeu {status_code or 'erro'} em {endpoint}: {self.detail}")


@dataclass(slots=True)
class Candidate:
    external_id: str
    title: str
    category: str
    price: float
    original_price: float | None
    rating: float
    review_count: int
    sold_quantity: int
    seller_reputation: float
    stock_available: bool
    listing_url: str
    thumbnail: str
    trend_keyword: str
    source: str = "mercado_livre"
    source_rank: int | None = None
    offer_available: bool = True
    catalog_product_id: str | None = None
    parent_catalog_product_id: str | None = None
    item_id: str = ""
    description: str = ""
    picture_urls: tuple[str, ...] = ()
    rating_source: str = ""
    sold_quantity_source: str = ""
    price_source: str = ""
    original_price_source: str = ""


CATEGORY_NAME_HINTS = {item.key: item.keywords for item in CATEGORY_DEFINITIONS}

# Critérios comerciais definidos para a Zavomi. O ranking oficial é a fonte
# principal. A nota mínima é 4,0; quantidade vendida não bloqueia a entrada.
MIN_ZAVOMI_RATING = 4.0
MIN_ZAVOMI_REVIEWS = 500
MAX_HIGHLIGHT_CATEGORIES_PER_GROUP = 2
MAX_HIGHLIGHT_PRODUCTS_PER_CATEGORY = 20

# Termos usados somente para classificar tendências e categorias. A descoberta de
# itens não depende mais do endpoint bloqueado /sites/MLB/search?q=...

# Categorias raiz estáveis usadas quando a listagem pública de categorias é
# bloqueada pela camada PolicyAgent do Mercado Livre. Os IDs podem ser
# sobrescritos pela variável MERCADO_LIVRE_DISCOVERY_CATEGORY_IDS.
FALLBACK_CATEGORY_IDS = {
    "casa": ["MLB1574"],
    "cozinha": ["MLB5726"],
    "organizacao": ["MLB1574"],
    "limpeza": ["MLB1574"],
    "beleza": ["MLB1246"],
    "cuidados_pessoais": ["MLB1246"],
    "eletronicos": ["MLB1000"],
    "celulares_acessorios": ["MLB1051"],
    "informatica": ["MLB1648"],
    "ferramentas": ["MLB1132"],
    "automotivo": ["MLB1743"],
    "pet": ["MLB1071"],
    "infantil": ["MLB1132"],
    "esporte_lazer": ["MLB1276"],
    "escritorio_papelaria": ["MLB1499"],
    "moda_acessorios": ["MLB1430"],
    "viagem": ["MLB1430"],
    "jardim": ["MLB1574"],
    "seguranca": ["MLB1000"],
    "utilidades": ["MLB1574"],
}

AuthMode = Literal["authenticated", "anonymous", "auto"]

CATEGORY_TERM_HINTS = CATEGORY_NAME_HINTS



class MercadoLivreClient:
    base_url = "https://api.mercadolibre.com"

    def __init__(self, db: Session | None = None, access_token: str | None = None, timeout: float = 20.0):
        self.db = db
        self._explicit_access_token = access_token
        self.timeout = timeout
        self.oauth = MercadoLivreOAuthService()
        self._resolved_access_token: str | None = access_token
        self.warnings: list[str] = []
        self.infos: list[str] = []
        self.sources_used: list[str] = []
        self._policy_blocked_families: set[str] = set()
        self._policy_block_counts: dict[str, int] = {}
        self._policy_skipped_requests = 0
        self._browser_fallback_calls = 0
        self._browser_fallback_disabled_reason = ""
        self._browser_snapshot_cache: dict[str, dict[str, Any]] = {}
        self._browser_render_lock = threading.Lock()

    @property
    def access_token(self) -> str | None:
        # Resolve o token uma única vez por cliente. Além de evitar consultas
        # repetidas ao banco, isso permite que as leituras HTTP paralelas usem
        # apenas uma string imutável, sem compartilhar a sessão SQLAlchemy.
        if self._resolved_access_token:
            return self._resolved_access_token
        if self._explicit_access_token:
            self._resolved_access_token = self._explicit_access_token
        elif self.db is not None:
            self._resolved_access_token = self.oauth.get_valid_access_token(self.db)
        else:
            self._resolved_access_token = settings.mercado_livre_access_token
        return self._resolved_access_token

    @property
    def configured(self) -> bool:
        if self._explicit_access_token or settings.mercado_livre_access_token:
            return True
        if self.db is None:
            return False
        return self.oauth.connection_status(self.db)["connected"]

    def _headers(self, *, authenticated: bool = True) -> dict[str, str]:
        headers = {"Accept": "application/json", "User-Agent": "AgenteIAAchadinhos/0.9.1"}
        if authenticated and self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    @staticmethod
    def _response_detail(response: httpx.Response) -> str:
        try:
            payload = response.json()
            return str(payload)
        except Exception:
            return (response.text or response.reason_phrase)[:800]

    @staticmethod
    def _is_policy_block(detail: str) -> bool:
        detail_upper = detail.upper()
        return "POLICYAGENT" in detail_upper or "PA_UNAUTHORIZED_RESULT_FROM_POLICIES" in detail_upper

    @staticmethod
    def _endpoint_family(path: str) -> str:
        value = str(path or "").split("?", 1)[0]
        value = re.sub(r"/products/[^/]+/items$", "/products/{id}/items", value)
        value = re.sub(r"/products/[^/]+$", "/products/{id}", value)
        value = re.sub(r"/items/[^/]+/sale_price$", "/items/{id}/sale_price", value)
        value = re.sub(r"/items/[^/]+/prices$", "/items/{id}/prices", value)
        value = re.sub(r"/items/[^/]+/description$", "/items/{id}/description", value)
        value = re.sub(r"/items/[^/]+$", "/items/{id}", value)
        value = re.sub(r"/reviews/item/[^/]+$", "/reviews/item/{id}", value)
        return value

    def _register_policy_block(self, path: str) -> None:
        family = self._endpoint_family(path)
        count = self._policy_block_counts.get(family, 0) + 1
        self._policy_block_counts[family] = count
        # PolicyAgent é uma política de acesso, não uma falha transitória.
        # Após a primeira negativa para uma família de endpoint, não repetimos
        # dezenas de chamadas iguais na mesma varredura; usamos o fallback.
        if count >= 1:
            self._policy_blocked_families.add(family)
        message = "O Mercado Livre restringiu uma consulta detalhada; o agente usou fontes públicas alternativas."
        if message not in self.warnings:
            self.warnings.append(message)

    def _get_once(self, client: httpx.Client, endpoint: str, params: dict[str, Any] | None, authenticated: bool) -> httpx.Response:
        return client.get(endpoint, headers=self._headers(authenticated=authenticated), params=params)

    def _get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        authenticated: bool = True,
        retry_anonymous_on_forbidden: bool = False,
        auth_mode: AuthMode | None = None,
    ) -> Any:
        """Executa GET com estratégia explícita de autenticação.

        ``auto`` tenta primeiro o modo mais apropriado informado por
        ``authenticated`` e, somente em 401/403, repete no modo oposto. Isso
        contorna diferenças de política entre endpoints públicos e privados sem
        esconder o erro final.
        """
        endpoint = f"{self.base_url}{path}"
        family = self._endpoint_family(path)
        if family in self._policy_blocked_families:
            self._policy_skipped_requests += 1
            raise MarketplaceRequestError(status_code=403, endpoint=endpoint, detail="Consulta ignorada após bloqueios repetidos de política; usar fallback público")
        mode = auth_mode or ("auto" if retry_anonymous_on_forbidden else ("authenticated" if authenticated else "anonymous"))
        attempts: list[bool]
        if mode == "authenticated":
            attempts = [True]
        elif mode == "anonymous":
            attempts = [False]
        else:
            attempts = [bool(authenticated), not bool(authenticated)]

        last_response: httpx.Response | None = None
        try:
            with httpx.Client(timeout=self.timeout, follow_redirects=True) as client:
                for index, use_auth in enumerate(attempts):
                    response = self._get_once(client, endpoint, params, use_auth)
                    last_response = response
                    if response.status_code not in (401, 403) or index == len(attempts) - 1:
                        response.raise_for_status()
                        return response.json()
                    logger.warning(
                        "API ML recusou modo=%s; tentando modo=%s endpoint=%s detalhe=%s",
                        "autenticado" if use_auth else "anônimo",
                        "anônimo" if use_auth else "autenticado",
                        response.url,
                        self._response_detail(response)[:240],
                    )
        except httpx.HTTPStatusError as exc:
            detail = self._response_detail(exc.response)
            if exc.response.status_code == 403 and self._is_policy_block(detail):
                self._register_policy_block(path)
            logger.warning(
                "Falha HTTP Mercado Livre status=%s endpoint=%s detalhe=%s",
                exc.response.status_code,
                exc.request.url,
                detail,
            )
            raise MarketplaceRequestError(
                status_code=exc.response.status_code,
                endpoint=str(exc.request.url),
                detail=detail,
            ) from exc
        except httpx.RequestError as exc:
            logger.warning("Falha de rede Mercado Livre endpoint=%s erro=%s", endpoint, exc)
            raise MarketplaceRequestError(status_code=None, endpoint=endpoint, detail=str(exc)) from exc
        except ValueError as exc:
            raise MarketplaceRequestError(status_code=None, endpoint=endpoint, detail="Resposta JSON inválida") from exc

        detail = self._response_detail(last_response) if last_response is not None else "Sem resposta"
        raise MarketplaceRequestError(
            status_code=last_response.status_code if last_response is not None else None,
            endpoint=str(last_response.request.url) if last_response is not None else endpoint,
            detail=detail,
        )

    def connection_probe(self) -> dict[str, bool]:
        """Testa recursos usados pelo motor sem interromper a varredura."""
        status = {"identity": False, "trends": False, "categories": False, "highlights": False, "items": False}
        try:
            status["identity"] = isinstance(self._get("/users/me", authenticated=True), dict)
        except MarketplaceRequestError as exc:
            self.warnings.append(f"Identidade OAuth indisponível ({exc.status_code or 'rede'}): {exc.detail[:120]}")
        status["categories"] = bool(self.site_categories())
        status["trends"] = bool(self.trends())
        return status

    def trends(self, site_id: str = "MLB", category_id: str | None = None) -> list[dict[str, Any]]:
        if not self.configured:
            return []
        path = f"/trends/{site_id}" + (f"/{category_id}" if category_id else "")
        try:
            payload = self._get(path, authenticated=False, auth_mode="auto")
        except MarketplaceRequestError as exc:
            self.warnings.append(f"Tendências indisponíveis ({exc.status_code or 'rede'}): {exc.detail[:120]}")
            return []
        if isinstance(payload, list):
            if "tendencias" not in self.sources_used:
                self.sources_used.append("tendencias")
            return payload
        return []

    def site_categories(self, site_id: str = "MLB") -> list[dict[str, Any]]:
        try:
            payload = self._get(f"/sites/{site_id}/categories", authenticated=False, auth_mode="auto")
        except MarketplaceRequestError as exc:
            self.warnings.append(f"Categorias indisponíveis ({exc.status_code or 'rede'}): {exc.detail[:120]}")
            return []
        return payload if isinstance(payload, list) else []

    def category_detail(self, category_id: str) -> dict[str, Any]:
        payload = self._get(f"/categories/{category_id}", authenticated=False, auth_mode="auto")
        return payload if isinstance(payload, dict) else {}

    def highlights(self, category_id: str, site_id: str = "MLB") -> list[dict[str, Any]]:
        """Retorna os 20 mais vendidos da categoria segundo o recurso oficial /highlights."""
        payload = self._get(f"/highlights/{site_id}/category/{category_id}", authenticated=True, auth_mode="auto")
        content = payload.get("content", []) if isinstance(payload, dict) else []
        if isinstance(content, list) and content and "mais_vendidos" not in self.sources_used:
            self.sources_used.append("mais_vendidos")
        return content if isinstance(content, list) else []

    def _category_ancestor_ids(self, category_id: str) -> list[str]:
        """Retorna a categoria informada e seus ancestrais, do mais específico ao mais amplo.

        O endpoint de destaques não aceita toda categoria folha. Quando isso ocorre,
        tentamos os ancestrais declarados em ``path_from_root`` antes de desistir.
        """
        ordered: list[str] = [category_id]
        try:
            detail = self.category_detail(category_id)
        except MarketplaceRequestError as exc:
            if exc.status_code == 404:
                self.warnings.append(f"Categoria {category_id} não existe e foi ignorada.")
            return ordered
        path = detail.get("path_from_root", []) if isinstance(detail, dict) else []
        ancestors = [str(node.get("id") or "") for node in path if isinstance(node, dict) and node.get("id")]
        for ancestor_id in reversed(ancestors):
            if ancestor_id and ancestor_id not in ordered:
                ordered.append(ancestor_id)
        return ordered

    def _highlights_with_ancestor_fallback(self, category_id: str) -> tuple[list[dict[str, Any]], str | None]:
        """Consulta destaques e recua para categorias ancestrais em 404/sem conteúdo."""
        attempted: list[str] = []
        for candidate_id in self._category_ancestor_ids(category_id):
            if candidate_id in attempted:
                continue
            attempted.append(candidate_id)
            try:
                entries = self.highlights(candidate_id)
            except MarketplaceRequestError as exc:
                if exc.status_code == 404:
                    logger.info("Categoria %s sem dimensão de highlights; tentando ancestral", candidate_id)
                    continue
                self.warnings.append(
                    f"Mais vendidos da categoria {candidate_id} indisponíveis "
                    f"({exc.status_code or 'rede'}): {exc.detail[:120]}"
                )
                continue
            if entries:
                if candidate_id != category_id:
                    message = f"A categoria {category_id} não possui ranking próprio; usado o ranking da categoria superior {candidate_id}."
                    self.infos.append(message)
                    logger.info(message)
                return entries, candidate_id
        self.warnings.append(
            f"A categoria {category_id} e seus níveis superiores não devolveram ranking de mais vendidos."
        )
        return [], None


    def catalog_product_search(
        self,
        keyword: str,
        *,
        site_id: str = "MLB",
        limit: int = 10,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Pesquisa produtos ativos no catálogo oficial por palavra-chave.

        Este é o endpoint documentado para localizar páginas de produto por ``q``.
        A chamada é autenticada e não depende da busca genérica de anúncios
        ``/sites/{site}/search?q=...``, bloqueada para algumas aplicações.
        """
        keyword = " ".join(str(keyword or "").split()).strip()
        if not keyword:
            return []
        payload = self._get(
            "/products/search",
            params={
                "status": "active",
                "site_id": site_id,
                "q": keyword,
                "limit": max(1, min(int(limit or 10), 20)),
                "offset": max(0, int(offset or 0)),
            },
            authenticated=True,
            auth_mode="auto",
        )
        results = payload.get("results", []) if isinstance(payload, dict) else []
        if isinstance(results, list) and results and "catalogo_por_tendencias" not in self.sources_used:
            self.sources_used.append("catalogo_por_tendencias")
        return results if isinstance(results, list) else []

    @staticmethod
    def _extract_item_id(value: Any) -> str | None:
        """Extrai um item_id de respostas heterogêneas do catálogo.

        A API já devolveu ``item_id`` diretamente, dentro de ``item`` e, em
        alguns recursos, dentro de ``winner``/``buy_box_winner``. Evitamos usar
        o ``id`` do próprio produto de catálogo como se fosse uma publicação.
        """
        if isinstance(value, str):
            value = value.strip()
            return value if value.startswith("MLB") else None
        if not isinstance(value, dict):
            return None
        direct = str(value.get("item_id") or "").strip()
        if direct.startswith("MLB"):
            return direct
        for key in ("item", "winner", "buy_box_winner", "offer"):
            nested = value.get(key)
            found = MercadoLivreClient._extract_item_id(nested)
            if found:
                return found
        # ``id`` só é aceito quando o objeto tem sinais claros de publicação.
        candidate = str(value.get("id") or "").strip()
        item_markers = {"seller_id", "price", "available_quantity", "permalink", "listing_type_id"}
        if candidate.startswith("MLB") and item_markers.intersection(value):
            return candidate
        return None

    def _item_detail_individual(self, item_id: str) -> dict[str, Any] | None:
        try:
            payload = self._get(
                f"/items/{item_id}", authenticated=True, auth_mode="auto",
            )
        except MarketplaceRequestError as exc:
            self.warnings.append(
                f"Detalhe da oferta {item_id} indisponível ({exc.status_code or 'rede'}): {exc.detail[:100]}"
            )
            return None
        return payload if isinstance(payload, dict) and payload.get("id") else None

    def item_details(self, item_ids: Iterable[str]) -> list[dict[str, Any]]:
        ids = list(dict.fromkeys(str(item_id).strip() for item_id in item_ids if str(item_id).strip()))
        results: list[dict[str, Any]] = []
        resolved: set[str] = set()
        for start in range(0, len(ids), 20):
            chunk = ids[start : start + 20]
            if not chunk:
                continue
            try:
                payload = self._get(
                    "/items",
                    params={"ids": ",".join(chunk)},
                    authenticated=True,
                    auth_mode="auto",
                )
            except MarketplaceRequestError as exc:
                self.warnings.append(
                    f"Consulta em lote de ofertas indisponível ({exc.status_code or 'rede'}); tentando individualmente."
                )
                payload = []
            if isinstance(payload, list):
                for row in payload:
                    body = None
                    if isinstance(row, dict) and int(row.get("code") or 0) == 200 and isinstance(row.get("body"), dict):
                        body = row["body"]
                    elif isinstance(row, dict) and row.get("id"):
                        body = row
                    if isinstance(body, dict) and body.get("id"):
                        item_id = str(body["id"])
                        results.append(body)
                        resolved.add(item_id)

            # Há contas em que o multiget responde 200, porém omite corpos de
            # itens que podem ser consultados individualmente. Esse fallback
            # impede que ofertas detectadas desapareçam silenciosamente.
            for item_id in chunk:
                if item_id in resolved:
                    continue
                body = self._item_detail_individual(item_id)
                if body:
                    results.append(body)
                    resolved.add(item_id)

        if results and "detalhes_itens" not in self.sources_used:
            self.sources_used.append("detalhes_itens")
        return results


    @staticmethod
    def _first_json_ld(html: str) -> list[dict[str, Any]]:
        """Extrai blocos JSON-LD sem depender de bibliotecas de scraping."""
        blocks: list[dict[str, Any]] = []
        pattern = re.compile(
            r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
            re.IGNORECASE | re.DOTALL,
        )
        for raw in pattern.findall(html or ""):
            try:
                payload = json.loads(unescape(raw).strip())
            except Exception:
                continue
            rows = payload if isinstance(payload, list) else [payload]
            for row in rows:
                if isinstance(row, dict):
                    if isinstance(row.get("@graph"), list):
                        blocks.extend(item for item in row["@graph"] if isinstance(item, dict))
                    else:
                        blocks.append(row)
        return blocks

    @staticmethod
    def _meta_value(html: str, key: str) -> str:
        patterns = [
            rf'<meta[^>]+property=["\']{re.escape(key)}["\'][^>]+content=["\']([^"\']+)',
            rf'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']{re.escape(key)}["\']',
            rf'<meta[^>]+name=["\']{re.escape(key)}["\'][^>]+content=["\']([^"\']+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, html or "", re.IGNORECASE)
            if match:
                return unescape(match.group(1)).strip()
        return ""

    @staticmethod
    def _br_number(raw: Any) -> float:
        """Converte números brasileiros sem transformar 4.8 em 48."""
        if raw is None:
            return 0.0
        text = unescape(str(raw)).strip().replace("R$", "").replace("\xa0", " ")
        text = re.sub(r"[^0-9,.-]", "", text)
        if not text:
            return 0.0
        if "," in text:
            text = text.replace(".", "").replace(",", ".")
        elif text.count(".") > 1:
            text = text.replace(".", "")
        try:
            return float(text)
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _compact_count(raw: Any) -> int:
        """Interpreta 24.669, +10 mil e 1,2 mi sem inventar valores."""
        if raw is None:
            return 0
        text = unescape(str(raw)).strip().lower().replace("+", "")
        multiplier = 1
        if re.search(r"\b(mi|milh(?:ão|oes|ões))\b", text):
            multiplier = 1_000_000
        elif re.search(r"\b(mil|k)\b", text):
            multiplier = 1_000
        match = re.search(r"([0-9]+(?:[\.,][0-9]+)?)", text)
        if not match:
            return 0
        token = match.group(1)
        if multiplier > 1:
            value = MercadoLivreClient._br_number(token)
            return int(value * multiplier)
        digits = re.sub(r"\D", "", token)
        return int(digits or 0)

    @classmethod
    def _public_snapshot_from_html(cls, html: str, final_url: str) -> dict[str, Any]:
        """Extrai somente dados explicitamente presentes na página pública.

        Prioriza JSON-LD e metadados; os seletores textuais cobrem o HTML
        renderizado pelo Mercado Livre. Ausência de preço/estoque continua como
        dado desconhecido, nunca como valor fictício.
        """
        snapshot: dict[str, Any] = {"permalink": final_url}
        products: list[dict[str, Any]] = []
        for row in cls._first_json_ld(html):
            kind = row.get("@type")
            kinds = kind if isinstance(kind, list) else [kind]
            if any(str(value).lower() == "product" for value in kinds):
                products.append(row)
        product = products[0] if products else {}
        offers = product.get("offers") if isinstance(product, dict) else {}
        if isinstance(offers, list):
            offers = next((x for x in offers if isinstance(x, dict)), {})
        if not isinstance(offers, dict):
            offers = {}
        aggregate = product.get("aggregateRating") if isinstance(product.get("aggregateRating"), dict) else {}

        description = str(product.get("description") or "").strip()
        if not description:
            description_candidates = (
                r'"plain_text"\s*:\s*"((?:\\.|[^"\\])*)"',
                r'"description"\s*:\s*"((?:\\.|[^"\\])*)"',
            )
            for pattern in description_candidates:
                match = re.search(pattern, html or "", re.IGNORECASE | re.DOTALL)
                if not match:
                    continue
                try:
                    description = json.loads('"' + match.group(1) + '"').strip()
                except Exception:
                    description = unescape(match.group(1)).replace('\\n', '\n').replace('\\"', '"').strip()
                if len(description) >= 40:
                    break
        if not description:
            meta_description = cls._meta_value(html, "og:description")
            if len(str(meta_description or "").strip()) >= 40:
                description = str(meta_description).strip()

        def first_match(patterns: tuple[str, ...]) -> str:
            for pattern in patterns:
                match = re.search(pattern, html or "", re.IGNORECASE | re.DOTALL)
                if match:
                    return unescape(re.sub(r"<[^>]+>", "", match.group(1))).strip()
            return ""

        title = str(product.get("name") or cls._meta_value(html, "og:title") or first_match((r"<h1[^>]*>(.*?)</h1>",))).strip()
        # A página pública pode expor a galeria completa em JSON-LD ou em
        # estados JSON embutidos. Reunimos todas as URLs oficiais, sem limitar
        # a coleta à primeira imagem/og:image.
        images: list[str] = []

        def add_image(value: Any) -> None:
            if isinstance(value, dict):
                value = value.get("url") or value.get("contentUrl") or value.get("secure_url")
            if isinstance(value, (list, tuple)):
                for row in value:
                    add_image(row)
                return
            raw = str(value or "").strip()
            if not raw:
                return
            try:
                raw = bytes(raw, "utf-8").decode("unicode_escape") if "\\u" in raw else raw
            except Exception:
                pass
            raw = raw.replace("\\/", "/").replace("&amp;", "&")
            if raw.startswith("//"):
                raw = "https:" + raw
            if not raw.startswith("http"):
                return
            # Aceita somente arquivos de mídia de produto. O HTML do Mercado
            # Livre também contém botões, placeholders e páginas de bloqueio em
            # mlstatic; esses recursos não pertencem à galeria do anúncio.
            lowered = raw.lower()
            if "mlstatic.com" not in lowered:
                return
            blocked = ("sprite", "icon", "logo", "favicon", "frontend-assets", "suspicious-traffic", "placeholder", "loading")
            if any(token in lowered for token in blocked):
                return
            filename = urlparse(raw).path.rsplit("/", 1)[-1].upper()
            if not (filename.startswith("D_NQ_NP_") or filename.startswith("D_Q_NP_")):
                return
            if raw not in images:
                images.append(raw)

        add_image(product.get("image"))
        add_image(cls._meta_value(html, "og:image"))

        # URLs podem estar escapadas dentro de scripts de estado da página.
        html_unescaped = (html or "").replace("\\/", "/").replace("\\u002F", "/").replace("\\u002f", "/")
        for match in re.finditer(r'https?://[^"\s<>]+?mlstatic\.com/[^"\s<>]+', html_unescaped, re.I):
            candidate = unescape(match.group(0)).rstrip("\\,;)]}")
            add_image(candidate)

        # Também cobre campos JSON comuns sem depender da ordem do payload.
        for pattern in (
            r'"(?:secure_url|url|src|image|imageUrl|zoom)"\s*:\s*"(https?://[^" ]+mlstatic\.com/[^" ]+)"',
            r'"(?:secure_url|url|src|image|imageUrl|zoom)"\s*:\s*"(//[^" ]+mlstatic\.com/[^" ]+)"',
        ):
            for match in re.finditer(pattern, html_unescaped, re.I):
                add_image(match.group(1))

        images = images[:24]

        price = cls._br_number(offers.get("price") or offers.get("lowPrice") or cls._meta_value(html, "product:price:amount"))
        if price < 1:
            fraction = first_match((
                r'andes-money-amount__fraction[^>]*>\s*([0-9\.]+)',
                r'ui-pdp-price__second-line[^>]*>.*?andes-money-amount__fraction[^>]*>\s*([0-9\.]+)',
                r'"price"\s*:\s*\{[^{}]*?"fraction"\s*:\s*([0-9]+)',
                r'"current_price"\s*:\s*([0-9]+(?:[\.,][0-9]+)?)',
            ))
            cents = first_match((r'andes-money-amount__cents[^>]*>\s*([0-9]{1,2})',))
            price = cls._br_number(fraction)
            if price >= 1 and cents:
                price += cls._br_number(cents) / 100

        rating = cls._br_number(aggregate.get("ratingValue"))
        if rating <= 0:
            rating = cls._br_number(first_match((
                r'ui-review-capability__rating__average[^>]*>\s*([0-5](?:[\.,][0-9])?)',
                r'ui-pdp-review__rating[^>]*>\s*([0-5](?:[\.,][0-9])?)',
                r'poly-reviews__rating[^>]*>\s*([0-5](?:[\.,][0-9])?)',
                r'"rating_average"\s*:\s*([0-5](?:[\.,][0-9])?)',
                r'"ratingAverage"\s*:\s*([0-5](?:[\.,][0-9])?)',
                r'"ratingValue"\s*:\s*"?([0-5](?:[\.,][0-9])?)',
            )))
        reviews = cls._compact_count(aggregate.get("reviewCount") or aggregate.get("ratingCount"))
        if reviews <= 0:
            reviews = cls._compact_count(first_match((
                r'([+0-9\.,]+\s*(?:mil|mi|milh(?:ão|ões))?)\s+(?:avalia(?:ç|c)[õo]es|opini(?:õ|o)es)',
                r'ui-pdp-review__amount[^>]*>\s*\(?\s*([+0-9\.,]+\s*(?:mil|mi)?)',
                r'poly-reviews__total[^>]*>\s*\(?\s*([+0-9\.,]+\s*(?:mil|mi)?)',
                r'"reviews_count"\s*:\s*([0-9]+)',
                r'"review_count"\s*:\s*([0-9]+)',
                r'"ratings_count"\s*:\s*([0-9]+)',
                r'"ratingCount"\s*:\s*"?([0-9]+)',
                r'"reviewCount"\s*:\s*"?([0-9]+)',
            )))

        sold_text = first_match((
            r'((?:mais\s+de\s+)?[+0-9\.,]+\s*(?:mil|mi|milh(?:ão|ões))?\s+vendidos)',
            r'((?:mais\s+de\s+)?[+0-9\.,]+\s*(?:mil|mi|milh(?:ão|ões))?\s+vendas)',
        ))
        sold = cls._compact_count(sold_text)
        if sold <= 0:
            sold = cls._compact_count(first_match((
                r'"sold_quantity"\s*:\s*([0-9]+)',
                r'"soldQuantity"\s*:\s*([0-9]+)',
            )))
        sold_is_minimum = bool(sold_text and re.search(r'\bmais\s+de\b|\+', sold_text, re.I))

        availability_text = str(offers.get("availability") or "").lower()
        page_text = re.sub(r"<[^>]+>", " ", html or "")
        page_text = re.sub(r"\s+", " ", unescape(page_text)).lower()
        explicit_unavailable = any(token in availability_text for token in ("outofstock", "discontinued", "soldout")) or any(
            phrase in page_text for phrase in (
                "este produto está indisponível", "este produto esta indisponivel",
                "produto indisponível", "produto indisponivel", "anúncio pausado", "anuncio pausado",
            )
        )
        explicit_available = any(token in availability_text for token in ("instock", "limitedavailability", "preorder")) or any(
            phrase in page_text for phrase in ("comprar agora", "adicionar ao carrinho", "chegará grátis", "chegara gratis")
        )
        status = "inactive" if explicit_unavailable else ("active" if explicit_available else "unknown")

        original_price = cls._br_number(
            offers.get("highPrice")
            or first_match((
                r'ui-pdp-price__original-value[^>]*>.*?andes-money-amount__fraction[^>]*>\s*([0-9\.]+)',
                r'andes-money-amount--previous[^>]*>.*?andes-money-amount__fraction[^>]*>\s*([0-9\.]+)',
                r'"original_price"\s*:\s*([0-9]+(?:[\.,][0-9]+)?)',
            ))
        )
        if original_price <= price:
            original_price = 0.0

        # Algumas PDPs públicas expõem o anúncio vencedor nos estados JSON.
        # Extrair o ITEM_ID daqui permite completar reviews/preço mesmo quando
        # buy_box_winner da API não está visível para a aplicação.
        public_item_id = ""
        for pattern in (
            r'"item_id"\s*:\s*"(MLB\d+)"',
            r'"itemId"\s*:\s*"(MLB\d+)"',
            r'"itemId"\s*:\s*"?(\d{7,})"?',
            r'produto\.mercadolivre\.com\.br/MLB-(\d+)-',
        ):
            match = re.search(pattern, html_unescaped, re.I)
            if match:
                raw = str(match.group(1) or "").upper()
                public_item_id = raw if raw.startswith("MLB") else f"MLB{raw}"
                if re.fullmatch(r"MLB\d+", public_item_id):
                    break
                public_item_id = ""

        snapshot.update({
            "name": title,
            "price": price,
            "original_price": original_price or None,
            "rating": rating,
            "reviews_count": reviews,
            "sold_quantity": sold,
            "sold_quantity_display": sold_text.strip() if sold_text else "",
            "sold_quantity_is_minimum": sold_is_minimum,
            "status": status,
            "available_quantity": 1 if explicit_available and not explicit_unavailable else (0 if explicit_unavailable else None),
            "availability_confirmed": bool(explicit_available or explicit_unavailable),
            "pictures": [{"url": image} for image in images],
            "description": description,
            "item_id": public_item_id or None,
            "public_page_enriched": True,
        })
        return snapshot

    @staticmethod
    def _safe_product_permalink(requested_url: str, final_url: str) -> str:
        """Nunca persiste URLs de login/verificação como link do produto."""
        blocked_parts = (
            "/gz/account-verification", "/account-verification", "/login",
            "/security", "/registration", "/oauth", "/auth",
        )

        def valid(candidate: str) -> bool:
            try:
                parsed = urlparse(str(candidate or "").strip())
            except Exception:
                return False
            host = parsed.netloc.lower()
            path = parsed.path.lower()
            if not parsed.scheme.startswith("http") or not host:
                return False
            if not any(domain in host for domain in ("mercadolivre.com", "mercadolibre.com", "meli.la")):
                return False
            if any(part in path for part in blocked_parts):
                return False
            return "/p/" in path or "produto.mercadolivre.com.br" in host or "produto.mercadolibre.com" in host

        # Alguns redirects de segurança carregam o destino real no parâmetro go.
        try:
            parsed_final = urlparse(str(final_url or ""))
            params = parse_qs(parsed_final.query)
            go_target = unquote((params.get("go") or [""])[0])
        except Exception:
            go_target = ""

        for candidate in (final_url, go_target, requested_url):
            if valid(candidate):
                return str(candidate).strip()
        return str(requested_url or final_url or "").strip()

    @classmethod
    def merge_public_snapshots(cls, *snapshots: dict[str, Any]) -> dict[str, Any]:
        """Combina PDP da oferta e PDP de catálogo sem perder métricas agregadas.

        O anúncio individual costuma ser melhor para preço/fotos/estoque, enquanto
        a página /p/{catalog_product_id} frequentemente expõe nota e quantidade
        de opiniões agregadas do produto. Para reviews/vendas usamos o maior valor
        explicitamente observado; isso nunca fabrica uma métrica.
        """
        merged: dict[str, Any] = {}
        best_rating = 0.0
        best_reviews = 0
        best_sold = 0
        sold_display = ""
        sold_is_minimum = False
        for snap in snapshots:
            if not isinstance(snap, dict) or not snap:
                continue
            merged = cls._merge_product_data(merged, snap)
            r = cls._safe_float(snap.get("rating") or snap.get("rating_average"), 0.0)
            c = cls._safe_int(snap.get("reviews_count") or snap.get("review_count"), 0)
            q = cls._safe_int(snap.get("sold_quantity"), 0)
            if r > best_rating:
                best_rating = r
            if c > best_reviews:
                best_reviews = c
            if q > best_sold:
                best_sold = q
                sold_display = str(snap.get("sold_quantity_display") or "").strip()
                sold_is_minimum = bool(snap.get("sold_quantity_is_minimum"))
        if best_rating > 0:
            merged["rating"] = best_rating
            merged["rating_average"] = best_rating
        if best_reviews > 0:
            merged["reviews_count"] = best_reviews
            merged["review_count"] = best_reviews
        if best_sold > 0:
            merged["sold_quantity"] = best_sold
            merged["sold_quantity_display"] = sold_display
            merged["sold_quantity_is_minimum"] = sold_is_minimum
        return merged

    def public_product_snapshot(self, url: str) -> dict[str, Any]:
        parsed = urlparse(str(url or "").strip())
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Link inválido")
        host = parsed.netloc.lower()
        if "mercadolivre.com" not in host and "mercadolibre.com" not in host and "meli.la" not in host:
            raise ValueError("Use um link do Mercado Livre")
        headers = {
            "Accept": "text/html,application/xhtml+xml",
            "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
        }
        try:
            with httpx.Client(timeout=self.timeout, follow_redirects=True, headers=headers) as client:
                response = client.get(str(url))
                response.raise_for_status()
                permalink = self._safe_product_permalink(str(url), str(response.url))
                return self._public_snapshot_from_html(response.text, permalink)
        except httpx.HTTPError as exc:
            raise MarketplaceRequestError(status_code=getattr(getattr(exc, "response", None), "status_code", None), endpoint=str(url), detail=str(exc)) from exc

    def browser_product_snapshot(self, url: str) -> dict[str, Any]:
        """Renderiza a PDP pública em Chromium somente como último fallback.

        Não autentica, não reutiliza cookies pessoais, não resolve CAPTCHA e possui
        orçamento/timeout rígidos para nunca prender a varredura. Se o navegador
        não estiver disponível no ambiente, o agente continua normalmente.
        """
        target = str(url or "").strip()
        parsed = urlparse(target)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return {}
        host = parsed.netloc.lower()
        if "mercadolivre.com" not in host and "mercadolibre.com" not in host and "meli.la" not in host:
            return {}
        if not settings.mercado_livre_browser_fallback_enabled:
            return {}
        runtime_ok, runtime_reason = _browser_runtime_available()
        if not runtime_ok:
            self._browser_fallback_disabled_reason = runtime_reason
            warning = "Chromium não está disponível no servidor; o agente seguirá sem fallback de navegador."
            if warning not in self.warnings:
                self.warnings.append(warning)
            return {}
        if target in self._browser_snapshot_cache:
            return dict(self._browser_snapshot_cache[target])
        max_calls = max(0, int(settings.mercado_livre_browser_max_products_per_scan or 0))
        if self._browser_fallback_calls >= max_calls:
            return {}
        if self._browser_fallback_disabled_reason:
            return {}
        self._browser_fallback_calls += 1
        lock_timeout = max(3.0, float(settings.mercado_livre_browser_timeout_seconds or 7.0) + 2.0)
        if not self._browser_render_lock.acquire(timeout=lock_timeout):
            logger.info("Fallback de navegador ocupado; produto seguirá sem bloquear a varredura: %s", target)
            return {}
        try:
            from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
        except Exception as exc:
            self._browser_render_lock.release()
            self._browser_fallback_disabled_reason = f"playwright indisponível: {exc}"
            logger.info("Fallback de navegador indisponível: %s", exc)
            warning = "Fallback de navegador indisponível no servidor; a coleta continuou pelas APIs e páginas públicas."
            if warning not in self.warnings:
                self.warnings.append(warning)
            return {}

        timeout_ms = max(3000, int(float(settings.mercado_livre_browser_timeout_seconds or 7) * 1000))
        wait_ms = max(0, min(4000, int(settings.mercado_livre_browser_wait_ms or 0)))
        browser = None
        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(
                    headless=True,
                    args=[
                        "--no-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-gpu",
                        "--disable-background-networking",
                    ],
                )
                context = browser.new_context(
                    user_agent="Mozilla/5.0 (Linux; Android 13; SM-A366E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Mobile Safari/537.36",
                    viewport={"width": 412, "height": 915},
                    locale="pt-BR",
                )
                page = context.new_page()
                page.set_default_timeout(timeout_ms)
                response = page.goto(target, wait_until="domcontentloaded", timeout=timeout_ms)
                if response is not None and response.status >= 400:
                    context.close()
                    browser.close()
                    self._browser_render_lock.release()
                    return {}
                if wait_ms:
                    page.wait_for_timeout(wait_ms)
                # Um pequeno scroll ajuda componentes lazy/dinâmicos a materializar
                # texto de reputação sem depender de interação humana.
                try:
                    page.evaluate("window.scrollTo(0, Math.min(document.body.scrollHeight, 1800))")
                    page.wait_for_timeout(min(wait_ms, 900))
                except Exception:
                    pass
                html = page.content()
                final_url = page.url or target
                context.close()
                browser.close()
                snapshot = self._public_snapshot_from_html(html, self._safe_product_permalink(target, final_url))
                if snapshot:
                    snapshot["browser_rendered"] = True
                    snapshot["browser_source"] = "playwright_public_page"
                    self._browser_snapshot_cache[target] = dict(snapshot)
                    if "browser_publico" not in self.sources_used:
                        self.sources_used.append("browser_publico")
                self._browser_render_lock.release()
                return snapshot
        except PlaywrightTimeoutError as exc:
            logger.info("Fallback de navegador expirou url=%s: %s", target, exc)
            if self._browser_render_lock.locked():
                self._browser_render_lock.release()
            return {}
        except Exception as exc:
            # Erros de executável/dependência desativam novas tentativas nesta
            # varredura para não repetir launches caros sem chance de sucesso.
            text = str(exc)
            if "Executable doesn't exist" in text or "Host system is missing dependencies" in text:
                self._browser_fallback_disabled_reason = text[:300]
                warning = "Chromium não está disponível no servidor; o fallback de navegador foi desativado nesta varredura."
                if warning not in self.warnings:
                    self.warnings.append(warning)
            logger.info("Fallback de navegador falhou url=%s: %s", target, text[:300])
            try:
                if browser is not None:
                    browser.close()
            except Exception:
                pass
            if self._browser_render_lock.locked():
                self._browser_render_lock.release()
            return {}

    @staticmethod
    def _merge_product_data(primary: dict[str, Any], enrichment: dict[str, Any]) -> dict[str, Any]:
        merged = dict(primary or {})
        for key, value in (enrichment or {}).items():
            current = merged.get(key)
            missing = current in (None, "", 0, 0.0, [], {})
            if missing and value not in (None, "", [], {}):
                merged[key] = value
        # Indisponibilidade explícita da página pública prevalece.
        if enrichment.get("status") == "inactive":
            merged["status"] = "inactive"
            merged["available_quantity"] = 0
        return merged

    @staticmethod
    def picture_urls(payload: dict[str, Any], *, limit: int = 12) -> list[str]:
        """Extrai imagens oficiais sem duplicação e prioriza URLs seguras."""
        urls: list[str] = []
        pictures = payload.get("pictures") or [] if isinstance(payload, dict) else []
        if isinstance(pictures, list):
            for picture in pictures:
                if not isinstance(picture, dict):
                    continue
                url = str(picture.get("secure_url") or picture.get("url") or "").strip()
                if url.startswith("http") and url not in urls:
                    urls.append(url)
                    if len(urls) >= max(1, limit):
                        return urls
        for key in ("secure_thumbnail", "thumbnail", "picture"):
            url = str(payload.get(key) or "").strip() if isinstance(payload, dict) else ""
            if url.startswith("http") and url not in urls:
                urls.append(url)
        return urls[:max(1, limit)]


    def item_sale_prices(self, item_id: str) -> dict[str, Any]:
        """Obtém preço atual e preço regular pelas APIs específicas de preço.

        Prioriza ``/sale_price`` com contexto marketplace e usa ``/prices``
        como contingência. Nunca cria preço anterior quando a fonte não o expõe.
        """
        value = str(item_id or "").strip().upper()
        if not re.fullmatch(r"MLB\d+", value):
            return {}

        def normalize(payload: Any, source: str) -> dict[str, Any]:
            if not isinstance(payload, dict):
                return {}
            amount = self._safe_float(payload.get("amount") or payload.get("price"), 0.0)
            regular = self._optional_float(
                payload.get("regular_amount") or payload.get("regular_price") or payload.get("original_price")
            )
            if amount < 1:
                return {}
            if regular is not None and regular <= amount:
                regular = None
            return {
                "price": amount,
                "original_price": regular,
                "price_source": source,
                "original_price_source": source if regular else "unavailable",
            }

        try:
            payload = self._get(
                f"/items/{value}/sale_price",
                params={"context": "channel_marketplace"},
                authenticated=True,
                auth_mode="auto",
            )
            result = normalize(payload, "sale_price_api")
            if result:
                if "precos" not in self.sources_used:
                    self.sources_used.append("precos")
                return result
        except MarketplaceRequestError as exc:
            logger.info("Preço específico indisponível item=%s status=%s", value, exc.status_code)

        try:
            payload = self._get(
                f"/items/{value}/prices",
                authenticated=True,
                auth_mode="auto",
            )
        except MarketplaceRequestError:
            return {}
        prices = payload.get("prices", []) if isinstance(payload, dict) else []
        if not isinstance(prices, list):
            return {}
        selected: dict[str, Any] = {}
        for row in prices:
            if not isinstance(row, dict):
                continue
            conditions = row.get("conditions") if isinstance(row.get("conditions"), dict) else {}
            context_restrictions = conditions.get("context_restrictions") or []
            candidate = normalize(row, "prices_api")
            if not candidate:
                continue
            if "channel_marketplace" in context_restrictions:
                selected = candidate
                break
            if not selected:
                selected = candidate
        if selected and "precos" not in self.sources_used:
            self.sources_used.append("precos")
        return selected

    def item_reviews(self, item_id: str, catalog_product_id: str = "") -> dict[str, Any]:
        """Consulta nota e avaliações do item, incluindo o contexto de catálogo.

        A API de opiniões pode exigir autenticação e, para itens vinculados ao
        catálogo, o ``catalog_product_id`` evita receber métricas vazias da oferta.
        """
        value = str(item_id or "").strip().upper()
        catalog = str(catalog_product_id or "").strip().upper()
        if not re.fullmatch(r"MLB\d+", value):
            return {}
        endpoint = f"/reviews/item/{value}"
        if re.fullmatch(r"MLB\d+", catalog):
            endpoint += f"?catalog_product_id={catalog}"
        attempts = (
            dict(authenticated=True, auth_mode="auto"),
            dict(authenticated=False, retry_anonymous_on_forbidden=True),
        )
        for options in attempts:
            try:
                payload = self._get(endpoint, **options)
                if isinstance(payload, dict) and payload:
                    return payload
            except MarketplaceRequestError:
                continue
        return {}

    @classmethod
    def review_metrics(cls, payload: dict[str, Any]) -> tuple[float, int, dict[str, int]]:
        """Normaliza nota, total e distribuição sem confundir página de reviews."""
        if not isinstance(payload, dict):
            return 0.0, 0, {}
        rating = cls._safe_float(payload.get("rating_average"), 0.0)
        levels_raw = payload.get("rating_levels") or {}
        levels: dict[str, int] = {}
        if isinstance(levels_raw, dict):
            for key in ("one_star", "two_star", "three_star", "four_star", "five_star"):
                levels[key] = max(0, cls._safe_int(levels_raw.get(key), 0))
        paging = payload.get("paging") or {}
        total = cls._safe_int(paging.get("total") if isinstance(paging, dict) else 0, 0)
        if total <= 0 and levels:
            total = sum(levels.values())
        return rating, total, levels

    def item_description(self, item_id: str) -> str:
        """Obtém a descrição original publicada para uma oferta do Mercado Livre."""
        value = str(item_id or "").strip().upper()
        if not re.fullmatch(r"MLB\d+", value):
            return ""
        try:
            payload = self._get(
                f"/items/{value}/description",
                authenticated=True,
                auth_mode="auto",
            )
        except MarketplaceRequestError as exc:
            self.warnings.append(
                f"Descrição da oferta {value} indisponível pela API ({exc.status_code or 'rede'})."
            )
            try:
                public = self.public_product_snapshot(self.item_public_url(value))
                return str(public.get("description") or "").strip()
            except Exception:
                return ""
        if not isinstance(payload, dict):
            return ""
        return str(payload.get("plain_text") or payload.get("text") or "").strip()

    def listing_media_and_description(
        self,
        *,
        link: str,
        catalog_product: dict[str, Any] | None = None,
        allow_item_api: bool = True,
    ) -> dict[str, Any]:
        """Coleta automaticamente fotos e descrição do anúncio original.

        Para links de catálogo, usa o vencedor da Buy Box quando acessível. Para
        links de publicação, consulta diretamente o item. Nunca inventa mídia ou
        descrição e devolve listas vazias quando a API não expõe os dados.
        """
        parsed = urlparse(str(link or "").strip())
        path = unquote(parsed.path or "")
        raw_ids = re.findall(r"MLB[-_]?(\d+)", path, flags=re.I)
        url_id = f"MLB{raw_ids[0]}" if raw_ids else ""
        is_catalog_url = bool(re.search(r"/p/MLB\d+", path, flags=re.I))

        product = dict(catalog_product or {})
        item_id = ""
        item: dict[str, Any] = {}

        if product:
            item_id = str(self._extract_item_id(self._winner_payload(product)) or "")
        elif is_catalog_url and url_id:
            try:
                product = self.product_detail(url_id)
                item_id = str(self._extract_item_id(self._winner_payload(product)) or "")
            except MarketplaceRequestError as exc:
                self.warnings.append(f"Produto de catálogo sem mídia oficial acessível ({exc.status_code or 'rede'}).")
        elif url_id:
            item_id = url_id

        if item_id and allow_item_api:
            item = self._item_detail_individual(item_id) or {}

        pictures = self.picture_urls(item, limit=12)
        if not pictures:
            pictures = self.picture_urls(product, limit=12)

        # Não agregamos imagens de produtos filhos/variações. Elas podem ser de
        # outra cor, modelo ou oferta e não pertencem necessariamente ao anúncio
        # escolhido pelo usuário. A galeria deve vir somente do item resolvido e
        # da página pública desse mesmo produto.
        pictures = pictures[:24]
        description = self.item_description(item_id) if item_id else ""
        public_snapshot: dict[str, Any] = {}
        # Mesmo quando a API retorna apenas a capa, a página pública pode
        # conter a galeria completa. Sempre fazemos a tentativa pública para
        # completar a lista (até 24 fotos), sem duplicar URLs.
        if not description or len(pictures) < 24:
            for public_url in dict.fromkeys([
                self.item_public_url(item_id) if item_id else "",
                str(link or "").strip(),
            ]):
                if not public_url:
                    continue
                try:
                    public_snapshot = self.public_product_snapshot(public_url)
                    public_item = str(public_snapshot.get("item_id") or "").strip().upper()
                    if not item_id and re.fullmatch(r"MLB\d+", public_item):
                        item_id = public_item
                    if not description:
                        description = str(public_snapshot.get("description") or "").strip()
                    for picture in self.picture_urls(public_snapshot, limit=24):
                        if picture not in pictures:
                            pictures.append(picture)
                    # Não interrompe ao encontrar apenas uma imagem. Outras
                    # fontes públicas podem conter o restante da galeria.
                    if description and len(pictures) >= 24:
                        break
                except Exception:
                    continue
        pictures = pictures[:24]

        return {
            "item_id": item_id,
            "pictures": pictures,
            "description": description,
            "media_source": "official_marketplace" if pictures else "",
            "public_snapshot": public_snapshot,
        }

    def product_detail(self, product_id: str) -> dict[str, Any]:
        """Obtém a página de produto e o Buy Box em uma única chamada oficial.

        O detalhe de ``/products/{id}`` é suficiente para montar a oportunidade
        comercial. Não consultamos ``/items/{item_id}`` de terceiros, pois esse
        recurso pode ser bloqueado pelo PolicyAgent mesmo quando o Buy Box é
        visível no produto de catálogo.
        """
        payload = self._get(
            f"/products/{product_id}",
            authenticated=True,
            auth_mode="auto",
        )
        return payload if isinstance(payload, dict) else {}

    @staticmethod
    def _winner_payload(product: dict[str, Any]) -> dict[str, Any]:
        """Normaliza o vencedor da Buy Box sem confundir produto com anúncio.

        A resposta oficial normalmente usa ``buy_box_winner.item_id``. Alguns
        recursos intermediários encapsulam os mesmos dados em ``item``,
        ``winner`` ou ``offer``. Somente dicionários com preço ou item_id são
        aceitos como oferta comercial.
        """
        winner = product.get("buy_box_winner") if isinstance(product, dict) else None
        if not isinstance(winner, dict):
            return {}
        merged = dict(winner)
        for key in ("item", "winner", "offer"):
            nested = winner.get(key)
            if isinstance(nested, dict):
                merged.update(nested)
        if not (merged.get("item_id") or merged.get("price")):
            return {}
        return merged

    @staticmethod
    def _child_product_ids(product: dict[str, Any]) -> list[str]:
        """Extrai produtos filhos compráveis de parents/pickers sem duplicar IDs."""
        ids: list[str] = []
        for raw in product.get("children_ids") or []:
            value = str(raw or "").strip()
            if value and value not in ids:
                ids.append(value)
        for picker in product.get("pickers") or []:
            if not isinstance(picker, dict):
                continue
            for child in picker.get("products") or []:
                if not isinstance(child, dict):
                    continue
                value = str(child.get("product_id") or "").strip()
                if value and value != str(product.get("id") or "") and value not in ids:
                    ids.append(value)
        return ids

    @classmethod
    def _rating_and_reviews(cls, product: dict[str, Any]) -> tuple[float, int]:
        """Extrai nota e quantidade de avaliações de formatos conhecidos da API."""
        reviews = product.get("reviews") if isinstance(product.get("reviews"), dict) else {}
        rating = cls._safe_float(
            product.get("rating")
            or product.get("rating_average")
            or reviews.get("rating_average")
            or reviews.get("average")
            or reviews.get("rate"),
            0.0,
        )
        count = cls._safe_int(
            product.get("reviews_count")
            or product.get("review_count")
            or product.get("ratings_count")
            or reviews.get("total")
            or reviews.get("count")
            or reviews.get("reviews_count"),
            0,
        )
        return rating, count

    @classmethod
    def _candidate_from_product(
        cls,
        product: dict[str, Any],
        *,
        internal_category: str,
        trend_keyword: str,
        source: str,
        source_rank: int,
        parent_catalog_product_id: str | None = None,
    ) -> Candidate | None:
        """Monta uma oportunidade sem acessar a publicação de outro vendedor."""
        if not isinstance(product, dict):
            return None
        product_id = str(product.get("id") or "").strip()
        title = str(product.get("name") or product.get("title") or product.get("family_name") or "").strip()
        if not product_id or not title:
            return None

        winner = cls._winner_payload(product)
        item_id = cls._extract_item_id(winner) or str(product.get("item_id") or "").strip().upper() or None
        # O produto pode ser comercialmente válido mesmo sem uma Buy Box visível
        # para a aplicação. Priorizamos o preço do vencedor quando disponível e,
        # em seguida, os campos públicos do próprio produto de catálogo.
        price = cls._safe_float(
            winner.get("price")
            or product.get("price")
            or product.get("minimum_price")
            or product.get("min_price"),
            0.0,
        )
        status = str(product.get("status") or winner.get("status") or "active").lower()
        available_probe = winner.get("available_quantity")
        if available_probe is None:
            available_probe = winner.get("available_quantity_range") or winner.get("stock")
        if available_probe is None:
            available_probe = product.get("available_quantity") or product.get("stock")
        availability_confirmed = bool(product.get("availability_confirmed")) or available_probe is not None
        stock_available = cls._stock_available(available_probe) if available_probe is not None else False
        offer_available = bool(price >= 1.0 and status == "active" and availability_confirmed and stock_available)

        original_price = cls._optional_float(
            winner.get("original_price") or product.get("original_price")
        )
        available_raw = available_probe
        seller_id = winner.get("seller_id")
        seller = winner.get("seller") if isinstance(winner.get("seller"), dict) else {}
        reputation_level = str(seller.get("reputation_level_id") or winner.get("reputation_level_id") or "")
        seller_rep = (
            cls._safe_float(winner.get("seller_reputation"), 0.0)
            or cls._reputation_score(reputation_level)
            if reputation_level else 0.0
        )
        sold_quantity = cls._sold_reference(
            winner.get("sold_quantity") or winner.get("sold_quantity_range") or product.get("sold_quantity")
        )
        # Nunca inventamos quantidade vendida. Quando a API não expõe esse dado,
        # a posição no ranking oficial é usada separadamente como sinal de
        # demanda, sem aparecer como número fictício de vendas.

        listing_url = str(product.get("permalink") or cls.catalog_product_url(product_id)).strip()
        return Candidate(
            external_id=item_id or product_id,
            title=title[:180],
            category=internal_category,
            price=price if offer_available else 0.0,
            original_price=original_price if offer_available else None,
            rating=cls._rating_and_reviews(product)[0],
            review_count=cls._rating_and_reviews(product)[1],
            sold_quantity=sold_quantity if offer_available else 0,
            seller_reputation=seller_rep if seller_id or winner else 0.0,
            stock_available=stock_available and status == "active",
            listing_url=listing_url,
            thumbnail=cls.catalog_thumbnail(product),
            trend_keyword=trend_keyword or "catálogo",
            source=source,
            source_rank=max(1, source_rank),
            offer_available=offer_available,
            catalog_product_id=product_id,
            parent_catalog_product_id=parent_catalog_product_id,
            item_id=str(product.get("item_id") or item_id or ""),
            description=str(product.get("description") or "").strip(),
            picture_urls=tuple(cls.picture_urls(product, limit=24)),
            rating_source=str(product.get("rating_source") or ("reviews_api" if cls._rating_and_reviews(product)[1] > 0 else "")),
            sold_quantity_source=str(product.get("sold_quantity_source") or ("listing" if sold_quantity > 0 and item_id else "catalog" if sold_quantity > 0 else "")),
            price_source=str(product.get("price_source") or ("listing_or_buy_box" if price > 0 else "")),
            original_price_source=str(product.get("original_price_source") or ("listing_or_buy_box" if original_price else "")),
        )

    def product_winner_item(self, product_id: str) -> str | None:
        payload = self._get(f"/products/{product_id}", authenticated=True, auth_mode="auto")
        if not isinstance(payload, dict):
            return None
        return self._extract_item_id(payload.get("buy_box_winner"))


    def product_offers(self, product_id: str, *, limit: int = 10) -> list[dict[str, Any]]:
        """Retorna as ofertas da PDP preservando os dados comerciais da resposta.

        ``/products/{product_id}/items`` já retorna dados da publicação concorrente
        (como item_id, preço, status e, quando exposto, quantidade disponível).
        Versões anteriores descartavam toda essa resposta e guardavam apenas o ID,
        obrigando o agente a consultar novamente ``/items/{id}``, justamente o
        recurso que costuma receber 403/PolicyAgent para ofertas de terceiros.
        """
        endpoint = f"/products/{product_id}/items"
        params = {"limit": max(1, min(int(limit or 10), 20))}
        payload = None
        errors: list[MarketplaceRequestError] = []
        for options in (
            {"authenticated": True, "auth_mode": "auto"},
            {"authenticated": False, "retry_anonymous_on_forbidden": True},
        ):
            try:
                payload = self._get(endpoint, params=params, **options)
                if payload is not None:
                    break
            except MarketplaceRequestError as exc:
                errors.append(exc)
        if payload is None and errors:
            raise errors[-1]
        rows = payload.get("results", []) if isinstance(payload, dict) else payload
        if not isinstance(rows, list):
            return []
        offers: list[dict[str, Any]] = []
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            row = dict(raw)
            item_id = self._extract_item_id(row) or str(row.get("id") or "").strip().upper()
            if not re.fullmatch(r"MLB\d+", str(item_id or "")):
                continue
            status = str(row.get("status") or "active").lower()
            if status not in {"active", ""}:
                continue
            row["item_id"] = item_id
            row.setdefault("id", item_id)
            row.setdefault("permalink", self.item_public_url(item_id))
            row.setdefault("catalog_product_id", str(product_id or "").strip().upper())
            offers.append(row)
        if offers and "itens_do_produto" not in self.sources_used:
            self.sources_used.append("itens_do_produto")
        return offers

    def product_items(self, product_id: str, *, limit: int = 10) -> list[str]:
        """Compatibilidade: retorna somente os IDs das ofertas da PDP."""
        return [str(row.get("item_id") or "") for row in self.product_offers(product_id, limit=limit) if row.get("item_id")]

    def product_candidate_items(self, product_id: str, *, limit: int = 5) -> list[str]:
        """Obtém somente ofertas vencedoras acessíveis para o produto.

        ``/products/{id}/items`` não é uma listagem geral de concorrentes. O
        recurso pode responder 404 ``No winners found`` para um produto válido.
        Esse estado é normal e significa apenas que não há oferta vencedora
        disponível no momento.
        """
        try:
            winner = self.product_winner_item(product_id)
        except MarketplaceRequestError as exc:
            if exc.status_code == 404 and "winner" in exc.detail.lower():
                return []
            raise
        if winner:
            return [winner]
        try:
            return self.product_items(product_id, limit=limit)
        except MarketplaceRequestError as exc:
            if exc.status_code == 404 and "winner" in exc.detail.lower():
                return []
            raise

    @staticmethod
    def catalog_product_url(product_id: str, site_domain: str = "mercadolivre.com.br") -> str:
        """URL pública da página de catálogo, mesmo sem oferta vencedora."""
        return f"https://www.{site_domain}/p/{product_id}"

    @staticmethod
    def item_public_url(item_id: str) -> str:
        """URL pública canônica para um ITEM do ranking, sem consultar /items."""
        value = str(item_id or "").strip().upper()
        match = re.fullmatch(r"([A-Z]{3})([0-9]+)", value)
        if not match:
            return ""
        return f"https://produto.mercadolivre.com.br/{match.group(1)}-{match.group(2)}-_JM"

    @staticmethod
    def catalog_thumbnail(product: dict[str, Any]) -> str:
        pictures = product.get("pictures") or []
        if isinstance(pictures, list):
            for picture in pictures:
                if isinstance(picture, dict):
                    url = str(picture.get("url") or picture.get("secure_url") or "").strip()
                    if url:
                        return url
        return str(product.get("thumbnail") or product.get("picture") or "").strip()

    def seller_reputations(self, seller_ids: Iterable[int | str]) -> dict[str, float]:
        ids = list(dict.fromkeys(str(item) for item in seller_ids if item))
        scores: dict[str, float] = {}
        for start in range(0, len(ids), 20):
            chunk = ids[start : start + 20]
            try:
                payload = self._get("/users", params={"ids": ",".join(chunk)}, authenticated=True, auth_mode="auto")
            except MarketplaceRequestError as exc:
                self.warnings.append(f"Reputação de vendedores indisponível ({exc.status_code or 'rede'}).")
                break
            if not isinstance(payload, list):
                continue
            for row in payload:
                body = row.get("body") if isinstance(row, dict) and isinstance(row.get("body"), dict) else row
                if not isinstance(body, dict):
                    continue
                seller_id = str(body.get("id") or "")
                reputation = body.get("seller_reputation") or {}
                level = str(reputation.get("level_id") or "") if isinstance(reputation, dict) else ""
                if seller_id:
                    scores[seller_id] = self._reputation_score(level)
        return scores

    def _configured_fallback_categories(self) -> dict[str, list[str]]:
        """Retorna categorias de contingência sem permitir que um ID inválido
        substitua completamente os padrões conhecidos.

        IDs informados no Render são tentados primeiro, mas os padrões oficiais
        permanecem como fallback. Isso evita que uma variável antiga ou digitada
        incorretamente deixe toda a descoberta sem fonte.
        """
        raw = getattr(settings, "mercado_livre_discovery_category_ids", None)
        custom_ids = [item.strip() for item in str(raw or "").split(",") if item.strip()]
        configured: dict[str, list[str]] = {}
        for key, defaults in FALLBACK_CATEGORY_IDS.items():
            merged: list[str] = []
            for category_id in [*custom_ids, *defaults]:
                if category_id and category_id not in merged:
                    merged.append(category_id)
            configured[key] = merged
        return configured

    def _filter_valid_categories(self, category_ids: Iterable[str]) -> list[str]:
        """Descarta IDs comprovadamente inexistentes (404).

        Respostas 401/403 não são tratadas como invalidade do ID, pois podem ser
        restrições temporárias da aplicação/PolicyAgent.
        """
        valid: list[str] = []
        for category_id in category_ids:
            try:
                detail = self.category_detail(category_id)
            except MarketplaceRequestError as exc:
                if exc.status_code == 404:
                    self.warnings.append(
                        f"Categoria configurada {category_id} não existe mais e foi ignorada."
                    )
                    continue
                valid.append(category_id)
                continue
            if isinstance(detail, dict) and detail.get("id"):
                valid.append(category_id)
        return valid

    def _target_categories(self, max_per_group: int = MAX_HIGHLIGHT_CATEGORIES_PER_GROUP) -> dict[str, list[str]]:
        """Seleciona categorias diversas dos nichos Zavomi para consultar /highlights.

        Preferimos subcategorias específicas porque seus rankings são mais úteis
        que rankings muito amplos. Quando a árvore pública é bloqueada, mantemos
        os IDs raiz de contingência e o fallback de ancestral já existente.
        """
        configured = [
            value.strip()
            for value in str(getattr(settings, "mercado_livre_discovery_category_ids", "") or "").split(",")
            if value.strip()
        ]
        if configured:
            return {"casa": configured[:max_per_group]}

        roots = self.site_categories()
        selected: dict[str, list[str]] = {key: [] for key in CATEGORY_NAME_HINTS}
        if not roots:
            return {
                key: self._filter_valid_categories(values)[:max_per_group]
                for key, values in FALLBACK_CATEGORY_IDS.items()
            }

        for root in roots:
            root_id = str(root.get("id") or "")
            root_name = str(root.get("name") or "")
            if not root_id:
                continue
            matching_groups = [group for group, hints in CATEGORY_NAME_HINTS.items() if self._contains_hint(root_name, hints)]
            if not matching_groups:
                continue
            try:
                detail = self.category_detail(root_id)
            except MarketplaceRequestError as exc:
                self.warnings.append(f"Subcategorias de {root_name} indisponíveis ({exc.status_code or 'rede'}).")
                detail = {}
            children = detail.get("children_categories", []) if isinstance(detail, dict) else []

            for group in matching_groups:
                hints = CATEGORY_NAME_HINTS[group]
                specific: list[str] = []
                for child in children:
                    if not isinstance(child, dict) or not child.get("id"):
                        continue
                    child_id = str(child["id"])
                    child_name = str(child.get("name") or "")
                    if self._contains_hint(child_name, hints) and child_id not in specific:
                        specific.append(child_id)
                # Mesmo que o nome da subcategoria não contenha o termo exato,
                # amostramos as primeiras ramificações para aumentar diversidade.
                if not specific:
                    specific = [str(c.get("id")) for c in children if isinstance(c, dict) and c.get("id")][:max_per_group]
                if not specific:
                    specific = [root_id]
                for category_id in specific:
                    if category_id not in selected[group] and len(selected[group]) < max_per_group:
                        selected[group].append(category_id)

        for group, fallback_ids in FALLBACK_CATEGORY_IDS.items():
            if not selected[group]:
                selected[group] = self._filter_valid_categories(fallback_ids)[:max_per_group]
        return selected

    def discover(self, limit_per_query: int = 8, categories: list[str] | None = None, progress_callback=None) -> list[Candidate]:
        """Seleciona candidatos exclusivamente dos rankings oficiais.

        ITEM e PRODUCT são tratados conforme o tipo retornado por /highlights.
        ITEM é lido pela página pública; PRODUCT usa /products/{id} e, quando
        houver item vencedor, enriquece pela página pública desse item. Nenhuma
        chamada a /items/{id} de terceiros é feita.
        """
        if not self.configured:
            return []
        _ = self.access_token

        ranked_meta: dict[str, tuple[str, int, str, str, str]] = {}
        categories_checked = 0
        entries_found = 0
        type_counts = {"PRODUCT": 0, "ITEM": 0, "USER_PRODUCT": 0, "OTHER": 0}
        target_categories = self._target_categories(max_per_group=MAX_HIGHLIGHT_CATEGORIES_PER_GROUP)
        if categories:
            allowed = {str(value).strip() for value in categories if str(value).strip()}
            target_categories = {key: value for key, value in target_categories.items() if key in allowed}
        for internal_category, category_ids in target_categories.items():
            for category_id in category_ids[:MAX_HIGHLIGHT_CATEGORIES_PER_GROUP]:
                categories_checked += 1
                entries, used_category = self._highlights_with_ancestor_fallback(category_id)
                for entry in entries[:MAX_HIGHLIGHT_PRODUCTS_PER_CATEGORY]:
                    if not isinstance(entry, dict):
                        continue
                    entry_id = str(entry.get("id") or "").strip()
                    entry_type = str(entry.get("type") or "OTHER").upper()
                    if entry_type not in type_counts:
                        entry_type = "OTHER"
                    type_counts[entry_type] += 1
                    if not entry_id:
                        continue
                    entries_found += 1
                    position = max(1, self._safe_int(entry.get("position"), 99))
                    key = f"{entry_type}:{entry_id}"
                    current = ranked_meta.get(key)
                    meta = (entry_type, position, internal_category, f"mais vendidos em {used_category or category_id}", "mercado_livre_highlights")
                    if current is None or position < current[1]:
                        ranked_meta[key] = meta

        ordered_all = sorted(ranked_meta.items(), key=lambda row: row[1][1])
        # A fase 1 descobre muitos produtos; a fase 2 enriquece somente os mais
        # promissores. Isso reduz 403/429, tempo de execução e pendências inúteis.
        # Não enriquece centenas de registros numa única execução. A versão
        # anterior podia selecionar até 600 entradas e, para cada PRODUCT,
        # testar 10 ofertas com várias chamadas HTTP em série. Em caso de fonte
        # lenta isso deixava a tela em 15% por mais de uma hora. Buscamos uma
        # margem de candidatos acima da meta e encerramos com os melhores dados
        # efetivamente obtidos.
        multiplier = max(2, min(5, int(getattr(settings, "discovery_enrichment_multiplier", 3) or 3)))
        enrichment_budget = max(20, min(90, int(limit_per_query or 8) * multiplier))
        supported = [row for row in ordered_all if row[1][0] in {"ITEM", "PRODUCT"}]
        ordered = supported[:enrichment_budget]
        diagnostics: list[dict[str, Any]] = []

        def diagnose(entry_id: str, entry_type: str, position: int, payload: dict[str, Any] | None, reason: str):
            if len(diagnostics) >= 12:
                return
            payload = payload or {}
            rating, reviews = self._rating_and_reviews(payload)
            diagnostics.append({
                "id": entry_id, "type": entry_type, "position": position,
                "title": str(payload.get("name") or payload.get("title") or "")[:80],
                "price": self._safe_float(payload.get("price") or payload.get("minimum_price") or payload.get("min_price"), 0.0),
                "rating": rating, "reviews": reviews,
                "status": str(payload.get("status") or "unknown"), "reason": reason,
            })

        def enrich_payload(payload: dict[str, Any], *, entry_type: str, entry_id: str) -> dict[str, Any]:
            """Completa a oportunidade antes do ranking e da persistência.

            A busca deixa de salvar apenas o cartão do ranking: resolve o item
            real, coleta descrição, fotos, nota, total de avaliações e vendas.
            Falhas de uma fonte não apagam dados confirmados por outra.
            """
            data = dict(payload or {})
            # O enriquecimento não depende da sessão do banco. Isso permite que
            # atualização manual, testes integrados e fluxos auxiliares consultem
            # as mesmas fontes oficiais usadas pela varredura principal.
            winner = self._winner_payload(data)
            item_id = self._extract_item_id(winner)
            if entry_type == "ITEM" and re.fullmatch(r"MLB\d+", entry_id.upper()):
                item_id = entry_id.upper()
            catalog_id = str(data.get("id") or "").upper() if entry_type == "PRODUCT" else str(data.get("catalog_product_id") or "").upper()

            # Muitos resultados de /highlights são PRODUCT e chegam sem
            # buy_box_winner visível para a aplicação. Na v1.0.97 isso impedia
            # toda a cadeia de enriquecimento: sem ITEM_ID não havia preço
            # específico, avaliações, estoque, descrição nem galeria. Resolve a
            # oferta real pelas fontes oficiais antes de desistir do produto.
            candidate_item_ids: list[str] = []
            offer_rows: dict[str, dict[str, Any]] = {}
            if item_id:
                candidate_item_ids.append(str(item_id).strip().upper())
            if entry_type == "PRODUCT" and catalog_id:
                probe_limit = max(1, min(5, int(getattr(settings, "discovery_offer_probe_limit", 3) or 3)))
                try:
                    for row in self.product_offers(catalog_id, limit=probe_limit):
                        value = str(row.get("item_id") or "").strip().upper()
                        if not value:
                            continue
                        offer_rows[value] = row
                        if value not in candidate_item_ids:
                            candidate_item_ids.append(value)
                except MarketplaceRequestError as exc:
                    self.warnings.append(
                        f"Ofertas reais do catálogo {catalog_id} indisponíveis ({exc.status_code or 'rede'})."
                    )

            # Avalia poucas ofertas, mas preserva primeiro os dados que o próprio
            # /products/{product_id}/items já entregou. Só consulta endpoints de
            # preço/reviews e a página pública para completar campos faltantes.
            best_item = ""
            best_bundle: dict[str, Any] = {}
            best_score = -1
            for candidate_item_id in candidate_item_ids[:max(1, min(5, int(getattr(settings, "discovery_offer_probe_limit", 3) or 3)))]:
                row = dict(offer_rows.get(candidate_item_id) or {})
                row_price = self._safe_float(row.get("price") or row.get("sale_price"), 0.0)
                row_original = self._optional_float(row.get("original_price") or row.get("regular_amount"))
                if row_original is not None and row_original <= row_price:
                    row_original = None
                candidate_price = {
                    "price": row_price,
                    "original_price": row_original,
                    "price_source": "catalog_competition_api" if row_price > 0 else "",
                    "original_price_source": "catalog_competition_api" if row_original else "unavailable",
                } if row_price > 0 else self.item_sale_prices(candidate_item_id)
                candidate_url = str(row.get("permalink") or self.item_public_url(candidate_item_id)).strip()
                try:
                    # Não chama /items/{id} durante descoberta de terceiros: essa
                    # chamada era a principal origem dos 403 PolicyAgent.
                    candidate_media = self.listing_media_and_description(
                        link=candidate_url, catalog_product=None, allow_item_api=False
                    )
                except Exception:
                    candidate_media = {}
                candidate_reviews = self.item_reviews(candidate_item_id, catalog_id)
                rating, total, levels = self.review_metrics(candidate_reviews)
                public_payload = candidate_media.get("public_snapshot") if isinstance(candidate_media, dict) else {}
                sold = self._sold_reference(
                    row.get("sold_quantity") or (public_payload.get("sold_quantity") if isinstance(public_payload, dict) else 0)
                )
                pictures_count = len(candidate_media.get("pictures") or []) if isinstance(candidate_media, dict) else 0
                available_probe = row.get("available_quantity")
                if available_probe is None:
                    available_probe = row.get("available_quantity_range") or row.get("stock")
                availability_confirmed = available_probe is not None
                stock_available = self._stock_available(available_probe) if availability_confirmed else False
                score = (
                    int(bool(candidate_price.get("price"))) * 40
                    + int(availability_confirmed and stock_available) * 15
                    + int(pictures_count >= 2) * 20
                    + min(pictures_count, 10)
                    + int(bool(candidate_media.get("description"))) * 10
                    + int(rating > 0) * 8
                    + int(total > 0) * 8
                    + int(sold > 0) * 4
                )
                if score > best_score:
                    best_score = score
                    best_item = candidate_item_id
                    best_bundle = {
                        "media": candidate_media, "price": candidate_price,
                        "rating": rating, "reviews": total, "levels": levels,
                        "sold": sold, "public": public_payload, "offer": row,
                        "availability_confirmed": availability_confirmed,
                        "stock_available": stock_available,
                    }
                if best_score >= 111:
                    break
            if best_item:
                item_id = best_item
                data["item_id"] = best_item
                data["resolved_item_source"] = "best_catalog_offer"
                offer_data = best_bundle.get("offer") or {}
                if isinstance(offer_data, dict):
                    data = self._merge_product_data(data, offer_data)
                    data["item_id"] = best_item
                    data["catalog_product_id"] = catalog_id or data.get("catalog_product_id")
                    if best_bundle.get("availability_confirmed"):
                        data["availability_confirmed"] = True
                        data["available_quantity"] = 1 if best_bundle.get("stock_available") else 0

            listing_url = str(
                self.item_public_url(item_id) if item_id
                else data.get("permalink") or self.catalog_product_url(catalog_id or entry_id)
            ).strip()
            try:
                media = best_bundle.get("media") or self.listing_media_and_description(
                    link=listing_url,
                    catalog_product=data if entry_type == "PRODUCT" and not item_id else None,
                    allow_item_api=bool(item_id),
                )
            except Exception as exc:
                self.warnings.append(f"Coleta completa falhou para {entry_id}: {str(exc)[:120]}")
                media = {}
            resolved_item = str(media.get("item_id") or item_id or "").upper()
            if resolved_item:
                data["item_id"] = resolved_item
            description = str(media.get("description") or data.get("description") or "").strip()
            if description:
                data["description"] = description
            pictures = list(media.get("pictures") or [])
            if pictures:
                data["pictures"] = [{"secure_url": url} for url in pictures]
            if resolved_item:
                price_data = best_bundle.get("price") or self.item_sale_prices(resolved_item)
                if price_data.get("price"):
                    data["price"] = price_data["price"]
                    data["price_source"] = price_data.get("price_source", "sale_price_api")
                    data["original_price"] = price_data.get("original_price")
                    data["original_price_source"] = price_data.get("original_price_source", "unavailable")
                if best_bundle:
                    rating = self._safe_float(best_bundle.get("rating"), 0.0)
                    total = self._safe_int(best_bundle.get("reviews"), 0)
                    levels = best_bundle.get("levels") or {}
                else:
                    reviews_payload = self.item_reviews(resolved_item, catalog_id)
                    rating, total, levels = self.review_metrics(reviews_payload)

                # Segunda tentativa após o ITEM_ID definitivo estar resolvido.
                # Alguns produtos de catálogo devolvem métricas vazias para a
                # primeira oferta, mas outra oferta do mesmo PRODUCT_ID consegue
                # retornar as opiniões agregadas do catálogo.
                if rating <= 0 or total <= 0:
                    retry_ids = [resolved_item] + [x for x in candidate_item_ids if x != resolved_item]
                    for review_item_id in retry_ids[:5]:
                        reviews_payload = self.item_reviews(review_item_id, catalog_id)
                        retry_rating, retry_total, retry_levels = self.review_metrics(reviews_payload)
                        if retry_rating > rating:
                            rating = retry_rating
                        if retry_total > total:
                            total = retry_total
                            levels = retry_levels
                        if rating > 0 and total > 0:
                            data["reviews_item_id"] = review_item_id
                            break
                if rating > 0:
                    data["rating_average"] = rating
                    data["rating_source"] = "reviews_api"
                if total > 0:
                    data["reviews_count"] = total
                    data["review_count"] = total
                    data["rating_levels"] = levels
                # Em descoberta de terceiros evitamos /items/{id}, que costuma
                # ser bloqueado pelo PolicyAgent. Vendas, preço e disponibilidade
                # são enriquecidos pela página pública do próprio anúncio.
                public_payload = media.get("public_snapshot") if isinstance(media, dict) else {}
                catalog_public: dict[str, Any] = {}
                # A PDP /p/{catalog_product_id} é uma fonte complementar essencial:
                # nela o Mercado Livre pode exibir a nota/opiniões agregadas do
                # produto mesmo quando a página da oferta individual não exibe.
                if catalog_id:
                    try:
                        catalog_public = self.public_product_snapshot(self.catalog_product_url(catalog_id))
                    except Exception:
                        catalog_public = {}
                combined_public = self.merge_public_snapshots(
                    public_payload if isinstance(public_payload, dict) else {},
                    catalog_public,
                )
                if combined_public:
                    public_rating = self._safe_float(combined_public.get("rating") or combined_public.get("rating_average"), 0.0)
                    public_reviews = self._safe_int(combined_public.get("reviews_count") or combined_public.get("review_count"), 0)
                    if rating <= 0 and public_rating > 0:
                        rating = public_rating
                        data["rating_average"] = public_rating
                        data["rating_source"] = "public_catalog_page" if catalog_public else "public_listing_page"
                    if total <= 0 and public_reviews > 0:
                        total = public_reviews
                        data["reviews_count"] = public_reviews
                        data["review_count"] = public_reviews
                        data["review_count_source"] = "public_catalog_page" if catalog_public else "public_listing_page"
                    sold = self._sold_reference(combined_public.get("sold_quantity"))
                    if sold > 0:
                        data["sold_quantity"] = sold
                        data["sold_quantity_source"] = "public_catalog_page" if catalog_public and sold == self._sold_reference(catalog_public.get("sold_quantity")) else "public_listing_page"
                        if combined_public.get("sold_quantity_display"):
                            data["sold_quantity_display"] = combined_public.get("sold_quantity_display")
                        data["sold_quantity_is_minimum"] = bool(combined_public.get("sold_quantity_is_minimum"))
                    data = self._merge_product_data(data, combined_public)

            # Fallback final independente de ITEM_ID: a própria página de
            # catálogo pode expor avaliações agregadas e uma faixa pública de
            # vendas. Isso é especialmente importante quando a aplicação não
            # recebe o buy_box_winner/ITEM_ID por PolicyAgent.
            fallback_public: list[dict[str, Any]] = []
            for public_url in dict.fromkeys([
                listing_url,
                self.catalog_product_url(catalog_id) if catalog_id else "",
            ]):
                if not public_url:
                    continue
                try:
                    snap = self.public_product_snapshot(public_url)
                    if snap:
                        fallback_public.append(snap)
                except Exception:
                    continue
            if fallback_public:
                combined = self.merge_public_snapshots(*fallback_public)
                current_rating = self._safe_float(data.get("rating_average") or data.get("rating"), 0.0)
                current_reviews = self._safe_int(data.get("reviews_count") or data.get("review_count"), 0)
                public_rating = self._safe_float(combined.get("rating") or combined.get("rating_average"), 0.0)
                public_reviews = self._safe_int(combined.get("reviews_count") or combined.get("review_count"), 0)
                if current_rating <= 0 and public_rating > 0:
                    data["rating_average"] = public_rating
                    data["rating"] = public_rating
                    data["rating_source"] = "public_product_page"
                if current_reviews <= 0 and public_reviews > 0:
                    data["reviews_count"] = public_reviews
                    data["review_count"] = public_reviews
                    data["review_count_source"] = "public_product_page"
                public_sold = self._sold_reference(combined.get("sold_quantity"))
                if self._sold_reference(data.get("sold_quantity")) <= 0 and public_sold > 0:
                    data["sold_quantity"] = public_sold
                    data["sold_quantity_source"] = "public_product_page"
                    data["sold_quantity_display"] = str(combined.get("sold_quantity_display") or "")
                    data["sold_quantity_is_minimum"] = bool(combined.get("sold_quantity_is_minimum"))
                data = self._merge_product_data(data, combined)

            # Último fallback: renderização real somente se continuarem ausentes
            # métricas públicas importantes. O orçamento por varredura evita que
            # Chromium torne a descoberta lenta ou fique preso em um produto.
            missing_rating = self._safe_float(data.get("rating_average") or data.get("rating"), 0.0) <= 0
            missing_reviews = self._safe_int(data.get("reviews_count") or data.get("review_count"), 0) <= 0
            missing_sales = self._sold_reference(data.get("sold_quantity")) <= 0
            if missing_rating or missing_reviews or missing_sales:
                rendered: list[dict[str, Any]] = []
                for browser_url in dict.fromkeys([
                    self.catalog_product_url(catalog_id) if catalog_id else "",
                    listing_url,
                ]):
                    if not browser_url:
                        continue
                    snap = self.browser_product_snapshot(browser_url)
                    if snap:
                        rendered.append(snap)
                    browser_combined = self.merge_public_snapshots(*rendered) if rendered else {}
                    browser_rating = self._safe_float(browser_combined.get("rating") or browser_combined.get("rating_average"), 0.0)
                    browser_reviews = self._safe_int(browser_combined.get("reviews_count") or browser_combined.get("review_count"), 0)
                    browser_sold = self._sold_reference(browser_combined.get("sold_quantity"))
                    if missing_rating and browser_rating > 0:
                        data["rating_average"] = browser_rating
                        data["rating"] = browser_rating
                        data["rating_source"] = "browser_public_page"
                        missing_rating = False
                    if missing_reviews and browser_reviews > 0:
                        data["reviews_count"] = browser_reviews
                        data["review_count"] = browser_reviews
                        data["review_count_source"] = "browser_public_page"
                        missing_reviews = False
                    if missing_sales and browser_sold > 0:
                        data["sold_quantity"] = browser_sold
                        data["sold_quantity_source"] = "browser_public_page"
                        data["sold_quantity_display"] = str(browser_combined.get("sold_quantity_display") or "")
                        data["sold_quantity_is_minimum"] = bool(browser_combined.get("sold_quantity_is_minimum"))
                        missing_sales = False
                    if browser_combined:
                        data = self._merge_product_data(data, browser_combined)
                    if not (missing_rating or missing_reviews or missing_sales):
                        break
            return data

        def fetch_one(key: str, meta: tuple[str, int, str, str, str]):
            entry_type, position, category, term, source = meta
            entry_id = key.split(":", 1)[1]
            try:
                if entry_type == "ITEM":
                    url = self.item_public_url(entry_id)
                    if not url:
                        return key, None, "invalid_item_id"
                    payload = self.public_product_snapshot(url)
                    payload["id"] = entry_id
                    payload["item_id"] = entry_id
                    payload["permalink"] = payload.get("permalink") or url
                    payload = enrich_payload(payload, entry_type=entry_type, entry_id=entry_id)
                    return key, payload, None
                if entry_type == "PRODUCT":
                    payload = self.product_detail(entry_id)
                    winner = self._winner_payload(payload)
                    item_id = self._extract_item_id(winner)
                    urls = []
                    if item_id:
                        item_url = self.item_public_url(item_id)
                        if item_url:
                            urls.append(item_url)
                    urls.append(str(payload.get("permalink") or self.catalog_product_url(entry_id)))
                    rating, reviews = self._rating_and_reviews(payload)
                    price = self._safe_float(winner.get("price") or payload.get("price") or payload.get("minimum_price") or payload.get("min_price"), 0.0)
                    needs_enrichment = price < 1 or rating <= 0 or reviews <= 0 or not payload.get("availability_confirmed")
                    if needs_enrichment:
                        for url in dict.fromkeys(urls):
                            try:
                                enriched = self.public_product_snapshot(url)
                                payload = self._merge_product_data(payload, enriched)
                                if item_id:
                                    payload.setdefault("item_id", item_id)
                                r, c = self._rating_and_reviews(payload)
                                p = self._safe_float(payload.get("price") or payload.get("minimum_price") or payload.get("min_price"), 0.0)
                                if p >= 1 and r > 0 and c > 0 and payload.get("availability_confirmed"):
                                    break
                            except (MarketplaceRequestError, ValueError):
                                continue
                    payload = enrich_payload(payload, entry_type=entry_type, entry_id=entry_id)
                    return key, payload, None
                return key, None, "unsupported_type"
            except MarketplaceRequestError as exc:
                if entry_type == "PRODUCT" and (exc.status_code == 403 or self._is_policy_block(exc.detail)):
                    try:
                        public_url = self.catalog_product_url(entry_id)
                        payload = self.public_product_snapshot(public_url)
                        payload["id"] = entry_id
                        payload["permalink"] = payload.get("permalink") or public_url
                        payload["policy_fallback"] = True
                        payload = enrich_payload(payload, entry_type=entry_type, entry_id=entry_id)
                        return key, payload, "policy_fallback_public"
                    except Exception:
                        pass
                return key, None, f"http_{exc.status_code or 'error'}"
            except Exception as exc:
                return key, None, f"read_error:{str(exc)[:80]}"

        workers = max(1, min(int(getattr(settings, "discovery_parallel_workers", 4) or 4), 6, len(ordered) or 1))
        results = []
        total_tasks = len(ordered)
        scan_timeout = max(60.0, float(getattr(settings, "discovery_scan_timeout_seconds", 600.0) or 600.0))
        if workers == 1:
            started_batch = __import__("time").monotonic()
            for index, (key, meta) in enumerate(ordered, start=1):
                if __import__("time").monotonic() - started_batch >= scan_timeout:
                    self.warnings.append("A janela máxima da varredura foi atingida; os dados já coletados foram salvos e o restante ficará para a próxima execução.")
                    break
                results.append(fetch_one(key, meta))
                if progress_callback and total_tasks:
                    progress_callback(18 + int(52 * index / total_tasks), f"Enriquecendo produtos do Mercado Livre ({index}/{total_tasks})")
        else:
            executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ml-ranking")
            futures = [executor.submit(fetch_one, key, meta) for key, meta in ordered]
            completed = 0
            try:
                for future in as_completed(futures, timeout=scan_timeout):
                    completed += 1
                    try:
                        results.append(future.result())
                    except Exception as exc:
                        logger.warning("Falha isolada no enriquecimento: %s", exc)
                    if progress_callback and total_tasks:
                        progress_callback(18 + int(52 * completed / total_tasks), f"Enriquecendo produtos do Mercado Livre ({completed}/{total_tasks})")
            except FuturesTimeoutError:
                self.warnings.append("A janela máxima da varredura foi atingida; os dados já coletados foram salvos e o restante ficará para a próxima execução.")
                for future in futures:
                    if not future.done():
                        future.cancel()
            finally:
                # Não esperamos tarefas lentas além da janela do job. Cada HTTP
                # possui timeout próprio e terminará sozinho sem bloquear a UI.
                executor.shutdown(wait=False, cancel_futures=True)

        candidates: list[Candidate] = []
        seen: set[str] = set()
        rejected_no_price = rejected_inactive = rejected_unknown = detail_failures = 0
        unsupported = 0
        parents_detected = 0
        children_checked = 0
        for key, payload, error in results:
            entry_type, position, category, term, source = ranked_meta[key]
            entry_id = key.split(":", 1)[1]
            if payload is None:
                if error == "unsupported_type":
                    unsupported += 1
                else:
                    detail_failures += 1
                diagnose(entry_id, entry_type, position, None, error or "sem_resposta")
                continue
            candidate = self._candidate_from_product(
                payload, internal_category=category, trend_keyword=term,
                source=source, source_rank=position,
            )
            if candidate and candidate.offer_available:
                marker = candidate.external_id or candidate.catalog_product_id or entry_id
                if marker not in seen:
                    seen.add(marker)
                    candidates.append(candidate)
                continue

            # Alguns rankings apontam para um produto-pai. Verificamos poucos
            # filhos, somente até encontrar a primeira variação comprável.
            if entry_type == "PRODUCT":
                child_ids = self._child_product_ids(payload)[:3]
                if child_ids:
                    parents_detected += 1
                for child_id in child_ids:
                    children_checked += 1
                    try:
                        child = self.product_detail(child_id)
                        child_candidate = self._candidate_from_product(
                            child, internal_category=category, trend_keyword=term,
                            source=source, source_rank=position,
                            parent_catalog_product_id=entry_id,
                        )
                    except Exception:
                        child_candidate = None
                    if child_candidate and child_candidate.offer_available:
                        marker = child_candidate.external_id or child_candidate.catalog_product_id or child_id
                        if marker not in seen:
                            seen.add(marker)
                            candidates.append(child_candidate)
                        candidate = child_candidate
                        break
                if candidate and candidate.offer_available:
                    continue
            status = str(payload.get("status") or "unknown").lower()
            raw_price = self._safe_float(payload.get("price") or payload.get("minimum_price") or payload.get("min_price"), 0.0)
            winner_price = self._safe_float(self._winner_payload(payload).get("price"), 0.0)
            if max(raw_price, winner_price) < 1:
                rejected_no_price += 1
                reason = "sem_preco"
            elif status == "inactive":
                rejected_inactive += 1
                reason = "indisponivel"
            else:
                rejected_unknown += 1
                reason = "disponibilidade_nao_confirmada"
            diagnose(entry_id, entry_type, position, payload, reason)

            # Mesmo quando a API não expõe preço/nota/estoque, o ranking oficial
            # continua sendo uma evidência objetiva de demanda. Mantemos esses
            # produtos como pré-selecionados para revisão manual, sem fingir que
            # os filtros comerciais foram confirmados.
            if entry_type == "PRODUCT":
                product_id = str(payload.get("id") or entry_id).strip()
                title = str(payload.get("name") or payload.get("title") or payload.get("family_name") or "").strip()
                if product_id and title:
                    marker = product_id
                    if marker not in seen:
                        seen.add(marker)
                        rating, reviews = self._rating_and_reviews(payload)
                        resolved_item = str(payload.get("item_id") or self._extract_item_id(self._winner_payload(payload)) or "").strip().upper()
                        pictures = tuple(self.picture_urls(payload, limit=24))
                        listing_url = str(
                            payload.get("permalink")
                            or (self.item_public_url(resolved_item) if resolved_item else "")
                            or self.catalog_product_url(product_id)
                        )
                        candidates.append(Candidate(
                            external_id=resolved_item or product_id,
                            title=title[:180],
                            category=category,
                            price=max(raw_price, winner_price),
                            original_price=self._optional_float(payload.get("original_price")),
                            rating=rating,
                            review_count=reviews,
                            sold_quantity=self._sold_reference(payload.get("sold_quantity")),
                            seller_reputation=0.0,
                            stock_available=bool(payload.get("availability_confirmed") and self._stock_available(payload.get("available_quantity"))),
                            listing_url=listing_url,
                            thumbnail=self.catalog_thumbnail(payload),
                            trend_keyword=term or "ranking oficial",
                            source=f"{source}_preselecionado",
                            source_rank=position,
                            offer_available=False,
                            catalog_product_id=product_id,
                            item_id=resolved_item,
                            description=str(payload.get("description") or "").strip(),
                            picture_urls=pictures,
                            rating_source=str(payload.get("rating_source") or ("reviews_api" if reviews > 0 else "")),
                            sold_quantity_source=str(payload.get("sold_quantity_source") or ("public_page" if self._sold_reference(payload.get("sold_quantity")) > 0 else "")),
                            price_source=str(payload.get("price_source") or ("catalog_competition_api" if max(raw_price, winner_price) > 0 else "")),
                            original_price_source=str(payload.get("original_price_source") or ("catalog_competition_api" if payload.get("original_price") else "")),
                        ))

        # Remove repetições do mesmo produto comercial (cores/títulos quase idênticos)
        # preservando a oferta com dados mais completos e melhor posição no ranking.
        deduped: dict[tuple[str, str], Candidate] = {}
        for candidate in candidates:
            normalized_title = re.sub(r"[^a-z0-9]+", " ", self._normalize(candidate.title)).strip()
            compact_title = " ".join(normalized_title.split()[:12])
            key = (candidate.category, compact_title or candidate.catalog_product_id or candidate.external_id)
            current = deduped.get(key)
            quality = (
                int(candidate.offer_available) * 100
                + int(candidate.price >= 1) * 20
                + int(candidate.stock_available) * 15
                + int(bool(candidate.picture_urls or candidate.thumbnail)) * 10
                + int(bool(candidate.description)) * 10
                + int(candidate.rating > 0) * 5
                + int(candidate.review_count > 0) * 5
                - min(candidate.source_rank or 999, 999) / 1000
            )
            if current is None:
                deduped[key] = candidate
                continue
            current_quality = (
                int(current.offer_available) * 100
                + int(current.price >= 1) * 20
                + int(current.stock_available) * 15
                + int(bool(current.picture_urls or current.thumbnail)) * 10
                + int(bool(current.description)) * 10
                + int(current.rating > 0) * 5
                + int(current.review_count > 0) * 5
                - min(current.source_rank or 999, 999) / 1000
            )
            if quality > current_quality:
                deduped[key] = candidate
        duplicates_removed = max(0, len(candidates) - len(deduped))
        candidates = sorted(deduped.values(), key=lambda c: c.source_rank or 9999)

        self.discovery_stats = {
            "terms": 0,
            "catalog_products": type_counts["PRODUCT"],
            "ranked_products_found": entries_found,
            "discovery_candidates_total": len(ordered_all),
            "enrichment_candidates_selected": len(ordered),
            "enrichment_candidates_skipped": max(0, len(ordered_all) - len(ordered)),
            "highlight_categories_checked": categories_checked,
            "highlight_products_found": entries_found,
            "highlight_product_entries": type_counts["PRODUCT"],
            "highlight_item_entries": type_counts["ITEM"],
            "highlight_user_product_entries": type_counts["USER_PRODUCT"],
            "highlight_unsupported_entries": unsupported + type_counts["OTHER"],
            "usable_candidates": len([c for c in candidates if c.offer_available]),
            "preselected_candidates": len([c for c in candidates if not c.offer_available]),
            "rejected_no_price": rejected_no_price,
            "rejected_inactive": rejected_inactive,
            "rejected_unknown_commercial": rejected_unknown,
            "product_detail_failures": detail_failures,
            "parallel_workers": workers,
            "diagnostic_samples": diagnostics,
            "minimum_rating": MIN_ZAVOMI_RATING,
            "minimum_reviews": MIN_ZAVOMI_REVIEWS,
            "third_party_item_api_requests": 0,
            "third_party_item_requests": 0,
            "ranked_unavailable": rejected_no_price + rejected_inactive + rejected_unknown,
            "parents_detected": parents_detected,
            "children_checked": children_checked,
            "duplicates_removed": duplicates_removed,
            "policy_blocked_families": len(self._policy_blocked_families),
            "policy_skipped_requests": self._policy_skipped_requests,
        }
        if candidates and "ranking_mais_vendidos" not in self.sources_used:
            self.sources_used.append("ranking_mais_vendidos")
        return candidates

    @staticmethod
    def _normalize(value: str) -> str:
        value = unicodedata.normalize("NFKD", value.lower())
        return "".join(char for char in value if not unicodedata.combining(char))

    @classmethod
    def _contains_hint(cls, value: str, hints: Iterable[str]) -> bool:
        text = cls._normalize(value)
        return any(cls._normalize(hint) in text for hint in hints)

    @classmethod
    def _category_from_text(cls, value: str) -> str:
        return classify_product_category(value, fallback="utilidades")

    @classmethod
    def _best_trend_for_title(cls, title: str, trends: list[str]) -> str:
        normalized_title = cls._normalize(title)
        matches = [term for term in trends if cls._normalize(term) in normalized_title]
        return max(matches, key=len) if matches else ""

    @staticmethod
    def _reputation_score(level_id: str) -> float:
        normalized = level_id.lower()
        mapping = {
            "5_green": 98,
            "4_light_green": 90,
            "3_yellow": 75,
            "2_orange": 55,
            "1_red": 30,
            "green": 95,
            "yellow": 75,
            "orange": 55,
            "red": 30,
        }
        return float(mapping.get(normalized, 80 if "green" in normalized else 65))

    @staticmethod
    def _sold_reference(raw: Any) -> int:
        if isinstance(raw, int):
            return raw
        if isinstance(raw, float):
            return int(raw)
        if isinstance(raw, str):
            # Handles strings such as "+250 mil vendidos", "mais de 10 mil"
            # and "1,2 mi" correctly. The previous digits-only parser would
            # interpret "250 mil" as 250.
            compact = MercadoLivreClient._compact_count(raw)
            if compact > 0:
                return compact
            digits = "".join(ch for ch in raw if ch.isdigit())
            return int(digits or 0)
        return 0

    @staticmethod
    def _safe_float(raw: Any, default: float = 0.0) -> float:
        try:
            return float(raw or default)
        except (TypeError, ValueError):
            return default

    @classmethod
    def _optional_float(cls, raw: Any) -> float | None:
        if raw in (None, ""):
            return None
        return cls._safe_float(raw)

    @staticmethod
    def _safe_int(raw: Any, default: int = 0) -> int:
        try:
            return int(raw)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _stock_available(raw: Any) -> bool:
        if isinstance(raw, str):
            return raw not in {"", "0", "RANGO_0"}
        return bool(raw)
