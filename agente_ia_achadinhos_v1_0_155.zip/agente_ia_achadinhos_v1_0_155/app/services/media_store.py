from __future__ import annotations

from pathlib import Path

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import MediaAsset

MAX_PERSISTED_MEDIA_BYTES = 35 * 1024 * 1024


def persist_file(
    db: Session,
    *,
    production_id: int,
    path: Path,
    content_type: str,
    replace_name: bool = True,
) -> MediaAsset:
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"Arquivo de mídia não encontrado: {path.name}")
    size = path.stat().st_size
    if size <= 0:
        raise ValueError(f"Arquivo de mídia vazio: {path.name}")
    if size > MAX_PERSISTED_MEDIA_BYTES:
        raise ValueError("O vídeo final excedeu 35 MB. Reduza a duração ou a qualidade antes de salvar.")
    if replace_name:
        db.execute(
            delete(MediaAsset).where(
                MediaAsset.production_id == production_id,
                MediaAsset.name == path.name,
            )
        )
    asset = MediaAsset(
        production_id=production_id,
        name=path.name,
        content_type=content_type,
        data=path.read_bytes(),
        size_bytes=size,
    )
    db.add(asset)
    db.flush()
    return asset


def media_url(asset_id: int) -> str:
    return f"{settings.public_base_url.rstrip('/')}/media/assets/{asset_id}"


def latest_asset(db: Session, production_id: int, name: str) -> MediaAsset | None:
    return db.scalar(
        select(MediaAsset)
        .where(MediaAsset.production_id == production_id, MediaAsset.name == name)
        .order_by(MediaAsset.id.desc())
    )
