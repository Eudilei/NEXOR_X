from __future__ import annotations

import secrets
import time
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import Publication, SocialConnection
from app.services.oauth_tokens import decrypt_value, encrypt_value
from app.services.media_store import latest_asset, media_url

logger = logging.getLogger("agente.instagram.meta")


class InstagramError(RuntimeError):
    pass


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class InstagramService:
    authorize_url = "https://www.instagram.com/oauth/authorize"
    token_url = "https://api.instagram.com/oauth/access_token"
    graph_url = "https://graph.instagram.com"
    scopes = (
        "instagram_business_basic",
        "instagram_business_content_publish",
        "instagram_business_manage_comments",
        "instagram_business_manage_messages",
    )

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout

    @property
    def configured(self) -> bool:
        return bool(settings.meta_app_id and settings.meta_app_secret and settings.instagram_redirect_uri)

    def authorization_url(self, state: str) -> str:
        if not self.configured:
            raise InstagramError("Configure META_APP_ID e META_APP_SECRET no Render.")
        params = {
            "client_id": settings.meta_app_id,
            "redirect_uri": settings.instagram_redirect_uri,
            "response_type": "code",
            "scope": ",".join(self.scopes),
            "state": state,
            # Meta recommends force_reauth for Business Login, especially on mobile.
            # It prevents Instagram from silently reusing an old authorization session
            # and opening only the normal Instagram surface without a consent screen.
            "force_reauth": "true",
        }
        return str(httpx.URL(self.authorize_url, params=params))

    def exchange_code(self, code: str) -> dict[str, Any]:
        payload = {
            "client_id": settings.meta_app_id,
            "client_secret": settings.meta_app_secret,
            "grant_type": "authorization_code",
            "redirect_uri": settings.instagram_redirect_uri,
            "code": code,
        }
        with httpx.Client(timeout=self.timeout, follow_redirects=True) as client:
            response = client.post(self.token_url, data=payload)
        data = self._json_or_error(response, "trocar o código pelo token")
        if not data.get("access_token"):
            raise InstagramError("A Meta não devolveu um token de acesso.")
        return data

    def exchange_long_lived(self, short_token: str) -> dict[str, Any]:
        params = {
            "grant_type": "ig_exchange_token",
            "client_secret": settings.meta_app_secret,
            "access_token": short_token,
        }
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.graph_url}/access_token", params=params)
        data = self._json_or_error(response, "converter o token para longa duração")
        if not data.get("access_token"):
            raise InstagramError("A Meta não devolveu o token de longa duração.")
        return data

    def refresh_long_lived(self, token: str) -> dict[str, Any]:
        params = {"grant_type": "ig_refresh_token", "access_token": token}
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.graph_url}/refresh_access_token", params=params)
        return self._json_or_error(response, "renovar o token do Instagram")

    def profile(self, token: str) -> dict[str, Any]:
        params = {"fields": "user_id,username", "access_token": token}
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.graph_url}/me", params=params)
        data = self._json_or_error(response, "consultar a conta do Instagram")
        if not (data.get("user_id") or data.get("id")):
            raise InstagramError("A Meta não devolveu o identificador da conta do Instagram.")
        return data


    def subscribe_webhooks(self, account_id: str, token: str) -> dict[str, Any]:
        """Inscreve a conta profissional nos eventos usados pelo agente.

        A validação global do callback não basta: cada conta conectada precisa
        ficar inscrita no aplicativo após o OAuth/reconexão.
        """
        payload = {
            "subscribed_fields": "comments,messages",
            "access_token": token,
        }
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(f"{self.graph_url}/{account_id}/subscribed_apps", data=payload)
        data = self._json_or_error(response, "assinar os webhooks da conta do Instagram")
        if data.get("success") is not True:
            raise InstagramError("A Meta não confirmou a assinatura dos comentários e mensagens.")
        return data

    def webhook_subscription_status(self, account_id: str, token: str) -> dict[str, Any]:
        params = {"access_token": token}
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.graph_url}/{account_id}/subscribed_apps", params=params)
        return self._json_or_error(response, "consultar a assinatura dos webhooks")

    def save_connection(self, db: Session, token_data: dict[str, Any], profile: dict[str, Any]) -> SocialConnection:
        connection = db.scalar(select(SocialConnection).where(SocialConnection.provider == "instagram"))
        if connection is None:
            connection = SocialConnection(provider="instagram")
            db.add(connection)
        expires_in = int(token_data.get("expires_in") or 60 * 24 * 60 * 60)
        connection.account_name = str(profile.get("username") or "")
        connection.external_account_id = str(profile.get("user_id") or profile.get("id") or "")
        connection.access_token_encrypted = encrypt_value(str(token_data["access_token"]))
        connection.refresh_token_encrypted = None
        connection.expires_at = _utcnow() + timedelta(seconds=max(expires_in - 300, 3600))
        connection.status = "conectado"
        connection.updated_at = _utcnow()
        db.commit()
        db.refresh(connection)
        return connection

    def valid_token(self, db: Session) -> tuple[SocialConnection, str]:
        connection = db.scalar(select(SocialConnection).where(SocialConnection.provider == "instagram"))
        if not connection or connection.status != "conectado" or not connection.access_token_encrypted:
            raise InstagramError("Conecte a conta do Instagram antes de publicar.")
        token = decrypt_value(connection.access_token_encrypted)
        if not token:
            raise InstagramError("Token do Instagram ausente.")
        expires_at = connection.expires_at
        if expires_at and expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if expires_at and expires_at <= _utcnow() + timedelta(days=7):
            refreshed = self.refresh_long_lived(token)
            token = str(refreshed.get("access_token") or token)
            connection.access_token_encrypted = encrypt_value(token)
            connection.expires_at = _utcnow() + timedelta(seconds=int(refreshed.get("expires_in") or 60 * 24 * 60 * 60) - 300)
            connection.updated_at = _utcnow()
            db.commit()
        return connection, token

    def disconnect(self, db: Session) -> None:
        connection = db.scalar(select(SocialConnection).where(SocialConnection.provider == "instagram"))
        if connection:
            db.delete(connection)
            db.commit()

    def validate_public_video(self, video_url: str) -> None:
        try:
            with httpx.Client(timeout=self.timeout, follow_redirects=True) as client:
                response = client.get(video_url, headers={"Range": "bytes=0-2047"})
        except Exception as exc:
            raise InstagramError(f"A URL pública do vídeo não pôde ser acessada: {exc}") from exc
        if response.status_code not in {200, 206}:
            raise InstagramError(f"O vídeo público não está disponível (HTTP {response.status_code}). Gere o vídeo novamente antes de publicar.")
        content_type = str(response.headers.get("content-type") or "").lower()
        if "video/mp4" not in content_type and "application/octet-stream" not in content_type:
            raise InstagramError(f"A URL do vídeo respondeu com tipo inválido: {content_type or 'desconhecido'}.")
        if not response.content:
            raise InstagramError("A URL pública do vídeo respondeu sem conteúdo.")

    def create_reel_container(self, account_id: str, token: str, video_url: str, caption: str) -> str:
        payload = {
            "media_type": "REELS",
            "video_url": video_url,
            "caption": caption,
            "share_to_feed": "true",
            "access_token": token,
        }
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(f"{self.graph_url}/{account_id}/media", data=payload)
        data = self._json_or_error(response, "enviar o Reel para processamento")
        creation_id = str(data.get("id") or "")
        if not creation_id:
            raise InstagramError("A Meta não devolveu o identificador do contêiner do Reel.")
        return creation_id

    def container_status(self, creation_id: str, token: str) -> dict[str, Any]:
        params = {"fields": "status_code,status", "access_token": token}
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.graph_url}/{creation_id}", params=params)
        return self._json_or_error(response, "consultar o processamento do Reel")

    def publish_container(self, account_id: str, token: str, creation_id: str) -> str:
        payload = {"creation_id": creation_id, "access_token": token}
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(f"{self.graph_url}/{account_id}/media_publish", data=payload)
        data = self._json_or_error(response, "publicar o Reel")
        media_id = str(data.get("id") or "")
        if not media_id:
            raise InstagramError("A Meta não devolveu o identificador da publicação.")
        return media_id

    def media_permalink(self, media_id: str, token: str) -> str:
        params = {"fields": "permalink", "access_token": token}
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.graph_url}/{media_id}", params=params)
        data = self._json_or_error(response, "consultar o link da publicação")
        return str(data.get("permalink") or "")

    def publish_reel(self, db: Session, publication_id: int) -> None:
        publication = db.get(Publication, publication_id)
        if not publication:
            return
        try:
            publication.status = "processando"
            publication.error = ""
            db.commit()
            production = publication.production
            if not production or production.status != "aprovado":
                raise InstagramError("A mídia precisa estar aprovada antes da publicação.")
            video_url = str(production.video_url or "").strip()
            if not video_url.startswith("https://"):
                raise InstagramError("O vídeo precisa estar disponível em uma URL HTTPS pública.")
            try:
                self.validate_public_video(video_url)
            except InstagramError as exc:
                # Preferência 1: recuperar o MP4 persistido no banco, imune a
                # reinícios do filesystem efêmero do Render.
                asset = latest_asset(db, production.id, "video.mp4") or latest_asset(db, production.id, "product_first_video.mp4")
                if asset:
                    production.video_url = media_url(asset.id)
                    video_url = production.video_url
                    db.commit()
                    self.validate_public_video(video_url)
                elif "HTTP 404" in str(exc):
                    # Preferência 2: regenerar automaticamente usando o job já
                    # registrado. A publicação volta para a fila e será tentada
                    # novamente quando o worker concluir o novo MP4.
                    production.status = "na_fila"
                    production.error = "MP4 público perdido após reinício; regeneração automática solicitada."
                    publication.status = "aguardando"
                    publication.error = "Vídeo indisponível; o agente está regenerando automaticamente antes de publicar."
                    db.commit()
                    return
                else:
                    raise
            connection, token = self.valid_token(db)
            account_id = connection.external_account_id
            creation_id = self.create_reel_container(account_id, token, video_url, publication.caption)
            publication.remote_id = creation_id
            db.commit()

            deadline = time.monotonic() + 150
            while time.monotonic() < deadline:
                status_data = self.container_status(creation_id, token)
                status_code = str(status_data.get("status_code") or "").upper()
                if status_code == "FINISHED":
                    break
                if status_code in {"ERROR", "EXPIRED"}:
                    raise InstagramError(str(status_data.get("status") or f"Processamento do Reel: {status_code}"))
                time.sleep(5)
            else:
                raise InstagramError("O Instagram não concluiu o processamento do Reel dentro do tempo esperado.")

            media_id = self.publish_container(account_id, token, creation_id)
            publication.remote_id = media_id
            publication.remote_url = self.media_permalink(media_id, token)
            publication.status = "publicado"
            publication.published_at = _utcnow()
            publication.error = ""
            publication.updated_at = _utcnow()
            db.commit()
        except Exception as exc:
            publication.status = "falhou"
            publication.error = str(exc)[:2000]
            publication.updated_at = _utcnow()
            db.commit()

    @staticmethod
    def new_state() -> str:
        return secrets.token_urlsafe(32)

    @staticmethod
    def _safe_response_text(response: httpx.Response, limit: int = 800) -> str:
        """Retorna texto útil sem expor tokens ou segredos nos logs/tela."""
        text = str(response.text or "")[:limit]
        for marker in ("access_token", "client_secret", "appsecret_proof"):
            text = text.replace(marker, f"{marker}_redacted")
        return text

    @classmethod
    def _meta_error_details(cls, response: httpx.Response, action: str, data: Any) -> tuple[dict[str, Any], str]:
        error = data.get("error") if isinstance(data, dict) else None
        if not isinstance(error, dict):
            error = {}
        details = {
            "event": "meta_instagram_api_error",
            "action": action,
            "http_status": int(response.status_code),
            "error_type": str(error.get("type") or ""),
            "error_code": error.get("code"),
            "error_subcode": error.get("error_subcode"),
            "message": str(error.get("message") or cls._safe_response_text(response) or "Erro sem mensagem"),
            "fbtrace_id": str(error.get("fbtrace_id") or ""),
            "is_transient": error.get("is_transient"),
        }
        parts = [
            f"Não foi possível {action}",
            f"HTTP {details['http_status']}",
        ]
        if details["error_code"] is not None:
            parts.append(f"código {details['error_code']}")
        if details["error_subcode"] is not None:
            parts.append(f"subcódigo {details['error_subcode']}")
        if details["error_type"]:
            parts.append(f"tipo {details['error_type']}")
        parts.append(details["message"])
        if details["fbtrace_id"]:
            parts.append(f"fbtrace_id {details['fbtrace_id']}")
        return details, ". ".join(str(part).rstrip(".") for part in parts if str(part).strip()) + "."

    @classmethod
    def _json_or_error(cls, response: httpx.Response, action: str) -> dict[str, Any]:
        try:
            data = response.json()
            parsed_json = True
        except Exception:
            data = {}
            parsed_json = False
        if response.status_code >= 400:
            details, user_message = cls._meta_error_details(response, action, data)
            logger.error(json.dumps(details, ensure_ascii=False, sort_keys=True))
            raise InstagramError(user_message)
        if not parsed_json or not isinstance(data, dict):
            details = {
                "event": "meta_instagram_invalid_response",
                "action": action,
                "http_status": int(response.status_code),
                "body_preview": cls._safe_response_text(response),
            }
            logger.error(json.dumps(details, ensure_ascii=False, sort_keys=True))
            raise InstagramError(f"Resposta inválida ao {action}. HTTP {response.status_code}.")
        return data

# Publicador persistente: processa a fila sequencialmente e retoma após reinicializações.
import threading
from app.db.database import SessionLocal

_publisher_stop = threading.Event()
_publisher_thread: threading.Thread | None = None


def _publisher_loop() -> None:
    service = InstagramService(timeout=45)
    while not _publisher_stop.wait(5):
        db = SessionLocal()
        try:
            now = _utcnow()
            due = db.scalar(
                select(Publication)
                .where(
                    Publication.provider == "instagram",
                    (
                        (Publication.status == "aguardando")
                        | ((Publication.status == "agendado") & (Publication.scheduled_at <= now))
                    ),
                )
                .order_by(Publication.scheduled_at.asc(), Publication.created_at.asc())
                .limit(1)
            )
            if due:
                service.publish_reel(db, due.id)
        except Exception:
            db.rollback()
        finally:
            db.close()


def start_instagram_publisher() -> None:
    global _publisher_thread
    if _publisher_thread and _publisher_thread.is_alive():
        return
    _publisher_stop.clear()
    _publisher_thread = threading.Thread(target=_publisher_loop, name="instagram-publisher", daemon=True)
    _publisher_thread.start()


def stop_instagram_publisher() -> None:
    _publisher_stop.set()
    if _publisher_thread and _publisher_thread.is_alive():
        _publisher_thread.join(timeout=3)
