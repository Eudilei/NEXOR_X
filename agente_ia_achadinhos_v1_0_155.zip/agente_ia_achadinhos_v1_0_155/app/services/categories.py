from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CategoryDefinition:
    key: str
    label: str
    icon: str
    keywords: tuple[str, ...]


CATEGORY_DEFINITIONS: tuple[CategoryDefinition, ...] = (
    CategoryDefinition("casa", "Casa", "🏠", ("casa", "lar", "decoracao", "banheiro", "lavanderia", "iluminacao", "tapete")),
    CategoryDefinition("cozinha", "Cozinha", "🍳", ("cozinha", "panela", "frigideira", "copo", "garrafa", "cafeteira", "air fryer", "utensilio", "pote")),
    CategoryDefinition("organizacao", "Organização", "🧺", ("organizador", "organizacao", "gaveta", "armario", "prateleira", "caixa organizadora", "cabide")),
    CategoryDefinition("limpeza", "Limpeza", "🧹", ("limpeza", "limpador", "vassoura", "mop", "esfregao", "aspirador", "escova eletrica", "lavadora")),
    CategoryDefinition("beleza", "Beleza", "✨", ("beleza", "maquiagem", "batom", "base facial", "perfume", "unha", "manicure", "secador", "chapinha")),
    CategoryDefinition("cuidados_pessoais", "Cuidados pessoais", "🧴", ("cuidados pessoais", "higiene", "barbeador", "depilador", "massageador", "escova dental", "saude", "facial")),
    CategoryDefinition("eletronicos", "Eletrônicos", "🔌", ("eletronico", "smartwatch", "fone", "caixa de som", "camera", "projetor", "controle remoto", "carregador")),
    CategoryDefinition("celulares_acessorios", "Celulares e acessórios", "📱", ("celular", "smartphone", "capa", "pelicula", "suporte celular", "power bank", "cabo usb")),
    CategoryDefinition("informatica", "Informática", "💻", ("informatica", "notebook", "computador", "teclado", "mouse", "monitor", "ssd", "impressora", "roteador")),
    CategoryDefinition("ferramentas", "Ferramentas", "🛠️", ("ferramenta", "parafusadeira", "furadeira", "chave", "alicate", "serra", "multimetro", "trena")),
    CategoryDefinition("automotivo", "Automotivo", "🚗", ("automotivo", "carro", "veiculo", "moto", "painel", "pneu", "limpa para-brisa", "aspirador veicular")),
    CategoryDefinition("pet", "Pet", "🐾", ("pet", "cachorro", "gato", "animal", "racao", "coleira", "comedouro", "brinquedo pet")),
    CategoryDefinition("infantil", "Infantil", "🧸", ("infantil", "bebe", "crianca", "brinquedo", "fralda", "maternidade", "carrinho de bebe")),
    CategoryDefinition("esporte_lazer", "Esporte e lazer", "⚽", ("esporte", "fitness", "academia", "bicicleta", "camping", "pesca", "bola", "lazer")),
    CategoryDefinition("escritorio_papelaria", "Escritório e papelaria", "📚", ("papelaria", "escritorio", "caderno", "caneta", "agenda", "mochila", "etiqueta", "grampeador")),
    CategoryDefinition("moda_acessorios", "Moda e acessórios", "👜", ("moda", "roupa", "camisa", "vestido", "calcado", "tenis", "bolsa", "oculos", "relogio")),
    CategoryDefinition("viagem", "Viagem", "🧳", ("viagem", "mala", "necessaire", "passaporte", "travesseiro de viagem", "organizador de mala")),
    CategoryDefinition("jardim", "Jardim", "🌿", ("jardim", "jardinagem", "planta", "mangueira", "vaso", "poda", "irrigacao")),
    CategoryDefinition("seguranca", "Segurança", "🔒", ("seguranca", "alarme", "fechadura", "cadeado", "sensor", "camera de seguranca", "detector")),
    CategoryDefinition("utilidades", "Utilidades", "🛍️", ("utilidade", "multiuso", "portatil", "recarregavel", "pratico")),
)

CATEGORY_BY_KEY = {item.key: item for item in CATEGORY_DEFINITIONS}


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFKD", str(value or "").lower())
    value = "".join(char for char in value if not unicodedata.combining(char))
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def classify_product_category(*parts: str, fallback: str = "utilidades") -> str:
    text = f" {' '.join(normalize_text(part) for part in parts if part)} "
    best_key, best_score = fallback, 0
    for category in CATEGORY_DEFINITIONS:
        score = 0
        for keyword in category.keywords:
            normalized = normalize_text(keyword)
            if normalized and f" {normalized} " in text:
                score += 3 + len(normalized.split())
            elif normalized and normalized in text:
                score += 1
        if score > best_score:
            best_key, best_score = category.key, score
    return best_key


def category_label(key: str) -> str:
    definition = CATEGORY_BY_KEY.get(str(key or "").strip().lower())
    return definition.label if definition else str(key or "Utilidades").replace("_", " ").title()
