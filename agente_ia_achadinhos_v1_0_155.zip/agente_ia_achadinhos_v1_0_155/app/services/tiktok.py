from __future__ import annotations

import secrets
import time
from datetime import datetime, timedelta, timezone
from typing import Any
import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import SocialConnection
from app.services.oauth_tokens import encrypt_value, decrypt_value

class TikTokError(RuntimeError):
    def __init__(self, message: str, *, code: str = "", log_id: str = ""):
        super().__init__(message)
        self.code = str(code or "")
        self.log_id = str(log_id or "")

class TikTokService:
    authorize_url = "https://www.tiktok.com/v2/auth/authorize/"
    token_url = "https://open.tiktokapis.com/v2/oauth/token/"
    api_base = "https://open.tiktokapis.com"

    @property
    def configured(self) -> bool:
        return bool(settings.tiktok_client_key and settings.tiktok_client_secret and settings.tiktok_redirect_uri)

    def new_state(self) -> str:
        return secrets.token_urlsafe(32)

    def authorization_url(self, state: str) -> str:
        if not self.configured:
            raise TikTokError("Credenciais do TikTok for Developers ainda não configuradas.")
        params = {
            "client_key": settings.tiktok_client_key,
            "scope": "user.info.basic,video.publish,video.upload",
            "response_type": "code",
            "redirect_uri": settings.tiktok_redirect_uri,
            "state": state,
        }
        return str(httpx.URL(self.authorize_url, params=params))

    def exchange_code(self, code: str) -> dict[str, Any]:
        return self._token_request({"client_key": settings.tiktok_client_key, "client_secret": settings.tiktok_client_secret, "code": code, "grant_type": "authorization_code", "redirect_uri": settings.tiktok_redirect_uri})

    def refresh(self, refresh_token: str) -> dict[str, Any]:
        return self._token_request({"client_key": settings.tiktok_client_key, "client_secret": settings.tiktok_client_secret, "grant_type": "refresh_token", "refresh_token": refresh_token})

    def _token_request(self, payload: dict[str, Any]) -> dict[str, Any]:
        r=httpx.post(self.token_url, data=payload, headers={"Content-Type":"application/x-www-form-urlencoded"}, timeout=30)
        if r.status_code >= 400:
            raise TikTokError(f"TikTok recusou a autorização (HTTP {r.status_code}): {r.text[:500]}")
        data=r.json()
        if not data.get("access_token"):
            raise TikTokError(str(data.get("error_description") or data.get("error") or "Resposta do TikTok sem access_token."))
        return data

    def save_connection(self, db: Session, data: dict[str, Any]) -> SocialConnection:
        c=db.scalar(select(SocialConnection).where(SocialConnection.provider=="tiktok"))
        if not c:
            c=SocialConnection(provider="tiktok"); db.add(c)
        c.account_name=str(data.get("display_name") or data.get("open_id") or "TikTok")
        c.external_account_id=str(data.get("open_id") or "")
        c.access_token_encrypted=encrypt_value(str(data["access_token"]))
        if data.get("refresh_token"): c.refresh_token_encrypted=encrypt_value(str(data["refresh_token"]))
        c.expires_at=datetime.now(timezone.utc)+timedelta(seconds=max(int(data.get("expires_in") or 86400)-60,60))
        c.status="conectado"; db.commit(); db.refresh(c); return c

    def access_token(self, db: Session) -> str:
        c=db.scalar(select(SocialConnection).where(SocialConnection.provider=="tiktok"))
        if not c or not c.access_token_encrypted: raise TikTokError("Conecte a conta do TikTok primeiro.")
        now=datetime.now(timezone.utc); exp=c.expires_at
        if exp and exp.tzinfo is None: exp=exp.replace(tzinfo=timezone.utc)
        if exp and exp <= now+timedelta(minutes=5) and c.refresh_token_encrypted:
            data=self.refresh(decrypt_value(c.refresh_token_encrypted) or "")
            c=self.save_connection(db,data)
        return decrypt_value(c.access_token_encrypted) or ""

    def creator_info(self, token: str) -> dict[str, Any]:
        r=httpx.post(self.api_base+"/v2/post/publish/creator_info/query/", headers={"Authorization":f"Bearer {token}","Content-Type":"application/json; charset=UTF-8"}, json={}, timeout=30)
        data=r.json(); err=data.get("error") or {}
        if r.status_code>=400 or err.get("code") not in (None,"ok"):
            raise TikTokError(f"Falha ao consultar a conta TikTok: {err.get('message') or r.text[:400]}", code=str(err.get("code") or r.status_code), log_id=str(err.get("log_id") or err.get("logid") or ""))
        return data.get("data") or {}

    def user_info(self, token: str) -> dict[str, Any]:
        """Obtém nome/avatar da conta conectada quando user.info.basic foi autorizado."""
        r=httpx.get(
            self.api_base+"/v2/user/info/",
            headers={"Authorization":f"Bearer {token}"},
            params={"fields":"open_id,display_name,avatar_url"},
            timeout=30,
        )
        data=r.json(); err=data.get("error") or {}
        if r.status_code>=400 or err.get("code") not in (None,"ok"):
            raise TikTokError(f"Falha ao consultar o perfil TikTok: {err.get('message') or r.text[:400]}")
        return (data.get("data") or {}).get("user") or {}

    def enrich_connection(self, db: Session, connection: SocialConnection) -> SocialConnection:
        """Atualiza o nome exibido sem expor token no navegador/logs."""
        try:
            token=self.access_token(db)
            user=self.user_info(token)
            if user.get("display_name"):
                connection.account_name=str(user["display_name"])[:120]
            if user.get("open_id"):
                connection.external_account_id=str(user["open_id"])[:120]
            db.commit(); db.refresh(connection)
        except Exception:
            # A conexão continua válida mesmo se a consulta de perfil falhar temporariamente.
            pass
        return connection

    def direct_post(
        self, token: str, *, video: bytes, caption: str, privacy_level: str,
        allow_duet: bool=True, allow_comment: bool=True, allow_stitch: bool=True,
        brand_content: bool=True, brand_organic: bool=False, is_aigc: bool=True,
    ) -> str:
        size=len(video)
        if size<=0:
            raise TikTokError("O vídeo está vazio.")
        payload={
            "post_info":{
                "title":caption[:2200],
                "privacy_level":privacy_level,
                "disable_duet":not bool(allow_duet),
                "disable_comment":not bool(allow_comment),
                "disable_stitch":not bool(allow_stitch),
                "brand_content_toggle":bool(brand_content),
                "brand_organic_toggle":bool(brand_organic),
                "is_aigc":bool(is_aigc),
            },
            "source_info":{
                "source":"FILE_UPLOAD",
                "video_size":size,
                "chunk_size":size,
                "total_chunk_count":1,
            },
        }
        r=httpx.post(
            self.api_base+"/v2/post/publish/video/init/",
            headers={"Authorization":f"Bearer {token}","Content-Type":"application/json; charset=UTF-8"},
            json=payload, timeout=45,
        )
        data=r.json(); err=data.get("error") or {}
        if r.status_code>=400 or err.get("code") not in (None,"ok"):
            code=str(err.get("code") or r.status_code)
            log_id=str(err.get("log_id") or err.get("logid") or "")
            detail=err.get("message") or r.text[:500]
            suffix=f" [log_id={log_id}]" if log_id else ""
            raise TikTokError(f"TikTok recusou a publicação ({code}): {detail}{suffix}", code=code, log_id=log_id)
        info=data.get("data") or {}; upload_url=info.get("upload_url"); publish_id=info.get("publish_id")
        if not upload_url or not publish_id:
            raise TikTokError("TikTok não retornou URL de upload ou publish_id.")
        u=httpx.put(
            upload_url, content=video,
            headers={"Content-Type":"video/mp4","Content-Length":str(size),"Content-Range":f"bytes 0-{size-1}/{size}"},
            timeout=180,
        )
        if u.status_code not in (200,201,204):
            raise TikTokError(f"Falha ao enviar vídeo ao TikTok (HTTP {u.status_code}): {u.text[:300]}")
        return str(publish_id)

    def upload_draft(self, token: str, *, video: bytes) -> str:
        """Fallback oficial: envia o MP4 para a caixa de entrada do TikTok para revisão/postagem no app."""
        size=len(video)
        if size<=0:
            raise TikTokError("O vídeo está vazio.")
        payload={"source_info":{"source":"FILE_UPLOAD","video_size":size,"chunk_size":size,"total_chunk_count":1}}
        r=httpx.post(
            self.api_base+"/v2/post/publish/inbox/video/init/",
            headers={"Authorization":f"Bearer {token}","Content-Type":"application/json; charset=UTF-8"},
            json=payload, timeout=45,
        )
        data=r.json(); err=data.get("error") or {}
        if r.status_code>=400 or err.get("code") not in (None,"ok"):
            code=str(err.get("code") or r.status_code); log_id=str(err.get("log_id") or err.get("logid") or "")
            raise TikTokError(f"TikTok recusou também o envio para rascunho ({code}): {err.get('message') or r.text[:500]}", code=code, log_id=log_id)
        info=data.get("data") or {}; upload_url=info.get("upload_url"); publish_id=info.get("publish_id")
        if not upload_url or not publish_id:
            raise TikTokError("TikTok não retornou URL de upload ou publish_id para o rascunho.")
        u=httpx.put(upload_url, content=video, headers={
            "Content-Type":"video/mp4","Content-Length":str(size),"Content-Range":f"bytes 0-{size-1}/{size}"
        }, timeout=180)
        if u.status_code not in (200,201,204):
            raise TikTokError(f"Falha ao enviar rascunho ao TikTok (HTTP {u.status_code}): {u.text[:300]}")
        return str(publish_id)

    def status(self, token: str, publish_id: str) -> dict[str, Any]:
        r=httpx.post(self.api_base+"/v2/post/publish/status/fetch/",headers={"Authorization":f"Bearer {token}","Content-Type":"application/json; charset=UTF-8"},json={"publish_id":publish_id},timeout=30)
        data=r.json(); err=data.get("error") or {}
        if r.status_code>=400 or err.get("code") not in (None,"ok"): raise TikTokError(err.get("message") or "Falha ao consultar publicação TikTok.")
        return data.get("data") or {}

    def wait_for_final_status(self, token: str, publish_id: str, *, attempts: int=10, interval_seconds: float=3.0) -> dict[str, Any]:
        """Acompanha o processamento inicial sem fazer polling agressivo."""
        last: dict[str, Any]={}
        for _ in range(max(1, attempts)):
            last=self.status(token, publish_id)
            status=str(last.get("status") or "").upper()
            if status in {"PUBLISH_COMPLETE", "FAILED"}:
                return last
            time.sleep(max(0.0, interval_seconds))
        return last
