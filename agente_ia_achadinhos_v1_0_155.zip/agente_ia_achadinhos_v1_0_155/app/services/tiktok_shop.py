from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from app.core.config import settings


class TikTokShopError(RuntimeError):
    pass


@dataclass
class TikTokShopCandidate:
    product_id: str
    title: str
    category: str
    price: float
    original_price: float | None = None
    rating: float = 0.0
    review_count: int = 0
    sold_quantity: int = 0
    monthly_sold_quantity: int = 0
    commission_pct: float = 0.0
    stock: int = 0
    affiliate_url: str = ""
    image_urls: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class TikTokShopCreatorClient:
    """Cliente do motor de afiliados do TikTok Shop.

    O endpoint de busca é configurável porque a TikTok libera o conjunto de APIs
    e versões conforme o app aprovado no Partner Center. O agente não simula
    resultados: sem credenciais e escopo oficial ele permanece em modo de espera.
    """

    def __init__(self) -> None:
        self.base_url = settings.tiktok_shop_api_base_url.rstrip("/")
        self.app_key = settings.tiktok_shop_app_key or ""
        self.app_secret = settings.tiktok_shop_app_secret or ""
        self.access_token = settings.tiktok_shop_access_token or ""
        self.search_path = (settings.tiktok_shop_creator_search_path or "").strip()

    @property
    def configured(self) -> bool:
        return settings.tiktok_shop_api_configured

    def _sign(self, path: str, params: dict[str, Any], body: str) -> str:
        filtered = {k: v for k, v in params.items() if k not in {"sign", "access_token"} and v is not None}
        ordered = "".join(f"{key}{filtered[key]}" for key in sorted(filtered))
        message = f"{path}{ordered}{body}"
        payload = f"{self.app_secret}{message}{self.app_secret}".encode()
        return hmac.new(self.app_secret.encode(), payload, hashlib.sha256).hexdigest()

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.configured:
            raise TikTokShopError("A API oficial do TikTok Shop ainda não foi conectada ao agente.")
        if not path.startswith("/"):
            path = "/" + path
        timestamp = int(time.time())
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        params: dict[str, Any] = {"app_key": self.app_key, "timestamp": timestamp}
        params["sign"] = self._sign(path, params, body)
        headers = {"Content-Type": "application/json", "x-tts-access-token": self.access_token}
        try:
            response = httpx.post(f"{self.base_url}{path}", params=params, content=body.encode(), headers=headers, timeout=35)
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPStatusError as exc:
            detail = exc.response.text[:800]
            raise TikTokShopError(f"TikTok Shop recusou a busca (HTTP {exc.response.status_code}): {detail}") from exc
        except (httpx.RequestError, ValueError) as exc:
            raise TikTokShopError(f"Falha ao consultar o TikTok Shop: {exc}") from exc
        if not isinstance(data, dict):
            raise TikTokShopError("Resposta inválida da API do TikTok Shop.")
        code = data.get("code")
        if code not in (None, 0, "0", "success"):
            raise TikTokShopError(str(data.get("message") or data.get("msg") or f"Erro TikTok Shop: {code}"))
        return data

    @staticmethod
    def _items(data: dict[str, Any]) -> list[dict[str, Any]]:
        node: Any = data.get("data", data)
        if isinstance(node, dict):
            for key in ("products", "product_list", "items", "results"):
                value = node.get(key)
                if isinstance(value, list):
                    return [item for item in value if isinstance(item, dict)]
        return []

    @staticmethod
    def _number(item: dict[str, Any], *keys: str, default: float = 0.0) -> float:
        for key in keys:
            value = item.get(key)
            if isinstance(value, dict):
                value = value.get("amount") or value.get("value")
            try:
                if value not in (None, ""):
                    return float(value)
            except (TypeError, ValueError):
                continue
        return default

    def search_open_collaboration_products(
        self,
        *,
        keyword: str = "",
        category_id: str = "",
        min_commission_pct: float = 0,
        min_monthly_sales: int = 0,
        min_stock: int = 0,
        page_size: int = 30,
    ) -> list[TikTokShopCandidate]:
        payload: dict[str, Any] = {
            "page_size": max(1, min(page_size, 50)),
            "keyword": keyword.strip(),
            "region": settings.tiktok_shop_region,
        }
        if category_id.strip():
            payload["category_id"] = category_id.strip()
        if min_commission_pct > 0:
            payload["min_commission_rate"] = min_commission_pct
        data = self._post(self.search_path, payload)
        candidates: list[TikTokShopCandidate] = []
        for item in self._items(data):
            product_id = str(item.get("product_id") or item.get("id") or item.get("productId") or "").strip()
            title = str(item.get("title") or item.get("product_name") or item.get("name") or "").strip()
            if not product_id or not title:
                continue
            images = item.get("images") or item.get("image_urls") or []
            if isinstance(images, str):
                images = [images]
            normalized_images: list[str] = []
            for image in images if isinstance(images, list) else []:
                url = image.get("url") if isinstance(image, dict) else image
                if url:
                    normalized_images.append(str(url))
            monthly_sales = int(self._number(item, "monthly_sold_quantity", "monthly_sales", "sales_30d", default=0))
            stock = int(self._number(item, "stock", "stock_count", "available_stock", default=0))
            commission = self._number(item, "commission_rate", "commission_pct", "commission", default=0)
            if 0 < commission <= 1:
                commission *= 100
            if commission < min_commission_pct or monthly_sales < min_monthly_sales or stock < min_stock:
                continue
            candidates.append(TikTokShopCandidate(
                product_id=product_id,
                title=title,
                category=str(item.get("category_name") or item.get("category") or "cuidados_pessoais"),
                price=self._number(item, "price", "sale_price", "min_price", default=0),
                original_price=self._number(item, "original_price", "list_price", default=0) or None,
                rating=self._number(item, "rating", "product_rating", default=0),
                review_count=int(self._number(item, "review_count", "reviews", default=0)),
                sold_quantity=int(self._number(item, "sold_quantity", "total_sales", default=monthly_sales)),
                monthly_sold_quantity=monthly_sales,
                commission_pct=commission,
                stock=stock,
                affiliate_url=str(item.get("affiliate_url") or item.get("promotion_link") or item.get("product_url") or ""),
                image_urls=normalized_images,
                metadata=item,
            ))
        return candidates
