from __future__ import annotations

import base64
from datetime import datetime, timezone
import json
import logging
import re
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import Product, ProductObservation, SitePublication
from app.services.production import parse_media_urls
from app.services.marketplace import MercadoLivreClient
from app.services.categories import category_label
from app.services.affiliate_links import resolve_affiliate_link

logger = logging.getLogger(__name__)
ACTIVE_PRODUCT_STATUSES = {"aprovado", "aprovado_comercial", "pronto_publicacao"}
INTERNAL_TEXT_PATTERNS = ("catalog_product_id=", "pré-selecionado pelo ranking", "precisam ser confirmados antes da aprovação")

class ZavomiSiteError(RuntimeError):
    pass

def configured() -> bool:
    return bool(settings.github_site_token and settings.github_site_owner and settings.github_site_repo)

def _money(value: float | None) -> str:
    if value is None or value <= 0: return ""
    return f"R$ {value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def source_metadata(product: Product) -> dict[str, Any]:
    try:
        data=json.loads(product.source_metadata_json or "{}")
        return data if isinstance(data,dict) else {}
    except Exception:
        return {}

def save_source_metadata(product: Product, data: dict[str, Any]) -> None:
    product.source_metadata_json=json.dumps(data,ensure_ascii=False,sort_keys=True)

def set_site_flag(product: Product, key: str, value: Any) -> None:
    data=source_metadata(product); site=data.get("zavomi_site") if isinstance(data.get("zavomi_site"),dict) else {}
    site[key]=value; data["zavomi_site"]=site; save_source_metadata(product,data)

def site_flags(product: Product) -> dict[str, Any]:
    data=source_metadata(product); value=data.get("zavomi_site")
    return value if isinstance(value,dict) else {}

def _confirmed(meta: dict[str, Any], *keys: str) -> bool:
    return any(bool(meta.get(k)) for k in keys)

def _clean_title(value: str) -> str:
    text=" ".join(str(value or "").split())
    text=re.sub(r"\bC\s*/?\s*(\d+)\b", r"com \1", text, flags=re.I)
    return text[:220]

def _affiliate_link_confirmed(product: Product, meta: dict[str, Any]) -> bool:
    """Confirma que o botão público usa um link de afiliado salvo conscientemente.

    O Mercado Livre credita a indicação pelo link gerado na Central de Afiliados.
    Um permalink comum do anúncio não é tratado como link comissionável.
    """
    url = str(product.affiliate_url or "").strip()
    if not url.startswith("https://"):
        return False
    if bool(meta.get("affiliate_link_confirmed")):
        return True
    # Links curtos gerados/compartilhados pelo ecossistema do Mercado Livre.
    return bool(re.match(r"https://(?:www\.)?(?:meli\.la|mercadolivre\.com/sec/)", url, flags=re.I))


def _public_description(product: Product, meta: dict[str, Any]) -> str:
    candidates=[meta.get("original_listing_description"),meta.get("listing_description"),product.original_description]
    for raw in candidates:
        text=str(raw or "").strip()
        if text and not any(pattern in text.lower() for pattern in INTERNAL_TEXT_PATTERNS):
            return text[:12000]
    return ""

def _attributes(meta: dict[str, Any]) -> list[dict[str,str]]:
    raw=meta.get("attributes") or meta.get("listing_attributes") or []
    out=[]
    if isinstance(raw,dict): raw=[{"name":k,"value":v} for k,v in raw.items()]
    if isinstance(raw,list):
        for item in raw:
            if not isinstance(item,dict): continue
            name=str(item.get("name") or item.get("label") or item.get("id") or "").strip()
            value=str(item.get("value_name") or item.get("value") or item.get("text") or "").strip()
            if name and value: out.append({"name":name[:120],"value":value[:300]})
    return out[:40]

def _technical_description(product: Product, meta: dict[str, Any]) -> str:
    """Gera descrição verificável sem inventar fatos."""
    attrs = _attributes(meta)
    title = _clean_title(product.title)
    if attrs:
        pairs = {row["name"].strip().lower(): row["value"].strip() for row in attrs}
        highlights = []
        for key in ("marca", "linha", "modelo", "material", "composição", "formato de venda", "unidades por kit", "cor", "tamanho"):
            if pairs.get(key):
                highlights.append(f"{key.capitalize()}: {pairs[key]}")
        intro = f"{title}. Este produto foi descrito com base nas características oficiais informadas no anúncio."
        if highlights:
            intro += " " + "; ".join(highlights[:6]) + "."
        lines = [f"{row['name']}: {row['value']}" for row in attrs[:24]]
        return (intro + "\n\nCaracterísticas confirmadas:\n" + "\n".join(f"• {line}" for line in lines))[:12000]
    words = [w for w in re.split(r"\s+", title) if w]
    if len(words) >= 7:
        category = str(product.category or "produto").replace("_", " ").strip().lower()
        return (f"{title}. Descrição técnica gerada automaticamente a partir do título oficial do anúncio. "
                f"Trata-se de um item da categoria {category}. Confira as fotos, variações, preço e condições no anúncio original antes da compra.")[:12000]
    return ""

def resolve_public_description(product: Product, meta: dict[str, Any]) -> tuple[str, str]:
    description = _public_description(product, meta)
    if description:
        return description, str(meta.get("description_source") or "original")
    technical = _technical_description(product, meta)
    if technical:
        return technical, "technical_from_attributes"
    return "", "unavailable"

def product_payload(product: Product) -> dict[str, Any] | None:
    flags=site_flags(product)
    if flags.get("excluded") or product.status not in ACTIVE_PRODUCT_STATUSES or not product.stock_available: return None
    images=[u for u in parse_media_urls(product.media_urls) if str(u).startswith("https://")]
    meta=source_metadata(product)
    if not images or not str(product.affiliate_url or "").startswith("https://"): return None
    description, description_source = resolve_public_description(product,meta)
    payload={
      "id":f"produto-{product.id}","source_id":product.external_product_id or "","title":_clean_title(product.title),
      "description":description,"category":category_label(product.category),"category_key":product.category,"price":_money(product.price),
      "images":images[:24],"image_url":images[0],"offer_url":product.affiliate_url.strip(),"status":"active",
      "marketplace":product.marketplace,"highlighted":bool(flags.get("highlighted")),
      "affiliate_link_confirmed": _affiliate_link_confirmed(product, meta),
      "updated_at":(product.updated_at or product.created_at or datetime.now(timezone.utc)).isoformat(),
      "attributes":_attributes(meta),"variants":meta.get("variants") if isinstance(meta.get("variants"),list) else [],
      "last_checked_at":str(meta.get("last_checked_at") or ""), "description_source": description_source,
    }
    if product.original_price and product.original_price>product.price: payload["original_price"]=_money(product.original_price)
    if product.rating and product.rating>0 and _confirmed(meta,"rating_confirmed","reviews_confirmed","source_verified"):
        payload["rating"]=round(float(product.rating),1)
    if product.review_count and _confirmed(meta,"review_count_confirmed","reviews_confirmed","source_verified"):
        payload["review_count"]=int(product.review_count)
    if product.sold_quantity and _confirmed(meta,"sold_quantity_confirmed","sold_count_confirmed","source_verified"):
        payload["sold_count"]=int(product.sold_quantity)
    payload["sort_sold_count"]=int(payload.get("sold_count") or -1)
    payload["sort_rating"]=float(payload.get("rating") or -1)
    payload["sort_review_count"]=int(payload.get("review_count") or -1)
    return payload

def build_catalog(db: Session) -> dict[str, Any]:
    products=db.scalars(select(Product).order_by(Product.updated_at.desc())).all()
    items=[p for product in products if (p:=product_payload(product)) and p.get("description") and p.get("affiliate_link_confirmed")]
    items.sort(key=lambda p:(bool(p.get("highlighted")),p["sort_sold_count"],p["sort_rating"],p["sort_review_count"],p.get("updated_at","")),reverse=True)
    return {"generated_at":datetime.now(timezone.utc).isoformat(),"source":"Agente IA Zavomi","sorting":"highlighted,sold_count,rating,review_count,updated_at","products":items}

def _headers():
    return {"Authorization":f"Bearer {settings.github_site_token}","Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28","User-Agent":"agente-ia-zavomi"}

def publish_catalog(db: Session, *, trigger: str="manual") -> SitePublication:
    event=SitePublication(status="processando",trigger=trigger,site_url=settings.zavomi_site_url); db.add(event); db.commit(); db.refresh(event)
    if not configured():
        event.status="nao_configurado"; event.error="Configure GITHUB_SITE_TOKEN no Render para ativar a publicação automática."; db.commit(); return event
    catalog=build_catalog(db); content=json.dumps(catalog,ensure_ascii=False,indent=2)+"\n"
    owner,repo,branch=settings.github_site_owner,settings.github_site_repo,settings.github_site_branch
    path=settings.github_site_catalog_path.strip("/"); api_url=f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"
    try:
        with httpx.Client(timeout=25,follow_redirects=True) as client:
            get=client.get(api_url,headers=_headers(),params={"ref":branch}); sha=""
            if get.status_code==200: sha=str(get.json().get("sha") or "")
            elif get.status_code!=404: raise ZavomiSiteError(f"GitHub recusou a leitura do catálogo (HTTP {get.status_code}).")
            body={"message":f"Atualiza catálogo Zavomi ({trigger})","content":base64.b64encode(content.encode()).decode(),"branch":branch}
            if sha: body["sha"]=sha
            response=client.put(api_url,headers=_headers(),json=body)
            if response.status_code not in {200,201}: raise ZavomiSiteError(f"GitHub recusou a publicação (HTTP {response.status_code}): {response.text[:600]}")
            result=response.json()
        event.status="publicado"; event.product_count=len(catalog["products"]); event.commit_sha=str((result.get("commit") or {}).get("sha") or ""); event.error=""; event.published_at=datetime.now(timezone.utc); db.commit(); return event
    except Exception as exc:
        logger.exception("Falha ao publicar catálogo da Zavomi"); event.status="falhou"; event.error=str(exc)[:2000]; db.commit(); return event

def publish_catalog_background(trigger: str="automatico") -> None:
    from app.db.database import SessionLocal
    db=SessionLocal()
    try: publish_catalog(db,trigger=trigger)
    finally: db.close()


def _extract_catalog_id(url: str) -> str:
    match = re.search(r"/p/(MLB\d+)(?:[/?#]|$)", str(url or ""), flags=re.I)
    return match.group(1).upper() if match else ""


def _extract_item_id(product: Product, meta: dict[str, Any]) -> str:
    for value in (meta.get("listing_item_id"), product.external_product_id):
        text = str(value or "").strip().upper()
        if re.fullmatch(r"MLB\d+", text):
            return text
    match = re.search(r"MLB[-_]?(\d+)", str(product.affiliate_url or ""), flags=re.I)
    return f"MLB{match.group(1)}" if match and "/p/" not in str(product.affiliate_url or "") else ""


def refresh_product_from_source(db: Session, product: Product) -> dict[str, Any]:
    """Atualiza preço, estoque, métricas, fotos, descrição e atributos sem inventar dados."""
    client = MercadoLivreClient(db=db)
    meta = source_metadata(product)
    before = {
        "price": float(product.price or 0), "rating": float(product.rating or 0),
        "review_count": int(product.review_count or 0), "sold_quantity": int(product.sold_quantity or 0),
        "stock_available": bool(product.stock_available),
    }
    item_id = _extract_item_id(product, meta)
    catalog: dict[str, Any] = {}
    source_url = str(meta.get("listing_url") or product.affiliate_url or "").strip()
    catalog_id = _extract_catalog_id(source_url) or str(meta.get("catalog_product_id") or "").strip().upper()
    if catalog_id:
        try:
            catalog = client.product_detail(catalog_id)
            winner = client._winner_payload(catalog)
            item_id = str(client._extract_item_id(winner) or item_id or "")
            if not item_id:
                item_id = str(client.product_winner_item(catalog_id) or "")
            if not item_id:
                candidates = client.product_items(catalog_id, limit=10)
                item_id = str(candidates[0] if candidates else "")
        except Exception as exc:
            meta["last_refresh_warning"] = f"Catálogo indisponível: {str(exc)[:180]}"

    # Segue redirecionamentos de links curtos/afiliados e recupera o ITEM_ID real
    # do anúncio antes de consultar a descrição oficial.
    if not item_id and source_url.startswith("https://"):
        try:
            public_probe = client.public_product_snapshot(source_url)
            final_link = str(public_probe.get("permalink") or "")
            match = re.search(r"MLB[-_]?(\d+)", final_link, flags=re.I)
            if match and "/p/" not in final_link:
                item_id = f"MLB{match.group(1)}"
            if not meta.get("listing_url") and final_link:
                meta["listing_url"] = final_link
        except Exception:
            pass

    item: dict[str, Any] = {}
    if item_id:
        try:
            item = client._item_detail_individual(item_id) or {}
        except Exception:
            item = {}

    # Consulta tanto a página da oferta quanto a PDP de catálogo. A primeira é
    # melhor para preço/estoque; a segunda pode conter avaliação e quantidade
    # de opiniões agregadas que não aparecem no anúncio individual.
    public_snapshots: list[dict[str, Any]] = []
    source_public: dict[str, Any] = {}
    public_urls = [
        client.item_public_url(item_id) if item_id else "",
        source_url,
        client.catalog_product_url(catalog_id) if catalog_id else "",
    ]
    for url in dict.fromkeys(public_urls):
        if not url:
            continue
        try:
            snap = client.public_product_snapshot(url)
            if snap:
                public_snapshots.append(snap)
                if source_url and url == source_url:
                    source_public = snap
        except Exception:
            continue
    public: dict[str, Any] = client.merge_public_snapshots(*public_snapshots) if public_snapshots else {}
    # The URL stored as the product source is what the operator/customer opens.
    # Keep its offer/variation price and title separate from aggregate catalog
    # enrichment so another buy-box offer cannot silently replace them.
    display_public = source_public or public

    winner = client._winner_payload(catalog) if catalog else {}
    merged: dict[str, Any] = {}
    for source in (catalog, winner, item, public):
        if isinstance(source, dict):
            merged = client._merge_product_data(merged, source)

    media_link = client.item_public_url(item_id) if item_id else source_url
    assets = client.listing_media_and_description(link=media_link, catalog_product=catalog)
    asset_item_id = str(assets.get("item_id") or "").strip().upper()
    if asset_item_id and not item_id:
        item_id = asset_item_id
    if item_id:
        meta["listing_item_id"] = item_id
        meta["item_id_status"] = "located"
    else:
        meta["item_id_status"] = "not_located"
    if source_url:
        meta["listing_url"] = source_url
    pictures = [str(x).strip() for x in assets.get("pictures") or [] if str(x).startswith("https://")]
    description = str(assets.get("description") or public.get("description") or "").strip()
    if not description and item_id:
        description = client.item_description(item_id)
    if pictures:
        product.media_urls = "\n".join(dict.fromkeys(pictures))
        product.media_license = "oficial_marketplace"
        meta["pictures_confirmed"] = True
        meta["media_source"] = "mercado_livre"
    if description:
        meta["description_api_status"] = "found"
        product.original_description = description
        meta["original_listing_description"] = description
        meta["description_confirmed"] = True
        meta["description_source"] = "original"
    else:
        technical = _technical_description(product, {**meta, "attributes": merged.get("attributes") or meta.get("attributes") or []})
        if technical:
            meta["description_api_status"] = "empty_fallback_generated"
            product.original_description = technical
            meta["description_confirmed"] = True
            meta["description_source"] = "technical_from_attributes"
        else:
            meta["description_api_status"] = "empty"
            meta["description_confirmed"] = False
            meta["description_source"] = "unavailable"

    if isinstance(merged.get("attributes"), list) and merged.get("attributes"):
        meta["attributes"] = merged.get("attributes")
    public_title = str(display_public.get("name") or display_public.get("title") or "").strip() if display_public else ""
    title = public_title or str(merged.get("title") or merged.get("name") or "").strip()
    if title:
        product.title = title[:180]
        if public_title:
            meta["title_source"] = "public_product_page_current"
    price = client._safe_float(merged.get("price") or merged.get("sale_price"), 0.0)
    original_price = client._safe_float(merged.get("original_price") or merged.get("base_price"), 0.0)

    # A atualização manual da v1.0.97 não chamava as APIs específicas de preço.
    # Por isso o botão "Atualizar fotos e descrição" podia continuar mostrando
    # preço não confirmado mesmo após localizar o anúncio real.
    # Current user-facing price must come from the same public PDP that the
    # shopper opens whenever that page exposes a valid active price. APIs such
    # as /sale_price may return another offer/variation of the same catalog
    # product, which caused values such as R$79,25 to be stored while the PDP
    # showed R$85,88. Public exact-offer snapshot wins; API is fallback only.
    public_price = client._safe_float(display_public.get("price"), 0.0) if display_public else 0.0
    public_original = client._safe_float(display_public.get("original_price"), 0.0) if display_public else 0.0
    if public_price > 0:
        price = public_price
        original_price = public_original if public_original > public_price else 0.0
        meta["price_source"] = "public_product_page_current"
        meta["original_price_source"] = "public_product_page_current" if original_price else "unavailable"
        meta["price_scope"] = "same_public_page"
    elif item_id:
        price_data = client.item_sale_prices(item_id)
        official_price = client._safe_float(price_data.get("price"), 0.0)
        if official_price > 0:
            price = official_price
            original_price = client._safe_float(price_data.get("original_price"), 0.0)
            meta["price_source"] = str(price_data.get("price_source") or "sale_price_api")
            meta["original_price_source"] = str(price_data.get("original_price_source") or "unavailable")
            meta["price_scope"] = "resolved_offer_api"

    rating, reviews = client._rating_and_reviews(merged)
    catalog_review_id = catalog_id or str(meta.get("catalog_product_id") or "").strip().upper()
    if item_id:
        review_payload = client.item_reviews(item_id, catalog_review_id)
        review_rating, review_total, rating_levels = client.review_metrics(review_payload)
        if review_rating > 0:
            rating = review_rating
            meta["rating_confirmed"] = True
            meta["rating_source"] = "reviews_api_catalog" if catalog_review_id else "reviews_api_item"
        if review_total > 0:
            reviews = review_total
            meta["review_count_confirmed"] = True
            meta["reviews_confirmed"] = True
            meta["review_count_source"] = "paging_total_or_rating_levels"
        if rating_levels:
            meta["rating_levels"] = rating_levels
    # Se a API de opiniões não trouxe métricas, usa somente valores explicitamente
    # exibidos na página pública (principalmente na PDP de catálogo).
    public_rating = client._safe_float(public.get("rating") or public.get("rating_average"), 0.0)
    public_reviews = client._safe_int(public.get("reviews_count") or public.get("review_count"), 0)
    if rating <= 0 and public_rating > 0:
        rating = public_rating
        meta["rating_confirmed"] = True
        meta["rating_source"] = "public_product_page"
    if reviews <= 0 and public_reviews > 0:
        reviews = public_reviews
        meta["review_count_confirmed"] = True
        meta["reviews_confirmed"] = True
        meta["review_count_source"] = "public_product_page"

    # Fallback final com navegador real, somente quando as métricas públicas
    # continuam ausentes. Não usa login/cookies e respeita o limite configurado.
    need_browser_rating = rating <= 0
    need_browser_reviews = reviews <= 0
    need_browser_sales = int(product.sold_quantity or 0) <= 0 and client._sold_reference(public.get("sold_quantity")) <= 0
    if settings.mercado_livre_browser_fallback_enabled and (need_browser_rating or need_browser_reviews or need_browser_sales):
        browser_snaps: list[dict[str, Any]] = []
        for browser_url in dict.fromkeys([
            client.item_public_url(item_id) if item_id else "",
            client.catalog_product_url(catalog_id) if catalog_id else "",
            source_url,
        ]):
            if not browser_url:
                continue
            try:
                snap = client.browser_product_snapshot(browser_url)
            except Exception:
                snap = {}
            if snap:
                browser_snaps.append(snap)
            combined_browser = client.merge_public_snapshots(*browser_snaps) if browser_snaps else {}
            if need_browser_rating:
                browser_rating = client._safe_float(combined_browser.get("rating") or combined_browser.get("rating_average"), 0.0)
                if browser_rating > 0:
                    rating = browser_rating
                    meta["rating_confirmed"] = True
                    meta["rating_source"] = "browser_public_page"
                    need_browser_rating = False
            if need_browser_reviews:
                browser_reviews = client._safe_int(combined_browser.get("reviews_count") or combined_browser.get("review_count"), 0)
                if browser_reviews > 0:
                    reviews = browser_reviews
                    meta["review_count_confirmed"] = True
                    meta["reviews_confirmed"] = True
                    meta["review_count_source"] = "browser_public_page"
                    need_browser_reviews = False
            if not (need_browser_rating or need_browser_reviews or need_browser_sales):
                break
        if browser_snaps:
            public = client.merge_public_snapshots(public, *browser_snaps)

    # Vendas pertencem prioritariamente à oferta real. Catálogo e HTML são
    # apenas fallback e ficam identificados para não misturar escopos.
    sold = 0
    sold_source = ""
    for source_name, source_payload in (
        ("listing", item), ("buy_box", winner), ("public_page", public), ("catalog", catalog)
    ):
        if not isinstance(source_payload, dict):
            continue
        candidate = client._sold_reference(source_payload.get("sold_quantity") or source_payload.get("soldQuantity") or source_payload.get("sold_quantity_range"))
        if candidate > 0:
            sold, sold_source = candidate, source_name
            break
    status = str(merged.get("status") or "").lower()
    available = merged.get("available_quantity")
    if price > 0:
        product.price = price
        meta["price_confirmed"] = True
    if original_price > price > 0:
        product.original_price = original_price
    elif price > 0:
        product.original_price = None
    if rating > 0:
        product.rating = rating
        meta["rating_confirmed"] = True
    if reviews > 0:
        product.review_count = reviews
        meta["review_count_confirmed"] = True
    if sold > 0:
        product.sold_quantity = sold
        meta["sold_quantity_confirmed"] = True
        meta["sold_quantity_source"] = sold_source
        meta["sold_quantity_scope"] = "listing" if sold_source in {"listing", "buy_box"} else sold_source
        if sold_source == "public_page":
            meta["sold_quantity_display"] = str(public.get("sold_quantity_display") or "").strip()
            meta["sold_quantity_is_minimum"] = bool(public.get("sold_quantity_is_minimum"))
    if available is not None or status:
        product.stock_available = not (status in {"inactive", "closed", "paused"} or available == 0)
        meta["stock_confirmed"] = True
    attrs = merged.get("attributes")
    if isinstance(attrs, list) and attrs:
        meta["attributes"] = attrs
    if item_id:
        meta["listing_item_id"] = item_id

    # Link e comissão: usa exclusivamente fontes oficiais/configuradas.
    # A comissão nunca é estimada; só é preenchida quando a integração retorna
    # explicitamente uma porcentagem válida.
    affiliate = resolve_affiliate_link(
        listing_url=str(meta.get("listing_url") or source_url or ""),
        item_id=item_id or "",
        catalog_product_id=catalog_id or "",
        existing_url=str(product.affiliate_url or ""),
        existing_confirmed=bool(meta.get("affiliate_link_confirmed")),
    )
    meta["affiliate_link_checked_at"] = datetime.now(timezone.utc).isoformat()
    if affiliate.confirmed and affiliate.url:
        product.affiliate_url = affiliate.url
        meta["affiliate_link_confirmed"] = True
        meta["affiliate_link_source"] = affiliate.source
        meta["affiliate_link_error"] = ""
        if affiliate.commission_pct > 0:
            product.commission_pct = affiliate.commission_pct
            meta["commission_confirmed"] = True
            meta["commission_source"] = affiliate.source
    elif not meta.get("affiliate_link_confirmed"):
        meta["affiliate_link_error"] = affiliate.error

    meta["last_checked_at"] = datetime.now(timezone.utc).isoformat()

    # Estado de completude usado pelo enriquecimento periódico. A prioridade
    # segue impacto comercial: vendas, comissão, estoque, avaliações, preço
    # anterior e link afiliado. Campos indisponíveis permanecem zerados.
    missing_fields: list[str] = []
    if int(product.sold_quantity or 0) <= 0:
        missing_fields.append("sold_quantity")
    if float(product.commission_pct or 0) <= 0:
        missing_fields.append("commission_pct")
    if not bool(meta.get("stock_confirmed")):
        missing_fields.append("stock_available")
    if float(product.rating or 0) <= 0 or int(product.review_count or 0) <= 0:
        missing_fields.append("reviews")
    if not product.original_price or float(product.original_price or 0) <= float(product.price or 0):
        missing_fields.append("original_price")
    if not bool(meta.get("affiliate_link_confirmed")):
        missing_fields.append("affiliate_link")
    meta["enrichment_missing_fields"] = missing_fields
    meta["enrichment_complete"] = not missing_fields
    meta["enrichment_attempts"] = int(meta.get("enrichment_attempts") or 0) + 1
    meta["enrichment_last_attempt_at"] = meta["last_checked_at"]
    meta["diagnostics"] = {
        "item_id": item_id or "", "item_id_status": meta.get("item_id_status", "not_located"),
        "description_status": meta.get("description_api_status", "unknown"),
        "attributes_count": len(_attributes(meta)), "pictures_count": len(parse_media_urls(product.media_urls)),
        "price_confirmed": bool(meta.get("price_confirmed")), "stock_confirmed": bool(meta.get("stock_confirmed")),
        "reviews_confirmed": bool(meta.get("reviews_confirmed")), "review_count": int(product.review_count or 0),
        "rating": float(product.rating or 0), "sold_quantity": int(product.sold_quantity or 0),
        "sold_quantity_source": str(meta.get("sold_quantity_source") or ""),
        "sold_quantity_confirmed": bool(meta.get("sold_quantity_confirmed")),
        "affiliate_link_confirmed": bool(meta.get("affiliate_link_confirmed")),
        "commission_pct": float(product.commission_pct or 0),
        "commission_confirmed": bool(meta.get("commission_confirmed")),
        "enrichment_missing_fields": list(meta.get("enrichment_missing_fields") or []),
    }
    meta["last_refresh_error"] = "" if description else "A fonte não forneceu a descrição original. O produto fica fora do site até a descrição ser obtida."
    if before["price"] and product.price != before["price"]:
        meta["previous_price"] = before["price"]
        meta["price_changed_at"] = meta["last_checked_at"]
    save_source_metadata(product, meta)
    db.add(ProductObservation(
        product_id=product.id, price=float(product.price or 0), rating=float(product.rating or 0),
        review_count=int(product.review_count or 0), sold_quantity=int(product.sold_quantity or 0),
        stock_available=bool(product.stock_available),
    ))
    db.commit(); db.refresh(product)
    return {
        "product_id": product.id, "item_id": item_id, "pictures": len(pictures),
        "description": bool(description), "price_changed": before["price"] != float(product.price or 0),
        "stock_changed": before["stock_available"] != bool(product.stock_available),
    }


def refresh_all_site_products(db: Session, *, publish: bool = True, trigger: str = "daily_refresh") -> dict[str, Any]:
    products = db.scalars(select(Product).where(Product.status.in_(ACTIVE_PRODUCT_STATUSES))).all()
    results=[]; errors=[]
    for product in products:
        if site_flags(product).get("excluded"):
            continue
        try:
            results.append(refresh_product_from_source(db, product))
        except Exception as exc:
            errors.append({"product_id": product.id, "error": str(exc)[:300]})
            meta=source_metadata(product); meta["last_checked_at"]=datetime.now(timezone.utc).isoformat(); meta["last_refresh_error"]=str(exc)[:500]
            save_source_metadata(product,meta); db.commit()
    publication = publish_catalog(db, trigger=trigger) if publish else None
    return {"checked":len(results)+len(errors),"updated":len(results),"errors":errors,"publication_status":getattr(publication,"status","")}
