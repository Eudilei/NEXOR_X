from __future__ import annotations

import json
from datetime import datetime, timezone
from time import perf_counter

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Product, ProductObservation
from app.models.schemas import ProductCategory, ProductInput
from app.services.scoring import score_product
from app.services.categories import classify_product_category
from app.services.tiktok_shop import TikTokShopCreatorClient, TikTokShopError


def _category(raw: str, title: str = "", description: str = "") -> ProductCategory:
    key = classify_product_category(raw, title, description, fallback="utilidades")
    return ProductCategory(key)


def _status(score: float, media_ready: bool) -> str:
    if score >= 78 and media_ready:
        return "aprovado"
    if score >= 65:
        return "aprovado_comercial"
    return "em_analise"


def _existing(db: Session, external_product_id: str) -> Product | None:
    return db.scalar(
        select(Product).where(
            Product.marketplace == "tiktok_shop",
            Product.external_product_id == external_product_id,
        )
    )


def run_tiktok_discovery(db: Session, *, filters: dict, max_products: int = 25, progress_callback=None) -> dict[str, object]:
    started = perf_counter()
    client = TikTokShopCreatorClient()
    if not client.configured:
        return {
            "status": "configuracao_pendente",
            "message": "Motor TikTok Shop criado, mas aguardando credenciais e escopo oficial do Partner Center.",
            "warnings": [
                "Cadastre TIKTOK_SHOP_APP_KEY, TIKTOK_SHOP_APP_SECRET, TIKTOK_SHOP_ACCESS_TOKEN e TIKTOK_SHOP_CREATOR_SEARCH_PATH no Render."
            ],
            "infos": ["Nenhum produto fictício foi criado enquanto a API oficial não estiver autorizada."],
            "stats": {"source": "tiktok_shop", "saved": 0, "updated": 0, "qualified_products": 0},
        }
    if progress_callback:
        progress_callback(8, "Conectando ao catálogo de afiliados do TikTok Shop")
    try:
        candidates = client.search_open_collaboration_products(
            keyword=str(filters.get("keyword") or ""),
            category_id=str(filters.get("category_id") or ""),
            min_commission_pct=float(filters.get("min_commission_pct") or 0),
            min_monthly_sales=int(filters.get("min_monthly_sales") or 0),
            min_stock=int(filters.get("min_stock") or 0),
            page_size=max_products,
        )
    except TikTokShopError as exc:
        return {
            "status": "api_indisponivel",
            "message": str(exc),
            "warnings": [str(exc)],
            "infos": [],
            "stats": {"source": "tiktok_shop", "saved": 0, "updated": 0, "qualified_products": 0},
        }
    if progress_callback:
        progress_callback(45, f"{len(candidates)} produtos recebidos; calculando potencial")

    ranked = []
    rejected_no_price = 0
    for candidate in candidates:
        if candidate.price <= 0 or not candidate.affiliate_url:
            rejected_no_price += 1
            continue
        input_data = ProductInput(
            title=candidate.title[:180],
            category=_category(candidate.category, candidate.title, str(candidate.metadata.get("description") or "")),
            marketplace="tiktok_shop",
            price=candidate.price,
            original_price=candidate.original_price,
            rating=max(0, min(candidate.rating, 5)),
            review_count=max(candidate.review_count, 0),
            sold_quantity=max(candidate.sold_quantity, 0),
            seller_reputation=80,
            commission_pct=max(0, min(candidate.commission_pct, 100)),
            stock_available=candidate.stock > 0,
            visual_quality=8 if len(candidate.image_urls) >= 3 else 6,
            demonstration_ease=8,
            novelty=7,
            return_risk=4,
            affiliate_url=candidate.affiliate_url,
            media_license="oficial_tiktok_shop" if candidate.image_urls else "origem_nao_confirmada",
        )
        score = score_product(input_data)
        demand_bonus = min(16, candidate.monthly_sold_quantity / 250)
        commission_bonus = min(12, candidate.commission_pct / 2)
        stock_bonus = min(6, candidate.stock / 500)
        final_score = min(100.0, score.total + demand_bonus + commission_bonus + stock_bonus)
        reasons = list(score.reasons)
        reasons.append(f"{candidate.monthly_sold_quantity} vendas informadas nos últimos 30 dias")
        reasons.append(f"Comissão de {candidate.commission_pct:.1f}% no TikTok Shop")
        ranked.append((final_score, candidate, input_data, reasons))
    ranked.sort(key=lambda row: row[0], reverse=True)

    saved = updated = unchanged = 0
    if progress_callback:
        progress_callback(75, "Salvando ranking independente do TikTok Shop")
    for final_score, candidate, input_data, reasons in ranked[:max_products]:
        product = _existing(db, candidate.product_id)
        created = product is None
        if product is None:
            product = Product()
        previous = (product.score or 0, product.price or 0, product.commission_pct or 0, product.monthly_sold_quantity or 0)
        product.title = input_data.title
        product.category = input_data.category.value
        product.marketplace = "tiktok_shop"
        product.external_product_id = candidate.product_id
        product.price = input_data.price
        product.original_price = input_data.original_price
        product.rating = input_data.rating
        product.review_count = input_data.review_count
        product.sold_quantity = input_data.sold_quantity
        product.monthly_sold_quantity = candidate.monthly_sold_quantity
        product.seller_reputation = input_data.seller_reputation
        product.commission_pct = input_data.commission_pct
        product.stock_available = input_data.stock_available
        product.visual_quality = input_data.visual_quality
        product.demonstration_ease = input_data.demonstration_ease
        product.novelty = input_data.novelty
        product.return_risk = input_data.return_risk
        product.affiliate_url = str(input_data.affiliate_url)
        product.media_license = input_data.media_license
        product.media_urls = "\n".join(candidate.image_urls)
        product.original_description = str(candidate.metadata.get("description") or "")
        product.score = final_score
        product.trend_score = min(100, candidate.monthly_sold_quantity / 50)
        product.classification = "Oportunidade TikTok Shop" if final_score >= 78 else "Em análise TikTok Shop"
        product.status = _status(final_score, bool(candidate.image_urls))
        product.score_reasons = "\n".join(reasons)
        product.notes = "Produto de colaboração aberta do TikTok Shop. Link e comissão pertencem exclusivamente ao TikTok Shop."
        product.source_metadata_json = json.dumps(candidate.metadata, ensure_ascii=False, default=str)
        if created:
            db.add(product)
            db.flush()
            saved += 1
        else:
            current = (product.score or 0, product.price or 0, product.commission_pct or 0, product.monthly_sold_quantity or 0)
            if current != previous:
                updated += 1
            else:
                unchanged += 1
        db.add(ProductObservation(
            product_id=product.id,
            price=product.price,
            rating=product.rating,
            review_count=product.review_count,
            sold_quantity=product.sold_quantity,
            stock_available=product.stock_available,
        ))
    db.commit()
    elapsed = round(perf_counter() - started, 1)
    if progress_callback:
        progress_callback(96, "Finalizando resultados do TikTok Shop")
    return {
        "found": len(ranked),
        "saved": saved,
        "updated": updated,
        "status": "concluido",
        "message": f"TikTok Shop: {len(ranked)} oportunidades qualificadas, {saved} novas e {updated} atualizadas.",
        "warnings": [],
        "infos": ["Ranking separado do Mercado Livre; links e métricas não são misturados."],
        "sources": ["tiktok_shop_open_collaboration"],
        "stats": {
            "source": "tiktok_shop",
            "qualified_products": len(ranked),
            "saved": saved,
            "updated": updated,
            "unchanged": unchanged,
            "rejected_no_price": rejected_no_price,
            "elapsed_seconds": elapsed,
        },
        "at": datetime.now(timezone.utc).isoformat(),
    }
