from __future__ import annotations

import logging
import re
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import InstagramCommentEvent, Publication
from app.services.instagram import InstagramError, InstagramService

logger = logging.getLogger(__name__)

BUY_INTENT_PATTERNS = (
    r"\bquero\b", r"\blink\b", r"manda(?:r)?\s+(?:o\s+)?link", r"onde\s+compra",
    r"quero\s+comprar", r"me\s+manda", r"qual\s+(?:o\s+)?valor", r"como\s+comprar",
)


def has_buy_intent(text: str) -> bool:
    normalized = re.sub(r"\s+", " ", str(text or "").casefold()).strip()
    return any(re.search(pattern, normalized, flags=re.I) for pattern in BUY_INTENT_PATTERNS)


def parse_comment_events(payload: dict[str, Any]) -> list[dict[str, str]]:
    """Normaliza eventos de comentários do Instagram.

    A Meta já enviou variações de nomes/campos entre versões do webhook.
    Aceitamos ``comments`` e ``comment`` e extraímos IDs tanto do objeto
    ``media`` quanto dos campos planos, sem registrar o payload integral.
    """
    events: list[dict[str, str]] = []
    for entry in payload.get("entry") or []:
        if not isinstance(entry, dict):
            continue
        for change in entry.get("changes") or []:
            if not isinstance(change, dict):
                continue
            field = str(change.get("field") or "").casefold()
            if field not in {"comments", "comment"}:
                continue
            value = change.get("value") or {}
            if not isinstance(value, dict):
                continue
            sender = value.get("from") or {}
            media = value.get("media") or {}
            sender = sender if isinstance(sender, dict) else {}
            media = media if isinstance(media, dict) else {}
            comment_id = str(value.get("id") or value.get("comment_id") or "").strip()
            media_id = str(media.get("id") or value.get("media_id") or value.get("media") or "").strip()
            text = str(value.get("text") or value.get("message") or "").strip()
            username = str(sender.get("username") or sender.get("id") or value.get("username") or "").strip()
            if comment_id and media_id:
                events.append({"comment_id": comment_id, "media_id": media_id, "text": text, "username": username})
    return events


class InstagramCommentAutomation:
    MAX_ATTEMPTS = 5

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout
        self.instagram = InstagramService(timeout=timeout)

    def private_reply(self, comment_id: str, token: str, message: str) -> None:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.instagram.graph_url}/{comment_id}/private_replies",
                data={"message": message}, headers={"Authorization": f"Bearer {token}"},
            )
        self.instagram._json_or_error(response, "enviar o link por mensagem privada")

    def public_reply(self, comment_id: str, token: str, message: str) -> None:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.instagram.graph_url}/{comment_id}/replies",
                data={"message": message}, headers={"Authorization": f"Bearer {token}"},
            )
        self.instagram._json_or_error(response, "responder publicamente ao comentário")

    def enqueue(self, db: Session, data: dict[str, str]) -> InstagramCommentEvent:
        comment_id = str(data.get("comment_id") or "").strip()
        existing = db.scalar(select(InstagramCommentEvent).where(InstagramCommentEvent.comment_id == comment_id))
        if existing:
            return existing
        event = InstagramCommentEvent(
            comment_id=comment_id, media_id=str(data.get("media_id") or ""),
            username=str(data.get("username") or ""), text=str(data.get("text") or ""),
            intent="compra" if has_buy_intent(str(data.get("text") or "")) else "ignorado",
            status="aguardando", attempts=0,
        )
        db.add(event); db.commit(); db.refresh(event)
        logger.info("Instagram comentário persistido id=%s comment_id=%s intent=%s", event.id, comment_id[:80], event.intent)
        return event

    def process_event(self, db: Session, event_id: int) -> InstagramCommentEvent | None:
        from datetime import datetime, timezone, timedelta
        event = db.get(InstagramCommentEvent, event_id)
        if not event or event.status in {"enviado", "ignorado"}:
            return event
        event.attempts = int(event.attempts or 0) + 1
        event.last_attempt_at = datetime.now(timezone.utc)
        event.status = "processando"
        event.error = ""
        db.commit(); db.refresh(event)
        comment_id, media_id, username, text = event.comment_id, event.media_id, event.username, event.text
        logger.info("Instagram comentário: processando event_id=%s tentativa=%s media_id=%s", event.id, event.attempts, media_id[:80])
        publication = db.scalar(select(Publication).where(
            Publication.provider == "instagram", Publication.remote_id == media_id,
            Publication.status == "publicado",
        ))
        event.publication_id = publication.id if publication else None
        if event.intent != "compra":
            event.status = "ignorado"; db.commit(); return event
        if not publication or not publication.production or not publication.production.script:
            return self._fail_or_retry(db, event, "O Reel não está vinculado a um produto publicado.", retry=False)
        product = publication.production.script.product
        if not str(product.affiliate_url or "").startswith("http"):
            return self._fail_or_retry(db, event, "Link afiliado inválido.", retry=False)
        try:
            connection, token = self.instagram.valid_token(db)
            if username.casefold() == str(connection.account_name or "").casefold():
                event.status = "ignorado"; event.error = "Comentário do próprio perfil."; db.commit(); return event
            tracked_url = f"{settings.public_base_url.rstrip('/')}/go/{publication.id}"
            msg = ("Oi! 😊 Aqui está o achadinho que você pediu:\n\n"
                   f"🔗 {tracked_url}\n\n"
                   "Este é um link de afiliado. Podemos receber comissão sem custo adicional para você.")
            self.private_reply(comment_id, token, msg)
            event.private_reply_sent = True
            try:
                self.public_reply(comment_id, token, "Enviei o link no Direct 😊")
                event.public_reply_sent = True
            except Exception as exc:
                event.error = f"Link enviado no Direct; resposta pública falhou: {exc}"[:2000]
            event.status = "enviado"; event.next_attempt_at = None
            db.commit(); db.refresh(event)
            logger.info("Instagram comentário concluído event_id=%s status=enviado", event.id)
            return event
        except Exception as exc:
            logger.exception("Instagram comentário falhou event_id=%s", event.id)
            return self._fail_or_retry(db, event, str(exc), retry=True)

    def _fail_or_retry(self, db: Session, event: InstagramCommentEvent, error: str, retry: bool) -> InstagramCommentEvent:
        from datetime import datetime, timezone, timedelta
        event.error = str(error)[:2000]
        if retry and int(event.attempts or 0) < self.MAX_ATTEMPTS:
            delay = min(15 * (2 ** max(int(event.attempts or 1) - 1, 0)), 900)
            event.status = "tentar_novamente"
            event.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=delay)
        else:
            event.status = "falhou"
            event.next_attempt_at = None
        db.commit(); db.refresh(event)
        return event

    def process(self, db: Session, data: dict[str, str]) -> InstagramCommentEvent:
        event = self.enqueue(db, data)
        return self.process_event(db, event.id) or event
