# Auditoria v1.0.133

## Roteirista Visual Gratuito
O vídeo 18946 mostrou a mensagem de bloqueio por similaridade após o Gemini Visual ser selecionado. O problema estava na camada posterior à geração: uma resposta válida podia ser descartada por semelhança lexical com roteiros recentes, inclusive do mesmo produto.

Correções:
- roteiros do mesmo produto não participam da memória entre produtos;
- até oito candidatos podem ser comparados e o menos parecido é preservado;
- similaridade passa a ser critério de seleção, não erro fatal;
- apenas duplicação praticamente literal dentro do mesmo lote (>= 0,82) bloqueia a geração.

## Risada
A v1.0.132 pedia ao Gemini para acrescentar uma risada não verbal ao final do gancho. O modelo podia simplesmente ignorar essa instrução.

Correção v1.0.133:
1. gera o gancho;
2. gera um arquivo de áudio separado contendo apenas a performance de risada;
3. gera a continuação sem nova risada;
4. concatena os três trechos.

A performance usa fonemas de riso e instruções genéricas de atuação. Não imita voz, risada, bordão ou maneirismo identificável de pessoa/canal real.

## Verificação local
- `python -m compileall -q app`: aprovado.
- 19 testes focados em Gemini Visual, diversidade, vozes, humor com risada e exclusão de roteiros: aprovados.
- ZIP verificado após empacotamento.
