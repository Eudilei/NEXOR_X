# Auditoria v1.0.151

## Falha confirmada
Uma nova varredura podia reencontrar um produto já concluído e tratá-lo novamente como `pre_selecionado`. Nesse caminho, o código substituía estado/classificação e podia zerar ou sobrescrever campos já preenchidos, como comissão, reputação, qualidade, descrição, mídia e link operacional. Além disso, a localização de um cadastro existente dependia demais do título/link atual e do marcador em notas; após o usuário trocar o link pelo afiliado ou editar o título, havia risco de não reconhecer o mesmo produto.

## Correção
- Cadastros concluídos passam a ser protegidos contra regressão por varredura parcial.
- Compatibilidade retroativa: produtos já existentes com status `pronto_publicacao`, `aprovado_comercial` ou `aprovado` recebem a mesma proteção, mesmo sem uma marca nova no metadata.
- Ao completar um cadastro manualmente, o metadata grava `manual_fields_protected=true` e `manual_completed_at`.
- A varredura continua podendo atualizar métricas comerciais válidas (preço, nota, avaliações e vendas) quando realmente obtidas, mas não pode apagar dados já confirmados nem rebaixar o produto para incompleto.
- Descrição e fotos existentes deixam de ser sobrescritas por uma varredura parcial; apenas lacunas podem ser preenchidas automaticamente.
- A identificação do mesmo produto agora também usa `catalog_product_id` e `item_id` persistidos em `source_metadata_json`, além dos métodos antigos. Isso evita duplicação/perda quando o link virou `meli.la` ou o título foi editado.
- Nenhuma migration destrutiva e nenhum reset de banco foram adicionados.

## Validação
- `python -m compileall -q app`: aprovado.
- 14 testes direcionados de persistência, descoberta, afiliados, enriquecimento e TikTok/renderização: aprovados.
