# Auditoria v1.0.110

Base: v1.0.109, que recupera funcionalmente a v1.0.107.

## Objetivo
Estabilizar a atualização do repositório por upload de um único ZIP, sem Codespaces e sem execução manual de Actions nas versões futuras.

## Proteções
- Gatilho apenas para `agente_ia_achadinhos_v*.zip` na branch `main`.
- Em evento `push`, usa somente ZIP(s) alterados naquele commit.
- Nome e pasta interna do ZIP devem corresponder à versão.
- Sincroniza o checkout com `origin/main` antes da aplicação.
- Valida `requirements.txt`, `render.yaml`, pasta `app`, tela Produtos, tela Descoberta e tela Site Zavomi.
- Confere botão `Excluir todos os produtos` e menu `Site Zavomi` antes e depois da cópia.
- Faz `compileall` antes do commit automático.
- Impede que commits criados pelo próprio GitHub Actions acionem novamente o workflow.
- Remove workflow duplicado antigo.

## Resultado esperado
Ao enviar uma nova versão com nome como `agente_ia_achadinhos_v1_0_111.zip` na raiz do repositório, o GitHub Actions deve processar o ZIP automaticamente e o Render deve iniciar o deploy a partir do commit resultante.
