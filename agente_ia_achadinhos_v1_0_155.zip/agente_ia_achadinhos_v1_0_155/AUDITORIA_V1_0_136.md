# Auditoria v1.0.136

## Alterações
- Prévia de voz reduzida para gancho + amostra curta da narração, evitando sintetizar o roteiro inteiro apenas para escolher uma voz.
- Cache de prévia por hash de texto + perfil + timbre + efeito. Repetir a mesma voz/texto reutiliza o MP3 já gerado.
- 16 novas opções de timbre modificado: 8 masculinas e 8 femininas.
- Efeitos são explicitamente rotulados como FX/modificados; não são apresentados como novos locutores-base.
- Pós-processamento FFmpeg com oito assinaturas acústicas: grave/quente, aveludado, brilhante, rádio, cartoon, escuro, telefone e punch.
- Produção final também aplica o efeito escolhido, mantendo a mesma identidade ouvida na prévia.
- Alterações da v1.0.135 (Gemini Visual resiliente, vozes e risada) foram preservadas.

## Verificações
- Compilação Python de todo app.
- Testes focados de seleção, diversidade e UI.
- Teste real dos 8 filtros de áudio sobre MP3 gerado localmente, todos produziram arquivo válido.
- ZIP final com uma única pasta raiz no padrão exigido pelo workflow.
