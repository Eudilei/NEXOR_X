# Auditoria v1.0.94

## Correção principal
A carga inicial deixou de ser uma rotina invisível. Agora há uma tela persistente em `/catalogo-inicial` com progresso por categoria, total cadastrado, categoria atual, mensagem e erro real.

## Operação
- Botão para iniciar ou continuar a carga.
- Botão para solicitar pausa.
- Estado persistido no banco PostgreSQL.
- Execução idempotente, sem duplicar anúncios existentes.
- Publicação do catálogo no site ao final de cada categoria, sem aguardar os 500 produtos.
- Falhas de busca e de sincronização ficam visíveis no painel.

## Validação
- Compilação de todos os módulos Python concluída.
- Testes de carga inicial e categorias ampliadas aprovados.
