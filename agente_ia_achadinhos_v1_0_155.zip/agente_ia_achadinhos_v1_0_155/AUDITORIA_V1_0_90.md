# Auditoria v1.0.90

- Atualizadas as três assinaturas de propriedade de URL solicitadas pelo TikTok.
- Termos: `/termos/tiktokJQz98WyODAiMd8f8amEcvdcilL5JDScP.txt`.
- Privacidade: `/privacidade/tiktokcW0wljDqyHw9qVE9FP8iLzSmegp0xq8c.txt`.
- Site principal: `/tiktokIpPyrWx7yFvNU8TwOPA48mxqauCSxRZL.txt`.
- Mantido suporte a GET e HEAD, texto puro e cache desativado.
