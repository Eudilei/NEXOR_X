# Auditoria v1.0.81

## Problema confirmado pelo vídeo
O campo Comissão aplicava a máscara durante cada tecla. Em celular, isso reposicionava o cursor, impedia apagar o valor com naturalidade e recriava a formatação durante a edição, igual ao problema corrigido anteriormente em Avaliação.

## Correção
- Campo Comissão inicia vazio no cadastro manual.
- Ao receber foco, seleciona todo o conteúdo.
- Durante a digitação mantém apenas os dígitos crus.
- Formata somente ao perder o foco.
- `12` vira `12,0`; `125` vira `12,5`; vazio permanece vazio.
- Aplicado em Cadastrar e avaliar e Completar dados.
- Corrigida também a regra antiga da tela Completar dados que interpretava `12` como `1,2`.
