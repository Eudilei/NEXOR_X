# Auditoria v1.0.148

## Diagnóstico
A v1.0.147 já continha OAuth, refresh token, creator_info, upload e Direct Post. Portanto a integração não precisava ser refeita do zero.

## Falhas encontradas
1. A tela não exibia as opções de privacidade devolvidas pelo creator_info.
2. A publicação escolhia automaticamente a privacidade em segundo plano, em vez de honrar uma escolha explícita do usuário.
3. Não havia confirmação explícita de envio para cada publicação.
4. As opções de comentário, Dueto e Costura não eram apresentadas ao usuário.
5. O fluxo encerrava em "enviado_ao_tiktok" sem acompanhar o publish_id até o estado final inicial.
6. O nome da conta podia ficar somente como open_id.
7. O OAuth não solicitava video.upload, apesar de esse escopo estar aprovado no app.

## Correções
Implementadas em app/services/tiktok.py, app/main.py e app/templates/social/index.html, com testes em tests/test_v148_tiktok_live_integration.py.

## Validação
- testes TikTok direcionados: 8 aprovados;
- python -m compileall -q app: aprovado;
- suíte completa foi iniciada, mas ultrapassou o limite de execução do ambiente em duas tentativas; não foi usada como evidência de aprovação global.
