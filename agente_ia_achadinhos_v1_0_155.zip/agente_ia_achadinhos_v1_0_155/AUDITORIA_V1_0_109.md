# AUDITORIA v1.0.109 — recuperação e proteção do atualizador ZIP

## Problema encontrado
O workflow anterior escolhia o ZIP pela data de modificação dos arquivos após o checkout (`find ... %T@`). Em um runner do GitHub essas datas não representam com segurança qual ZIP foi enviado no commit. Com vários ZIPs antigos na raiz, uma versão antiga podia ser escolhida e publicada, causando regressão de telas e recursos.

## Correções
- Base restaurada a partir da v1.0.107, que contém as telas e controles esperados.
- O disparo automático aceita somente `agente_ia_achadinhos_v*.zip` na branch `main`.
- Em `push`, o workflow lê os arquivos alterados no commit e escolhe o ZIP daquele envio, não o "mais recente" por timestamp.
- Se mais de um ZIP for enviado no mesmo commit, escolhe a maior versão numérica.
- Valida a pasta interna e o nome da versão.
- Bloqueia a atualização se faltarem `Descoberta`, `Produtos`, `Site Zavomi` ou o botão de exclusão em Produtos.
- Mantém validação de ZIP, `requirements.txt`, `render.yaml`, pasta `app` e compilação Python.
- Remove ZIPs de versão após a atualização para evitar acúmulo e seleção incorreta futura.

## Resultado esperado
Após esta recuperação, nas próximas versões basta enviar um único ZIP `agente_ia_achadinhos_vX_Y_Z.zip` na raiz do repositório. O GitHub Actions deverá processar exatamente esse arquivo e o Render fará o deploy do commit gerado.
