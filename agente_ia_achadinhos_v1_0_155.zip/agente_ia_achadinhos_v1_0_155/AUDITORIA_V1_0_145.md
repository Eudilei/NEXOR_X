# Auditoria v1.0.145

- Base: v1.0.136 original.
- Preservado motor de voz e FX da v136.
- 2 perfis originais de risada continuam pelo método original aprovado.
- 10 novos perfis usam timbres de narração distintos da v136.
- A risada dos novos perfis é gerada separadamente por Puck/Vindemiatrix (motores comprovados na v136) e inserida entre gancho e continuação.
- Risadas recebem FX diferentes sem alterar o timbre principal da narração.
- Perfis com risada não fazem fallback silencioso para Edge.
- Mensagem de erro agora mostra diagnóstico sanitizado para identificar 403/429/modelo/timeout sem expor chave.
