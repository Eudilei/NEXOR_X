# Auditoria v1.0.147

## Objetivo
Encurtar as risadas dos perfis de humor para cerca de 4 segundos sem alterar o motor estável da v1.0.146.

## Causa identificada
A v1.0.146 enviava quatro comandos expressivos consecutivos (`[laughs] [laughs uncontrollably] [gasp] [laughs]`). O Gemini podia interpretar isso como várias fases de gargalhada, prolongando o riso.

## Correção
- Uma única tag `[laughs]` imediatamente após o gancho.
- Direção de duração-alvo entre 3,5 e 4,5 segundos.
- Risada histérica, espontânea, com perda breve de controle e corte abrupto.
- Sem repetição da risada durante a narração.
- Cache da prévia atualizado para v147.

## Limite do teste local
A duração acústica exata depende da resposta real do Gemini no Render. Localmente foram validados fluxo, prompt, cache e testes de regressão; a API real não é chamada sem a chave do ambiente Render.
