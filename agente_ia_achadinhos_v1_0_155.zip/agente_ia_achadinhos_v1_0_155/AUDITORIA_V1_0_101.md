# Auditoria v1.0.101

## Alterações
- Botão **Excluir** em cada card da tela Produtos.
- Botão **Excluir todos os produtos** no topo da tela.
- Confirmação obrigatória antes das exclusões.
- Exclusão em massa remove registros dependentes do catálogo (observações, roteiros, produções, mídias, publicações e cliques relacionados), preservando credenciais OAuth, conexões sociais e configurações do agente.
- Layout adaptado para celular.

## Validação
- Compilação Python concluída sem erros.
- Testes específicos dos controles e rota de exclusão: 2 aprovados.
