# Blueprint MVP Definitivo — Agente IA de Achadinhos

## Missão
Operar uma marca sem rosto que encontra produtos afiliados, gera conteúdo vertical profissional, submete para aprovação pelo celular e publica nos canais autorizados.

## Escopo da primeira versão
- Marketplace: Mercado Livre
- Redes: Instagram e TikTok
- Categorias: casa, cozinha, organização, beleza e cuidados pessoais
- Limite operacional inicial: 30 produtos ativos
- Modo: semiautomático, com aprovação humana antes da publicação

## Fluxo obrigatório
1. Importar ou cadastrar produto.
2. Validar link afiliado, estoque e mídia.
3. Pontuar potencial comercial.
4. Bloquear produto reprovado.
5. Criar três variações de roteiro.
6. Produzir vídeo 9:16 com mídia autorizada.
7. Executar auditoria de conformidade.
8. Exibir no painel para aprovação.
9. Publicar via integração oficial ou exportar pacote pronto.
10. Registrar métricas e resultado.

## Módulos do MVP
- Catálogo de produtos
- Avaliador comercial
- Controle de licença de mídia
- Gerador de roteiros
- Produtor de vídeo
- Auditor de conformidade
- Fila de aprovação
- Publicador por adaptadores
- Métricas básicas
- Logs e alertas

## Regra de mídia
Nenhuma imagem ou vídeo externo pode ser usado automaticamente sem origem e permissão registradas.

Licenças aceitas:
- oficial do marketplace
- fabricante
- autorizado pelo vendedor
- licenciado comercialmente
- produzido pela própria operação

## Autonomia
### Nível 1
Produção automática e aprovação manual.

### Nível 2
Publicação automática apenas para produtos e templates já validados.

### Nível 3
Otimização automática orientada por cliques e vendas reais.

## Critérios mínimos do produto
- estoque disponível
- mídia autorizada
- avaliação preferencial acima de 4,2
- reputação do vendedor preferencial acima de 80/100
- benefício visual claro
- baixo risco de devolução
- link afiliado válido

## Itens fora do MVP
- Amazon
- YouTube Shorts
- múltiplas marcas
- anúncios pagos automáticos
- atendimento completo por mensagens
- publicação totalmente autônoma desde o primeiro dia

## Critério de conclusão
O MVP será considerado operacional quando conseguir processar um produto real do início ao fim: cadastro, aprovação, roteiro, vídeo, revisão, pacote de publicação e registro do resultado.
