## v1.0.152
- Botão Voltar automático onde faltava.
- Telas separadas de produtos completos/incompletos com busca e filtros.
- Sem alteração destrutiva do banco.

## v1.0.151
- Impede que uma nova varredura rebaixe um produto já concluído para `pre_selecionado`.
- Preserva campos manuais, descrição, mídia, afiliado e estado de publicação.
- Reconhece o mesmo produto por IDs persistidos mesmo após troca para link afiliado ou edição de título.
- Mantém atualização segura de métricas comerciais confirmadas.

## v1.0.150
- Renderização em uma única passagem FFmpeg para reduzir o gargalo da montagem.
- Botão para abrir o TikTok ao receber vídeo em revisão/rascunho.
- Mantidos Direct Post, fallback video.upload e integrações existentes.


## v1.0.149
- Remove download duplicado de fotos durante a produção.
- Paraleliza downloads e renderização com limites seguros para Render.
- Preserva código/log_id dos erros TikTok.
- Usa Upload API como fallback quando o Direct Post público é bloqueado por cliente não auditado.
## 1.0.65
- Adicionada verificação do prefixo raiz do TikTok para a Web/Desktop URL.
- Incluído GET/HEAD para o terceiro arquivo de propriedade na raiz do site.

## 1.0.64 - 2026-08-04
- Adicionadas assinaturas independentes do TikTok para os prefixos `/termos/` e `/privacidade/`.
- Adicionados aliases públicos `/termos` e `/privacidade`, preservando as URLs legais anteriores.
- Materialização física simultânea dos dois arquivos `.txt` no Render, com suporte a GET e HEAD.
- Mantida compatibilidade com a configuração legada de assinatura única.
- Incluídos testes de regressão para as duas verificações de URL.

## v1.0.59 — 2026-08-04

- Adiciona página pública de Termos de Serviço para revisão do TikTok.
- Adiciona entrega segura e configurável do arquivo de assinatura de verificação de URL do TikTok.
- Permite trocar nome e conteúdo do arquivo no Render sem novo deploy.
- Atualiza a Política de Privacidade para incluir a integração com TikTok.

# v1.0.43

- Corrige o Roteirista OpenAI para recuperar localmente narrações curtas antes da reprovação.
- Torna obrigatório o cumprimento do estilo pedido: humor, custo-benefício, comparativo e informativo.
- Amplia o humor específico por categoria e reforça ganchos realmente cômicos.
- Adiciona auditoria de aderência ao estilo e testes de regressão.
- Mantém erro técnico nos logs e mensagem simples na interface.

## v1.0.38 — vozes gratuitas com gênero bloqueado

- Seis perfis femininos e seis masculinos.
- Escolha explícita de voz sempre prevalece e não muda de gênero por fallback.
- Perfil inválido é rejeitado antes da fila.

## v1.0.33 — Diretor de vídeo semântico

- CTA visual limitado a no máximo 3 segundos.
- Prova social consolidada em uma única cena.
- Storyboard com distribuição variável de duração.
- Textos duplicados removidos do corpo do vídeo.
- CTA encurtado na renderização, sem “desta publicação”.
- Renderização usa a taxa configurada em VIDEO_FPS.
- Testes de regressão do diretor adicionados.

## v1.0.32
- Revisão gramatical de gênero e concordância antes do TTS.
- Fallback seguro para produtos com gênero desconhecido.
- Imagens oficiais com pessoas continuam permitidas, sem criar endosso profissional não confirmado.
- Remoção de textos genéricos e CTA mais curto.

## v1.0.28

- Medidas visuais preservam todos os números e unidades, inclusive dimensões mistas como 70 cm × 1,40 m.
- Ganchos longos reduzem a fonte automaticamente em vez de perder o final da frase.
- CTA final cita descrição e bio e recebe orçamento de tempo para não ser cortado da narração.
- Sobreposições usam o nome específico do item, como KIT COM 3 TOALHAS.
- Validação bloqueia medidas órfãs ou truncadas antes da montagem.

## v1.0.27
- Corrige a pronúncia de preços em português: R$ 44,00 vira “quarenta e quatro reais” e centavos são falados naturalmente.
- Mantém o valor visual em formato monetário, alterando apenas o texto enviado à voz.
- Adiciona testes para valores inteiros, centavos, singular e milhares.

## v1.0.23

- Fila persistente para Editor Gratuito, OpenAI e HeyGen.
- Geração local removida da requisição do navegador, evitando falhas por concorrência e timeout.
- Posição na fila, cancelamento e atualização automática da página.
- Recuperação automática após reinício do Render.
- Retentativa sem recriar voz ou imagens e falha definitiva somente após três tentativas.
- Renderização acelerada com no máximo sete cenas, preset ultrafast e qualidade vertical 720x1280.
- Bloqueio órfão reduzido para 90 segundos.


## v1.0.19 — voz gratuita obrigatória
- O Editor Zavomi gratuito agora gera narração pt-BR sem créditos HeyGen/OpenAI.
- Escolha entre voz feminina, masculina ou automática.
- Gancho, argumento e CTA são narrados; instruções técnicas continuam removidas.
- A produção falha de forma clara se o serviço gratuito de voz estiver indisponível, em vez de gerar vídeo mudo.
# v1.0.19

- adiciona Editor Zavomi gratuito, sem consumo de créditos de API;
- mantém OpenAI, HeyGen realista, HeyGen animado e upload de MP4;
- permite criar roteiros sem obrigar seleção de avatar quando o motor não é HeyGen;
- separa claramente opções gratuitas e pagas;
- registra o motor escolhido no PostgreSQL;
- permite novas produções depois de falhas, bloqueando apenas tarefas realmente ativas;
- reorganiza a revisão de produção em cartões responsivos.

## v1.0.8
- Correção da biblioteca HeyGen e do layout mobile.

# v1.0.4 — apresentadores, vozes e roteiros variados

- Perfil de apresentador definido antes do roteiro.
- Escolha de gênero, idade aparente, energia, estilo e voz.
- Três variações reais de roteiro e redução de repetição.
- Produção com seis cenas orientadas por apresentador e produto.
- Migração compatível com PostgreSQL existente.
- Botões Voltar mantidos.

# Changelog — v0.8.0

## Correções estruturais
- Cadastro por link com um único script, título HTML válido e campos desconhecidos mantidos em zero.
- Disponibilidade só é aceita quando a fonte a confirma explicitamente; preço isolado não prova estoque.
- Comissão e reputação não são presumidas.
- Pontuação comercial usa sinais objetivos; critérios editoriais manuais têm peso limitado.
- Aprovação comercial e prontidão para publicação são estados distintos.
- Roteiros automáticos só são criados quando a mídia está autorizada.
- Observações históricas de preço, nota, avaliações, vendas, ranking e estoque passam a ser registradas.
- Varredura removida do processo web e transferida para worker persistente com fila no banco.
- Jobs interrompidos voltam para a fila após reinício.
- Blueprint do Render passa a usar PostgreSQL compartilhado entre web e worker.
- Arquivos de cache, bytecode e auditorias obsoletas removidos do pacote.

## 0.8.2
- Trata separadamente entradas PRODUCT e ITEM do ranking oficial.
- Lê ITEM por URL pública canônica, sem usar /items/{id} de terceiros.
- Enriquece PRODUCT pela página do item vencedor quando o item_id estiver disponível.
- Corrige extração brasileira de preço, nota, avaliações e quantidades abreviadas.
- Não presume disponibilidade, estoque, comissão ou reputação.
- Adiciona amostra diagnóstica de produtos rejeitados no painel.

## 1.0.3 — Persistência de dados e mídia
- Produtos, roteiros, aprovações, jobs e produções passam a usar PostgreSQL quando `DATABASE_URL` está configurada.
- O MP4 final é salvo em `media_assets`, não no sistema de arquivos efêmero do serviço.
- O armazenamento local agora é apenas temporário para geração e renderização.

## v1.0.21
- Normalização de abreviações comerciais antes do TTS (`c/3` vira `com 3`).
- Perfis engraçados com ritmo e pausas realmente distintos.
- Modo automático escolhe voz humorística quando o roteiro é de humor.
- Prévia gratuita fala o roteiro real selecionado.
- Editor gratuito usa cenas dinâmicas, textos sincronizados, deduplicação visual, marca Zavomi e CTA final.

## v1.0.27
- Interpretação natural de títulos, sem cortar palavras como Luxo.
- Medidas convertidas apenas quando o X está entre números.
- Roteiros específicos por produto, gramática revisada e humor contextual.
- Textos de tela com produto e medidas reais.

## v1.0.34
- Legendas centrais removidas; gancho e CTA discreto são as únicas sobreposições.
- CTA reduzido para dois segundos e texto simplificado.
- Durações intermediárias variadas deterministicamente.

## v1.0.35
Editor de roteiro antes da aprovação, CTA exclusivo para Instagram/TikTok e auditoria contra frases genéricas sobre fotos e imagens.

## v1.0.37
Gerador Premium universal, direção visual refinada, sem barra de progresso e roteiros de 40 segundos mais específicos.

## v1.0.48 — Instagram OAuth e publicação de Reels
- OAuth oficial com callback `/integracoes/instagram/callback`.
- Permissões mínimas `instagram_business_basic` e `instagram_business_content_publish`.
- Token de longa duração criptografado e renovável.
- Criação de contêiner `REELS`, consulta de processamento e `media_publish`.
- Confirmação manual antes da publicação e proteção contra postagem duplicada.

## v1.0.57 — Motores independentes Mercado Livre + TikTok Shop

- Cria a área de descoberta por fonte: Mercado Livre, TikTok Shop e visão consolidada.
- Mantém links, métricas, IDs e comissões separados por marketplace.
- Adiciona fila de descoberta identificada por fonte e filtros persistentes.
- Implementa cliente oficial configurável para Creator Affiliate API do TikTok Shop.
- Implementa busca por palavra-chave, categoria, comissão mínima, vendas em 30 dias e estoque.
- Adiciona ranking específico do TikTok Shop com peso para comissão, demanda, estoque e qualidade visual.
- Não cria produtos fictícios quando a API oficial ainda não está autorizada.
- Inclui migração automática e compatível com o banco existente.
