# Configuração do motor TikTok Shop

O motor usa a API oficial de afiliados para criadores do TikTok Shop. O aplicativo precisa ser criado/aprovado no TikTok Shop Partner Center e autorizado pelo criador.

Variáveis no Render:

- `TIKTOK_SHOP_APP_KEY`
- `TIKTOK_SHOP_APP_SECRET`
- `TIKTOK_SHOP_ACCESS_TOKEN`
- `TIKTOK_SHOP_CREATOR_SEARCH_PATH` — caminho exato liberado no app aprovado
- `TIKTOK_SHOP_API_BASE_URL` — padrão `https://open-api.tiktokglobalshop.com`
- `TIKTOK_SHOP_REGION` — padrão `BR`

O caminho de busca é configurável porque a versão e o endpoint disponíveis dependem do produto e do escopo aprovados no Partner Center. Sem essas credenciais, o painel informa a pendência e não inventa resultados.
