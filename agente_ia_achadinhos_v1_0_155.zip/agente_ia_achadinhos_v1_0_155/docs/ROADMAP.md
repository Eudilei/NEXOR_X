# Roadmap

## Marco 1 — Fundação (incluído nesta entrega)
- Blueprint MVP
- API inicial
- modelos de produto
- pontuação comercial
- controle de licença
- gerador básico de roteiro
- testes iniciais

## Marco 2 — Estúdio de vídeo
- templates 9:16
- narração
- legendas
- trilha licenciada
- renderização FFmpeg
- capas

## Marco 3 — Painel móvel
- produtos
- roteiros
- vídeos
- aprovação
- agenda
- alertas

## Marco 4 — Integrações
- OAuth Instagram
- TikTok Content Posting API
- Mercado Livre afiliados conforme recursos liberados à conta

## Marco 5 — Métricas e aprendizado
- visualizações
- cliques
- vendas e comissões
- testes de ganchos
- priorização dos vencedores
