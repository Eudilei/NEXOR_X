# Auditoria v1.0.67 — Site Zavomi

## Correções
- Galeria com até 24 fotos HTTPS oficiais por anúncio.
- Descrição pública usa somente a descrição original confirmada; observações internas e IDs técnicos são bloqueados.
- Métricas (nota, avaliações e vendidos) só são publicadas quando marcadas como confirmadas na origem.
- Ordenação: destaque manual, vendidos, nota, avaliações e recência.
- Botões no agente para visualizar, atualizar dados oficiais, destacar, excluir do site e republicar.
- Exclusão remove somente do catálogo público; o produto permanece no banco do agente.
- Página individual do produto com galeria, descrição, características, métricas e data de atualização.
- Título comercial normaliza abreviações como C/ 3 para “com 3”.

## Verificação
- Compilação Python concluída.
- Suíte completa: 258 testes aprovados.
