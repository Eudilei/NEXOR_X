# Auditoria v1.0.66 — Integração Site Zavomi

## Escopo validado
- Nova tela administrativa `Site Zavomi` integrada ao menu e ao painel inicial.
- Botão visível para voltar e botão para abrir `https://www.zavomi.com.br`.
- Geração do catálogo em `data/products.json` no repositório `zavomi-site`.
- Sincronização manual e automática após aprovar, pausar ou reprovar produtos.
- Histórico persistente de sincronizações, quantidade de produtos e commit publicado.
- Bloqueio de produtos sem aprovação, sem estoque, sem foto real ou sem link HTTPS.
- Quantidade vendida somente é exportada quando a origem marca o dado como confirmado.
- Token do GitHub mantido apenas em variável secreta; não é gravado em banco, template ou log.

## Testes
- Suíte completa executada: 255 testes aprovados.
- Sem regressões funcionais detectadas.
- Avisos existentes são de depreciação futura do Pillow/Starlette e não impedem o deploy.

## Configuração necessária no Render
Criar uma variável secreta:

`GITHUB_SITE_TOKEN=<token fino do GitHub>`

O token deve ter acesso somente ao repositório `zavomi-site` e permissão:
- Repository permissions → Contents → Read and write

As demais variáveis já possuem valores padrão compatíveis:
- `GITHUB_SITE_OWNER=Eudilei`
- `GITHUB_SITE_REPO=zavomi-site`
- `GITHUB_SITE_BRANCH=main`
- `GITHUB_SITE_CATALOG_PATH=data/products.json`
- `ZAVOMI_SITE_URL=https://www.zavomi.com.br`
