# Auditoria v1.0.92 — categorias ampliadas e catálogo Zavomi

## Alterações
- Catálogo central com 20 categorias oficiais, nomes padronizados e palavras-chave.
- Classificação automática por título, descrição e categoria da origem.
- Descoberta do Mercado Livre ampliada para novas famílias de produtos.
- TikTok Shop passa a usar o mesmo classificador central.
- Exportação para o site inclui `category_key` estável e nome público padronizado.
- Cadastro manual continua permitindo correção da categoria.

## Compatibilidade
- Categorias anteriores foram preservadas.
- Banco de dados não exige migração: o campo `category` já comporta os novos identificadores.
- Produtos sem evidência suficiente entram em `utilidades`, evitando classificação incorreta como `casa`.
