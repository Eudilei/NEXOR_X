# Auditoria v1.0.107

## Objetivo
Completar, quando publicamente visíveis, avaliação, número de avaliações e referência pública de vendas que permaneciam ausentes após APIs oficiais e HTML estático.

## Implementação
- Camada final `browser_product_snapshot()` com Playwright/Chromium headless.
- Acesso somente a URLs públicas do Mercado Livre; sem autenticação, cookies pessoais ou resolução de CAPTCHA.
- Prioridade mantida: API oficial -> página pública HTTP -> navegador renderizado.
- O navegador é chamado apenas se rating/reviews/vendas ainda estiverem ausentes.
- Consulta primeiro PDP de catálogo e depois oferta individual.
- Cache por URL durante a varredura.
- Orçamento padrão de 10 páginas renderizadas por varredura.
- Timeout padrão de 14 segundos e espera dinâmica curta.
- Serialização das renderizações para evitar múltiplos Chromiums concorrentes no plano gratuito.
- Falhas de browser não interrompem a varredura e são reportadas como aviso.

## Deploy
- `playwright==1.54.0` incluído nas dependências.
- `render.yaml` instala Chromium após as dependências, sem derrubar o deploy caso o navegador não possa ser instalado.

## Validação
- Compilação de `app/services/marketplace.py` concluída.
- Testes específicos do fallback e regressões de importação/enriquecimento: 11 aprovados.
- O parser confirmou nota 4,8, 1.234 avaliações e o texto público `Mais de 5 mil vendidos` como mínimo de 5.000, sem tratá-lo como quantidade exata.
