## v1.0.133

- Corrige as prévias que falhavam quando o Gemini TTS não estava configurado.
- Perfis de voz agora usam Gemini quando disponível e o catálogo Edge pt-BR em tempo de execução quando não há chave.
- A interface informa a voz real utilizada em cada prévia.
- Produção final registra o locutor/timbre realmente usado.

## v1.0.128

### Vozes realmente diferentes

A diversidade vocal usa Gemini TTS com timbres-base distintos. O fallback Edge pt-BR é tratado de forma transparente como apenas duas vozes básicas (Antonio e Francisca); perfis especiais nunca são silenciosamente convertidos para a mesma voz. A prévia informa provedor e timbre utilizado.

## v1.0.120
- Nova categoria Humor Viral realmente engraçada.
- Seleção automática do Narrador Cômico Zavomi para Humor Viral.
- Estruturas cômicas com escalada, personificação, confissão, falso documentário e punchline.

# Agente IA de Achadinhos v1.0.28

7
# Agente IA de Achadinhos — v1.0.13

Painel privado para descobrir e avaliar produtos fáceis de vender nos nichos da Zavomi: casa, cozinha, organização, beleza e cuidados pessoais.

## Critérios comerciais

- origem principal: rankings oficiais de mais vendidos do Mercado Livre;
- nota mínima: 4,0;
- pelo menos 500 avaliações;
- preço real;
- disponibilidade explicitamente confirmada;
- comissão, reputação e vendas nunca são inventadas;
- campos desconhecidos permanecem zerados e identificados para conferência.

## Cadastro por link

Cole um link comum ou de afiliado do Mercado Livre e use **Analisar e preencher**. O sistema importa os dados confirmados, as fotos oficiais e a descrição original quando a API os disponibiliza. Link comum não é convertido automaticamente em link de afiliado.

## Estados

- `aprovado_comercial`: atende aos filtros, mas a mídia ainda não está autorizada;
- `pronto_publicacao`: produto aprovado e mídia autorizada;
- `reprovado`: falhou em preço, disponibilidade, nota, avaliações ou pontuação.

## Produção no Render

A arquitetura possui três recursos declarados em `render.yaml`:

1. serviço web;
2. worker persistente de descoberta;
3. PostgreSQL compartilhado.

O serviço web apenas cria o job. O worker executa a varredura e grava o resultado no PostgreSQL. Isso evita perda da execução por timeout, suspensão ou reinício do processo web.

SQLite é mantido apenas para desenvolvimento local. Não deve ser usado como armazenamento definitivo no Render.

## Execução local

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Em outro terminal:

```bash
python -m app.workers.discovery_worker
```

## Testes

```bash
pytest -q
```


## Compatibilidade Render
A v1.0.12 funciona no serviço web existente e preserva o PostgreSQL já configurado. A fila permanece no banco, mas o próprio processo web inicia o consumidor de jobs; não é necessário criar um Background Worker separado para concluir a varredura.


## Produção e publicação

Após aprovar um roteiro, use **Criar vídeo**. Com `OPENAI_API_KEY`, o sistema gera imagens originais, narração e MP4 vertical. Sem a chave, é possível enviar um MP4 pronto sem simular geração automática. A mídia precisa ser aprovada antes da etapa de publicação.

Instagram e TikTok exigem aplicativos e autorizações oficiais. O painel identifica as credenciais e mantém a publicação bloqueada até a conexão OAuth e a confirmação final do usuário.


## Produção profissional HeyGen
A v1.0.12 usa a biblioteca automática da HeyGen com `HEYGEN_API_KEY`, agrupa os looks por personagem e filtra apresentadores por gênero e idade aparente antes do roteiro. O MP4 concluído é baixado imediatamente para o PostgreSQL, pois URLs externas podem expirar.


## Vídeo focado no produto

Na v1.0.15, o produto ocupa 100% do quadro final. O clipe HeyGen é usado somente como fonte de narração, eliminando cenários incompatíveis e gestos artificiais. Instruções de cena são removidas do texto antes do envio à fala.

## Editor automático de criativos v1.0.16

- produto real ocupa a área útil com fundo desfocado da própria foto;
- fotos repetidas são eliminadas por similaridade visual;
- cada cena recebe movimento suave e texto comercial sincronizado;
- preço, nota, avaliações e vendas só aparecem quando confirmados;
- identidade Zavomi e CTA padronizados;
- HeyGen é usada somente como fonte de voz; cenário e gestos do avatar não entram no vídeo final.

## Motores de produção

- **Editor Zavomi gratuito (recomendado):** monta o vídeo com fotos reais, textos, movimentos e CTA, sem consumir créditos da HeyGen ou da OpenAI. A saída pode ser silenciosa, adequada a publicação com trilha da própria rede social.
- **Editor Zavomi + OpenAI:** usa o mesmo editor e adiciona narração por voz da OpenAI; exige saldo de API.
- **HeyGen:** mantém pessoas realistas e personagens animados; exige créditos da HeyGen.
- **Upload de MP4:** preserva o fluxo para vídeos produzidos externamente.

A escolha do motor fica registrada no roteiro e pode ser alterada na revisão antes da produção.


## Roteirista IA
Na criação do roteiro, escolha entre IA Gratuita e OpenAI. Os dois motores executam análise do produto, estratégia, geração de cinco candidatos, revisão e auditoria. A OpenAI exige `OPENAI_API_KEY`; não existe fallback silencioso quando ela é escolhida.

### Instagram — configuração no Render
Configure as variáveis secretas:

```env
META_APP_ID=<ID do app do Instagram>
META_APP_SECRET=<chave secreta do app do Instagram>
INSTAGRAM_REDIRECT_URI=https://agente-ia-achadinhos.onrender.com/integracoes/instagram/callback
```

Cadastre exatamente a mesma URL em **Meta for Developers → Instagram → Configuração da API com login do Instagram → URI de redirecionamento OAuth válida**. Depois abra **Publicação → Conectar Instagram** no agente.


## Instagram: conversão automática

A v1.0.51 adiciona webhook de comentários e resposta privada oficial. Configure na Meta:

- Callback: `https://SEU-DOMINIO/webhooks/instagram`
- Verify token: o mesmo valor de `INSTAGRAM_WEBHOOK_VERIFY_TOKEN`
- Campo assinado: `comments`
- Reconecte o Instagram para conceder `instagram_business_manage_comments` e `instagram_business_manage_messages`.

Quando alguém comenta **QUERO**, **link**, **manda o link**, **onde compra** ou variações, o agente identifica o Reel, localiza o produto correspondente e envia uma única resposta privada com link rastreável.

Campanhas pagas são opcionais e exigem `META_ADS_ACCESS_TOKEN`, `META_AD_ACCOUNT_ID` e `META_PAGE_ID`. O sistema cria a campanha pausada e aplica `META_ADS_MAX_TOTAL_BRL` como teto.


## Descoberta multiorigem (v1.0.57)

A tela Descoberta possui motores separados para Mercado Livre e TikTok Shop. Consulte `docs/TIKTOK_SHOP_SETUP.md` para conectar a API oficial.


## Verificação das URLs no TikTok for Developers

No Render, configure com os dados do arquivo de assinatura baixado no portal TikTok:

```env
TIKTOK_URL_VERIFICATION_FILENAME=nome-exato-do-arquivo.txt
TIKTOK_URL_VERIFICATION_CONTENT=conteudo-exato-do-arquivo
```

Depois do deploy, confirme que abre publicamente:

```text
https://agente-ia-achadinhos.onrender.com/SEU_ARQUIVO.txt
```

Páginas legais públicas:

- `/termos-de-servico`
- `/politica-de-privacidade`

## v1.0.70 — coleta profissional de anúncios
- preserva link afiliado confirmado e separa o link original usado para coleta;
- resolve e persiste ITEM_ID quando disponível;
- consulta avaliações pelo endpoint dedicado;
- usa descrição original, fallback técnico por atributos oficiais e, somente por último, descrição manual verificada;
- mantém a coleta automática ativa mesmo após descrição manual;
- impede publicação sem descrição e link afiliado confirmados.
