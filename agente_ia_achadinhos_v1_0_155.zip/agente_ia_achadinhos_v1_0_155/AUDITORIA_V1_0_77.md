# Auditoria v1.0.77

## Correções executadas
- O link de afiliado informado é preservado exatamente como recebido e passa a ser o link usado nas publicações.
- O destino resolvido do link curto é separado em `listing_url` e usado apenas para consultar o produto.
- Links `meli.la` agora são resolvidos antes de identificar catálogo ou anúncio.
- A análise tenta catálogo, oferta individual, página pública, avaliações, fotos e descrição.
- Preço anterior passa a ser extraído de `highPrice`, preço original ou preço anterior exibido.
- Campos manuais receberam formatação brasileira para moeda, decimal, percentual e milhares.
- Valores automáticos agora aparecem como `147,81`, `303,86`, `4,9`, `2.560`, `5.000` e `12,0`.
- A gravação preserva metadados separados para link afiliado e link original do anúncio.

## Validação
- Suíte completa aprovada.
- Testes específicos para preço anterior, nota decimal, vendas compactas e máscaras pt-BR.
