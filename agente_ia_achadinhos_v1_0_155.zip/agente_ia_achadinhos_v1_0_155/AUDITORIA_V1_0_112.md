# Auditoria v1.0.112

Versão de validação do fluxo automático por ZIP.

- Base funcional preservada da v1.0.111 / v1.0.107.
- O ZIP não inclui `.github/workflows`, pois workflows do GitHub Actions são preservados e gerenciados separadamente.
- O workflow instalado no repositório deve excluir `.github/workflows/` da sincronização automática.
