# Auditoria v1.0.118

## Objetivo
Eliminar roteiros genéricos usando visão multimodal sobre as fotos reais do produto.

## Implementação
- novo engine `gemini_vision`
- modelo padrão `gemini-2.5-flash`
- até 4 imagens por geração, baixadas diretamente das URLs oficiais já cadastradas
- descrição original e métricas confirmadas entram como contexto factual
- retorno estruturado contém gancho, narração, CTA, insights visuais e plano de cenas
- alegações visuais promocionais não são promovidas a fatos
- falhas/timeout do serviço não corrompem roteiros já existentes

## Configuração
Adicionar `GEMINI_API_KEY` no Render. A chave pode usar o nível gratuito do Google AI Studio, sujeito aos limites vigentes do provedor.

## Compatibilidade
Mantidos IA local e OpenAI como alternativas.
