# Auditoria v1.0.95

## Falha encontrada
A varredura mantinha uma conexão PostgreSQL durante o processamento e abria sessões curtas para atualizar o progresso. Com `pool_size=2`, `max_overflow=0` e `pool_timeout=15`, as tarefas concorrentes esgotavam o pool.

## Correção
- `DB_POOL_SIZE=5`
- `DB_MAX_OVERFLOW=5`
- `DB_POOL_TIMEOUT=60`
- `pool_use_lifo=True`

Os valores podem ser ajustados por variáveis de ambiente sem nova alteração de código.
