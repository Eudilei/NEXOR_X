# Auditoria v1.0.133

## Alterações verificadas
- Rota POST `/scripts/delete-all` protegida por login e CSRF.
- Exclusão em massa remove publicações, mídias, pastas de produção, produções e roteiros.
- Botão “Excluir todos os roteiros” só aparece quando há roteiros e exige confirmação.
- Perfis masculino e feminino de Humor Viral + risada têm `laugh_after_hook=True`.
- Quando Gemini está ativo, o gancho é separado da continuação; a primeira geração recebe direção explícita para uma risada não verbal intensa e crescente no final.
- A continuação é gerada em segundo trecho com instrução explícita para não repetir a risada.
- O efeito permanece original e não pede imitação de pessoa, canal, bordão ou maneirismo real.
