# Meta App Review — Agente IA Zavomi

## URLs
- Política: `/politica-de-privacidade`
- Exclusão: `/exclusao-de-dados`
- Guia interno: `/app-review`
- Webhook: `/webhooks/instagram`

## Permissões
`instagram_business_basic`, `instagram_business_content_publish`, `instagram_business_manage_comments`, `instagram_business_manage_messages`.

## Vídeo de demonstração
Grave a conexão OAuth, publicação de um Reel, comentário QUERO feito por outra conta, evento no painel, Direct recebido e exclusão/desconexão. Não mostre tokens, segredos ou variáveis do Render.

## Segurança
A v1.0.55 valida `X-Hub-Signature-256`, persiste o comentário antes do HTTP 200, usa fila com retentativas e remove tokens dos logs HTTP.
