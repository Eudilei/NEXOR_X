## v1.0.133

- Corrige as prévias que falhavam quando o Gemini TTS não estava configurado.
- Perfis de voz agora usam Gemini quando disponível e o catálogo Edge pt-BR em tempo de execução quando não há chave.
- A interface informa a voz real utilizada em cada prévia.
- Produção final registra o locutor/timbre realmente usado.

## v1.0.128 — auditoria final de vozes e empacotamento limpo

- Remove nomes de pessoas que não correspondiam aos timbres Gemini e exibe o timbre real.
- Preview informa provedor e timbre efetivamente usados, inclusive na tela de produção.
- Gemini TTS tenta o modelo configurado, Gemini 3.1 Flash TTS e 2.5 Flash TTS em fallback controlado.
- Perfis ricos nunca caem silenciosamente para Antonio/Francisca.
- Áudio final é separado por perfil+timbre para impedir reutilização de voz anterior.
- Release não inclui banco local, caches Python ou arquivos RELEASE antigos.

## v1.0.127 — diversidade vocal real e diagnóstico de provedor

- Corrige a causa mostrada no vídeo: todas as prévias estavam em `edge_tts_free`, cujo endpoint pt-BR colapsava para Antonio/Francisca.
- Perfis especiais agora exigem Gemini TTS e usam timbres-base distintos; não existe mais fallback silencioso para a mesma pessoa.
- Edge permanece disponível explicitamente como duas opções básicas.
- A prévia mostra provedor e timbre real usado.
- O painel informa se Gemini TTS está ativo antes do teste.

## v1.0.125 — prévia de voz corrigida
- Prévia usa exatamente a voz escolhida e regenera após edição do roteiro.
- Erros de TTS aparecem na tela em vez de falha genérica.
- Resposta informa perfil e provedor realmente usados.
- Áudio não fica preso em cache antigo.

## v1.0.120
- Nova categoria Humor Viral realmente engraçada.
- Seleção automática do Narrador Cômico Zavomi para Humor Viral.
- Estruturas cômicas com escalada, personificação, confissão, falso documentário e punchline.

## v1.0.119
- Perfis de voz aprimorados e Narrador Cômico Zavomi original.
- Seleção automática de voz por tipo de roteiro.

## v1.0.118

- adiciona Roteirista Visual Gratuito com Gemini 2.5 Flash multimodal
- analisa até 4 fotos reais do anúncio junto com descrição e métricas confirmadas
- gera roteiro específico para o que aparece nas imagens e plano de cenas compatível com a mídia disponível
- mantém auditoria antialucinação, diversidade estrutural, humor dedicado e enquadramento seguro
- IA local continua como fallback e OpenAI permanece opcional

## v1.0.117
- diversidade estrutural obrigatória entre variações
- regeneração automática de roteiros semelhantes
- humor dedicado com seis mecanismos cômicos
- preserva enquadramento integral das imagens 9:16

## v1.0.116
- Roteirista gratuito passa a usar 18 estruturas editoriais e 8 ângulos comerciais, escolhidos por produto e variação.
- Novos arquétipos: anti-hype, cenário real, checklist de compra, objeção/resposta, micro-review e decisão rápida.
- Seleção dos candidatos usa semente estável do produto para evitar o mesmo esqueleto em produtos diferentes.
- OpenAI recebe regra explícita para variar abertura, ordem, ritmo e arquétipo entre os cinco candidatos.
- Ajuste de duração não deixa frases terminarem em preposição ou conjunção.
- Produção vertical deixa de aplicar zoom/crop sobre o quadro final; produto e textos permanecem inteiros.

## v1.0.115
- Mantém o enriquecimento comercial fora do caminho crítico de inicialização.
- Chromium/Playwright fica desativado por padrão no Render; quando habilitado, o executável é validado uma única vez por processo antes de qualquer launch.
- Reduz lotes de enriquecimento e amplia o intervalo para evitar competição com carga inicial e deploy.
- Mantém circuit breaker para endpoints do Mercado Livre bloqueados por PolicyAgent (403).
- Preserva API, HTML público, dados oficiais e links de afiliado como fontes sem inventar métricas.

## v1.0.113

- adiciona enriquecimento comercial periódico para produtos incompletos;
- prioriza quantidade vendida, comissão, estoque, avaliações, preço anterior e link afiliado;
- usa navegador público como último fallback para vendas/avaliações quando habilitado;
- registra fontes, campos ainda ausentes, tentativas e backoff por produto;
- aceita comissão somente quando retornada explicitamente por integração oficial de afiliados;
- mantém dados confirmados e nunca substitui ausência por valores inventados.

## v1.0.111

- Nova versão para validar o disparo automático do workflow por upload de ZIP.
- Mantém a base funcional da v1.0.110.
- Mantém o workflow em `.github/workflows/ATIVAR_ATUALIZACAO_POR_ZIP.yml`.

v1.0.102: corrige token CSRF nos botões de exclusão individual e total de produtos.
## 1.0.99
- Corrige enriquecimento de produtos de catálogo sem Buy Box visível.
- Resolve a oferta real antes de consultar preço, avaliações, estoque, descrição e fotos.
- Atualização manual passa a usar as APIs específicas de preço.

## 1.0.97
- Enriquecimento oficial de preços e ordenação do catálogo.

# v1.0.95

- Corrige falha `QueuePool limit ... connection timed out` durante varreduras.
- Amplia o pool PostgreSQL de forma segura e configurável por ambiente.
- Permite conexões temporárias de overflow para progresso e sincronização.
- Aumenta o tempo de espera do pool para evitar falhas em picos curtos.

# v1.0.94
- Painel persistente da carga inicial em `/catalogo-inicial`.
- Progresso e erros por categoria.
- Botões para iniciar/continuar e pausar.
- Sincronização incremental do site a cada categoria.

## v1.0.68
- Verificação diária de preço, estoque, vendas, avaliações, fotos e descrição.
- Bloqueio de publicação sem descrição original.
- Histórico de observações e detecção de mudança de preço.
- Atualização em lote no painel Site Zavomi.

## v1.0.67
- Vitrine Zavomi profissional com galeria, dados oficiais, ordenação por vendas e gestão completa no agente.

## 1.0.64 - 2026-08-04
- Adicionadas assinaturas independentes do TikTok para os prefixos `/termos/` e `/privacidade/`.
- Adicionados aliases públicos `/termos` e `/privacidade`, preservando as URLs legais anteriores.
- Materialização física simultânea dos dois arquivos `.txt` no Render, com suporte a GET e HEAD.
- Mantida compatibilidade com a configuração legada de assinatura única.
- Incluídos testes de regressão para as duas verificações de URL.

# v1.0.63

- Diagnóstico detalhado das respostas da API Meta/Instagram.
- Exibição de HTTP status, code, error_subcode, type, message e fbtrace_id na tela.
- Log estruturado em JSON para auditoria no Render, sem tokens ou segredos.
- Registro de respostas inválidas e falhas no teste de conexão.
- Testes de regressão para formato detalhado e proteção de credenciais.

# v1.0.62

- Remove as rotas genéricas `/{verification_filename}` que interceptavam Produtos, Roteiros, Produções e Publicação.
- Mantém a verificação do TikTok apenas em prefixos legais específicos.
- Adiciona suporte à verificação em `/politica-de-privacidade/{arquivo.txt}`.
- Adiciona testes de regressão para isolamento das rotas do agente.

# v1.0.61

- Materializa a assinatura de verificação do TikTok como arquivo físico no início do serviço.
- Serve o arquivo físico no prefixo `/termos-de-servico/` e também na raiz por compatibilidade.
- Adiciona suporte explícito a requisições HTTP `HEAD`, usadas por alguns validadores.
- Remove assinaturas antigas ao trocar o arquivo configurado.
- Mantém validação estrita do nome do arquivo e resposta `text/plain` sem cache.

## v1.0.66 — Site Zavomi integrado
- Nova tela `Site Zavomi` com botão visível para voltar, acesso ao domínio e histórico de sincronizações.
- Catálogo público gerado somente com produtos aprovados, em estoque, com foto real e link HTTPS.
- Publicação automática no repositório `zavomi-site` após aprovar, pausar ou reprovar produtos.
- Publicação manual de segurança pelo painel.
- Métricas não comprovadas, como quantidade vendida, não são exportadas ao site.

## v1.0.80
- Corrigida a edição móvel do campo Avaliação: entrada crua durante digitação e máscara apenas ao sair do campo.
- Removido script duplicado na tela Completar dados.

## v1.0.92
- Amplia a busca e o cadastro para 20 categorias oficiais.
- Adiciona classificação automática centralizada e categoria pública padronizada para o site Zavomi.
- Exporta `category_key` para filtragem exata no catálogo.

## v1.0.93
- Carga inicial automática de 25 produtos por categoria (meta total de 500 produtos).
- Descoberta segmentada por categoria e persistência idempotente no banco do agente.
- Retomada automática em deploys seguintes quando alguma categoria não alcançar a meta.
- Publicação do catálogo Zavomi após finalizar a carga.
- Preservação estrita de links afiliados confirmados.

## v1.0.101
- Adiciona exclusão individual de produtos diretamente nos cards.
- Adiciona exclusão total do catálogo com confirmação e limpeza segura de dependências.
\n- v1.0.103: corrige perda de dados na pré-seleção e passa a reutilizar diretamente os dados comerciais de /products/{catalog_product_id}/items, evitando depender de /items/{id} de terceiros.

## v1.0.104
- Evita repetição de endpoints bloqueados por PolicyAgent durante a mesma varredura.
- Adiciona fallback de autenticação para detalhe de produto de catálogo.
- Preserva métricas confirmadas em varreduras parciais.
- Separa corretamente listing_url de affiliate_url na detecção de alterações.
- Preserva licença de mídia oficial do Mercado Livre no fluxo manual.

## v1.0.105
- Reforça a coleta de reviews após resolver o ITEM_ID definitivo.
- Enriquece manualmente métricas públicas sem zerar dados existentes.
- Adiciona fila e importação em lote de links afiliados oficiais.

## v1.0.106
- Combina PDP da oferta e PDP de catálogo para avaliações/opiniões.
- Captura vendas públicas em formato mínimo/faixa sem inventar quantidade exata.
- Reforça atualização manual e preservação de mídia oficial.
## v1.0.107
- Adiciona fallback com navegador Chromium headless para métricas públicas que não chegam pela API/HTML bruto.
- O navegador só roda como último recurso para avaliação, quantidade de avaliações e vendas públicas.
- Não usa login, cookies pessoais, CAPTCHA ou qualquer tentativa de contornar bloqueios.
- Adiciona timeout, orçamento por varredura, cache e serialização para não travar nem sobrecarregar o Render.
- Mantém API oficial e página pública comum como fontes prioritárias.
- Build do Render passa a instalar Chromium de forma tolerante a falhas; se indisponível, o agente continua funcionando sem o fallback.


## v1.0.109
- Recupera a base v1.0.107 e corrige seleção determinística do ZIP no GitHub Actions.
- Adiciona travas anti-regressão para Descoberta, Produtos e Site Zavomi.

## v1.0.110
- Mantém a base funcional recuperada da v1.0.107.
- Instala o workflow definitivo de atualização por ZIP com gatilho automático para novos arquivos `agente_ia_achadinhos_v*.zip` enviados à `main`.
- Seleciona o ZIP do próprio commit de upload, sincroniza com a `main` antes de aplicar e evita `non-fast-forward`.
- Valida estrutura e funções críticas (Descoberta, Produtos, exclusão e Site Zavomi) antes de substituir o projeto.
- Remove o workflow duplicado antigo para impedir execuções concorrentes ou regressões.
