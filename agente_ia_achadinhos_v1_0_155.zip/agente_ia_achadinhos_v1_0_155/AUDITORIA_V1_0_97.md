# Auditoria v1.0.97

- Preço atual consultado prioritariamente em `/items/{id}/sale_price?context=channel_marketplace`.
- Preço regular/anterior salvo apenas quando oficialmente retornado e maior que o atual.
- Fallback em `/items/{id}/prices`.
- Avaliações continuam pelo endpoint `/reviews/item/{id}` com contexto de catálogo.
- Ranking de demanda continua pelo `/highlights`.
- Fontes de cada campo registradas no metadado do produto.
- Ordenação e filtros adicionados à tela Produtos.
- Links de afiliado preservados; links comuns não são marcados como confirmados.
