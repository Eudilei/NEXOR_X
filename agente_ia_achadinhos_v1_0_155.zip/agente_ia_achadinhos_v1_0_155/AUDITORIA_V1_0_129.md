# Auditoria v1.0.129

- Corrigido o caso mostrado no vídeo: perfis especiais não falham mais quando GEMINI_API_KEY não está configurada.
- Com Gemini configurado, mantém timbres Gemini distintos.
- Sem Gemini, cada perfil tenta uma voz pt-BR Edge real diferente, validada em tempo de execução.
- Se a voz preferida não estiver disponível no Edge, o agente escolhe outra voz real do mesmo gênero e informa qual foi usada.
- A prévia e o manifesto da produção agora registram o locutor/timbre realmente utilizado.
- Seleção manual continua sendo respeitada.
