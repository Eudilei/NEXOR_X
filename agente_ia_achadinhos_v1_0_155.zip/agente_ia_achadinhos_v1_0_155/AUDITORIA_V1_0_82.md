# Auditoria v1.0.82

## Falha corrigida
Ao salvar um produto, o redirecionamento abria a tela de detalhes sem enviar `source_meta` ao template. O Jinja2 gerava `UndefinedError: source_meta is undefined`, resultando em Internal Server Error apesar de o produto já ter sido gravado.

## Correções
- A rota `/products/{product_id}` agora carrega `source_metadata(product)` e envia `source_meta` ao template.
- O template possui fallback seguro para `{}` caso outra rota futura deixe de enviar a variável.
- Testes de regressão adicionados.
