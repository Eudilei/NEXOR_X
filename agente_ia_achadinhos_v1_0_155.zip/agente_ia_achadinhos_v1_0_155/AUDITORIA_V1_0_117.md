# Auditoria v1.0.117

- Trava de similaridade entre variações do mesmo lote.
- Regeneração automática quando dois roteiros repetem a mesma espinha narrativa.
- Motor de humor dedicado com seis mecanismos cômicos.
- Humor seco e expectativa x realidade possuem arcos próprios.
- Mantida a correção de enquadramento da v1.0.116.
