# Auditoria v1.0.106

## Correções
- Consulta e combina a página pública da oferta e a PDP de catálogo para aproveitar métricas complementares.
- Avaliação e quantidade de opiniões podem ser recuperadas da PDP de catálogo quando a API de reviews ou a oferta individual não expõem esses dados.
- Reconhece textos públicos de vendas como `Mais de 5 mil vendidos` sem converter a informação em quantidade exata; registra o valor como mínimo público.
- Amplia os padrões de leitura de avaliações/opiniões em HTML e estados JSON.
- O botão de atualização manual usa o mesmo fallback de catálogo.
- Fotos confirmadas do Mercado Livre passam a marcar a mídia como `oficial_marketplace`.
- Mantém separação rígida entre link original e link afiliado. Sem gerador oficial configurado, o link continua pendente e não é inventado.

## Validação
- Compilação completa do pacote `app` sem erros.
- Testes v206 + regressões de enriquecimento, afiliados e preservação de dados: 12 aprovados.
