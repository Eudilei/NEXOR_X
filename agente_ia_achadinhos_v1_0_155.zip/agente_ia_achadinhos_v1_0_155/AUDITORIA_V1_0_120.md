# Auditoria v1.0.120

- Nova categoria **Humor Viral — realmente engraçado**.
- Estrutura dedicada: situação cotidiana, escalada cômica, entrada tardia do produto, punchline e utilidade confirmada.
- Seis mecanismos de abertura variáveis: confissão, falso documentário, personificação, absurdo cotidiano e contraste.
- Não inventa atributos para fazer piada: fatos comerciais continuam restritos ao anúncio.
- `Narrador Cômico Zavomi` passa a ser escolhido automaticamente para Humor Viral quando a voz estiver em Automática.
- Formato automático com instruções de humor também pode selecionar Humor Viral.
