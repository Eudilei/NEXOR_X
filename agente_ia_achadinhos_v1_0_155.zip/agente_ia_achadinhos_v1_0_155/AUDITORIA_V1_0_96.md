# Auditoria v1.0.96

- Progresso da carga inicial recalculado diretamente do PostgreSQL.
- Categorias com 25 ou mais produtos são ignoradas automaticamente.
- Reinício ou repouso do Render não zera os contadores.
- Status `interrupted` identifica execução interrompida por reinício.
- Salvamento após cada tentativa e cada categoria.
- Workflow temporário do GitHub Actions consulta `/health` a cada 10 minutos.
- A carga continua idempotente e não apaga produtos existentes.
