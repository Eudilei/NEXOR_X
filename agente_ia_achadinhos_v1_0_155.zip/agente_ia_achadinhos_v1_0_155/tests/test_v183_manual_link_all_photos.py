from app.services.marketplace import MercadoLivreClient


def test_public_page_extracts_complete_mlstatic_gallery():
    html = r'''
    <script type="application/ld+json">
    {"@type":"Product","name":"Caderneta rosa","image":[
      "https://http2.mlstatic.com/D_NQ_NP_111111-MLB1-F.jpg",
      "https://http2.mlstatic.com/D_NQ_NP_222222-MLB2-F.jpg"
    ],"offers":{"price":"49.90"}}
    </script>
    <script>
      window.__STATE__={"pictures":[
        {"secure_url":"https:\/\/http2.mlstatic.com\/D_NQ_NP_333333-MLB3-F.jpg"},
        {"zoom":"https://http2.mlstatic.com/D_NQ_NP_444444-MLB4-F.jpg"}
      ]};
    </script>
    '''
    data = MercadoLivreClient._public_snapshot_from_html(
        html, "https://www.mercadolivre.com.br/p/MLB123"
    )
    urls = [row["url"] for row in data["pictures"]]
    assert urls == [
        "https://http2.mlstatic.com/D_NQ_NP_111111-MLB1-F.jpg",
        "https://http2.mlstatic.com/D_NQ_NP_222222-MLB2-F.jpg",
        "https://http2.mlstatic.com/D_NQ_NP_333333-MLB3-F.jpg",
        "https://http2.mlstatic.com/D_NQ_NP_444444-MLB4-F.jpg",
    ]


def test_listing_media_merges_public_gallery_when_api_has_only_cover(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "_item_detail_individual", lambda item_id: {
        "id": item_id,
        "pictures": [{"secure_url": "https://http2.mlstatic.com/D_NQ_NP_cover-F.jpg"}],
    })
    monkeypatch.setattr(client, "item_description", lambda item_id: "Descrição completa")
    monkeypatch.setattr(client, "public_product_snapshot", lambda url: {
        "pictures": [
            {"url": "https://http2.mlstatic.com/D_NQ_NP_cover-F.jpg"},
            {"url": "https://http2.mlstatic.com/D_NQ_NP_second-F.jpg"},
            {"url": "https://http2.mlstatic.com/D_NQ_NP_third-F.jpg"},
        ],
        "description": "Descrição completa",
    })

    data = client.listing_media_and_description(
        link="https://produto.mercadolivre.com.br/MLB-1234567890-produto-_JM"
    )

    assert data["pictures"] == [
        "https://http2.mlstatic.com/D_NQ_NP_cover-F.jpg",
        "https://http2.mlstatic.com/D_NQ_NP_second-F.jpg",
        "https://http2.mlstatic.com/D_NQ_NP_third-F.jpg",
    ]
