import json
from unittest.mock import Mock, patch

from app.services.hybrid_video import create_hybrid_direction


def test_fallback_builds_compact_scene_plan(monkeypatch):
    from app.services import hybrid_video
    monkeypatch.setattr(hybrid_video.settings, "gemini_api_key", None)
    result = create_hybrid_direction(
        product_title="Produto", description="Descrição", hook="Gancho", narration="Narração",
        on_screen_text="Linha 1\nLinha 2\nLinha 3\nLinha 4",
        media_urls=[f"https://example.com/{i}.jpg" for i in range(10)], duration_seconds=40,
    )
    assert 4 <= len(result.scene_plan) <= 7
    assert result.scene_plan[0]["objective"] == "gancho"
    assert len(result.on_screen_text.splitlines()) <= 3


def test_hybrid_accepts_semantic_scene_plan(monkeypatch):
    from app.services import hybrid_video
    monkeypatch.setattr(hybrid_video.settings, "gemini_api_key", "test")
    monkeypatch.setattr(
        hybrid_video,
        "_download_image_parts",
        lambda urls: ([{"inline_data": {"mime_type": "image/jpeg", "data": "x"}} for _ in urls], list(range(len(urls)))),
    )
    payload = {
        "image_order": [3, 1, 2, 4],
        "hook": "Novo gancho",
        "narration": "Problema, solução, benefício e prova visual.",
        "on_screen_text": ["GANCHO", "BENEFÍCIO"],
        "scene_plan": [
            {"image_position": 1, "objective": "gancho"},
            {"image_position": 2, "objective": "solução"},
            {"image_position": 3, "objective": "benefício"},
            {"image_position": 4, "objective": "prova visual"},
        ],
    }
    response = Mock()
    response.raise_for_status.return_value = None
    response.json.return_value = {"candidates": [{"content": {"parts": [{"text": json.dumps(payload)}]}}]}
    client = Mock()
    client.__enter__ = Mock(return_value=client)
    client.__exit__ = Mock(return_value=False)
    client.post.return_value = response
    with patch("app.services.hybrid_video.httpx.Client", return_value=client):
        result = create_hybrid_direction(
            product_title="Produto", description="Descrição", hook="Gancho", narration="Narração",
            on_screen_text="Linha", media_urls=[f"https://example.com/{i}.jpg" for i in range(4)], duration_seconds=40,
        )
    assert result.image_order == [2, 0, 1, 3]
    assert [scene["objective"] for scene in result.scene_plan] == ["gancho", "solução", "benefício", "prova visual"]
    assert result.provider.endswith("commercial_storyboard_v3") is False
    assert "director_v2" in result.provider
