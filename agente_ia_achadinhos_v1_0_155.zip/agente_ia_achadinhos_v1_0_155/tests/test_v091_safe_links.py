from app.services.marketplace import MercadoLivreClient


def test_account_verification_redirect_never_replaces_catalog_url():
    requested = "https://www.mercadolivre.com.br/p/MLB71570812"
    redirected = (
        "https://www.mercadolivre.com.br/gz/account-verification?"
        "go=https%3A%2F%2Fwww.mercadolivre.com.br%2Fp%2FMLB71570812"
    )
    assert MercadoLivreClient._safe_product_permalink(requested, redirected) == requested


def test_valid_product_redirect_is_kept():
    requested = "https://www.mercadolivre.com.br/p/MLB71570812"
    final = "https://produto.mercadolivre.com.br/MLB-123456789-_JM"
    assert MercadoLivreClient._safe_product_permalink(requested, final) == final
