from pathlib import Path

from app.services.production import _audit_visual_plan, _scene_durations_for_roles


def test_equivalent_scenes_never_block_production():
    cover = Path("cover.jpg")
    paths = [cover, Path("a.jpg"), Path("b.jpg"), Path("c.jpg"), cover]
    roles = ["produto_completo", "detalhe", "detalhe", "detalhe", "cta"]
    durations = _scene_durations_for_roles(40, roles)
    # A falta de variedade visual deve ser corrigida por movimentos alternados,
    # não convertida em falha de produção.
    _audit_visual_plan(paths, roles, durations, 40)
