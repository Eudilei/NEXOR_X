from app.models.schemas import ProductInput, ProductCategory, ScriptRequest
from app.services.scripts import generate_script, _text_similarity

def product():
    return ProductInput(title='Camera instantanea Fujifilm Instax Mini 12 Verde', category=ProductCategory.ELETRONICOS, marketplace='mercado_livre', price=599.0, rating=4.8, review_count=2300, sold_quantity=10000, affiliate_url='https://example.com/produto')

def test_three_automatic_variations_are_structurally_distinct():
    outs=[generate_script(ScriptRequest(product=product(), format='automatico', variation_index=i, voice_instructions='voz natural')) for i in range(3)]
    for i in range(3):
        for j in range(i+1,3):
            assert _text_similarity(outs[i].hook+' '+outs[i].narration, outs[j].hook+' '+outs[j].narration) < .48

def test_humor_is_not_generic_template():
    outs=[]
    for i, fmt in enumerate(('humor_observacao','humor_seco','expectativa_realidade')):
        out=generate_script(ScriptRequest(product=product(), format=fmt, variation_index=i, voice_instructions='quero uma versao realmente engraçada com humor'))
        text=(out.hook+' '+out.narration).lower(); outs.append(out)
        assert any(x in text for x in ('pose','filme','foto','decoração','vergonha','orçamento','tutorial','devolução dá trabalho','salvação da humanidade'))
    assert max(_text_similarity(outs[i].narration, outs[j].narration) for i in range(3) for j in range(i+1,3)) < .48
