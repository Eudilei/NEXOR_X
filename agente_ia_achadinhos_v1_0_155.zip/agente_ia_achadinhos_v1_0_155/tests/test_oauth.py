from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.database import Base
from app.services.oauth_tokens import MercadoLivreOAuthService, decrypt_value, encrypt_value


def make_db() -> Session:
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    return Session(engine)


def test_token_encryption_roundtrip(monkeypatch):
    monkeypatch.setattr(settings, "session_secret", "segredo-de-teste-muito-forte")
    encrypted = encrypt_value("token-secreto")
    assert encrypted != "token-secreto"
    assert decrypt_value(encrypted) == "token-secreto"


def test_save_and_read_oauth_tokens(monkeypatch):
    monkeypatch.setattr(settings, "session_secret", "segredo-de-teste-muito-forte")
    db = make_db()
    service = MercadoLivreOAuthService()
    service.save_tokens(
        db,
        {
            "access_token": "access-123",
            "refresh_token": "refresh-456",
            "expires_in": 21600,
            "token_type": "Bearer",
            "user_id": 987,
        },
    )
    status = service.connection_status(db)
    assert status["connected"] is True
    assert status["user_id"] == "987"
    assert service.get_valid_access_token(db) == "access-123"


def test_authorization_url_contains_pkce(monkeypatch):
    monkeypatch.setattr(settings, "mercado_livre_client_id", "12345")
    monkeypatch.setattr(settings, "mercado_livre_client_secret", "secret")
    monkeypatch.setattr(settings, "mercado_livre_redirect_uri", "https://example.com/callback")
    url = MercadoLivreOAuthService().authorization_url("state-1", "challenge-1")
    assert "client_id=12345" in url
    assert "state=state-1" in url
    assert "code_challenge=challenge-1" in url
    assert "code_challenge_method=S256" in url
