import json
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import Product
from app.services.autonomous import _save_preselected
from app.services.marketplace import Candidate, MercadoLivreClient


def _candidate(**overrides):
    data = dict(
        external_id="MLB1234567890", title="Produto", category="casa",
        price=0.0, original_price=None, rating=0.0, review_count=0,
        sold_quantity=0, seller_reputation=0.0, stock_available=False,
        listing_url="https://produto.mercadolivre.com.br/MLB-1234567890-_JM",
        thumbnail="", trend_keyword="produto", source="ranking", source_rank=1,
        offer_available=False, catalog_product_id="MLB999", item_id="MLB1234567890",
        description="", picture_urls=(), rating_source="", sold_quantity_source="",
        price_source="", original_price_source="",
    )
    data.update(overrides)
    return Candidate(**data)


def test_product_detail_uses_auto_auth_fallback(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    seen = {}
    def fake_get(path, **kwargs):
        seen.update(kwargs)
        return {"id": "MLB999"}
    monkeypatch.setattr(client, "_get", fake_get)
    assert client.product_detail("MLB999")["id"] == "MLB999"
    assert seen["auth_mode"] == "auto"


def test_policy_family_is_cached_after_first_policy_block():
    client = MercadoLivreClient(access_token="token")
    client._register_policy_block("/items/MLB123/sale_price")
    assert "/items/{id}/sale_price" in client._policy_blocked_families
    assert MercadoLivreClient._endpoint_family("/items/MLB999/sale_price") == "/items/{id}/sale_price"


def test_partial_scan_does_not_erase_confirmed_metrics(monkeypatch):
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        product = Product(
            title="Produto", category="casa", marketplace="mercado_livre",
            price=199.9, original_price=249.9, rating=4.8, review_count=321,
            sold_quantity=900, stock_available=True, affiliate_url="",
            source_metadata_json=json.dumps({"listing_url":"https://produto.mercadolivre.com.br/MLB-1234567890-_JM"})
        )
        db.add(product); db.commit()
        monkeypatch.setattr("app.services.autonomous._automatic_affiliate", lambda *a, **k: type("A", (), {"confirmed": False, "url": "", "source": "", "error": ""})())
        _save_preselected(db, _candidate())
        db.commit(); db.refresh(product)
        assert product.price == 199.9
        assert product.original_price == 249.9
        assert product.rating == 4.8
        assert product.review_count == 321
        assert product.sold_quantity == 900
        assert product.stock_available is True
