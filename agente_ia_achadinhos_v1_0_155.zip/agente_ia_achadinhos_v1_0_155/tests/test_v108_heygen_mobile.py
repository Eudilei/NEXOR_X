from pathlib import Path


def test_heygen_pagination_uses_token():
    text = Path("app/services/heygen.py").read_text()
    assert 'page_params["token"] = next_token' in text
    assert 'page_params["next_token"] = next_token' not in text


def test_script_form_not_outer_grid():
    html = Path("app/templates/scripts/form.html").read_text()
    assert 'class="panel form-panel script-form"' in html
    assert 'class="panel form-grid"' not in html


def test_mobile_css_prevents_overflow():
    css = Path("app/static/app.css").read_text()
    assert 'overflow-x:hidden' in css
    assert '.script-form{display:block' in css
    assert 'max-width:100%' in css


def test_heygen_error_is_friendly():
    from app.services.heygen import friendly_error
    msg = friendly_error(Exception('{"code":"invalid_parameter","param":"next_token"}'))
    assert 'parâmetro' in msg
    assert 'next_token' not in msg
