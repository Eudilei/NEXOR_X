from pathlib import Path

import pytest

from app.models.schemas import ProductInput, ScriptRequest
from app.services import scripts


def _product() -> ProductInput:
    return ProductInput(
        title="Gillette Mach3 Sensitive Carga 8 Unidades com Aloe",
        category="cuidados_pessoais",
        price=89.90,
        rating=4.8,
        review_count=2400,
        sold_quantity=50000,
        affiliate_url="https://example.com/produto",
    )


def test_free_writer_is_default_and_does_not_call_openai(monkeypatch):
    monkeypatch.setattr(scripts, "_openai_writer_pipeline", lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("OpenAI não deveria ser chamada")))
    output = scripts.generate_script(ScriptRequest(product=_product(), writer_engine="free_ai"))
    assert output.hook
    assert "barbear" in output.narration.lower()


def test_openai_writer_uses_selected_pipeline(monkeypatch):
    narration = " ".join([
        "Quem tem pele sensível sabe que uma carga incompatível pode transformar o barbear em desconforto.",
        "Este conjunto reúne oito refis Mach3 Sensitive e o anúncio destaca a presença de aloe.",
        "A análise deve começar pela compatibilidade com o aparelho, pela quantidade de cargas e pela lubrificação.",
        "Esses critérios ajudam a entender se a opção combina com a rotina de reposição e com a frequência de uso.",
        "A nota e o volume de avaliações ajudam a contextualizar a procura, mas não substituem a conferência da oferta.",
        "Antes de decidir, confirme o modelo do aparelho, a quantidade escolhida, o preço atual e as condições de entrega.",
        "Assim, a compra fica baseada no uso real, e não apenas na aparência da embalagem.",
    ])
    def fake_pipeline(request, profile, category_profile, proof):
        return {
            "analysis": {"central_thesis": "compatibilidade e lubrificação decidem a compra"},
            "chosen": {"strategy": "problema_solucao", "spoken_cta": "Confira se esta opção combina com você no link da bio.", "score": 96},
            "hook": "Sua pele irrita depois do barbear? Confira a compatibilidade.",
            "narration": narration,
        }
    monkeypatch.setattr(scripts, "_openai_writer_pipeline", fake_pipeline)
    output = scripts.generate_script(ScriptRequest(product=_product(), writer_engine="openai", creativity_level="criativo"))
    assert "Sua pele irrita" in output.hook
    assert "compatibilidade" in output.narration.lower()
    assert "#roteiroOpenAI" in output.hashtags
    assert any("ROTEIRISTA · OpenAI" in line for line in output.on_screen_text)


def test_openai_choice_does_not_silently_fallback_without_key(monkeypatch):
    monkeypatch.setattr(scripts.settings, "openai_api_key", None)
    profile = scripts._product_profile(_product().title)
    category_profile = scripts._category_script_profile(_product().title, "cuidados_pessoais", profile)
    with pytest.raises(ValueError, match="OPENAI_API_KEY"):
        scripts._openai_writer_pipeline(ScriptRequest(product=_product(), writer_engine="openai"), profile, category_profile, "nota 4,8")


def test_writer_selector_and_creativity_are_visible_in_form():
    html = Path("app/templates/scripts/form.html").read_text(encoding="utf-8")
    assert 'name="writer_engine" value="free_ai"' in html
    assert 'name="writer_engine" value="openai"' in html
    assert 'name="creativity_level"' in html
    assert "A escolha do roteirista é independente da voz" in html


def test_script_model_and_database_persist_writer_choice():
    models = Path("app/db/models.py").read_text(encoding="utf-8")
    main = Path("app/main.py").read_text(encoding="utf-8")
    assert "writer_engine" in models
    assert "creativity_level" in models
    assert '"writer_engine": "VARCHAR(30)' in main
    assert "writer_engine=writer_engine" in main
