from app.models.schemas import ProductCategory
from app.services.categories import CATEGORY_DEFINITIONS, category_label, classify_product_category
from app.services.marketplace import MercadoLivreClient


def test_catalog_has_expanded_categories_in_stable_order():
    keys = [item.key for item in CATEGORY_DEFINITIONS]
    assert len(keys) >= 20
    assert keys[:4] == ["casa", "cozinha", "organizacao", "limpeza"]
    assert "ferramentas" in keys
    assert "pet" in keys
    assert "automotivo" in keys
    assert "informatica" in keys
    assert set(keys) == {item.value for item in ProductCategory}


def test_semantic_category_classification_uses_product_context():
    assert classify_product_category("Parafusadeira elétrica sem fio com maleta") == "ferramentas"
    assert classify_product_category("Comedouro automático para gatos e cachorros") == "pet"
    assert classify_product_category("Capa com suporte para smartphone") == "celulares_acessorios"
    assert classify_product_category("Mini seladora térmica recarregável") == "utilidades"


def test_marketplace_classifier_no_longer_defaults_everything_to_house():
    assert MercadoLivreClient._category_from_text("Teclado e mouse sem fio para notebook") == "informatica"
    assert MercadoLivreClient._category_from_text("Kit jardinagem com tesoura de poda") == "jardim"
    assert MercadoLivreClient._category_from_text("Produto diferente sem pista") == "utilidades"


def test_public_labels_are_standardized():
    assert category_label("cuidados_pessoais") == "Cuidados pessoais"
    assert category_label("escritorio_papelaria") == "Escritório e papelaria"
