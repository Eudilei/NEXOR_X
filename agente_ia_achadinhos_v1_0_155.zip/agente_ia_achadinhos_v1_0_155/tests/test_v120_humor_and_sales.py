from app.services.scripts import _sales_reference, generate_script
from app.services.production import resolve_free_voice_profile
from app.models.schemas import ProductInput, ProductCategory, ScriptRequest


def product(sold=53247):
    return ProductInput(title="Kit com 3 toalhas 70 x 1,40", category=ProductCategory.CASA, price=79.9,
        rating=4.6, review_count=1200, sold_quantity=sold, seller_reputation=90, commission_pct=10,
        stock_available=True, affiliate_url="https://produto.mercadolivre.com.br/MLB-123")


def test_sales_reference_is_rounded_down():
    assert _sales_reference(53247) == "mais de 50 mil vendas"
    assert _sales_reference(8750) == "mais de 8 mil vendas"
    assert _sales_reference(1438) == "mais de 1 mil vendas"
    assert _sales_reference(126900) == "mais de 100 mil vendas"


def test_humor_variations_are_distinct_and_not_exact_sales():
    outputs = [generate_script(ScriptRequest(product=product(), format="humor_observacao", variation_index=i)) for i in range(3)]
    assert len({o.hook for o in outputs}) == 3
    assert len({o.narration for o in outputs}) == 3
    joined = " ".join(o.narration for o in outputs)
    assert "53.247" not in joined and "53247" not in joined
    assert "mais de 50 mil vendas" in joined


def test_free_voice_profiles_offer_distinct_styles():
    funny = resolve_free_voice_profile("feminina_engracada")
    natural = resolve_free_voice_profile("feminina_natural")
    dry = resolve_free_voice_profile("humor_seco")
    assert funny["rate"] != natural["rate"]
    assert funny["pitch"] != natural["pitch"]
    assert dry["voice"] != natural["voice"]
    assert "Humor seco" in dry["label"]
