from pathlib import Path


def test_script_model_has_target_platforms():
    source = Path("app/db/models.py").read_text(encoding="utf-8")
    assert 'target_platforms: Mapped[str]' in source
    assert 'default="all"' in source


def test_script_form_offers_all_social_targets():
    html = Path("app/templates/scripts/form.html").read_text(encoding="utf-8")
    assert 'name="target_platforms"' in html
    for value in ("all", "instagram", "tiktok", "facebook"):
        assert f'value="{value}"' in html


def test_routes_persist_and_validate_target_platforms():
    source = Path("app/main.py").read_text(encoding="utf-8")
    assert 'target_platforms: str = Form("all")' in source
    assert 'target_platforms not in {"all", "instagram", "tiktok", "facebook"}' in source
    assert 'target_platforms=target_platforms' in source
    assert 'script.target_platforms = target_platforms' in source


def test_migration_adds_target_platforms_column():
    source = Path("app/main.py").read_text(encoding="utf-8")
    assert '"target_platforms": "VARCHAR(40) DEFAULT \'all\'"' in source
