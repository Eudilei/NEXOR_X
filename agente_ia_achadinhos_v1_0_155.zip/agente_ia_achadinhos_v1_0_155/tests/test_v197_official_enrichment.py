from app.services.marketplace import MercadoLivreClient


def test_sale_price_api_is_primary(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    calls = []

    def fake_get(path, params=None, **kwargs):
        calls.append((path, params))
        return {"amount": 79.9, "regular_amount": 99.9, "currency_id": "BRL"}

    monkeypatch.setattr(client, "_get", fake_get)
    result = client.item_sale_prices("MLB123")
    assert result["price"] == 79.9
    assert result["original_price"] == 99.9
    assert result["price_source"] == "sale_price_api"
    assert calls[0] == ("/items/MLB123/sale_price", {"context": "channel_marketplace"})


def test_sale_price_does_not_invent_old_price(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "_get", lambda *a, **k: {"amount": 79.9, "regular_amount": 79.9})
    result = client.item_sale_prices("MLB123")
    assert result["price"] == 79.9
    assert result["original_price"] is None
    assert result["original_price_source"] == "unavailable"


def test_review_total_falls_back_to_rating_levels():
    rating, total, levels = MercadoLivreClient.review_metrics({
        "rating_average": 4.8,
        "rating_levels": {"one_star": 1, "two_star": 2, "three_star": 3, "four_star": 4, "five_star": 90},
    })
    assert rating == 4.8
    assert total == 100
    assert levels["five_star"] == 90
