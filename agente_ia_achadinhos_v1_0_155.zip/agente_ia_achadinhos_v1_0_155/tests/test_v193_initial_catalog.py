from app.models.schemas import ProductCategory
from app.core.config import settings


def test_initial_catalog_defaults_cover_500_products():
    assert settings.initial_catalog_products_per_category == 25
    assert len(list(ProductCategory)) == 20
    assert settings.initial_catalog_products_per_category * len(list(ProductCategory)) == 500


def test_initial_catalog_bootstrap_enabled_by_default():
    assert settings.initial_catalog_bootstrap_enabled is True
