from pathlib import Path


def test_refresh_listing_retries_reviews_after_real_item_resolution():
    source = Path('app/main.py').read_text(encoding='utf-8')
    assert 'for item_id in item_ids[:5]' in source
    assert 'client.item_reviews(item_id, catalog_id)' in source
    assert 'review_count_source' in source
    assert 'sold_quantity_type' in source


def test_discovery_retries_reviews_across_catalog_offers():
    source = Path('app/services/marketplace.py').read_text(encoding='utf-8')
    assert 'retry_ids = [resolved_item]' in source
    assert 'reviews_item_id' in source
    assert 'retry_total > total' in source


def test_affiliate_batch_queue_and_import_exist():
    source = Path('app/main.py').read_text(encoding='utf-8')
    template = Path('app/templates/affiliate_links.html').read_text(encoding='utf-8')
    base = Path('app/templates/base.html').read_text(encoding='utf-8')
    assert '@app.get("/affiliate-links"' in source
    assert '@app.post("/affiliate-links/import")' in source
    assert 'manual_official_batch' in source
    assert 'ID do produto | link original' in template
    assert 'href="/affiliate-links"' in base


def test_affiliate_import_never_relabels_original_listing_automatically():
    source = Path('app/main.py').read_text(encoding='utf-8')
    assert 'product.affiliate_url = url' in source
    assert 'affiliate_link_confirmed"] = True' in source
    assert 'listing_url' in source
