from pathlib import Path
from unittest.mock import patch

from app.services.production import FREE_TTS_PROFILES, resolve_free_voice_profile, generate_profile_speech


def test_profiles_use_real_different_gemini_speakers():
    rich = [p for p in FREE_TTS_PROFILES.values() if p.get("provider") in {"gemini", "auto"}]
    gemini = [p["gemini_voice"] for p in rich]
    assert len(gemini) >= 20
    assert len(set(gemini)) == len(gemini)


def test_expressive_profiles_use_different_gemini_voices():
    names = ["narrador_comico_zavomi", "comico_caotico", "review_natural", "narrador_premium", "humor_seco"]
    voices = [resolve_free_voice_profile(n)["gemini_voice"] for n in names]
    assert len(set(voices)) == len(voices)


def test_comic_profiles_include_interpretation_not_only_speed():
    comic = resolve_free_voice_profile("narrador_comico_zavomi")
    chaotic = resolve_free_voice_profile("comico_caotico")
    assert "timing" in comic["style"].lower()
    assert "imite" in comic["style"].lower()
    assert comic["gemini_voice"] != chaotic["gemini_voice"]
    assert comic["gemini_voice"] != chaotic["gemini_voice"]


def test_profile_speech_prefers_gemini_when_key_is_present(tmp_path):
    profile = resolve_free_voice_profile("review_natural")
    target = tmp_path / "voice.mp3"
    fake_settings = type("S", (), {"gemini_api_key": "x"})()
    with patch("app.services.production.settings", fake_settings), patch("app.services.production.generate_gemini_tts") as gemini:
        gemini.return_value = target
        result, provider = generate_profile_speech("teste", target, profile)
    assert result == target
    assert provider == "gemini_tts_distinct"
    gemini.assert_called_once()


def test_ui_exposes_distinct_comic_voice():
    html = Path("app/templates/productions/form.html").read_text(encoding="utf-8")
    assert 'value="comico_caotico"' in html
    assert "Cômico Zavomi" in html
    assert "locutor" in html or "voz" in html
