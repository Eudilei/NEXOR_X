from pathlib import Path


def test_video_renderer_encodes_cards_in_one_pass():
    source = Path('app/services/production.py').read_text(encoding='utf-8')
    block = source[source.index('def compose_product_first_video'):]
    assert 'slides.txt' in block
    assert 'duration {float(scene_duration):.3f}' in block
    assert '"-vf", "fps=15,format=yuv420p"' in block
    assert '_render_motion_segment(ffmpeg' not in block.split('return output', 1)[0]


def test_tiktok_draft_history_has_open_button():
    html = Path('app/templates/social/index.html').read_text(encoding='utf-8')
    assert "publication.status == 'enviado_tiktok_revisao'" in html
    assert 'Abrir TikTok para revisar/publicar' in html
    assert 'Abrir publicação' in html
