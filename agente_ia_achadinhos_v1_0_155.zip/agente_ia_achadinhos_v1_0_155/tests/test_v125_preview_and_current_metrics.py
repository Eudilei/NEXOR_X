from pathlib import Path

from starlette.responses import FileResponse

from app.services.marketplace import MercadoLivreClient
from app.services import production


def test_voice_preview_headers_are_http_safe(tmp_path):
    audio = tmp_path / "preview.mp3"
    audio.write_bytes(b"x" * 2048)
    headers = {
        "X-Zavomi-Voice-Profile": "narrador_viral_br",
        "X-Zavomi-Voice-Provider": "edge_tts_free",
        "Cache-Control": "no-store, max-age=0",
    }
    response = FileResponse(audio, media_type="audio/mpeg", headers=headers)
    # Starlette materializes raw_headers at construction time; non-latin1 emoji
    # here would raise UnicodeEncodeError and reproduce the production failure.
    assert response.headers["x-zavomi-voice-profile"] == "narrador_viral_br"


def test_preview_route_does_not_send_human_label_in_header():
    source = Path("app/main.py").read_text(encoding="utf-8")
    assert '"X-Zavomi-Voice-Profile": str(profile.get("name") or "voice")' in source
    assert '"X-Zavomi-Voice-Profile": str(profile.get("label")' not in source


def test_edge_voice_runtime_falls_back_to_supported_ptbr(monkeypatch):
    class FakeEdge:
        @staticmethod
        async def list_voices():
            return [
                {"Locale": "pt-BR", "ShortName": "pt-BR-AntonioNeural", "Gender": "Male"},
                {"Locale": "pt-BR", "ShortName": "pt-BR-FranciscaNeural", "Gender": "Female"},
            ]

    monkeypatch.setattr(production, "_EDGE_VOICE_CACHE", None)
    monkeypatch.setattr(production, "_EDGE_VOICE_CACHE_AT", 0.0)
    import sys
    monkeypatch.setitem(sys.modules, "edge_tts", FakeEdge)
    assert production._runtime_edge_voice("pt-BR-DonatoNeural", "masculino", "review") == "pt-BR-AntonioNeural"
    monkeypatch.setattr(production, "_EDGE_VOICE_CACHE", None)
    assert production._runtime_edge_voice("pt-BR-YaraNeural", "feminino", "viral") == "pt-BR-FranciscaNeural"


def test_sold_reference_understands_compact_brazilian_counts():
    assert MercadoLivreClient._sold_reference("+250 mil vendidos") == 250000
    assert MercadoLivreClient._sold_reference("mais de 10 mil vendas") == 10000
    assert MercadoLivreClient._sold_reference("1,2 mi vendidos") == 1200000


def test_refresh_code_prioritizes_public_current_price():
    source = Path("app/services/zavomi_site.py").read_text(encoding="utf-8")
    assert 'meta["price_source"] = "public_product_page_current"' in source
    assert 'meta["price_scope"] = "same_public_page"' in source
    # Regression guard: existing non-zero price must be correctable, not frozen.
    main = Path("app/main.py").read_text(encoding="utf-8")
    assert 'abs(float(product.price or 0) - public_price) > 0.009' in main


def test_public_snapshot_reads_current_price_and_250k_sales():
    html = '''
    <html><head>
      <meta property="product:price:amount" content="85.88">
      <meta property="og:title" content="Liquidificador Turbo Power Mondial 550W L-99 FB">
    </head><body>
      <div>4.7</div><span>+250 mil vendidos</span>
      <div class="ui-pdp-price__original-value"><span class="andes-money-amount__fraction">172</span></div>
      <button>Comprar agora</button>
    </body></html>
    '''
    snap = MercadoLivreClient._public_snapshot_from_html(html, "https://www.mercadolivre.com.br/p/MLB15699907")
    assert snap["price"] == 85.88
    assert snap["sold_quantity"] == 250000
    assert snap["sold_quantity_is_minimum"] is True


def test_refresh_keeps_source_page_separate_from_other_offer_snapshots():
    source = Path("app/services/zavomi_site.py").read_text(encoding="utf-8")
    assert "source_public: dict[str, Any] = {}" in source
    assert "display_public = source_public or public" in source
    assert 'display_public.get("price")' in source
