from pathlib import Path

from app.models.schemas import ProductInput, ScriptRequest
from app.services.scripts import generate_script


def _product(title: str, category: str = "casa") -> ProductInput:
    return ProductInput(
        title=title,
        category=category,
        price=129.9,
        rating=4.8,
        review_count=3210,
        sold_quantity=25000,
        affiliate_url="https://example.com/produto",
    )


def test_towel_hook_is_short_concrete_and_does_not_claim_luxury_as_fact():
    output = generate_script(ScriptRequest(
        product=_product("Kit c/3 Toalhas de Banho Grandes de Luxo 70 x 140 cm"),
        variation_index=0,
        duration_seconds=40,
    ))
    joined = f"{output.hook} {output.narration}".lower()
    assert len(output.hook.split()) <= 14
    assert "chamou atenção de muita gente" not in joined
    assert "fama faz sentido" not in joined
    assert "grandes e de luxo" not in joined
    assert "composição" in joined or "gramatura" in joined or "dimens" in joined


def test_all_three_angles_have_unique_short_hooks_and_real_category_thesis():
    product = _product("Gillette Mach3 Sensitive Carga 8 Unidades com Aloe", "cuidados_pessoais")
    outputs = [generate_script(ScriptRequest(product=product, variation_index=i, duration_seconds=40)) for i in range(3)]
    assert len({item.hook for item in outputs}) == 3
    assert all(len(item.hook.split()) <= 14 for item in outputs)
    assert all("barbear" in item.narration.lower() for item in outputs)
    assert all("compatibilidade" in item.narration.lower() or "refis" in item.narration.lower() for item in outputs)


def test_visual_director_preserves_manual_order_and_uses_cover_for_cta():
    code = Path("app/services/production.py").read_text(encoding="utf-8")
    assert "selected_images = images[:12]" in code
    assert "selected_images = selected_images + [product_cover]" in code
    assert "[hook_image] + selected_images + [product_cover]" in code
    assert "_select_diverse_product_images(images, desired_scenes)" not in code


def test_quality_gate_has_no_hundred_point_structure_bonus():
    code = Path("app/services/scripts.py").read_text(encoding="utf-8")
    assert "score += 100" not in code
    assert "O roteiro não atingiu o padrão mínimo de qualidade" in code
