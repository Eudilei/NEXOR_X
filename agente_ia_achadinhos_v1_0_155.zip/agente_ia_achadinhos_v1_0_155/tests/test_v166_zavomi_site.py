import json

from app.db.models import Product
from app.services.zavomi_site import product_payload


def test_only_approved_real_product_enters_site():
    p = Product(
        id=7, title="Organizador real", category="organizacao", price=49.9,
        affiliate_url="https://produto.example/item", media_urls="https://img.example/1.jpg",
        original_description="Descrição real do anúncio", status="pronto_publicacao",
        stock_available=True, marketplace="mercado_livre", source_metadata_json="{}",
    )
    payload = product_payload(p)
    assert payload
    assert payload["id"] == "produto-7"
    assert payload["image_url"].startswith("https://")
    assert "sold_count" not in payload


def test_paused_product_is_removed_from_site_catalog():
    p = Product(
        title="Produto pausado", category="casa", price=10,
        affiliate_url="https://produto.example/item", media_urls="https://img.example/1.jpg",
        status="pausado", stock_available=True,
    )
    assert product_payload(p) is None
