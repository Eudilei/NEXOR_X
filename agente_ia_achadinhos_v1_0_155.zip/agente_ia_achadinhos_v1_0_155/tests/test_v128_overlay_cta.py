from pathlib import Path

from PIL import Image

from app.models.schemas import ProductInput, ScriptRequest
from app.services.production import _commercial_scene_texts, _fit_overlay_text, _render_product_scene
from app.services.scripts import generate_script, product_visual_facts


def _product(title: str = "Kit C/ 3 Toalha De Banho Gigante Luxo 70 X 1,40") -> ProductInput:
    return ProductInput(
        title=title,
        price=44.0,
        rating=4.3,
        review_count=7899,
        sold_quantity=53400,
        affiliate_url="https://example.com/p",
        category="casa",
    )


def test_measurement_overlay_keeps_both_numbers_and_units():
    facts = product_visual_facts(_product().title)
    assert facts["measurement"] == "70 cm × 1,40 m"
    texts = _commercial_scene_texts(
        _product().title, "", "Gancho", "Confira o link na descrição ou na bio desta publicação."
    )
    assert "70 cm × 1,40 m" in texts
    assert not any(text.upper().startswith("CM ×") for text in texts)


def test_product_overlay_names_the_item_not_generic_units():
    texts = _commercial_scene_texts(
        _product().title, "", "Gancho", "Confira o link na descrição ou na bio desta publicação."
    )
    assert "KIT COM 3 TOALHAS" in texts
    assert "KIT COM 3 UNIDADES" not in texts


def test_hook_is_not_truncated_when_rendered(tmp_path: Path):
    source = tmp_path / "source.jpg"
    output = tmp_path / "scene.jpg"
    Image.new("RGB", (800, 800), "navy").save(source)
    hook = "Tem produto que resolve um problema tão específico que parece que ouviu a gente reclamando."
    _render_product_scene(source, output, hook, 0, 5)
    assert output.exists() and output.stat().st_size > 0
    # Verifica diretamente o algoritmo de ajuste: todas as palavras permanecem.
    canvas = Image.new("RGB", (720, 1280), "white")
    from PIL import ImageDraw
    draw = ImageDraw.Draw(canvas)
    _, lines, _ = _fit_overlay_text(draw, hook, max_width=620, max_lines=5, start_size=44, min_size=24)
    assert " ".join(lines) == hook.upper()
    assert len(lines) <= 5


def test_script_reserves_audible_adaptive_cta():
    out = generate_script(ScriptRequest(
        product=_product(), duration_seconds=20, format="humor_observacao",
        voice_instructions="Narrador divertido",
    ))
    assert "QUERO" in out.call_to_action and "Direct" in out.call_to_action
    total_words = len((out.hook + " " + out.narration + " " + out.call_to_action).split())
    assert total_words <= int(20 * 2.65) + 1
    assert "link" not in out.narration.lower()  # CTA aparece uma única vez, no final.
