from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_products_list_has_individual_and_bulk_delete_controls():
    html = (ROOT / "app/templates/products/list.html").read_text(encoding="utf-8")
    assert '/products/delete-all' in html
    assert 'Excluir todos os produtos' in html
    assert '/products/{{ product.id }}/delete' in html
    assert 'Excluir este produto do catálogo?' in html


def test_bulk_delete_route_exists_and_preserves_connections():
    source = (ROOT / "app/main.py").read_text(encoding="utf-8")
    assert '@app.post("/products/delete-all")' in source
    assert 'delete_all_products' in source
    assert 'delete(ProductObservation)' in source
    assert 'delete(Product)' in source
    assert 'delete(OAuthCredential)' not in source
    assert 'delete(SocialConnection)' not in source
