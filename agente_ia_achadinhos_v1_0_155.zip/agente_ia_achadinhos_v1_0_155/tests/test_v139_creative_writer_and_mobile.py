from pathlib import Path
from app.models.schemas import ProductInput, ScriptRequest
from app.services.scripts import generate_script


def product(title='Gillette Mach3 Sensitive Carga 8 Unidades com Aloe'):
    return ProductInput(title=title, category='cuidados_pessoais', price=89.9, rating=4.8,
        review_count=2400, sold_quantity=50000, affiliate_url='https://example.com/p')


def test_creative_variations_change_structure_not_only_product_name():
    outputs=[generate_script(ScriptRequest(product=product(), variation_index=i, duration_seconds=40)) for i in range(3)]
    assert len({o.hook for o in outputs}) == 3
    assert len({o.narration for o in outputs}) == 3
    assert all(len((o.hook+' '+o.narration).split()) >= 70 for o in outputs)
    joined=' '.join(o.narration.lower() for o in outputs)
    assert 'barbear' in joined
    assert 'compatibilidade' in joined or 'refis' in joined


def test_different_products_do_not_receive_same_script_shell():
    razor=generate_script(ScriptRequest(product=product(), variation_index=0))
    pan=generate_script(ScriptRequest(product=product('Panela Antiaderente 24 cm com Tampa'), variation_index=0))
    assert razor.hook != pan.hook
    assert 'barbear' in razor.narration.lower()
    assert 'fogão' in pan.narration.lower() or 'revestimento' in pan.narration.lower()


def test_mobile_engine_layout_keeps_free_button_visible():
    css=Path('app/static/app.css').read_text()
    html=Path('app/templates/productions/form.html').read_text()
    assert 'overflow:visible!important' in css
    assert '.production-engine-grid .engine-card button' in css
    assert 'Gerar com voz gratuita' in html
