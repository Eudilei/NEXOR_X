from app.core.config import settings
from app.models.schemas import ProductInput, ProductCategory, ScriptRequest
from app.services import scripts
from app.services.scripts import generate_script, _style_contract_issues


def towel_product():
    return ProductInput(
        title="Kit C/ 3 Toalha De Banho Gigante Luxo 70 X 1,40 Atacado Sortida Listrados E Estampado",
        category=ProductCategory.CASA,
        price=44.0,
        rating=4.3,
        review_count=7899,
        sold_quantity=53400,
        affiliate_url="https://example.com/p",
    )


def test_all_free_humor_variations_keep_humor_in_hook_and_body():
    outputs = [
        generate_script(ScriptRequest(
            product=towel_product(), format="humor_observacao",
            voice_instructions="humor observacional", variation_index=index,
        ))
        for index in range(3)
    ]
    assert len({item.hook for item in outputs}) == 3
    assert len({item.narration for item in outputs}) == 3
    for item in outputs:
        assert not _style_contract_issues(
            "humor", item.hook, item.narration,
            scripts._category_script_profile(towel_product().title, "casa", scripts._product_profile(towel_product().title)),
        )


def test_openai_editorial_repair_returns_when_api_candidates_are_safe_but_weak(monkeypatch):
    monkeypatch.setattr(settings, "openai_api_key", "test-key")
    response = {
        "analysis": {
            "product": "kit com três toalhas", "category": "enxoval",
            "audience": "quem quer renovar o enxoval", "problem": "toalhas antigas",
            "purchase_criteria": ["medidas", "composição", "gramatura"],
            "confirmed_features": ["três unidades", "70 centímetros por 1 metro e 40 centímetros"],
            "prohibited_claims": ["absorção garantida"],
            "central_thesis": "tamanho e composição importam mais que a estampa",
        },
        "candidates": [
            {"strategy": f"estrategia_{i}", "hook": "Toalha bonita é fácil. Mas ela enxuga?",
             "narration": "Este kit reúne três toalhas e diferentes estampas.",
             "spoken_cta": "Confira o link da bio.", "score": 55, "review": "curto"}
            for i in range(5)
        ],
        "selected_index": 0,
    }
    monkeypatch.setattr(scripts, "_openai_response", lambda payload: response)
    output = generate_script(ScriptRequest(
        product=towel_product(), writer_engine="openai", format="humor_observacao",
        voice_instructions="humor observacional", duration_seconds=40,
    ))
    assert output.hook
    assert len(output.narration.split()) >= 68
    assert "absorção garantida" not in output.narration.lower()
    assert "aposentadoria" in output.narration.lower() or "enxugar" in output.narration.lower()
