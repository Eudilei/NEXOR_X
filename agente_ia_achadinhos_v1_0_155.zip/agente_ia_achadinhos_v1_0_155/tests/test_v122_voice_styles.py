from pathlib import Path

from app.services.production import (
    FREE_TTS_PROFILES,
    choose_free_voice_profile,
    resolve_free_voice_profile,
)


def test_new_voice_styles_exist_and_use_distinct_gemini_voices():
    names = [
        "narrador_viral_br",
        "storyteller_casual",
        "documental_curioso",
        "jovem_social",
        "suspense_revelacao",
        "radio_comercial",
        "feminina_storyteller",
        "feminina_viral",
    ]
    voices = [FREE_TTS_PROFILES[name]["gemini_voice"] for name in names]
    assert len(set(voices)) == len(voices)


def test_viral_voice_is_style_direction_not_only_speed():
    viral = resolve_free_voice_profile("narrador_viral_br")
    text = viral["style"].lower()
    assert "dicção" in text
    assert "micro-pausas" in text
    assert "mudanças" in text
    assert "não imite" in text
    assert viral["gemini_voice"] != resolve_free_voice_profile("narrador_comico_zavomi")["gemini_voice"]


def test_auto_humor_viral_can_rotate_between_compatible_voices():
    from unittest.mock import patch
    fake = type("S", (), {"gemini_api_key": "x"})()
    with patch("app.services.production.settings", fake):
        chosen = {
            choose_free_voice_profile("auto", "masculino", "humor_viral", variation_seed=seed)["name"]
            for seed in range(20)
        }
    assert len(chosen) >= 2
    assert chosen.issubset({"narrador_viral_br", "narrador_comico_zavomi", "comico_caotico"})


def test_auto_female_humor_uses_female_profiles():
    profile = choose_free_voice_profile("auto", "feminino", "humor_viral", variation_seed=4)
    assert profile["gender"] == "feminino"


def test_manual_selection_is_never_overridden_by_script_style():
    profile = choose_free_voice_profile("suspense_revelacao", "masculino", "humor_viral", variation_seed=3)
    assert profile["name"] == "suspense_revelacao"


def test_production_ui_exposes_special_style_group():
    html = Path("app/templates/productions/form.html").read_text(encoding="utf-8")
    assert "Estilos especiais" in html
    assert 'value="narrador_viral_br"' in html
    assert 'value="storyteller_casual"' in html
    assert 'value="suspense_revelacao"' in html
    assert "Automática conforme o estilo do roteiro" in html


def test_create_production_keeps_auto_until_worker():
    main = Path("app/main.py").read_text(encoding="utf-8")
    assert 'free_voice = "auto"' in main
    assert "preserva ``auto`` até o worker" in main
