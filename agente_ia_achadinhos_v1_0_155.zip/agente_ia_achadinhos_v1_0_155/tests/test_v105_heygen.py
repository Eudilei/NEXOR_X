from app.core.config import settings
from app.services import heygen

def test_heygen_config_fields_exist():
    assert hasattr(settings, "heygen_api_key")
    assert hasattr(settings, "heygen_female_avatar_id")
    assert hasattr(settings, "heygen_male_voice_id")

def test_form_exposes_professional_mode():
    text = open("app/templates/productions/form.html", encoding="utf-8").read()
    assert 'value="heygen"' in text
    assert "Gerar com HeyGen" in text

def test_detail_has_refresh():
    text = open("app/templates/productions/detail.html", encoding="utf-8").read()
    assert "/refresh" in text
