from pathlib import Path

from app.services import heygen


def test_form_requires_gender_and_age_before_showing_avatars():
    text = Path("app/templates/scripts/form.html").read_text()
    assert 'id="presenter_gender"' in text
    assert 'id="presenter_age"' in text
    assert 'value="idoso"' in text
    assert "Os avatares só aparecem depois" in text
    assert 'id="avatar-people"' in text
    assert 'id="avatar-looks-panel"' in text
    assert "← Voltar" in text


def test_avatar_groups_looks_and_filters(monkeypatch):
    items = [
        {"id": "ana-kitchen", "group_id": "ana", "name": "Ana Kitchen1 P1 R1", "gender": "female", "age_group": "20-30", "status": "completed", "preview_image_url": "ana1.jpg"},
        {"id": "ana-office", "group_id": "ana", "name": "Ana Office2 P1 R2", "gender": "female", "age_group": "20-30", "status": "completed", "preview_image_url": "ana2.jpg"},
        {"id": "maria-senior", "group_id": "maria", "name": "Maria Senior", "gender": "female", "age_group": "65+", "status": "completed", "preview_image_url": "maria.jpg"},
        {"id": "marco-young", "group_id": "marco", "name": "Marco Young", "gender": "male", "age_group": "20-30", "status": "completed", "preview_image_url": "marco.jpg"},
    ]
    def fake_pages(path, params, *, max_items):
        if path == "/v3/avatars":
            groups = []
            seen = set()
            for item in items:
                gid = item["group_id"]
                if gid not in seen:
                    seen.add(gid)
                    groups.append({"id": gid, "name": item["name"], "gender": item["gender"], "age_group": item.get("age_group"), "status": item.get("status")})
            return groups
        return items
    monkeypatch.setattr(heygen, "_request_pages", fake_pages)
    young_women = heygen.list_avatars(gender="feminino", age="jovem")
    assert len(young_women) == 1
    assert young_women[0]["group_id"] == "ana"
    assert young_women[0]["name"] == "Ana"
    assert len(young_women[0]["looks"]) == 2
    senior_women = heygen.list_avatars(gender="feminino", age="idoso")
    assert [x["group_id"] for x in senior_women] == ["maria"]


def test_unknown_age_is_kept_as_possible_match_without_guessing(monkeypatch):
    def fake_pages(path, params, *, max_items):
        if path == "/v3/avatars":
            return [{"id": "x", "name": "Pessoa X", "gender": "female", "status": "completed"}]
        return [{"id": "look-x", "group_id": "x", "name": "Pessoa X", "gender": "female", "status": "completed"}]
    monkeypatch.setattr(heygen, "_request_pages", fake_pages)
    result = heygen.list_avatars(gender="feminino", age="jovem")
    assert len(result) == 1
    assert result[0]["age"] == "nao_informado"
    all_groups = heygen.list_avatars(gender="feminino")
    assert all_groups[0]["age"] == "nao_informado"
