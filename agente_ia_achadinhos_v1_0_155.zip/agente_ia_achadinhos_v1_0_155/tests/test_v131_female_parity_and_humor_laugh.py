from app.services.production import FREE_TTS_PROFILES, choose_free_voice_profile
from app.services.scripts import FORMATS, _viral_laugh_story


def test_female_catalog_has_broad_style_parity():
    required = {
        'feminina_natural','feminina_encorpada','feminina_profissional','feminina_energetica',
        'feminina_review','feminina_oferta','feminina_comica_zavomi','feminina_comica_caotica',
        'feminina_humor_seco','feminina_documental','feminina_jovem_social','feminina_suspense',
        'feminina_radio_comercial','feminina_storyteller','feminina_viral','feminina_viral_risada',
    }
    assert required.issubset(FREE_TTS_PROFILES)
    assert all(FREE_TTS_PROFILES[k]['gender'] == 'feminino' for k in required)


def test_humor_laugh_auto_voice_respects_gender():
    assert choose_free_voice_profile('auto', 'feminino', 'humor_risada', 1)['gender'] == 'feminino'
    assert choose_free_voice_profile('auto', 'masculino', 'humor_risada', 1)['gender'] == 'masculino'
    assert choose_free_voice_profile('auto', 'feminino', 'humor_risada', 1).get('laugh_after_hook') is True
    assert choose_free_voice_profile('auto', 'masculino', 'humor_risada', 1).get('laugh_after_hook') is True


def test_humor_laugh_is_a_real_script_format():
    assert 'humor_risada' in FORMATS
    profile = {'spoken_name': 'liquidificador'}
    sp = {
        'problem': 'a mistura ficar pela metade',
        'use_cases': ['preparar receitas', 'agilizar a cozinha'],
        'decision': 'potência, capacidade e voltagem',
    }
    hook, body = _viral_laugh_story(profile, sp, 'nota confirmada no anúncio', 2, 'beneficio')
    assert hook and body
    assert 'haha' not in (hook + body).lower()
    assert 'risada' not in (hook + body).lower()
    assert 'liquidificador' in body.lower()
