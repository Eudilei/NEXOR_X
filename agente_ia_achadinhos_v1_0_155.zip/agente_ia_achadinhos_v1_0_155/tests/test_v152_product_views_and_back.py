import json
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import Product
from app.main import _product_registration_complete, _product_registration_missing


def _product(**overrides):
    values = dict(
        title="Produto teste", category="utilidades", marketplace="mercado_livre",
        price=99.9, original_price=None, rating=4.8, review_count=100,
        sold_quantity=500, seller_reputation=5, commission_pct=10,
        stock_available=True, visual_quality=8, demonstration_ease=8,
        novelty=7, return_risk=2, affiliate_url="https://meli.la/teste",
        media_license="oficial_marketplace", original_description="Descrição",
        media_urls="https://img/1.jpg\nhttps://img/2.jpg", notes="", score=80,
        classification="Boa oportunidade", status="pronto_publicacao", score_reasons="ok",
        source_metadata_json=json.dumps({"listing_url":"https://www.mercadolivre.com.br/p/MLB123"}),
    )
    values.update(overrides)
    return Product(**values)


def test_manual_completed_product_is_always_in_complete_view():
    p = _product(status="pre_selecionado", price=0, rating=0,
        source_metadata_json=json.dumps({"manual_fields_protected": True, "manual_completed_at":"2026-08-13T10:00:00Z"}))
    assert _product_registration_complete(p) is True


def test_preselected_missing_product_is_in_incomplete_view_and_explains_missing_fields():
    p = _product(status="pre_selecionado", price=0, rating=0, affiliate_url="",
        source_metadata_json=json.dumps({}))
    assert _product_registration_complete(p) is False
    missing = _product_registration_missing(p)
    assert "preço" in missing
    assert "avaliação" in missing
    assert "link do produto" in missing


def test_product_views_and_global_back_are_present_in_templates():
    list_html = Path("app/templates/products/list.html").read_text()
    base_html = Path("app/templates/base.html").read_text()
    assert "/products/completos" in list_html
    assert "/products/incompletos" in list_html
    assert 'name="q"' in list_html
    assert "global-back-button" in base_html
    assert "document.referrer" in base_html
