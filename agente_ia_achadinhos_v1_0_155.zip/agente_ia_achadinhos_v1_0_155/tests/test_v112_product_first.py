from pathlib import Path

def test_product_columns_and_review_flow():
    models = Path("app/db/models.py").read_text(encoding="utf-8")
    main = Path("app/main.py").read_text(encoding="utf-8")
    form = Path("app/templates/productions/form.html").read_text(encoding="utf-8")
    assert "original_description" in models
    assert "media_urls" in models
    assert "len(product_media) < 2" in main
    assert "Produto em primeiro lugar" in form
    assert "script.heygen_avatar_preview_url" in form

def test_product_first_compositor_exists():
    text = Path("app/services/production.py").read_text(encoding="utf-8")
    assert "def compose_product_first_video" in text
    assert '"-map", "0:v:0"' in text
    assert '"-map", "1:a?"' in text
    assert "overlay=W-w-24:H-h-70" not in text
    assert "Não será criado produto genérico" in text

def test_mobile_avatar_layout_is_stacked():
    css = Path("app/static/app.css").read_text(encoding="utf-8")
    assert "#heygen-library{display:block!important}" in css
    assert "#avatar-looks{display:grid!important" in css
