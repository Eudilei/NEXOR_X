from pathlib import Path


def test_script_buttons_are_state_specific():
    text = Path("app/templates/scripts/detail.html").read_text()
    assert "{% if script.status == 'rascunho' %}" in text
    assert "Roteiro aprovado" in text
    assert "Reabrir para revisão" in text


def test_product_script_generation_requires_media():
    text = Path("app/main.py").read_text()
    assert 'product.status not in {"pronto_publicacao", "conteudo_pronto"} or not media_ready' in text


def test_script_copy_is_category_aware():
    text = Path("app/services/scripts.py").read_text()
    assert '"cuidados_pessoais"' in text
    assert '#cuidadospessoais' in text
    assert 'link da descrição ou da bio' in text
    assert 'link da nossa vitrine' not in text
