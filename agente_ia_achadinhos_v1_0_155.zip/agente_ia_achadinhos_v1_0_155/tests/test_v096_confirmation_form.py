from pathlib import Path

from app.main import integer, number


def test_brazilian_numeric_parsers():
    assert number("R$ 1.234,56") == 1234.56
    assert number("19,92") == 19.92
    assert number("22%") == 22.0
    assert integer("20.000") == 20000
    assert integer("1 234") == 1234


def test_completion_route_imports_observation_model():
    source = Path("app/main.py").read_text()
    assert "from app.db.models import DiscoveryJob, Product, ProductObservation, Script" in source
    assert "db.add(ProductObservation(" in source


def test_confirmation_form_has_native_mobile_masks():
    template = Path("app/templates/products/complete.html").read_text()
    for name in ("price", "original_price", "rating", "review_count", "sold_quantity", "commission_pct"):
        assert f'id="{name}"' in template
    assert 'data-mask="currency"' in template
    assert 'data-mask="integer"' in template
    assert 'data-mask="rating"' in template
    assert 'data-mask="percent"' in template
