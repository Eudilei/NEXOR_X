from types import SimpleNamespace
from app.services.discovery.ranking import quality_level
from app.services.discovery.models import EnrichmentReport


def test_quality_levels_require_essentials_and_affiliate_for_a():
    assert quality_level(price=99, stock=True, pictures=True, description=True, rating=4.8, reviews=1200, affiliate_confirmed=True) == "A"
    assert quality_level(price=99, stock=True, pictures=True, description=True, rating=0, reviews=0, affiliate_confirmed=False) == "B"
    assert quality_level(price=99, stock=False, pictures=False, description=False, rating=0, reviews=0, affiliate_confirmed=False) == "C"
    assert quality_level(price=0, stock=False, pictures=False, description=False, rating=0, reviews=0, affiliate_confirmed=False) == "D"


def test_enrichment_report_keeps_source_and_confidence():
    report = EnrichmentReport()
    report.put("rating", 4.9, "reviews_api", "confirmed")
    meta = report.metadata()
    assert meta["rating"]["source"] == "reviews_api"
    assert meta["rating"]["confidence"] == "confirmed"
    assert meta["rating"]["checked_at"]
