from pathlib import Path
from unittest.mock import Mock

from app.services import production


def test_laugh_preview_uses_single_gemini_call(monkeypatch, tmp_path):
    calls=[]
    def fake(text, output, voice, style_prompt=""):
        calls.append((text, voice, style_prompt))
        output.write_bytes(b"x"*2048)
        return output
    monkeypatch.setattr(production, "generate_gemini_tts", fake)
    profile=dict(production.FREE_TTS_PROFILES["risada_m_fenrir"])
    out=tmp_path/"a.mp3"
    production._generate_gemini_laugh_after_hook("Gancho forte! Depois continua.", out, profile)
    assert len(calls)==1
    text, voice, style = calls[0]
    assert voice=="Fenrir"
    assert text.index("Gancho forte!") < text.index("[laughs]") < text.index("Depois continua.")
    assert "RISADA HUMANA" in style


def test_retry_after_is_bounded():
    response=Mock()
    response.headers={"retry-after":"99"}
    assert production._gemini_retry_after_seconds(response, 1)==12.0
    response.headers={"retry-after":"3"}
    assert production._gemini_retry_after_seconds(response, 1)==3.0


def test_v146_has_cooldown_and_last_good_model():
    source=Path(production.__file__).read_text()
    assert "_GEMINI_TTS_MODEL_COOLDOWN_UNTIL" in source
    assert "_GEMINI_TTS_LAST_GOOD_MODEL" in source
    assert "response.status_code == 429" in source
    assert "gemini-2.5-flash-preview-tts" in source


def test_429_falls_through_to_second_model(monkeypatch, tmp_path):
    import base64
    calls=[]
    class Resp:
        def __init__(self,status,data=None):
            self.status_code=status; self._data=data; self.headers={}; self.text='rate'
        def json(self):
            return self._data if self._data is not None else {"error":{"code":429}}
        def raise_for_status(self):
            if self.status_code >= 400:
                request=__import__('httpx').Request('POST','https://example.test')
                response=__import__('httpx').Response(self.status_code, request=request)
                raise __import__('httpx').HTTPStatusError('err', request=request, response=response)
    class Client:
        def __init__(self,*a,**k): pass
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def post(self,url,**kwargs):
            calls.append(url)
            if len(calls)==1:
                return Resp(429)
            pcm=b'\0\0'*2000
            return Resp(200,{"candidates":[{"content":{"parts":[{"inlineData":{"data":base64.b64encode(pcm).decode()}}]}}]})
    class Proc:
        returncode=0; stderr=b''
    def fake_run(cmd, input=None, stdout=None, stderr=None, timeout=None, **kwargs):
        Path(cmd[-1]).write_bytes(b'ID3'+b'x'*3000)
        return Proc()
    monkeypatch.setattr(production.httpx,'Client',Client)
    monkeypatch.setattr(production.subprocess,'run',fake_run)
    monkeypatch.setattr(production.settings,'gemini_api_key','fake')
    monkeypatch.setattr(production.settings,'gemini_tts_model','gemini-3.1-flash-tts-preview')
    production._GEMINI_TTS_MODEL_COOLDOWN_UNTIL.clear()
    production._GEMINI_TTS_LAST_GOOD_MODEL=None
    out=tmp_path/'ok.mp3'
    production.generate_gemini_tts('Teste',out,'Puck','Natural')
    assert out.exists()
    assert len(calls)==2
    assert 'gemini-3.1-flash-tts-preview' in calls[0]
    assert 'gemini-2.5-flash-preview-tts' in calls[1]
