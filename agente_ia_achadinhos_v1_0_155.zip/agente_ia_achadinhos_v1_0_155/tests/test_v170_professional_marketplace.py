from types import SimpleNamespace
from app.services.zavomi_site import resolve_public_description, _affiliate_link_confirmed

def test_technical_description_fallback():
    product=SimpleNamespace(title="Kit C/ 3 Toalhas", original_description="")
    text, source=resolve_public_description(product,{"attributes":[{"name":"Material","value_name":"Algodão"}]})
    assert "Algodão" in text
    assert source == "technical_from_attributes"

def test_confirmed_affiliate_is_preserved_by_flag():
    product=SimpleNamespace(affiliate_url="https://www.mercadolivre.com/sec/abc")
    assert _affiliate_link_confirmed(product,{"affiliate_link_confirmed":True})
