from pathlib import Path


def test_form_uses_review_count_contract():
    text = Path("app/templates/products/form.html").read_text()
    assert 'id="review_count"' in text
    assert 'reviews_count' not in text


def test_discovery_separates_preselected_and_qualified():
    text = Path("app/templates/discovery.html").read_text()
    assert "preselected_count" in text
    assert "preselected_products" in text
    assert "Amostra diagnóstica dos rejeitados" not in text


def test_package_ignores_local_database():
    ignore = Path(".gitignore").read_text()
    assert "*.db" in ignore
