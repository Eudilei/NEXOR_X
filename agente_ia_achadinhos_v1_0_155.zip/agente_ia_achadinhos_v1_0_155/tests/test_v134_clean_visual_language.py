from app.services.production import _cta_text, _scene_durations


def test_cta_is_minimal_destination_only():
    assert _cta_text("Confira os detalhes no link da descrição ou da bio desta publicação.") == "Link na bio"
    assert _cta_text("Acesse o link da bio") == "Link na bio"


def test_cta_uses_only_two_seconds_in_thirty_second_video():
    durations = _scene_durations(30, 9)
    assert abs(sum(durations) - 30) < 0.01
    assert durations[-1] <= 2.0
    assert len(set(durations[:-1])) > 1


def test_product_video_has_only_hook_and_cta_overlays():
    source = open("app/services/production.py", encoding="utf-8").read()
    assert 'scene_texts = [re.sub' in source
    assert 'scene_texts.extend([""] * max(0, body_slots - 1))' in source
    assert 'elif headline and scene_index == total_scenes - 1' in source
