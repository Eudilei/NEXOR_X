from pathlib import Path
from PIL import Image

from app.services.production import (
    _commercial_scene_texts,
    _deduplicate_product_images,
    _render_product_scene,
)


def test_scene_texts_use_confirmed_product_data():
    texts = _commercial_scene_texts(
        "Kit C/ 3 Toalha 70 X 1,40", "Maciez\nCores sortidas", "Gancho", "Link na descrição",
        price=99.9, rating=4.4, review_count=231, sold_quantity=0,
    )
    joined = " | ".join(texts)
    assert "KIT COM 3 TOALHAS" in joined
    assert "70 cm × 1,40 m" in joined
    assert "NOTA 4,4 · 231 AVALIAÇÕES" in joined
    assert "VENDIDOS" not in joined


def test_visual_duplicate_images_are_removed(tmp_path: Path):
    first = tmp_path / "a.jpg"
    second = tmp_path / "b.jpg"
    third = tmp_path / "c.jpg"
    Image.new("RGB", (200, 200), "white").save(first)
    Image.new("RGB", (200, 200), "white").save(second)
    image = Image.new("RGB", (200, 200), "black")
    for x in range(100, 200):
        for y in range(200):
            image.putpixel((x, y), (255, 255, 255))
    image.save(third)
    assert len(_deduplicate_product_images([first, second, third])) == 2


def test_scene_card_fills_vertical_canvas(tmp_path: Path):
    source = tmp_path / "source.jpg"
    output = tmp_path / "scene.jpg"
    Image.new("RGB", (1000, 500), "orange").save(source)
    _render_product_scene(source, output, "Kit com 3 unidades", 0, 6)
    with Image.open(output) as result:
        assert result.size == (720, 1280)
