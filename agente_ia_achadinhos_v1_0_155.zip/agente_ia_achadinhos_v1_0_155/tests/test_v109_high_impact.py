from pathlib import Path
from app.models.schemas import ProductInput, ProductCategory, ScriptRequest
from app.services.scripts import generate_script


def product():
    return ProductInput(
        title="Organizador Multiuso Premium",
        category=ProductCategory.ORGANIZACAO,
        price=89.90,
        rating=4.8,
        review_count=1200,
        sold_quantity=15000,
        affiliate_url="https://mercadolivre.com.br/afiliado/produto123",
    )


def test_caption_contains_direct_affiliate_link_and_disclosure():
    out = generate_script(ScriptRequest(product=product()))
    assert "https://mercadolivre.com.br/afiliado/produto123" in out.caption
    assert "link de afiliado" in out.caption.lower()


def test_video_has_fast_hook_and_retention_plan():
    out = generate_script(ScriptRequest(product=product(), duration_seconds=20))
    assert out.hook
    assert any("0–2s" in line for line in out.on_screen_text)
    assert any("QUERO" in line for line in out.on_screen_text)


def test_heygen_speaks_hook_and_cta():
    text = Path("app/main.py").read_text()
    assert 'spoken_text = sanitize_spoken_text(f"{script.hook} {script.narration} {script.call_to_action}")' in text


def test_new_formats_are_available():
    html = Path("app/templates/scripts/form.html").read_text()
    for value in ("erro_comum", "comparacao_rapida", "surpresa_visual"):
        assert f'value="{value}"' in html
