from app.core.config import settings
from app.workers.discovery_worker import start_embedded_worker, stop_embedded_worker


def test_embedded_worker_is_enabled_by_default():
    assert settings.discovery_embedded_worker_enabled is True


def test_embedded_worker_start_is_idempotent():
    first = start_embedded_worker()
    second = start_embedded_worker()
    assert first is True
    assert second is False
    stop_embedded_worker()
