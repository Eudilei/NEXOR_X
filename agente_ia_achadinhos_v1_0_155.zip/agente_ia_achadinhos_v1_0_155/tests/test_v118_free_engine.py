from pathlib import Path


def test_script_form_offers_all_engines():
    text = Path('app/templates/scripts/form.html').read_text(encoding='utf-8')
    assert 'value="free_editor"' in text
    assert 'value="openai_editor"' in text
    assert 'value="heygen"' in text
    assert 'Editor Zavomi gratuito' in text


def test_production_page_offers_free_openai_heygen_and_upload():
    text = Path('app/templates/productions/form.html').read_text(encoding='utf-8')
    for mode in ('free', 'ai', 'heygen', 'upload'):
        assert f'value="{mode}"' in text


def test_free_mode_never_requests_ai_voice():
    text = Path('app/workers/production_worker.py').read_text(encoding='utf-8')
    assert 'use_ai_voice=(mode == "ai")' in text
    production = Path('app/services/production.py').read_text(encoding='utf-8')
    assert 'if use_ai_voice and settings.openai_api_key' in production


def test_script_model_persists_engine_choice():
    model = Path('app/db/models.py').read_text(encoding='utf-8')
    assert 'production_engine' in model
    main = Path('app/main.py').read_text(encoding='utf-8')
    assert 'production_engine: str = Form("free_editor")' in main
