from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from app.core.config import settings
from app.services.instagram import InstagramService


def test_instagram_authorization_url_contains_required_business_scopes(monkeypatch):
    monkeypatch.setattr(settings, "meta_app_id", "123")
    monkeypatch.setattr(settings, "meta_app_secret", "secret")
    monkeypatch.setattr(settings, "instagram_redirect_uri", "https://example.com/integracoes/instagram/callback")
    url = InstagramService().authorization_url("secure-state")
    assert "client_id=123" in url
    assert "instagram_business_basic" in url
    assert "instagram_business_content_publish" in url
    assert "state=secure-state" in url
    assert "force_reauth=true" in url
    assert "instagram_business_manage_comments" in url
    assert "instagram_business_manage_messages" in url
    assert "force_authentication" not in url
    assert "redirect_uri=https%3A%2F%2Fexample.com%2Fintegracoes%2Finstagram%2Fcallback" in url


def test_social_page_has_connect_and_explicit_publish_controls():
    html = open("app/templates/social/index.html", encoding="utf-8").read()
    assert "/integracoes/instagram/conectar" in html
    assert "/integracoes/instagram/callback" not in html
    assert "/social/instagram/publicar" in html
    assert "Publicar agora no Instagram" in html
    assert "confirm(" in html


def test_instagram_service_uses_reels_container_and_media_publish():
    source = open("app/services/instagram.py", encoding="utf-8").read()
    assert '"media_type": "REELS"' in source
    assert '"video_url": video_url' in source
    assert '/media_publish' in source
    assert 'status_code' in source
    assert 'share_to_feed' in source


def test_instagram_tokens_are_encrypted_before_persistence():
    source = open("app/services/instagram.py", encoding="utf-8").read()
    assert "encrypt_value(str(token_data[\"access_token\"]))" in source
    assert "access_token_encrypted" in source
    assert "refresh_long_lived" in source


def test_duplicate_publication_is_blocked_in_route():
    source = open("app/main.py", encoding="utf-8").read()
    assert 'Publication.status.in_(("aguardando", "processando", "publicado"))' in source
    assert "Esta produção já está na fila ou já foi publicada" in source
