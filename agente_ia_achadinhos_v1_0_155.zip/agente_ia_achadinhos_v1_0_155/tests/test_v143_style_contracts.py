from app.models.schemas import ProductInput, ScriptRequest
from app.services.scripts import generate_script


def product(title, category="casa", price=99.9):
    return ProductInput(
        title=title, category=category, price=price, rating=4.8,
        review_count=1200, sold_quantity=10000,
        affiliate_url="https://example.com/item",
    )


def test_free_humor_is_actually_humorous_and_product_specific():
    req=ScriptRequest(
        product=product("Caderneta Anotação A5 Executiva Tipo Moleskine Couro Sintético"),
        format="humor_observacao", voice_instructions="Roteiro engraçado e natural",
        duration_seconds=40, writer_engine="free_ai",
    )
    out=generate_script(req)
    text=(out.hook+" "+out.narration).lower()
    assert any(x in text for x in ("memória", "plantão", "férias"))
    assert any(x in text for x in ("ideia", "caderneta", "anota"))
    assert len(out.narration.split()) >= 70


def test_free_cost_benefit_discusses_value_not_only_features():
    req=ScriptRequest(
        product=product("Gillette Mach3 Sensitive Carga com Aloe 8 Unidades", "cuidados_pessoais", 129.9),
        format="vale_a_pena", voice_instructions="Mostre custo-benefício real",
        duration_seconds=40, writer_engine="free_ai",
    )
    out=generate_script(req)
    text=(out.hook+" "+out.narration).lower()
    assert any(x in text for x in ("custo-benefício", "menor preço", "valor total", "compensa"))
    assert any(x in text for x in ("oito", "unidades", "refis", "quantidade"))
    assert any(x in text for x in ("durabilidade", "uso real", "compatibilidade"))
