from pathlib import Path


def test_scripts_list_has_delete_all_button():
    html = Path('app/templates/scripts/list.html').read_text(encoding='utf-8')
    assert 'action="/scripts/delete-all"' in html
    assert 'Excluir todos os roteiros' in html
    assert 'Esta ação não pode ser desfeita' in html


def test_delete_all_route_removes_linked_content():
    source = Path('app/main.py').read_text(encoding='utf-8')
    assert '@app.post("/scripts/delete-all")' in source
    assert 'delete(Publication)' in source
    assert 'delete(MediaAsset)' in source
    assert 'db.delete(production)' in source
    assert 'db.delete(script)' in source


def test_laugh_profiles_and_hook_split_are_enabled():
    source = Path('app/services/production.py').read_text(encoding='utf-8')
    assert '"narrador_viral_risada"' in source
    assert '"feminina_viral_risada"' in source
    assert source.count('"laugh_after_hook": True') >= 2
    assert 'def _split_hook_and_rest' in source
    assert 'def _generate_gemini_laugh_after_hook' in source
    assert 'gemini_tts_distinct_hook_laugh' in source
    assert 'explosão de risada não verbal' in source
    assert 'NÃO faça outra risada' in source
