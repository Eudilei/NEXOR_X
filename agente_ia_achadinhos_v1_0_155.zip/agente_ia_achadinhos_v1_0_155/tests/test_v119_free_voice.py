from pathlib import Path

from app.services.production import FREE_TTS_VOICES, resolve_free_voice


def test_free_voice_mapping_by_selection():
    assert resolve_free_voice("feminina", "masculino") == FREE_TTS_VOICES["feminina"]
    assert resolve_free_voice("masculina", "feminino") == FREE_TTS_VOICES["masculina"]


def test_free_voice_auto_follows_presenter_gender():
    assert resolve_free_voice("auto", "masculino") == FREE_TTS_VOICES["masculina"]
    assert resolve_free_voice("auto", "feminino") == FREE_TTS_VOICES["feminina"]


def test_free_engine_ui_requires_voice():
    html = Path("app/templates/productions/form.html").read_text(encoding="utf-8")
    assert 'name="free_voice"' in html
    assert "Gerar com voz gratuita" in html
    assert "Não usa créditos HeyGen nem OpenAI" in html


def test_free_engine_route_enables_free_voice():
    worker = Path("app/workers/production_worker.py").read_text(encoding="utf-8")
    assert 'use_free_voice=(mode in {"free", "hybrid"})' in worker
    assert 'spoken_text=(f"{effective_hook} {effective_narration} {script.call_to_action}" if mode == "hybrid" else str(job.get("spoken_text") or ""))' in worker
