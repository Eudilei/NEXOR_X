from pathlib import Path

from app.services.production import _audit_visual_plan, _scene_durations_for_roles


def test_contrast_storyboard_closes_with_recommended_product():
    contrast = Path("wrong-model.jpg")
    product = Path("recommended.jpg")
    detail = Path("detail.jpg")
    paths = [contrast, product, detail, product]
    roles = ["contrast", "recommended_product", "detail", "cta"]
    durations = _scene_durations_for_roles(40, roles)
    _audit_visual_plan(paths, roles, durations, 40)


def test_hook_plus_contrast_closes_with_recommended_product():
    hook = Path("hook.jpg")
    contrast = Path("wrong-model.jpg")
    product = Path("recommended.jpg")
    paths = [hook, contrast, product, product]
    roles = ["gancho_ilustrado", "contrast", "recommended_product", "cta"]
    durations = _scene_durations_for_roles(40, roles)
    _audit_visual_plan(paths, roles, durations, 40)
