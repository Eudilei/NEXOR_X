from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_new_product_commission_uses_blur_formatting():
    html = (ROOT / "app/templates/products/form.html").read_text()
    assert 'name="commission_pct" id="commission_pct" value=""' in html
    assert "requestAnimationFrame(() => el.select())" in html
    assert "el.value = digits(el.value).slice(0, 4)" in html
    assert "el.addEventListener('blur'" in html


def test_complete_product_commission_uses_dedicated_percent_formatter():
    html = (ROOT / "app/templates/products/complete.html").read_text()
    assert "const percentDecimal = (value)" in html
    assert "digits.length <= 2 ? Number(digits) : Number(digits) / 10" in html
    assert "if (kind === 'percent')" in html
    assert "input.value = digitsOnly(input.value).slice(0, 4)" in html
