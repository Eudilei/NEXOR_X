from pathlib import Path


def _production_text():
    return Path("app/services/production.py").read_text(encoding="utf-8")

def test_v147_uses_single_laugh_tag():
    text=_production_text()
    marker='tagged = f"{hook} [laughs]"'
    assert marker in text
    block=text[text.index(marker):text.index('return generate_gemini_tts', text.index(marker))]
    assert '[gasp]' not in block
    assert '[laughs uncontrollably]' not in block

def test_v147_targets_about_four_seconds():
    text=_production_text()
    assert 'ideal entre 3,5 e 4,5 s' in text
    assert 'NÃO prolongue a risada' in text
    assert 'corte abruptamente' in text
