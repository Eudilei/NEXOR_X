from app.services.scripts import product_visual_facts
from app.services.production import _commercial_scene_texts, _is_complete_overlay


def test_hair_mask_gets_category_specific_facts():
    facts = product_visual_facts("Máscara de Reconstrução Profunda para Cabelos Danificados com Proteína do Trigo 500g")
    assert facts["product"] == "RECONSTRUÇÃO PARA CABELOS DANIFICADOS"
    assert "COM PROTEÍNA DO TRIGO" in facts["attributes"]
    assert "CONTEÚDO: 500 G" in facts["attributes"]


def test_truncated_overlay_is_rejected():
    assert not _is_complete_overlay("MÁSCARA DE RECONSTRUÇÃO PROFUNDA PARA")
    assert _is_complete_overlay("RECONSTRUÇÃO PARA CABELOS DANIFICADOS")


def test_cta_only_at_end_and_social_is_consolidated():
    texts = _commercial_scene_texts(
        "Máscara de Reconstrução Profunda para Cabelos Danificados 500g",
        "0–2s · Gancho\n2–6s · MÁSCARA DE RECONSTRUÇÃO PROFUNDA PARA\n24–30s · VEJA NO LINK DA BIO",
        "Seu cabelo pediu socorro?",
        "Confira no link da descrição ou da bio",
        rating=4.9,
        review_count=23650,
        sold_quantity=120000,
    )
    joined = " | ".join(texts).upper()
    assert "PROFUNDA PARA" not in joined
    assert texts[-1].upper().startswith("CONFIRA NO LINK")
    assert "23.650 AVALIAÇÕES" in joined
    assert joined.count("NOTA 4,9") == 1
    assert joined.count("MAIS DE 100 MIL VENDAS") == 1


def test_unverified_professional_endorsement_is_filtered():
    texts = _commercial_scene_texts(
        "Máscara Capilar 500g",
        "2–6s · PROFISSIONAL RECOMENDA ESTE PRODUTO",
        "Veja os detalhes",
        "Confira no link",
    )
    assert all("PROFISSIONAL RECOMENDA" not in text.upper() for text in texts)
