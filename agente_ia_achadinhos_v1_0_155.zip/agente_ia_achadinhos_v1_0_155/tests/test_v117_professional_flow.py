from app.models.schemas import ProductInput, ProductCategory, ScriptRequest
from app.services.scripts import generate_script
from app.services.heygen import _avatar_kind


def product():
    return ProductInput(
        title="Kit C/ 3 Toalha De Banho Gigante Luxo 70 X 1,40",
        category=ProductCategory.CASA,
        price=89.90,
        rating=4.4,
        review_count=321,
        sold_quantity=0,
        affiliate_url="https://produto.mercadolivre.com.br/MLB-123",
    )


def test_three_requested_variations_are_structurally_distinct():
    outputs = [generate_script(ScriptRequest(product=product(), format="vale_a_pena", variation_index=i)) for i in range(3)]
    assert len({o.hook for o in outputs}) == 3
    assert len({o.narration for o in outputs}) == 3
    assert len({o.call_to_action for o in outputs}) == 3
    assert {o.hashtags[-1] for o in outputs} == {"#beneficio", "#criterio_compra", "#prova_oferta"}


def test_animated_avatar_classification():
    assert _avatar_kind({"name": "Zavomi Cartoon Mascot"}) == "animado"
    assert _avatar_kind({"name": "Maria Office Presenter"}) == "realista"


def test_natural_motion_and_persistent_worker_present():
    from pathlib import Path
    heygen = Path("app/services/heygen.py").read_text()
    worker = Path("app/workers/production_worker.py").read_text()
    assert 'expressiveness = "low"' in heygen
    assert 'não balance o corpo' in heygen
    assert 'montando_ativo' in worker
    assert 'assembly_attempts' in worker
