from pathlib import Path
from types import SimpleNamespace

from PIL import Image

from app.services.production import _hook_image_prompt, create_hook_image
from app.services.social_content import build_instagram_caption, caption_issues


def _product():
    return SimpleNamespace(
        title="Kit C/ 3 Toalha de Banho",
        category="casa",
        rating=0,
        review_count=0,
        sold_quantity=0,
        price=49.9,
    )


def test_instagram_caption_has_clean_bio_cta_without_raw_url():
    caption = build_instagram_caption(_product(), SimpleNamespace(hook="Seu banheiro merece isso?"))
    assert "link na bio" in caption.lower()
    assert "http://" not in caption
    assert "https://" not in caption
    assert "/achadinhos" not in caption
    assert caption_issues(caption, _product()) == []


def test_caption_audit_rejects_raw_url():
    issues = caption_issues("Veja no link na bio: https://example.com/achadinhos", _product())
    assert any("URL completa" in issue for issue in issues)


def test_hook_prompt_forbids_fake_commercial_claims():
    prompt = _hook_image_prompt("Aparelho de barbear", "Sua barba vira discussão com o espelho?", "com aloe")
    lowered = prompt.lower()
    assert "representar visualmente o gancho" in lowered
    assert "sem números" in lowered
    assert "sem preços" in lowered
    assert "não substitua a foto real" in lowered


def test_hook_image_has_local_fallback_without_api(monkeypatch, tmp_path: Path):
    from app.services import production

    monkeypatch.setattr(production.settings, "openai_api_key", None)
    cover = tmp_path / "cover.jpg"
    output = tmp_path / "hook.jpg"
    Image.new("RGB", (800, 800), "white").save(cover)
    path, provider = create_hook_image(
        "Organizador de cozinha", "Sua gaveta parece uma mudança?", "", cover, output
    )
    assert path.exists()
    assert path.stat().st_size > 0
    assert provider == "local_fallback"
    with Image.open(path) as generated:
        assert generated.size == (720, 1280)
