from types import SimpleNamespace

from app.services.instagram_automation import has_buy_intent, parse_comment_events
from app.services.social_content import build_instagram_caption, caption_issues


def test_buy_intent_variations():
    assert has_buy_intent("QUERO")
    assert has_buy_intent("me manda o link")
    assert has_buy_intent("onde compra?")
    assert not has_buy_intent("muito bonito")


def test_parse_comment_webhook():
    payload = {"entry": [{"changes": [{"field": "comments", "value": {
        "id": "comment-1", "text": "quero", "from": {"username": "cliente"}, "media": {"id": "reel-1"}
    }}]}]}
    assert parse_comment_events(payload) == [{"comment_id": "comment-1", "media_id": "reel-1", "text": "quero", "username": "cliente"}]


def test_caption_has_direct_and_bio_without_raw_url():
    product = SimpleNamespace(title="Kit C/ 3 Toalha", category="casa", rating=4.8, review_count=10, sold_quantity=100, price=99.9)
    script = SimpleNamespace(hook="Seu banheiro merece isso?")
    caption = build_instagram_caption(product, script)
    assert "Comente QUERO" in caption
    assert "Direct" in caption
    assert "link na bio" in caption
    assert "http" not in caption
    assert caption_issues(caption, product) == []
