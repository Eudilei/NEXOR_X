from app.services.marketplace import MercadoLivreClient


def test_review_metrics_uses_paging_total():
    rating, total, levels = MercadoLivreClient.review_metrics({
        "rating_average": 4.8,
        "paging": {"total": 1234},
        "rating_levels": {"one_star": 1, "two_star": 2, "three_star": 3, "four_star": 4, "five_star": 50},
    })
    assert rating == 4.8
    assert total == 1234
    assert levels["five_star"] == 50


def test_review_metrics_sums_levels_when_paging_is_empty():
    rating, total, _ = MercadoLivreClient.review_metrics({
        "rating_average": "4.9",
        "paging": {},
        "rating_levels": {"one_star": 1, "two_star": 2, "three_star": 3, "four_star": 4, "five_star": 90},
    })
    assert rating == 4.9
    assert total == 100


def test_item_reviews_adds_catalog_context(monkeypatch):
    client = object.__new__(MercadoLivreClient)
    calls = []
    def fake_get(endpoint, **kwargs):
        calls.append((endpoint, kwargs))
        return {"rating_average": 4.7}
    monkeypatch.setattr(client, "_get", fake_get)
    payload = client.item_reviews("MLB123", "MLB999")
    assert payload["rating_average"] == 4.7
    assert calls[0][0] == "/reviews/item/MLB123?catalog_product_id=MLB999"
    assert calls[0][1]["authenticated"] is True
