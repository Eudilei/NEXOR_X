from pathlib import Path

from PIL import Image, ImageDraw

from app.services.production import (
    _audio_filter_for_target,
    _audit_visual_plan,
    _scene_durations_for_roles,
    _stabilize_visual_sequence,
)


def _img(path: Path, kind: str, color: tuple[int, int, int]) -> Path:
    image = Image.new("RGB", (500, 500), "white")
    draw = ImageDraw.Draw(image)
    if kind == "cover":
        draw.rectangle((80, 120, 420, 400), fill=color)
    elif kind == "info":
        for y in range(40, 450, 28):
            draw.text((30, y), "INFORMAÇÃO DO PRODUTO 123", fill="black")
    elif kind == "detail":
        draw.ellipse((150, 150, 350, 350), fill=color)
    elif kind == "variation":
        draw.rectangle((40, 40, 460, 460), fill=color)
    image.save(path)
    return path


def test_visual_director_breaks_three_equivalent_scenes_and_keeps_cover():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        cover = _img(root / "cover.jpg", "cover", (210, 120, 130))
        d1 = _img(root / "d1.jpg", "detail", (205, 120, 128))
        d2 = _img(root / "d2.jpg", "detail", (204, 121, 129))
        d3 = _img(root / "d3.jpg", "detail", (203, 122, 130))
        variation = _img(root / "blue.jpg", "variation", (30, 90, 210))
        ordered, roles = _stabilize_visual_sequence([cover, d1, d2, d3, variation])
        assert ordered[0] == cover
        assert not any(roles[i] == roles[i-1] == roles[i-2] for i in range(2, len(roles)))


def test_scene_plan_closes_40_seconds_and_cta_is_two_seconds():
    roles = ["produto_completo", "informacao", "detalhe", "variacao", "cta"]
    durations = _scene_durations_for_roles(40, roles)
    assert abs(sum(durations) - 40) < 0.05
    assert durations[-1] == 2.0
    assert durations[1] > durations[2] > durations[3]


def test_visual_auditor_rejects_cover_in_the_middle():
    cover = Path("cover.jpg")
    paths = [cover, Path("a.jpg"), cover, cover]
    roles = ["produto_completo", "detalhe", "produto_completo", "cta"]
    durations = [12.0, 12.0, 14.0, 2.0]
    try:
        _audit_visual_plan(paths, roles, durations, 40)
    except RuntimeError as exc:
        assert "capa" in str(exc).lower()
    else:
        raise AssertionError("auditoria deveria bloquear repetição intermediária da capa")


def test_audio_filter_targets_end_near_38_4_seconds(monkeypatch, tmp_path):
    audio = tmp_path / "audio.mp3"
    audio.write_bytes(b"fake")
    monkeypatch.setattr("app.services.production._media_duration_seconds", lambda *_: 36.4)
    audio_filter, actual, target = _audio_filter_for_target("ffmpeg", audio, 40)
    assert actual == 36.4
    assert target == 38.4
    assert "atempo=" in audio_filter
    assert "apad=pad_dur=40" in audio_filter
