from pathlib import Path

from app.services.instagram import InstagramService
from app.services.scripts import _limit_question_density, _conversion_cta


def test_subscribe_webhooks_uses_account_subscription(monkeypatch):
    captured = {}

    class Response:
        status_code = 200
        text = '{"success":true}'
        def json(self): return {"success": True}

    class Client:
        def __init__(self, *a, **k): pass
        def __enter__(self): return self
        def __exit__(self, *a): pass
        def post(self, url, data=None):
            captured["url"] = url; captured["data"] = data
            return Response()

    monkeypatch.setattr("app.services.instagram.httpx.Client", Client)
    result = InstagramService().subscribe_webhooks("1789", "token")
    assert result["success"] is True
    assert captured["url"].endswith("/1789/subscribed_apps")
    assert captured["data"]["subscribed_fields"] == "comments,messages"


def test_question_density_keeps_only_one_question():
    hook, narration = _limit_question_density(
        "Sua toalha ainda enxuga?",
        "Ela é bonita? Ela é grande? Vale a pena? Confira as medidas.",
    )
    assert (hook + narration).count("?") == 1
    assert "Confira as medidas." in narration


def test_conversion_cta_requests_quero_direct():
    cta = _conversion_cta()
    assert "QUERO" in cta
    assert "Direct" in cta
