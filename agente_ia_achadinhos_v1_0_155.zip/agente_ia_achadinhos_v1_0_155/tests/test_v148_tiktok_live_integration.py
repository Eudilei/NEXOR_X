from pathlib import Path

from app.services.tiktok import TikTokService


def test_tiktok_oauth_requests_approved_posting_scopes(monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, "tiktok_client_key", "client-key")
    monkeypatch.setattr(settings, "tiktok_client_secret", "client-secret")
    monkeypatch.setattr(settings, "tiktok_redirect_uri", "https://example.com/integracoes/tiktok/callback")
    url = TikTokService().authorization_url("state-123")
    assert "user.info.basic" in url
    assert "video.publish" in url
    assert "video.upload" in url
    assert "state=state-123" in url


def test_tiktok_screen_honors_creator_options_and_explicit_consent():
    template = Path("app/templates/social/index.html").read_text(encoding="utf-8")
    assert "privacy_level_options" in template
    assert 'name="privacy_level"' in template
    assert 'name="consent"' in template
    assert "Conta de destino" in template
    assert 'name="allow_comment"' in template
    assert 'name="allow_duet"' in template
    assert 'name="allow_stitch"' in template


def test_tiktok_publish_route_revalidates_privacy_and_consent():
    main = Path("app/main.py").read_text(encoding="utf-8")
    assert 'if consent != "1"' in main
    assert 'if privacy_level not in options' in main
    assert 'service.creator_info(token)' in main
    assert 'processando_tiktok' in main
    assert 'wait_for_final_status' in main


def test_direct_post_uses_user_selected_interactions():
    source = Path("app/services/tiktok.py").read_text(encoding="utf-8")
    assert '"disable_duet":not bool(allow_duet)' in source
    assert '"disable_comment":not bool(allow_comment)' in source
    assert '"disable_stitch":not bool(allow_stitch)' in source
    assert '"brand_content_toggle":bool(brand_content)' in source
    assert '"is_aigc":bool(is_aigc)' in source
