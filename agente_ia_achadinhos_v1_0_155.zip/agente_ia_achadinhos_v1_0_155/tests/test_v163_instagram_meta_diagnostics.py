import json
import logging

import httpx
import pytest

from app.services.instagram import InstagramError, InstagramService


def _response(status: int, payload) -> httpx.Response:
    request = httpx.Request("GET", "https://graph.instagram.com/me")
    return httpx.Response(status, request=request, json=payload)


def test_meta_error_exposes_diagnostic_fields_to_operator(caplog):
    response = _response(400, {"error": {
        "message": "API access blocked.",
        "type": "OAuthException",
        "code": 200,
        "error_subcode": 2018028,
        "fbtrace_id": "TRACE123",
        "is_transient": False,
    }})
    with caplog.at_level(logging.ERROR, logger="agente.instagram.meta"):
        with pytest.raises(InstagramError) as exc:
            InstagramService._json_or_error(response, "consultar a conta do Instagram")
    message = str(exc.value)
    assert "HTTP 400" in message
    assert "código 200" in message
    assert "subcódigo 2018028" in message
    assert "OAuthException" in message
    assert "API access blocked" in message
    assert "fbtrace_id TRACE123" in message
    record = json.loads(caplog.records[-1].message)
    assert record["event"] == "meta_instagram_api_error"
    assert record["error_code"] == 200
    assert record["error_subcode"] == 2018028
    assert record["fbtrace_id"] == "TRACE123"


def test_meta_diagnostic_does_not_log_request_token(caplog):
    request = httpx.Request("GET", "https://graph.instagram.com/me?access_token=SECRET_TOKEN")
    response = httpx.Response(500, request=request, text="temporary failure")
    with caplog.at_level(logging.ERROR, logger="agente.instagram.meta"):
        with pytest.raises(InstagramError):
            InstagramService._json_or_error(response, "consultar a conta")
    logged = "\n".join(record.message for record in caplog.records)
    assert "SECRET_TOKEN" not in logged
    assert "https://graph.instagram.com/me" not in logged


def test_invalid_success_response_is_audited(caplog):
    request = httpx.Request("GET", "https://graph.instagram.com/me")
    response = httpx.Response(200, request=request, content=b"not-json")
    with caplog.at_level(logging.ERROR, logger="agente.instagram.meta"):
        with pytest.raises(InstagramError, match="Resposta inválida"):
            InstagramService._json_or_error(response, "consultar a conta")
    assert "meta_instagram_invalid_response" in caplog.records[-1].message
