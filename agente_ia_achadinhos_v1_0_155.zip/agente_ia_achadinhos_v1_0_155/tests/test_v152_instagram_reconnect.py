from app.core.config import settings
from app.services.instagram import InstagramService


def test_mobile_reconnect_forces_fresh_instagram_authorization(monkeypatch):
    monkeypatch.setattr(settings, "meta_app_id", "123")
    monkeypatch.setattr(settings, "meta_app_secret", "secret")
    monkeypatch.setattr(settings, "instagram_redirect_uri", "https://example.com/integracoes/instagram/callback")
    url = InstagramService().authorization_url("fresh-state")
    assert url.startswith("https://www.instagram.com/oauth/authorize?")
    assert "force_reauth=true" in url
    assert "instagram_business_manage_comments" in url
    assert "instagram_business_manage_messages" in url
    assert "redirect_uri=https%3A%2F%2Fexample.com%2Fintegracoes%2Finstagram%2Fcallback" in url


def test_connect_route_disables_browser_cache():
    source = open("app/main.py", encoding="utf-8").read()
    assert 'response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"' in source
    assert 'response.headers["Pragma"] = "no-cache"' in source
