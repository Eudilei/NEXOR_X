from pathlib import Path
from unittest.mock import patch
import pytest

from app.services.production import FREE_TTS_PROFILES, generate_profile_speech, resolve_free_voice_profile


def test_every_rich_profile_has_unique_gemini_timbre():
    rich = [p for p in FREE_TTS_PROFILES.values() if p.get("provider") in {"gemini", "auto"}]
    ids = [p["gemini_voice"] for p in rich]
    assert len(ids) >= 20
    assert len(ids) == len(set(ids))


def test_no_gemini_uses_real_runtime_edge_instead_of_failing(tmp_path):
    profile = resolve_free_voice_profile("narrador_viral_br")
    fake = type("S", (), {"gemini_api_key": ""})()
    target = tmp_path / "x.mp3"
    def fake_speech(text, output, voice, rate="+0%", pitch="+0Hz"):
        output.write_bytes(b"x" * 2048)
        return output
    with patch("app.services.production.settings", fake), patch("app.services.production._runtime_edge_voice", return_value="pt-BR-NicolauNeural"), patch("app.services.production.generate_free_speech", side_effect=fake_speech):
        out, provider = generate_profile_speech("teste", target, profile)
    assert out.exists()
    assert provider == "edge_tts_runtime"
    assert profile["_runtime_engine"] == "pt-BR-NicolauNeural"


def test_edge_fallbacks_are_explicitly_only_two():
    edge = [p for p in FREE_TTS_PROFILES.values() if p.get("provider") == "edge"]
    assert {p["name"] for p in edge} == {"edge_masculina_basica", "edge_feminina_basica"}

def test_ui_explains_real_provider_and_engine():
    detail = Path("app/templates/scripts/detail.html").read_text(encoding="utf-8")
    assert "Diversidade real ativa" in detail
    assert "X-Zavomi-Voice-Engine" in detail
    assert "Fallback Edge básico" in detail
