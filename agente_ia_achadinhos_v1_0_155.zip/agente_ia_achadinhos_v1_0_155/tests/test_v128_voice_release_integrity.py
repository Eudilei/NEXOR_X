from pathlib import Path
from app.services.production import FREE_TTS_PROFILES, choose_free_voice_profile
from app.core.config import settings


def test_rich_profiles_have_unique_real_gemini_timbres():
    rich=[p for p in FREE_TTS_PROFILES.values() if p.get('provider') in {'gemini','auto'}]
    voices=[p.get('gemini_voice') for p in rich]
    assert len(rich) >= 20
    assert all(voices)
    assert len(voices) == len(set(voices))


def test_labels_do_not_claim_unrelated_person_names():
    labels=' '.join(p.get('label','') for p in FREE_TTS_PROFILES.values())
    for wrong in ('Thalita','Leila','Giovanna','Brenda','Yara','Manuela','Donato','Nicolau','Fábio','Humberto','Júlio'):
        assert wrong not in labels


def test_manual_voice_selection_is_not_replaced():
    p=choose_free_voice_profile('narrador_viral_br','feminino','review',variation_seed=99)
    assert p['name']=='narrador_viral_br'
    assert p['gemini_voice']=='Enceladus'


def test_current_default_tts_model_is_recommended_31():
    assert settings.gemini_tts_model == 'gemini-3.1-flash-tts-preview'


def test_only_current_release_marker_remains():
    releases=sorted(p.name for p in Path('.').glob('RELEASE_v1.0.*.txt'))
    assert releases == ['RELEASE_v1.0.130.txt']
