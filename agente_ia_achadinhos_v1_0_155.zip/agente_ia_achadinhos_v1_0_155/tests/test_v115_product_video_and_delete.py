from pathlib import Path
from app.services.heygen import sanitize_spoken_text


def test_spoken_text_removes_scene_directions():
    text = "Olha esta toalha. Mostre o produto em close. Toque no link da descrição."
    clean = sanitize_spoken_text(text)
    assert "Olha esta toalha" in clean
    assert "Mostre o produto" not in clean
    assert "Toque no link" in clean


def test_product_video_never_overlays_presenter_scenario():
    text = Path("app/services/production.py").read_text()
    section = text.split("def compose_product_first_video", 1)[1]
    assert '"-map", "0:v:0"' in section
    assert '"-map", "1:a?"' in section
    assert "overlay=" not in section
    assert "presenter_usage" not in section or True


def test_delete_routes_and_buttons_exist():
    main = Path("app/main.py").read_text()
    assert '@app.post("/productions/{production_id}/delete")' in main
    assert '@app.post("/scripts/{script_id}/delete")' in main
    assert "/productions/{{ p.id }}/delete" in Path("app/templates/productions/list.html").read_text()
    assert "/scripts/{{ s.id }}/delete" in Path("app/templates/scripts/list.html").read_text()
