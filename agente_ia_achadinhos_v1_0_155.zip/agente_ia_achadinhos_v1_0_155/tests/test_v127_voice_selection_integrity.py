from pathlib import Path

from app.services.production import FREE_TTS_PROFILES


def test_rich_profiles_use_unique_gemini_voice_ids():
    rich = [p for p in FREE_TTS_PROFILES.values() if p.get("provider") in {"gemini", "auto"}]
    ids = [p.get("gemini_voice") for p in rich]
    assert len(rich) >= 20
    assert None not in ids and "" not in ids
    assert len(ids) == len(set(ids))


def test_production_audio_filename_is_voice_specific_and_not_legacy_shared_file():
    src = Path("app/services/production.py").read_text(encoding="utf-8")
    assert 'narration_free_{profile_token}_{engine_token}.mp3' in src
    assert 'audio_path = folder / "narration_free.mp3"' not in src


def test_ui_explains_runtime_edge_behavior_without_gemini():
    html = Path("app/templates/productions/form.html").read_text(encoding="utf-8")
    assert "Edge" in html
    assert "locutor real" in html or "locutor" in html
