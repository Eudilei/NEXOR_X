from pathlib import Path
from app.models.schemas import ProductInput, ProductCategory, ScriptRequest
from app.services.scripts import generate_script


def product(title, category='casa', price=99.9):
    return ProductInput(title=title, category=ProductCategory(category), price=price, affiliate_url='https://example.com/p')


def test_automatic_scripts_change_structure_across_different_products():
    titles = [
        ('Organizador De Gaveta Ajustável 8 Divisórias', 'organizacao'),
        ('Fone Bluetooth TWS Com Estojo Carregador', 'eletronicos'),
        ('Frigideira Antiaderente 24cm Com Tampa', 'cozinha'),
        ('Caderneta A5 Capa Couro Sintético Com Elástico', 'escritorio_papelaria'),
    ]
    outputs = [generate_script(ScriptRequest(product=product(t,c), variation_index=0, duration_seconds=40)) for t,c in titles]
    assert len({o.hook for o in outputs}) >= 3
    starts = {' '.join(o.narration.lower().split()[:7]) for o in outputs}
    assert len(starts) >= 3


def test_same_product_variations_do_not_repeat_hook():
    p = product('Gillette Mach3 Sensitive Carga 8 Unidades com Aloe', 'cuidados_pessoais', 129.9)
    outs = [generate_script(ScriptRequest(product=p, variation_index=i, duration_seconds=40)) for i in range(3)]
    assert len({o.hook for o in outs}) == 3


def test_duration_fit_never_ends_with_dangling_connector():
    p = product('Caderneta A5 Tipo Moleskine Couro Sintético', 'escritorio_papelaria', 39.9)
    out = generate_script(ScriptRequest(product=p, format='humor_observacao', voice_instructions='humor observacional', duration_seconds=40))
    assert not out.narration.lower().rstrip('.!?').endswith((' e', ' ou', ' de', ' com', ' para', ' em', ' por'))


def test_video_motion_filter_no_longer_uses_zoompan_or_crop():
    code = Path('app/services/production.py').read_text(encoding='utf-8')
    block = code[code.index('def _render_motion_segment'):code.index('def compose_product_first_video')]
    assert 'zoompan' not in block
    assert 'crop=720:1280' not in block
    assert 'pad=720:1280' in block
