from fastapi.testclient import TestClient

from app.main import app
from app.core.config import settings


def test_terms_and_privacy_are_public():
    client = TestClient(app)
    assert client.get("/termos-de-servico").status_code == 200
    assert client.get("/politica-de-privacidade").status_code == 200


def test_tiktok_signature_file_is_exact_and_plain_text(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "tt-signature.txt")
    monkeypatch.setattr(settings, "tiktok_url_verification_content", "tiktok-site-verification=abc123")
    client = TestClient(app)
    terms_response = client.get("/termos-de-servico/tt-signature.txt")
    privacy_response = client.get("/politica-de-privacidade/tt-signature.txt")
    for response in (terms_response, privacy_response):
        assert response.status_code == 200
        assert response.text == "tiktok-site-verification=abc123\n"
        assert response.headers["content-type"].startswith("text/plain")
        assert response.headers["x-content-type-options"] == "nosniff"
    assert client.get("/tt-signature.txt").status_code == 404
    assert client.get("/outro.txt").status_code == 404
    assert client.get("/termos-de-servico/outro.txt").status_code == 404
    assert client.get("/politica-de-privacidade/outro.txt").status_code == 404


def test_tiktok_signature_rejects_path_in_config(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "pasta/tt-signature.txt")
    monkeypatch.setattr(settings, "tiktok_url_verification_content", "abc")
    client = TestClient(app)
    assert client.get("/tt-signature.txt").status_code == 404
    assert client.get("/termos-de-servico/tt-signature.txt").status_code == 404


def test_tiktok_shop_configuration_property_is_boolean():
    assert isinstance(settings.tiktok_shop_api_configured, bool)
