from app.models.schemas import ProductInput, ScriptRequest
from app.services import scripts


def _product():
    return ProductInput(
        title="Gillette Mach3 Sensitive Carga para Aparelho de Barbear com Aloe 8 Unidades",
        category="cuidados_pessoais",
        price=129.9,
        rating=4.8,
        review_count=2300,
        sold_quantity=10000,
        affiliate_url="https://example.com/item",
    )


def _package(short=False):
    narration = (
        "Este refil foi pensado para quem sente desconforto ao fazer a barba e precisa escolher a reposição correta. "
        "O kit reúne oito cargas compatíveis com aparelhos Mach3 e o anúncio destaca fita lubrificante com aloe. "
        "Antes de comprar, confirme a compatibilidade com o seu aparelho, a quantidade de unidades e as condições atuais da oferta. "
        "Para quem se barbeia com frequência, ter cargas de reposição ajuda a manter a rotina sem improviso. "
        "A avaliação e o volume de vendas ajudam a contextualizar a procura, mas a decisão deve considerar principalmente compatibilidade, quantidade e proposta para pele sensível."
    )
    if short:
        narration = "Este produto tem aloe e oito unidades. Confira antes de comprar."
    candidates=[]
    for i in range(5):
        candidates.append({
            "strategy": f"estrategia_{i}",
            "hook": "Sua pele reclama depois de cada barbear?",
            "narration": narration,
            "spoken_cta": "Confira o link da bio.",
            "score": 90,
            "review": "bom",
        })
    return {
        "analysis": {
            "product": "refil Mach3 Sensitive",
            "category": "cuidados pessoais",
            "audience": "pessoas com pele sensível",
            "problem": "irritação no barbear",
            "purchase_criteria": ["compatibilidade", "quantidade", "lubrificação"],
            "confirmed_features": ["oito unidades", "aloe", "Mach3"],
            "prohibited_claims": ["elimina irritação"],
            "central_thesis": "compatibilidade e lubrificação orientam a escolha",
        },
        "candidates": candidates,
        "selected_index": 0,
    }


def test_openai_pipeline_expands_short_candidate_locally(monkeypatch):
    monkeypatch.setattr(scripts.settings, "openai_api_key", "test-key")
    calls=[]
    monkeypatch.setattr(scripts, "_openai_response", lambda payload: (calls.append(payload) or _package(short=True)))
    req=ScriptRequest(product=_product(), writer_engine="openai", duration_seconds=40)
    profile=scripts._product_profile(req.product.title)
    category=scripts._category_script_profile(req.product.title, "cuidados_pessoais", profile)
    out=scripts._openai_writer_pipeline(req, profile, category, "nota 4,8")
    assert out["attempts"] == 1
    assert len(calls) == 1
    assert len(out["narration"].split()) >= 68


def test_openai_pipeline_chooses_best_locally_not_selected_index(monkeypatch):
    monkeypatch.setattr(scripts.settings, "openai_api_key", "test-key")
    package=_package(short=False)
    package["selected_index"] = 0
    package["candidates"][0]["narration"] = "Texto curto demais."
    monkeypatch.setattr(scripts, "_openai_response", lambda payload: package)
    req=ScriptRequest(product=_product(), writer_engine="openai", duration_seconds=40)
    profile=scripts._product_profile(req.product.title)
    category=scripts._category_script_profile(req.product.title, "cuidados_pessoais", profile)
    out=scripts._openai_writer_pipeline(req, profile, category, "nota 4,8")
    assert out["chosen"]["strategy"] != "estrategia_0"


def test_openai_pipeline_reports_after_three_irrecoverable_attempts(monkeypatch):
    monkeypatch.setattr(scripts.settings, "openai_api_key", "test-key")
    calls=[]
    bad=_package(short=False)
    for candidate in bad["candidates"]:
        candidate["narration"] += " Elimina irritação imediatamente."
    monkeypatch.setattr(scripts, "_openai_response", lambda payload: (calls.append(1) or bad))
    req=ScriptRequest(product=_product(), writer_engine="openai", duration_seconds=40)
    profile=scripts._product_profile(req.product.title)
    category=scripts._category_script_profile(req.product.title, "cuidados_pessoais", profile)
    try:
        scripts._openai_writer_pipeline(req, profile, category, "nota 4,8")
        assert False, "deveria falhar"
    except ValueError as exc:
        assert "três tentativas automáticas" in str(exc)
    assert len(calls) == 3
