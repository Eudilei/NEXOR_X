from pathlib import Path
from app.services.scripts import generate_script, script_language_issues
from app.models.schemas import ProductInput, ScriptRequest

def _product():
    return ProductInput(title="Caderneta A5 couro sintético com elástico", category="organizacao", marketplace="mercado_livre", price=49.9, rating=4.8, review_count=1200, sold_quantity=8000, seller_reputation=5, commission_pct=8, stock_available=True, visual_quality=8, demonstration_ease=8, novelty=6, return_risk=2, affiliate_url="https://example.com/p")

def test_40_second_script_is_substantial_and_clean():
    out=generate_script(ScriptRequest(product=_product(), format="problema_solucao", duration_seconds=40, variation_index=0))
    spoken=f"{out.hook} {out.narration} {out.call_to_action}"
    assert len(spoken.split()) >= 70
    assert not script_language_issues(spoken)
    assert "quero" in out.call_to_action.lower() and "direct" in out.call_to_action.lower()

def test_production_gallery_has_manual_selection():
    html=Path("app/templates/productions/form.html").read_text()
    assert "media-check" in html
    assert "media-order" in html
    assert "Definir como capa" in html
    assert "selected_media_urls" in html
