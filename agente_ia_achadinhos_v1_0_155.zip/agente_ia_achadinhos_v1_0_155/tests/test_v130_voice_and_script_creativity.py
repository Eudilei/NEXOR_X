from app.services.production import FREE_TTS_PROFILES
from app.services.scripts import _text_similarity


def test_v130_exposes_all_30_unique_gemini_timbres():
    voices = {p.get('gemini_voice') for p in FREE_TTS_PROFILES.values() if p.get('gemini_voice')}
    assert len(voices) >= 30
    for name in ('Autonoe','Umbriel','Algieba','Despina','Erinome'):
        assert name in voices


def test_v130_new_interpretation_styles_exist():
    for key in ('estilo_confidencia','estilo_reacao','estilo_lista_rapida','estilo_ironia','estilo_feminina_reacao'):
        assert key in FREE_TTS_PROFILES
        assert FREE_TTS_PROFILES[key]['style']


def test_similarity_gate_detects_template_reuse():
    a = 'Esse produto ajuda na rotina e antes de comprar confira medidas e compatibilidade.'
    b = 'Esse produto ajuda na rotina e antes de comprar confira medidas e compatibilidade.'
    assert _text_similarity(a,b) >= 0.9
