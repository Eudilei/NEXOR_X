from fastapi.testclient import TestClient

from app.main import app, TIKTOK_VERIFICATION_DIR
from app.core.config import settings


def test_tiktok_verification_is_materialized_as_physical_file(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "tiktok-proof.txt")
    monkeypatch.setattr(settings, "tiktok_url_verification_content", "tiktok-developers-site-verification=proof123")
    target = TIKTOK_VERIFICATION_DIR / "tiktok-proof.txt"
    target.unlink(missing_ok=True)

    with TestClient(app) as client:
        response = client.get("/termos-de-servico/tiktok-proof.txt")
        assert response.status_code == 200
        assert target.is_file()
        assert target.read_text(encoding="utf-8") == "tiktok-developers-site-verification=proof123\n"
        assert response.text == "tiktok-developers-site-verification=proof123\n"
        assert response.headers["content-type"].startswith("text/plain")


def test_tiktok_verification_supports_head(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "tiktok-head.txt")
    monkeypatch.setattr(settings, "tiktok_url_verification_content", "tiktok-developers-site-verification=head123")

    with TestClient(app) as client:
        response = client.head("/termos-de-servico/tiktok-head.txt")
        assert response.status_code == 200
        assert response.text == ""
        assert response.headers["content-type"].startswith("text/plain")


def test_old_physical_signature_is_removed(monkeypatch):
    TIKTOK_VERIFICATION_DIR.mkdir(parents=True, exist_ok=True)
    old = TIKTOK_VERIFICATION_DIR / "old-signature.txt"
    old.write_text("old", encoding="utf-8")
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "new-signature.txt")
    monkeypatch.setattr(settings, "tiktok_url_verification_content", "new")

    with TestClient(app):
        assert not old.exists()
        assert (TIKTOK_VERIFICATION_DIR / "new-signature.txt").is_file()
