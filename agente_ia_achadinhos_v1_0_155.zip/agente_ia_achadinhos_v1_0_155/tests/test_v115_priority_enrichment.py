from types import SimpleNamespace

from app.services.product_enrichment import _priority, _source_rank


def product(**kw):
    base = dict(id=1, status="em_analise", notes="", sold_quantity=0, commission_pct=0,
                rating=0, review_count=0, original_price=None, price=10, affiliate_url="",
                external_product_id="MLB1")
    base.update(kw)
    return SimpleNamespace(**base)


def test_preselected_beats_standard_even_with_same_missing_fields():
    a = product(id=10, status="pre_selecionado", notes="posição #7")
    b = product(id=1, status="em_analise")
    assert _priority(a, {}) < _priority(b, {})


def test_best_rank_is_prioritized_between_preselected():
    a = product(id=10, status="pre_selecionado", notes="posição #3")
    b = product(id=1, status="pre_selecionado", notes="posição #18")
    assert _priority(a, {}) < _priority(b, {})
    assert _source_rank(a, {}) == 3
