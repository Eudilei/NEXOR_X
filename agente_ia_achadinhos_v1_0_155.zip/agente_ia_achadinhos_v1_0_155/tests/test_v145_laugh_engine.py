from pathlib import Path
from app.services import production


def test_laugh_profiles_have_real_distinct_narration_voices():
    profiles = {k:v for k,v in production.FREE_TTS_PROFILES.items() if v.get('laugh_after_hook')}
    assert len(profiles) == 12
    voices = [v.get('gemini_voice') for v in profiles.values()]
    assert len(set(voices)) == 12


def test_new_laugh_profile_uses_selected_voice_for_narration_and_proven_voice_for_laugh(tmp_path, monkeypatch):
    calls=[]
    def fake_tts(text, output, voice, style):
        calls.append((text, voice, style))
        Path(output).write_bytes(b'ID3' + b'x'*3000)
        return Path(output)
    def fake_concat(parts, output):
        Path(output).write_bytes(b'ID3' + b'y'*5000)
        return Path(output)
    monkeypatch.setattr(production, 'generate_gemini_tts', fake_tts)
    monkeypatch.setattr(production, '_concat_mp3', fake_concat)
    monkeypatch.setattr(production, '_apply_timbre_fx', lambda p,fx:p)
    profile = dict(production.FREE_TTS_PROFILES['risada_m_sadachbia'])
    out = tmp_path/'x.mp3'
    production._generate_gemini_laugh_after_hook('Gancho aqui! Continuação aqui.', out, profile)
    assert calls[0][1] == 'Sadachbia'
    assert calls[1][1] == 'Puck'
    assert '[laughs]' in calls[1][0]
    assert calls[2][1] == 'Sadachbia'


def test_original_v136_profiles_still_use_original_single_call(tmp_path, monkeypatch):
    calls=[]
    def fake_tts(text, output, voice, style):
        calls.append((text,voice,style))
        Path(output).write_bytes(b'ID3'+b'x'*3000)
        return Path(output)
    monkeypatch.setattr(production, 'generate_gemini_tts', fake_tts)
    profile = dict(production.FREE_TTS_PROFILES['narrador_viral_risada'])
    production._generate_gemini_laugh_after_hook('Gancho! Continua.', tmp_path/'o.mp3', profile)
    assert len(calls) == 1
    assert calls[0][1] == 'Puck'
    assert '[laughs uncontrollably]' in calls[0][0]
