from pathlib import Path

from PIL import Image, ImageDraw

from app.services.production import (
    _foreground_color_signature,
    _select_diverse_product_images,
    parse_media_urls,
)


def _make(path: Path, color: tuple[int, int, int], shape: str = "book") -> Path:
    image = Image.new("RGB", (300, 300), "white")
    draw = ImageDraw.Draw(image)
    if shape == "book":
        draw.rounded_rectangle((80, 35, 220, 265), radius=12, fill=color)
    elif shape == "open":
        draw.polygon([(35, 85), (145, 55), (145, 245), (35, 220)], fill=color)
        draw.polygon([(155, 55), (265, 85), (265, 220), (155, 245)], fill=color)
    else:
        draw.rectangle((40, 120, 260, 180), fill=color)
    image.save(path)
    return path


def test_parse_media_urls_preserves_up_to_twenty_four_variations():
    urls = [f"https://example.com/{index}.jpg" for index in range(30)]
    assert len(parse_media_urls(urls)) == 24


def test_foreground_signature_ignores_white_background(tmp_path):
    pink = _make(tmp_path / "pink.jpg", (235, 120, 160))
    blue = _make(tmp_path / "blue.jpg", (30, 75, 180))
    assert _foreground_color_signature(pink) != _foreground_color_signature(blue)


def test_selector_prioritizes_other_variations_before_similar_images(tmp_path):
    pink_front = _make(tmp_path / "pink_front.jpg", (235, 120, 160), "book")
    pink_detail = _make(tmp_path / "pink_detail.jpg", (235, 120, 160), "detail")
    pink_open = _make(tmp_path / "pink_open.jpg", (235, 120, 160), "open")
    blue_front = _make(tmp_path / "blue_front.jpg", (30, 75, 180), "book")
    blue_open = _make(tmp_path / "blue_open.jpg", (30, 75, 180), "open")

    selected = _select_diverse_product_images(
        [pink_front, pink_detail, pink_open, blue_front, blue_open], 4
    )

    assert pink_front in selected
    assert any(path.name.startswith("blue") for path in selected[:3])
    assert len(set(selected)) == 4


def test_selector_repeats_only_when_distinct_inventory_is_insufficient(tmp_path):
    first = _make(tmp_path / "first.jpg", (235, 120, 160), "book")
    second = _make(tmp_path / "second.jpg", (235, 120, 160), "open")
    selected = _select_diverse_product_images([first, second], 5)
    assert len(selected) == 5
    assert len(set(selected)) == 2
    assert all(a != b for a, b in zip(selected, selected[1:]))
