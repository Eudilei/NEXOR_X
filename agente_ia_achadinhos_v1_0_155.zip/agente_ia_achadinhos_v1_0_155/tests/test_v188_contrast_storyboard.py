from unittest.mock import Mock, patch

from app.services.hybrid_video import create_hybrid_direction


def test_fallback_preserves_error_common_contrast(monkeypatch):
    from app.services import hybrid_video
    monkeypatch.setattr(hybrid_video.settings, "gemini_api_key", None)
    result = create_hybrid_direction(
        product_title="Produto", description="", hook="Erro comum na hora de escolher",
        narration="Esses modelos não são os melhores. O mais adequado é este.",
        on_screen_text="", media_urls=["a", "b", "c", "d"], duration_seconds=40,
    )
    assert result.scene_plan[0]["role"] == "contrast"
    assert result.scene_plan[1]["role"] == "recommended_product"


def test_gemini_cannot_put_contrast_after_recommended(monkeypatch):
    from app.services import hybrid_video
    monkeypatch.setattr(hybrid_video.settings, "gemini_api_key", "test")
    monkeypatch.setattr(hybrid_video, "_download_image_parts", lambda urls: ([{"inline_data": {"mime_type": "image/jpeg", "data": "x"}} for _ in urls], list(range(len(urls)))))
    response = Mock()
    response.raise_for_status.return_value = None
    response.json.return_value = {"candidates": [{"content": {"parts": [{"text": '{"image_order":[1,2,3,4],"hook":"Erro comum","narration":"Evite os primeiros. O mais adequado é este.","on_screen_text":[],"scene_plan":[{"image_position":1,"objective":"erro","role":"contrast"},{"image_position":2,"objective":"produto recomendado","role":"recommended_product"},{"image_position":3,"objective":"outro erro","role":"contrast"},{"image_position":4,"objective":"detalhe","role":"detail"}]}' }]}}]}
    client = Mock(); client.__enter__ = Mock(return_value=client); client.__exit__ = Mock(return_value=False); client.post.return_value = response
    with patch("app.services.hybrid_video.httpx.Client", return_value=client):
        result = create_hybrid_direction(product_title="Produto", description="", hook="Erro comum", narration="Evite esses modelos. O mais adequado é este.", on_screen_text="", media_urls=["a","b","c","d"], duration_seconds=40)
    roles = [x["role"] for x in result.scene_plan]
    assert roles[:2] == ["contrast", "recommended_product"]
    assert "contrast" not in roles[2:]
