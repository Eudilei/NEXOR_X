from app.models.schemas import ProductInput, ProductCategory, ScriptRequest
from app.services.scripts import generate_script


def product():
    return ProductInput(title="Kit Aparador Completo", category=ProductCategory.CUIDADOS_PESSOAIS, price=99.9, rating=4.8, review_count=1000, sold_quantity=50000, affiliate_url="https://example.com/p")

def test_automatic_variations_are_structurally_different():
    outputs = [generate_script(ScriptRequest(product=product(), format="automatico", variation_index=i)) for i in range(3)]
    assert len({o.hook for o in outputs}) == 3
    assert len({o.narration for o in outputs}) == 3

def test_presenter_profile_is_reflected_in_script_metadata():
    out = generate_script(ScriptRequest(product=product(), presenter_age="jovem", presenter_energy="engracada", presenter_style="creator"))
    assert any("engracada" in line and "jovem" in line for line in out.on_screen_text)
