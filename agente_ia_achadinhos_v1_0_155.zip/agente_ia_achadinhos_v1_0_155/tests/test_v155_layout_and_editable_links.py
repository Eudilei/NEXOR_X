from pathlib import Path

def test_cache_bust_and_navigation_layout():
    base = Path("app/templates/base.html").read_text(encoding="utf-8")
    css = Path("app/static/app.css").read_text(encoding="utf-8")
    assert "/static/app.css?v=1.0.155" in base
    assert "grid-template-columns:repeat(5,minmax(0,1fr))!important" in css

def test_card_actions_are_stacked_and_static():
    css = Path("app/static/app.css").read_text(encoding="utf-8")
    assert "flex-direction:column!important" in css
    assert ".product-delete-form{" in css
    assert "position:static!important" in css

def test_product_links_are_editable_and_clearable():
    tpl = Path("app/templates/products/complete.html").read_text(encoding="utf-8")
    main = Path("app/main.py").read_text(encoding="utf-8")
    assert 'name="listing_url"' in tpl
    assert 'name="affiliate_url"' in tpl
    original = tpl.split("Link original do produto",1)[1].split("</label>",1)[0]
    affiliate = tpl.split("Link de afiliado",1)[1].split("</label>",1)[0]
    assert "readonly" not in original
    assert "readonly" not in affiliate
    assert 'listing_url: str = Form("")' in main
    assert 'affiliate_url: str = Form("")' in main
    assert 'product.affiliate_url = submitted_affiliate' in main
    assert 'meta["listing_url"] = submitted_listing' in main

def test_manual_link_edits_survive_discovery():
    auto = Path("app/services/autonomous.py").read_text(encoding="utf-8")
    assert "manual_listing_url_override" in auto
    assert "manual_affiliate_url_override" in auto
