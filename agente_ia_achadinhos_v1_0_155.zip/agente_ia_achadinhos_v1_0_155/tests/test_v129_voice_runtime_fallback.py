from pathlib import Path
from unittest.mock import patch

from app.services.production import FREE_TTS_PROFILES, generate_profile_speech, choose_free_voice_profile


def test_rich_profiles_keep_unique_gemini_timbres_but_are_resilient_auto_provider():
    rich=[p for p in FREE_TTS_PROFILES.values() if p.get('provider')=='auto']
    voices=[p.get('gemini_voice') for p in rich]
    assert len(rich) >= 20
    assert all(voices)
    assert len(voices)==len(set(voices))


def test_without_gemini_special_profile_uses_runtime_edge_instead_of_failing(tmp_path):
    profile=choose_free_voice_profile('narrador_viral_br','masculino','humor_viral',1)
    fake_settings=type('S',(),{'gemini_api_key':''})()
    target=tmp_path/'x.mp3'
    def fake_speech(text, output, voice, rate='+0%', pitch='+0Hz'):
        output.write_bytes(b'x'*2048)
        return output
    with patch('app.services.production.settings', fake_settings), \
         patch('app.services.production._runtime_edge_voice', return_value='pt-BR-NicolauNeural'), \
         patch('app.services.production.generate_free_speech', side_effect=fake_speech):
        out, provider=generate_profile_speech('teste', target, profile)
    assert out.exists()
    assert provider=='edge_tts_runtime'
    assert profile['_runtime_engine']=='pt-BR-NicolauNeural'


def test_preview_header_reports_runtime_engine():
    src=Path('app/main.py').read_text(encoding='utf-8')
    assert 'profile.get("_runtime_engine")' in src


def test_current_release_marker_is_129():
    releases=sorted(p.name for p in Path('.').glob('RELEASE_v1.0.*.txt'))
    assert releases==['RELEASE_v1.0.130.txt']
