from fastapi.testclient import TestClient
from app.main import app


def test_current_tiktok_verification_urls():
    client = TestClient(app)
    cases = {
        '/termos/tiktokJQz98WyODAiMd8f8amEcvdcilL5JDScP.txt': 'tiktok-developers-site-verification=JQz98WyODAiMd8f8amEcvdcilL5JDScP\n',
        '/privacidade/tiktokcW0wljDqyHw9qVE9FP8iLzSmegp0xq8c.txt': 'tiktok-developers-site-verification=cW0wljDqyHw9qVE9FP8iLzSmegp0xq8c\n',
        '/tiktokIpPyrWx7yFvNU8TwOPA48mxqauCSxRZL.txt': 'tiktok-developers-site-verification=IpPyrWx7yFvNU8TwOPA48mxqauCSxRZL\n',
    }
    for url, expected in cases.items():
        response = client.get(url)
        assert response.status_code == 200
        assert response.text == expected
        assert response.headers['content-type'].startswith('text/plain')
        assert client.head(url).status_code == 200
