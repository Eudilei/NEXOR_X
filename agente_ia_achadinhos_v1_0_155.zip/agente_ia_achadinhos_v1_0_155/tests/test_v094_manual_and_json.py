from pathlib import Path


def test_manual_mode_is_real_anchor_without_javascript_dependency():
    html = Path('app/templates/products/form.html').read_text()
    assert 'id="manual-mode" href="#manual-fields"' in html
    assert 'id="manual-fields"' in html


def test_analyze_endpoint_always_uses_jsonresponse():
    source = Path('app/main.py').read_text()
    block = source.split('@app.post("/products/analyze-link")', 1)[1].split('@app.post("/products/new")', 1)[0]
    assert 'return JSONResponse' in block
    assert 'client.product_detail(product_id)' in block
    assert 'public_product_snapshot(link)' in block


def test_no_fake_commercial_defaults_in_analyze_payload():
    source = Path('app/main.py').read_text()
    block = source.split('@app.post("/products/analyze-link")', 1)[1].split('@app.post("/products/new")', 1)[0]
    assert '"seller_reputation": 0' in block
    assert '"commission_pct": 0' in block
    assert 'price=price if price >= 1 else 0.01' not in block
