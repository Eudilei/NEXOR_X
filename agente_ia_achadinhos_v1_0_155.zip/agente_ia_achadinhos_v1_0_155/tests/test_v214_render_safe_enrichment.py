from pathlib import Path

from app.core.config import settings


def test_render_safe_defaults_do_not_require_chromium():
    assert settings.mercado_livre_browser_fallback_enabled is False
    assert settings.mercado_livre_browser_timeout_seconds <= 7
    assert settings.mercado_livre_browser_max_products_per_scan <= 2


def test_enrichment_is_delayed_and_batched():
    assert settings.product_enrichment_initial_delay_seconds >= 300
    assert settings.product_enrichment_batch_size <= 3
    assert settings.product_enrichment_interval_seconds >= 3600


def test_dashboard_shows_v114():
    text = Path('app/templates/dashboard.html').read_text(encoding='utf-8')
    assert 'v1.0.114' in text
    assert 'enriquecimento resiliente' in text
