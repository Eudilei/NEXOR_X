from app.services.production import normalize_spoken_text_ptbr, resolve_free_voice_profile, _commercial_scene_texts


def test_commercial_abbreviations_are_spoken_naturally():
    text = normalize_spoken_text_ptbr('Kit c/3 toalhas 70 x 1,40')
    assert 'com 3' in text
    assert '70 por 1,40' in text
    assert 'c/3' not in text


def test_funny_voice_profiles_are_distinct():
    funny = resolve_free_voice_profile('masculina_engracada', 'masculino')
    dry = resolve_free_voice_profile('humor_seco', 'masculino')
    assert funny['rate'] != dry['rate']
    assert funny['name'] == 'masculina_engracada'


def test_scene_text_removes_timing_and_direction_metadata():
    texts = _commercial_scene_texts('Kit c/3 toalhas 70 x 1,40', '0–2s · GANCHO FORTE\nDIREÇÃO · creator\n2–6s · KIT COM 3', 'Olha isso', 'Confira no link')
    assert any('GANCHO FORTE' in item for item in texts)
    assert not any(item.startswith('0–2s') for item in texts)
    assert not any(item.startswith('DIREÇÃO') for item in texts)
