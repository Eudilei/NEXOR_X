from pathlib import Path


def test_product_detail_passes_source_meta_to_template():
    source = Path("app/main.py").read_text(encoding="utf-8")
    start = source.index('def product_detail(product_id: int')
    end = source.index('@app.post("/products/{product_id}/status")', start)
    block = source[start:end]
    assert "meta = source_metadata(product)" in block
    assert "source_meta=meta" in block


def test_product_detail_template_has_safe_source_meta_default():
    template = Path("app/templates/products/detail.html").read_text(encoding="utf-8")
    assert "{% set source_meta = source_meta|default({}, true) %}" in template
