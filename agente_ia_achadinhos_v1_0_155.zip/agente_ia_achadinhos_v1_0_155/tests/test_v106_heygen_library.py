from pathlib import Path

from app.db.models import Script
from app.services import heygen


def test_script_has_heygen_selection_fields():
    assert hasattr(Script, "heygen_avatar_id")
    assert hasattr(Script, "heygen_voice_id")


def test_form_contains_heygen_library_controls():
    text = Path("app/templates/scripts/form.html").read_text()
    assert 'name="heygen_avatar_id"' in text
    assert 'name="heygen_voice_id"' in text
    assert "Biblioteca HeyGen" in text


def test_create_video_requires_explicit_selection():
    try:
        heygen.create_avatar_video(title="x", script="x", avatar_id="", voice_id="", energy="alegre", style="creator", duration=20)
    except heygen.HeyGenError as exc:
        assert "Escolha um apresentador" in str(exc)
    else:
        raise AssertionError("deveria bloquear IDs vazios")
