from pathlib import Path


def test_visual_writer_similarity_is_selection_not_false_failure():
    source = Path('app/main.py').read_text(encoding='utf-8')
    assert 'x.product_id != product.id' in source
    assert 'best_output = output' in source
    assert 'best_score = 1.0' in source
    assert '>= 0.82' in source
    assert 'Este roteiro ficou parecido demais com roteiros recentes de outros produtos' not in source


def test_laugh_is_generated_as_own_audio_segment():
    source = Path('app/services/production.py').read_text(encoding='utf-8')
    assert '_laugh").with_suffix(".mp3")' in source
    assert 'laugh_text = "HÁ! HÁHAHAHAHA! AHAHAHA... HÁ!"' in source
    assert 'explosão de risada não verbal' in source
    assert 'parts = [hook_file, laugh_file]' in source
    assert 'gemini_tts_distinct_hook_laugh' in source
