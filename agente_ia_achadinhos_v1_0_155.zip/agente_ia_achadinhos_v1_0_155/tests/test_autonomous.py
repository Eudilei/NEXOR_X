from app.services.autonomous import candidate_to_product_input
from app.services.marketplace import Candidate
from app.services.scoring import score_product


def test_candidate_can_be_commercially_approved_without_media():
    candidate = Candidate(
        external_id="MLB1", title="Organizador de gavetas ajustável", category="organizacao",
        price=49.9, original_price=69.9, rating=4.8, review_count=500,
        sold_quantity=3000, seller_reputation=98, stock_available=True,
        listing_url="https://produto.mercadolivre.com.br/MLB1", thumbnail="", trend_keyword="organizador",
    )
    data = candidate_to_product_input(candidate)
    result = score_product(data)
    assert result.approved is True
    assert any("aguardando mídia" in reason.lower() for reason in result.reasons)


def _make_candidate(*, external_id: str, offer: bool, score_source_rank: int = 1, catalog_id: str = "MLBP1"):
    return Candidate(
        external_id=external_id,
        title="Organizador de cozinha premium",
        category="organizacao",
        price=59.9 if offer else 0.0,
        original_price=79.9 if offer else None,
        rating=4.9 if offer else 0,
        review_count=500 if offer else 0,
        sold_quantity=2500 if offer else 0,
        seller_reputation=98 if offer else 80,
        stock_available=True,
        listing_url=(f"https://produto.mercadolivre.com.br/{external_id}" if offer else f"https://www.mercadolivre.com.br/p/{catalog_id}"),
        thumbnail="https://http2.mlstatic.com/test.jpg",
        trend_keyword="organizador de cozinha",
        source="mercado_livre_catalogo_tendencias" if offer else "mercado_livre_catalogo_aguardando_oferta",
        source_rank=score_source_rank,
        offer_available=offer,
        catalog_product_id=catalog_id,
    )


def test_discovery_prioritizes_real_offer_before_provisional(monkeypatch):
    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session
    from app.db.database import Base
    from app.db.models import Product
    import app.services.autonomous as autonomous

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)

    class FakeClient:
        configured = True
        warnings = []
        infos = []
        sources_used = ["catalogo_por_tendencias"]
        discovery_stats = {"terms": 1, "catalog_products": 2, "with_offer": 1, "awaiting_offer": 1}
        def __init__(self, db=None): pass
        def discover(self, limit_per_query=8):
            return [_make_candidate(external_id="MLBP1", offer=False), _make_candidate(external_id="MLBITEM1", offer=True)]

    monkeypatch.setattr(autonomous, "MercadoLivreClient", FakeClient)
    result = autonomous.run_discovery(db, max_products=1)
    products = db.scalars(select(Product)).all()
    assert result["saved"] == 1
    assert len(products) == 1
    assert products[0].status == "aprovado_comercial"
    assert products[0].affiliate_url == ""
    import json
    assert "MLBITEM1" in json.loads(products[0].source_metadata_json)["listing_url"]


def test_discovery_upgrades_provisional_record_to_real_offer(monkeypatch):
    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session
    from app.db.database import Base
    from app.db.models import Product
    import app.services.autonomous as autonomous

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)
    provisional = Product(
        title="Organizador de cozinha premium", category="organizacao", marketplace="mercado_livre",
        price=0.01, affiliate_url="https://www.mercadolivre.com.br/p/MLBP1",
        status="aguardando_oferta", score=52, notes="catalog_product_id=MLBP1.",
    )
    db.add(provisional); db.commit()

    class FakeClient:
        configured = True
        warnings = []
        infos = []
        sources_used = ["catalogo_por_tendencias"]
        discovery_stats = {"terms": 1, "catalog_products": 1, "with_offer": 1, "awaiting_offer": 0}
        def __init__(self, db=None): pass
        def discover(self, limit_per_query=8): return [_make_candidate(external_id="MLBITEM1", offer=True)]

    monkeypatch.setattr(autonomous, "MercadoLivreClient", FakeClient)
    result = autonomous.run_discovery(db, max_products=25)
    products = db.scalars(select(Product)).all()
    assert result["saved"] == 1
    assert result["updated"] == 0
    assert len(products) == 1
    assert products[0].status == "aprovado_comercial"
    assert products[0].affiliate_url == ""
    import json
    assert "MLBITEM1" in json.loads(products[0].source_metadata_json)["listing_url"]


def test_discovery_removes_legacy_fake_price_and_rejects_unproven_demand(monkeypatch):
    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session
    from app.db.database import Base
    from app.db.models import Product
    import app.services.autonomous as autonomous

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)
    db.add(Product(
        title="Provisório", category="casa", marketplace="mercado_livre", price=0.01,
        affiliate_url="https://www.mercadolivre.com.br/p/MLBOLD", status="aguardando_oferta",
        score=56, notes="legado",
    ))
    db.commit()

    weak = _make_candidate(external_id="MLBWEAK", offer=True, score_source_rank=99, catalog_id="MLBPW")
    weak.source = "mercado_livre_catalogo_tendencias"
    weak.sold_quantity = 0
    weak.review_count = 0

    class FakeClient:
        configured = True
        warnings = []
        infos = []
        sources_used = []
        discovery_stats = {}
        def __init__(self, db=None): pass
        def discover(self, limit_per_query=8): return [weak]

    monkeypatch.setattr(autonomous, "MercadoLivreClient", FakeClient)
    result = autonomous.run_discovery(db)
    assert result["saved"] == 0
    assert result["stats"]["removed_invalid"] == 1
    assert result["stats"]["rejected_few_reviews"] == 1
    assert db.scalars(select(Product)).all() == []


def test_discovery_accepts_rating_4_without_sales_minimum(monkeypatch):
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session
    from app.db.database import Base
    import app.services.autonomous as autonomous

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)
    candidate = _make_candidate(external_id="MLBRATING", offer=True)
    candidate.rating = 4.0
    candidate.review_count = 5000

    class FakeClient:
        configured = True
        warnings = []
        infos = []
        sources_used = ["mais_vendidos"]
        discovery_stats = {}
        def __init__(self, db=None): pass
        def discover(self, limit_per_query=8): return [candidate]

    monkeypatch.setattr(autonomous, "MercadoLivreClient", FakeClient)
    result = autonomous.run_discovery(db)
    assert result["saved"] == 1
    assert result["stats"]["rejected_low_rating"] == 0


def test_discovery_accepts_ranked_product_without_discount(monkeypatch):
    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session
    from app.db.database import Base
    from app.db.models import Product
    import app.services.autonomous as autonomous

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)
    candidate = _make_candidate(external_id="MLBRANKED", offer=True, score_source_rank=8)
    candidate.source = "mercado_livre_highlights"
    candidate.original_price = None
    candidate.rating = 4.6
    candidate.review_count = 800
    candidate.sold_quantity = 0

    class FakeClient:
        configured = True
        warnings = []
        infos = []
        sources_used = ["mais_vendidos"]
        discovery_stats = {}
        def __init__(self, db=None): pass
        def discover(self, limit_per_query=8): return [candidate]

    monkeypatch.setattr(autonomous, "MercadoLivreClient", FakeClient)
    result = autonomous.run_discovery(db)
    products = db.scalars(select(Product)).all()
    assert result["saved"] == 1
    assert len(products) == 1
    assert "posição #8" in products[0].score_reasons


def test_discovery_qualifies_ranked_offer_when_optional_metrics_are_blocked(monkeypatch):
    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session
    from app.db.database import Base
    from app.db.models import Product
    import app.services.autonomous as autonomous

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)
    candidate = _make_candidate(external_id="MLBPARTIAL", offer=True, score_source_rank=3)
    candidate.rating = 0
    candidate.review_count = 0
    candidate.picture_urls = ("https://example.test/photo.jpg",)

    class FakeClient:
        configured = True
        warnings = ["O Mercado Livre restringiu uma consulta detalhada; o agente usou fontes públicas alternativas."]
        infos = []
        sources_used = ["mais_vendidos"]
        discovery_stats = {}
        def __init__(self, db=None): pass
        def discover(self, limit_per_query=8): return [candidate]

    monkeypatch.setattr(autonomous, "MercadoLivreClient", FakeClient)
    result = autonomous.run_discovery(db)
    products = db.scalars(select(Product)).all()
    assert result["saved"] == 1
    assert result["stats"]["qualified_metrics_pending"] == 1
    assert products[0].classification == "Qualificado — métricas em atualização"

