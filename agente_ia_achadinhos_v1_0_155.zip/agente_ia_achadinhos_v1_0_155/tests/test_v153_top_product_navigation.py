
from pathlib import Path

def test_top_navigation_has_separate_complete_and_incomplete_products():
    html = Path("app/templates/base.html").read_text(encoding="utf-8")
    assert '<a href="/products/incompletos">Produtos incompletos</a>' in html
    assert '<a href="/products/completos">Produtos completos</a>' in html
    assert '<a href="/products">Produtos</a>' not in html
