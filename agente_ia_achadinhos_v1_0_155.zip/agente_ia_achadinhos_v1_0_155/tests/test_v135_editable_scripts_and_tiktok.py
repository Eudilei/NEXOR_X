from pathlib import Path
from app.services.scripts import sanitize_script_language, script_language_issues, _cta_destination
from app.services.production import _cta_text


def test_meta_language_is_removed_or_blocked():
    cleaned = sanitize_script_language('Nas fotos dá para conferir os detalhes reais mostrados nas fotos.')
    assert 'nas fotos' not in cleaned.lower()
    assert 'detalhes reais' not in cleaned.lower()
    assert script_language_issues('Pelas imagens dá para conferir o produto.')


def test_instagram_tiktok_cta_is_bio_only():
    assert _cta_destination() == 'link da bio'
    assert _cta_text('Confira o link da descrição ou da bio') == 'Link na bio'


def test_script_editor_exists_before_approval():
    template = Path('app/templates/scripts/detail.html').read_text(encoding='utf-8')
    main = Path('app/main.py').read_text(encoding='utf-8')
    assert 'Editar roteiro antes de aprovar' in template
    assert 'action="/scripts/{{ script.id }}/edit"' in template
    assert '@app.post("/scripts/{script_id}/edit")' in main
    assert 'Salvar alterações' in template
