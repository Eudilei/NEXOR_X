from fastapi.testclient import TestClient
from app.main import app, settings, _materialize_tiktok_verification_files


def test_legacy_verification_does_not_hide_current_files(monkeypatch):
    monkeypatch.setattr(settings, 'tiktok_url_verification_filename', 'tiktok-old.txt')
    monkeypatch.setattr(settings, 'tiktok_url_verification_content', 'tiktok-developers-site-verification=old')
    _materialize_tiktok_verification_files()
    client = TestClient(app)
    current = {
        '/termos/tiktokJQz98WyODAiMd8f8amEcvdcilL5JDScP.txt': 'JQz98WyODAiMd8f8amEcvdcilL5JDScP',
        '/privacidade/tiktokcW0wljDqyHw9qVE9FP8iLzSmegp0xq8c.txt': 'cW0wljDqyHw9qVE9FP8iLzSmegp0xq8c',
        '/tiktokIpPyrWx7yFvNU8TwOPA48mxqauCSxRZL.txt': 'IpPyrWx7yFvNU8TwOPA48mxqauCSxRZL',
    }
    for url, token in current.items():
        r = client.get(url)
        assert r.status_code == 200
        assert token in r.text
    assert client.get('/termos/tiktok-old.txt').status_code == 200
