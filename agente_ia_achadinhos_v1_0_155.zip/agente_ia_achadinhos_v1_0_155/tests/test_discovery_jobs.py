from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from app.db.database import Base
from app.services.discovery_jobs import active_job, claim_next_job, start_job


def test_start_job_only_enqueues_and_returns_immediately():
    engine=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False})
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        job, created=start_job(db)
        assert created is True
        assert job.status == 'queued'
        assert active_job(db).id == job.id


def test_worker_claims_one_job_and_prevents_duplicate():
    engine=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False})
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        first, created=start_job(db)
        second, created_second=start_job(db)
        assert created is True and created_second is False and second.id == first.id
        claimed=claim_next_job(db)
        assert claimed.id == first.id and claimed.status == 'running'
        assert claim_next_job(db) is None
