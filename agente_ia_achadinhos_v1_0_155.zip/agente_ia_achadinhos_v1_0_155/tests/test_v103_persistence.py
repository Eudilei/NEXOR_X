from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import MediaAsset, Product, Production, Script
from app.services.media_store import media_url, persist_file


def test_video_is_persisted_as_database_asset(tmp_path: Path):
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    video = tmp_path / "video.mp4"
    video.write_bytes(b"fake-mp4-data")

    with Session(engine) as db:
        product = Product(
            title="Produto",
            category="cuidados_pessoais",
            price=10,
            affiliate_url="https://example.com",
        )
        db.add(product)
        db.flush()
        script = Script(
            product_id=product.id,
            hook="Gancho",
            narration="Narração",
            on_screen_text="Texto",
            caption="Legenda",
            call_to_action="Confira",
            hashtags="#teste",
        )
        db.add(script)
        db.flush()
        production = Production(script_id=script.id)
        db.add(production)
        db.flush()

        asset = persist_file(
            db,
            production_id=production.id,
            path=video,
            content_type="video/mp4",
        )
        db.commit()

        stored = db.get(MediaAsset, asset.id)
        assert stored is not None
        assert stored.data == b"fake-mp4-data"
        assert stored.size_bytes == len(b"fake-mp4-data")
        assert media_url(stored.id).endswith(f"/media/assets/{stored.id}")


def test_replacing_same_asset_name_does_not_duplicate(tmp_path: Path):
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    video = tmp_path / "video.mp4"

    with Session(engine) as db:
        product = Product(title="Produto", category="casa", price=10, affiliate_url="https://example.com")
        db.add(product); db.flush()
        script = Script(product_id=product.id, hook="h", narration="n", on_screen_text="t", caption="c", call_to_action="a", hashtags="#x")
        db.add(script); db.flush()
        production = Production(script_id=script.id)
        db.add(production); db.flush()

        video.write_bytes(b"one")
        persist_file(db, production_id=production.id, path=video, content_type="video/mp4")
        video.write_bytes(b"two")
        persist_file(db, production_id=production.id, path=video, content_type="video/mp4")
        db.commit()

        assets = db.query(MediaAsset).filter_by(production_id=production.id, name="video.mp4").all()
        assert len(assets) == 1
        assert assets[0].data == b"two"
