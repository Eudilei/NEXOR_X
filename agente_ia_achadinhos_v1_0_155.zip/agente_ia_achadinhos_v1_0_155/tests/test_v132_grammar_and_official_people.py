from app.models.schemas import ProductCategory, ProductInput, ScriptRequest
from app.services.scripts import generate_script, _grammar_safety_pass, _product_profile
from app.services.production import _commercial_scene_texts


def _mask_product():
    return ProductInput(
        title="Máscara de Reconstrução Profunda para Cabelos Danificados com Proteína do Trigo 500g",
        category=ProductCategory.BELEZA,
        price=79.90,
        rating=4.9,
        review_count=23650,
        sold_quantity=120000,
        affiliate_url="https://produto.mercadolivre.com.br/teste",
    )


def test_feminine_product_never_uses_masculine_article():
    out = generate_script(ScriptRequest(product=_mask_product(), variation_index=0))
    text = f"{out.hook} {out.narration}".casefold()
    assert "este é o máscara" not in text
    assert "este mascara" not in text
    assert "esta máscara" in text or "máscara de reconstrução" in text


def test_grammar_safety_pass_repairs_known_agreement_errors():
    profile = _product_profile("Máscara capilar 500g")
    fixed = _grammar_safety_pass("Este é o máscara. Uma produto com duas unidade.", profile)
    assert "esta máscara" in fixed.casefold()
    assert "um produto" in fixed
    assert "duas unidades" in fixed


def test_official_person_image_is_not_removed_by_text_planner():
    # O planejador recebe apenas textos. Ele deve filtrar endosso não confirmado,
    # mas não cria qualquer regra para excluir a imagem oficial que contém pessoa.
    texts = _commercial_scene_texts(
        "Máscara capilar 500g",
        "2–6s · PROFISSIONAL RECOMENDA ESTE PRODUTO\n6–10s · COM PROTEÍNA DO TRIGO",
        "Seu cabelo pediu socorro?",
        "Confira os detalhes no link da bio.",
    )
    joined = " | ".join(texts).upper()
    assert "PROFISSIONAL RECOMENDA" not in joined
    assert "COM PROTEÍNA DO TRIGO" in joined


def test_generic_scene_fallback_is_not_reused():
    texts = _commercial_scene_texts(
        "Máscara capilar 500g",
        "6–10s · CONFIRA AS CARACTERÍSTICAS DO ANÚNCIO",
        "Seu cabelo pediu socorro?",
        "Confira os detalhes no link da bio.",
    )
    assert all("CONFIRA AS CARACTERÍSTICAS DO ANÚNCIO" not in t.upper() for t in texts)
