from fastapi.testclient import TestClient

from app.main import app, TIKTOK_VERIFICATION_DIR
from app.core.config import settings


def test_terms_and_privacy_alias_pages_are_public(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_content", None)
    with TestClient(app) as client:
        assert client.get("/termos").status_code == 200
        assert client.get("/privacidade").status_code == 200


def test_tiktok_terms_and_privacy_have_independent_signatures(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_content", None)
    monkeypatch.setattr(settings, "tiktok_terms_verification_filename", "terms-proof.txt")
    monkeypatch.setattr(settings, "tiktok_terms_verification_content", "tiktok-developers-site-verification=terms")
    monkeypatch.setattr(settings, "tiktok_privacy_verification_filename", "privacy-proof.txt")
    monkeypatch.setattr(settings, "tiktok_privacy_verification_content", "tiktok-developers-site-verification=privacy")

    with TestClient(app) as client:
        terms = client.get("/termos/terms-proof.txt")
        privacy = client.get("/privacidade/privacy-proof.txt")
        assert terms.status_code == 200
        assert privacy.status_code == 200
        assert terms.text == "tiktok-developers-site-verification=terms\n"
        assert privacy.text == "tiktok-developers-site-verification=privacy\n"
        assert (TIKTOK_VERIFICATION_DIR / "terms-proof.txt").is_file()
        assert (TIKTOK_VERIFICATION_DIR / "privacy-proof.txt").is_file()


def test_signature_filename_cannot_be_used_on_unconfigured_file(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_content", None)
    with TestClient(app) as client:
        assert client.get("/termos/not-configured.txt").status_code == 404
