from pathlib import Path

from app.db.models import Production, Publication, SocialConnection
from app.services.production import create_title_card


def test_production_models_exist():
    assert Production.__tablename__ == "productions"
    assert Publication.__tablename__ == "publications"
    assert SocialConnection.__tablename__ == "social_connections"


def test_title_card_is_generated(tmp_path: Path):
    target = tmp_path / "card.jpg"
    create_title_card("Produto de teste", "Gancho de teste", target)
    assert target.exists()
    assert target.stat().st_size > 1000


def test_render_slideshow_with_audio_orders_ffmpeg_inputs_correctly(tmp_path: Path, monkeypatch):
    from PIL import Image
    from app.services import production as service

    frame = tmp_path / "frame.jpg"
    Image.new("RGB", (100, 180), "white").save(frame)
    audio = tmp_path / "narration.mp3"
    audio.write_bytes(b"fake-audio")
    output = tmp_path / "video.mp4"
    captured = {}

    class Result:
        returncode = 0
        stderr = ""

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        output.write_bytes(b"fake-video")
        return Result()

    monkeypatch.setattr(service.imageio_ffmpeg, "get_ffmpeg_exe", lambda: "ffmpeg")
    monkeypatch.setattr(service.subprocess, "run", fake_run)

    service.render_slideshow([frame], 20, output, audio)

    cmd = captured["cmd"]
    audio_input_index = cmd.index(str(audio))
    video_filter_index = cmd.index("-vf")
    assert audio_input_index < video_filter_index
    assert output.exists()


def test_render_uses_low_memory_ffmpeg_options(tmp_path: Path, monkeypatch):
    from PIL import Image
    from app.services import production as service

    monkeypatch.setattr(service.settings, "storage_dir", str(tmp_path / "storage"))
    frame = tmp_path / "frame.jpg"
    Image.new("RGB", (100, 180), "white").save(frame)
    output = tmp_path / "video.mp4"
    captured = {}

    class Result:
        returncode = 0
        stderr = ""

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        output.write_bytes(b"fake-video")
        return Result()

    monkeypatch.setattr(service.imageio_ffmpeg, "get_ffmpeg_exe", lambda: "ffmpeg")
    monkeypatch.setattr(service.subprocess, "run", fake_run)

    service.render_slideshow([frame], 20, output)
    cmd = captured["cmd"]
    assert "-threads" in cmd and cmd[cmd.index("-threads") + 1] == "1"
    assert "-preset" in cmd and cmd[cmd.index("-preset") + 1] == "ultrafast"
    assert "fps=25,format=yuv420p" in cmd
    assert service.VIDEO_SIZE == (720, 1280)


def test_generate_assets_reuses_existing_ai_files(tmp_path: Path, monkeypatch):
    from app.services import production as service

    monkeypatch.setattr(service.settings, "storage_dir", str(tmp_path / "storage"))
    monkeypatch.setattr(service.settings, "public_base_url", "https://example.test")
    monkeypatch.setattr(service.settings, "openai_api_key", "test")
    monkeypatch.setattr(service.settings, "enable_ai_voice", True)

    folder = tmp_path / "storage" / "productions" / "7"
    folder.mkdir(parents=True)
    for index in range(1, 4):
        (folder / f"ai_scene_{index}.png").write_bytes(b"existing")
    (folder / "narration.mp3").write_bytes(b"existing-audio")

    calls = {"image": 0, "speech": 0}
    monkeypatch.setattr(service, "generate_ai_image", lambda *a, **k: calls.__setitem__("image", calls["image"] + 1))
    monkeypatch.setattr(service, "generate_ai_speech", lambda *a, **k: calls.__setitem__("speech", calls["speech"] + 1))

    def fake_render(images, duration, output, audio=None):
        output.write_bytes(b"video")
        return output

    monkeypatch.setattr(service, "render_slideshow", fake_render)
    import pytest
    with pytest.raises(ValueError, match="duas fotos originais"):
        service.generate_production_assets(7, "Produto", "Gancho", "Narracao", 20)
    assert calls == {"image": 0, "speech": 0}
