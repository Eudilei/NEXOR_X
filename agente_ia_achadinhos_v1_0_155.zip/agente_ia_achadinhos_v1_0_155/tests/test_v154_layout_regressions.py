from pathlib import Path


def test_topbar_has_wrapping_rules_and_compact_navigation():
    css = Path("app/static/app.css").read_text(encoding="utf-8")
    assert "/* v1.0.154" in css
    assert "flex-wrap:wrap" in css
    assert "grid-column:1/-1" in css


def test_product_delete_action_is_no_longer_absolute_in_actions():
    css = Path("app/static/app.css").read_text(encoding="utf-8")
    assert ".product-card-actions .product-delete-form" in css
    assert "position:static" in css


def test_separate_product_navigation_is_preserved():
    html = Path("app/templates/base.html").read_text(encoding="utf-8")
    assert '/products/incompletos">Produtos incompletos' in html
    assert '/products/completos">Produtos completos' in html
