import json
from unittest.mock import Mock, patch

from app.services.hybrid_video import create_hybrid_direction


def test_hybrid_falls_back_without_key(monkeypatch):
    from app.services import hybrid_video
    monkeypatch.setattr(hybrid_video.settings, "gemini_api_key", None)
    result = create_hybrid_direction(
        product_title="Produto", description="Descrição", hook="Gancho", narration="Narração",
        on_screen_text="Linha", media_urls=["https://example.com/1.jpg", "https://example.com/2.jpg"], duration_seconds=40,
    )
    assert result.fallback_used is True
    assert result.image_order == [0, 1]
    assert result.hook == "Gancho"


def test_hybrid_reorders_and_validates(monkeypatch):
    from app.services import hybrid_video
    monkeypatch.setattr(hybrid_video.settings, "gemini_api_key", "test")
    monkeypatch.setattr(hybrid_video, "_download_image_parts", lambda urls: ([{"inline_data": {"mime_type": "image/jpeg", "data": "x"}} for _ in urls], list(range(len(urls)))))
    response = Mock()
    response.raise_for_status.return_value = None
    response.json.return_value = {"candidates": [{"content": {"parts": [{"text": json.dumps({
        "image_order": [2, 1], "hook": "Novo gancho", "narration": "Nova narração", "on_screen_text": ["Um", "Dois"]
    })}]}}]}
    client = Mock()
    client.__enter__ = Mock(return_value=client)
    client.__exit__ = Mock(return_value=False)
    client.post.return_value = response
    with patch("app.services.hybrid_video.httpx.Client", return_value=client):
        result = create_hybrid_direction(
            product_title="Produto", description="Descrição", hook="Gancho", narration="Narração",
            on_screen_text="Linha", media_urls=["https://example.com/1.jpg", "https://example.com/2.jpg"], duration_seconds=40,
        )
    assert result.fallback_used is False
    assert result.image_order == [1, 0]
    assert result.hook == "Novo gancho"
    assert result.on_screen_text == "Um\nDois"
