import json
from types import SimpleNamespace

from app.services.autonomous import _apply_candidate_content, _confirmed_affiliate_url
from app.services.marketplace import Candidate


def _product():
    return SimpleNamespace(
        affiliate_url="https://meli.la/abc",
        source_metadata_json=json.dumps({"affiliate_link_confirmed": True}),
        original_description="", media_urls="", external_product_id="",
    )

def test_discovery_preserves_confirmed_affiliate_link():
    assert _confirmed_affiliate_url(_product()) == "https://meli.la/abc"

def test_complete_candidate_content_is_persisted_without_overwriting_affiliate():
    product = _product()
    candidate = Candidate(
        external_id="MLB123", title="Produto", category="casa", price=10, original_price=12,
        rating=4.8, review_count=1500, sold_quantity=8000, seller_reputation=90,
        stock_available=True, listing_url="https://produto.mercadolivre.com.br/MLB-123",
        thumbnail="https://img/1.jpg", trend_keyword="ranking", item_id="MLB123",
        description="Descrição oficial completa do produto.",
        picture_urls=("https://img/1.jpg", "https://img/2.jpg"),
        rating_source="reviews_api", sold_quantity_source="listing",
    )
    _apply_candidate_content(product, candidate)
    meta = json.loads(product.source_metadata_json)
    assert product.affiliate_url == "https://meli.la/abc"
    assert product.original_description.startswith("Descrição oficial")
    assert product.media_urls.count("https://img/") == 2
    assert meta["item_id"] == "MLB123"
    assert meta["rating_source"] == "reviews_api"
    assert meta["sold_quantity_source"] == "listing"
