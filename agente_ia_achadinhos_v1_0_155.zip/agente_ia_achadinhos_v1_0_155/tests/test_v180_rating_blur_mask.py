from pathlib import Path


def test_new_product_rating_formats_only_on_blur():
    html = Path('app/templates/products/form.html').read_text(encoding='utf-8')
    block = html.split('const bindRating = (id) => {', 1)[1].split('const bindCommission', 1)[0]
    assert "el.addEventListener('input'" in block
    assert "el.value = digits(el.value).slice(0, 2)" in block
    assert "el.addEventListener('blur'" in block
    assert "el.value = decimal.format(n)" in block
    assert "el.addEventListener('click'" not in block
    assert "setSelectionRange" not in block


def test_complete_form_has_single_script_and_rating_blur_mask():
    html = Path('app/templates/products/complete.html').read_text(encoding='utf-8')
    assert html.count('<script>') == 1
    assert "if (kind === 'rating')" in html
    rating_block = html.split("if (kind === 'rating')", 1)[1].split('return;', 1)[0]
    assert "input.addEventListener('input'" in rating_block
    assert "input.value = digitsOnly(input.value).slice(0, 2)" in rating_block
    assert "input.addEventListener('blur'" in rating_block
    assert "input.value = oneDecimal(input.value, 5)" in rating_block
    assert "input.addEventListener('click'" not in rating_block
