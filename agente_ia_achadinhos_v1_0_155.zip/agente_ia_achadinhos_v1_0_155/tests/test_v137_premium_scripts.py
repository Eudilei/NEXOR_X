from app.services.scripts import _build_40_second_narration, _category_script_profile, _product_profile, sanitize_script_language


def test_premium_script_is_product_specific_for_razor():
    title = 'Gillette Mach3 Sensitive Carga 8 Unidades com Aloe'
    profile = _product_profile(title)
    text = _build_40_second_narration(profile, 'nota 4,8, mais de 10 mil vendas', 'facilitar os cuidados pessoais', title, 'beneficio', 'cuidados_pessoais')
    lower = text.lower()
    assert 'compatibilidade' in lower or 'refis' in lower
    assert 'barbear' in lower
    assert 'nas fotos' not in lower
    assert 'detalhes reais' not in lower


def test_premium_script_is_not_generic_for_pan():
    title = 'Panela Antiaderente 24 cm com Tampa'
    profile = _product_profile(title)
    sp = _category_script_profile(title, 'cozinha', profile)
    assert 'revestimento' in sp['decision']
    assert 'fogão' in sp['decision']


def test_sanitizer_removes_meta_language():
    text = sanitize_script_language('Nas fotos dá para conferir os detalhes reais mostrados nas fotos.')
    assert 'nas fotos' not in text.lower()
    assert 'detalhes reais' not in text.lower()
