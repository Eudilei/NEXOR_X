import json
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import Product
from app.services.autonomous import _save_preselected
from app.services.marketplace import Candidate, MercadoLivreClient


def test_product_offers_preserves_commercial_fields(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "_get", lambda *a, **k: {
        "results": [{
            "item_id": "MLB1234567890",
            "price": 129.90,
            "original_price": 159.90,
            "status": "active",
            "available_quantity": 12,
            "sold_quantity": 250,
        }]
    })
    rows = client.product_offers("MLB65719614", limit=3)
    assert rows[0]["item_id"] == "MLB1234567890"
    assert rows[0]["price"] == 129.90
    assert rows[0]["available_quantity"] == 12
    assert rows[0]["sold_quantity"] == 250


def test_candidate_from_enriched_payload_uses_resolved_item_id():
    candidate = MercadoLivreClient._candidate_from_product(
        {
            "id": "MLB65719614",
            "item_id": "MLB1234567890",
            "name": "Tênis Flyer Runner Mesh Bdp Puma",
            "status": "active",
            "price": 199.90,
            "available_quantity": 1,
            "availability_confirmed": True,
            "rating_average": 4.8,
            "reviews_count": 321,
            "description": "Descrição original confirmada",
            "pictures": [{"url": "https://http2.mlstatic.com/D_NQ_NP_123.jpg"}],
        },
        internal_category="moda_acessorios", trend_keyword="tenis", source="ranking", source_rank=1,
    )
    assert candidate is not None
    assert candidate.item_id == "MLB1234567890"
    assert candidate.external_id == "MLB1234567890"
    assert candidate.price == 199.90
    assert candidate.offer_available is True


def test_preselected_persists_partial_description_photos_and_item_id(monkeypatch):
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    db = Session(engine)
    candidate = Candidate(
        external_id="MLB1234567890",
        title="Tênis Flyer Runner Mesh Bdp Puma",
        category="moda_acessorios",
        price=0.0,
        original_price=None,
        rating=4.7,
        review_count=210,
        sold_quantity=0,
        seller_reputation=0,
        stock_available=False,
        listing_url="https://produto.mercadolivre.com.br/MLB-1234567890-_JM",
        thumbnail="https://http2.mlstatic.com/D_NQ_NP_123.jpg",
        trend_keyword="tenis",
        source="ranking_preselecionado",
        source_rank=1,
        offer_available=False,
        catalog_product_id="MLB65719614",
        item_id="MLB1234567890",
        description="Descrição importada do anúncio",
        picture_urls=("https://http2.mlstatic.com/D_NQ_NP_123.jpg", "https://http2.mlstatic.com/D_NQ_NP_456.jpg"),
        rating_source="reviews_api",
    )
    monkeypatch.setattr("app.services.autonomous._automatic_affiliate", lambda *a, **k: type("A", (), {"confirmed": False, "url": "", "source": "", "error": ""})())
    created, _ = _save_preselected(db, candidate)
    db.commit()
    product = db.query(Product).one()
    assert created is True
    assert product.external_product_id == "MLB1234567890"
    assert product.original_description == "Descrição importada do anúncio"
    assert "D_NQ_NP_123" in product.media_urls and "D_NQ_NP_456" in product.media_urls
    meta = json.loads(product.source_metadata_json)
    assert meta["item_id"] == "MLB1234567890"
    assert meta["catalog_product_id"] == "MLB65719614"
    assert meta["rating_source"] == "reviews_api"
