from app.models.schemas import ProductInput, ScriptRequest
from app.services.scripts import generate_script


def product(title="Kit C/ 3 Toalha De Banho Gigante 70 X 1,40 Sortida", category="casa", price=45.0):
    return ProductInput(
        title=title, category=category, price=price, rating=4.5,
        review_count=3000, sold_quantity=20000,
        affiliate_url="https://example.com/item",
    )


def build(fmt, instructions="", title=None, category="casa", price=45.0):
    return generate_script(ScriptRequest(
        product=product(title or "Kit C/ 3 Toalha De Banho Gigante 70 X 1,40 Sortida", category, price),
        format=fmt, voice_instructions=instructions, duration_seconds=40,
        writer_engine="free_ai",
    ))


def test_humor_substyles_are_structurally_distinct_and_sustained():
    observation = build("humor_observacao", "humor observacional")
    dry = build("humor_seco", "humor seco")
    expectation = build("expectativa_realidade", "expectativa x realidade")
    assert len({observation.hook, dry.hook, expectation.hook}) == 3
    assert "aposentadoria" in observation.narration.lower() or "enxugar" in observation.narration.lower()
    assert any(token in dry.narration.lower() for token in ("requisito", "operacional", "obrigatório"))
    assert observation.narration.lower().count("toalha") >= 2
    assert expectation.narration.lower().count("expectativa") >= 2
    assert expectation.narration.lower().count("realidade") >= 2


def test_cost_benefit_calculates_unit_value_and_discusses_real_use():
    out = build("vale_a_pena", "custo-benefício real")
    text = out.narration.lower()
    assert "r$ 15,00 por unidade" in text
    assert "valor total" in text
    assert "uso real" in text or "frequência de uso" in text
    assert "quantidade" in text and "gramatura" in text


def test_comparison_storytelling_list_and_error_have_own_logic():
    comparison = build("comparacao_rapida", "comparativo")
    story = build("automatico", "storytelling com mini história")
    reasons = build("tres_motivos", "três motivos")
    error = build("erro_comum")
    assert "lado a lado" in comparison.narration.lower() or "enquanto" in comparison.narration.lower()
    assert "a cena começa" in story.narration.lower() and "história" in story.narration.lower()
    assert all(word in reasons.narration.lower() for word in ("primeiro", "segundo", "terceiro"))
    assert "erro comum" in error.narration.lower() and "preço" in error.narration.lower()


def test_category_specific_humor_changes_with_product_family():
    towel = build("humor_observacao", "humor observacional")
    notebook = build(
        "humor_observacao", "humor observacional",
        "Caderneta A5 Tipo Moleskine Couro Sintético", "casa", 39.9,
    )
    razor = build(
        "humor_observacao", "humor observacional",
        "Gillette Mach3 Sensitive Carga com Aloe 8 Unidades", "cuidados_pessoais", 129.9,
    )
    assert "toalha" in towel.narration.lower()
    assert any(x in notebook.narration.lower() for x in ("memória", "ideia", "anotar"))
    assert any(x in razor.narration.lower() for x in ("espelho", "barba", "pele"))
    assert len({towel.hook, notebook.hook, razor.hook}) == 3


def test_kit_uses_masculine_agreement():
    out = build("demonstracao")
    assert "esta kit" not in out.narration.lower()
    assert "este kit" in out.narration.lower() or "kit com" in out.narration.lower()
