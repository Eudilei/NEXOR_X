from app.services.production import _commercial_scene_texts, _consolidate_social_texts, _scene_durations, _cta_text


def test_social_proof_is_consolidated_once():
    texts = _commercial_scene_texts(
        "Máscara de reconstrução capilar 200 ml com proteína do trigo",
        "0–3s · Gancho\n3–6s · NOTA 4,9\n6–9s · MAIS DE 100 MIL VENDAS",
        "Seu cabelo pediu socorro?",
        "Veja os detalhes no link da descrição ou da bio.",
        rating=4.9,
        review_count=23650,
        sold_quantity=100000,
    )
    directed = _consolidate_social_texts(texts[:-1])
    social = [t for t in directed if "AVALIAÇÕES" in t or "VENDAS" in t or "NOTA" in t]
    assert len(social) == 1
    assert "NOTA 4,9" in social[0]
    assert "23.650 AVALIAÇÕES" in social[0]
    assert "MAIS DE 100 MIL VENDAS" in social[0]


def test_cta_is_short_and_without_redundancy():
    assert _cta_text("Confira o link da descrição ou da bio desta publicação.") == "Link na bio"


def test_cta_duration_is_at_most_three_seconds():
    durations = _scene_durations(30, 9)
    assert abs(sum(durations) - 30) < 0.01
    assert durations[-1] <= 3.0
    assert durations[-1] >= 1.6
