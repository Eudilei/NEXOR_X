import httpx

from app.services.marketplace import MercadoLivreClient, MarketplaceRequestError


def make_response(status: int, url: str, payload):
    request = httpx.Request("GET", url)
    return httpx.Response(status, request=request, json=payload)


def product_payload(product_id="MLBP1", item_id="MLBITEM1", price=59.9):
    return {
        "id": product_id,
        "status": "active",
        "name": "Organizador de cozinha ajustável",
        "permalink": f"https://www.mercadolivre.com.br/p/{product_id}",
        "pictures": [{"url": "https://example.test/image.jpg"}],
        "buy_box_winner": {
            "item_id": item_id,
            "price": price,
            "currency_id": "BRL",
            "seller_id": 99,
            "available_quantity": 12,
            "sold_quantity": 250,
        },
    }


def quiet_catalog(client, monkeypatch, products):
    monkeypatch.setattr(client, "_target_categories", lambda max_per_group=1: {"cozinha": ["MLB123"]})
    entries = [{"id": row["id"], "position": index, "type": "PRODUCT"} for index, row in enumerate(products, start=1)]
    monkeypatch.setattr(client, "_highlights_with_ancestor_fallback", lambda category_id: (entries, category_id))


def test_highlights_returns_official_ranking(monkeypatch):
    def fake_get(self, url, headers=None, params=None):
        return make_response(200, str(httpx.URL(url, params=params)), {"content": [{"id": "MLBP1", "position": 1, "type": "PRODUCT"}]})

    monkeypatch.setattr(httpx.Client, "get", fake_get)
    client = MercadoLivreClient(access_token="token")
    assert client.highlights("MLB123")[0]["type"] == "PRODUCT"
    assert "mais_vendidos" in client.sources_used


def test_discover_builds_offer_from_product_buy_box_without_items_endpoint(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    quiet_catalog(client, monkeypatch, [{"id": "MLBP1", "name": "Organizador"}])
    monkeypatch.setattr(client, "product_detail", lambda product_id: product_payload(product_id))
    monkeypatch.setattr(client, "item_details", lambda ids: (_ for _ in ()).throw(AssertionError("/items não deve ser chamado")))

    result = client.discover(limit_per_query=8)
    assert len(result) == 1
    assert result[0].external_id == "MLBITEM1"
    assert result[0].catalog_product_id == "MLBP1"
    assert result[0].offer_available is True
    assert result[0].price == 59.9
    assert result[0].listing_url.endswith("/p/MLBP1")
    assert client.discovery_stats["third_party_item_requests"] == 0


def test_discover_rejects_ranked_product_without_real_price(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    quiet_catalog(client, monkeypatch, [{"id": "MLBP2", "name": "Organizador sem oferta"}])
    monkeypatch.setattr(client, "product_detail", lambda product_id: {
        "id": product_id, "status": "active", "name": "Organizador sem oferta",
        "permalink": f"https://www.mercadolivre.com.br/p/{product_id}", "pictures": []
    })
    result = client.discover()
    assert len(result) == 1
    assert result[0].offer_available is False
    assert result[0].source.endswith("_preselecionado")
    assert client.discovery_stats["ranked_unavailable"] >= 1


def test_product_detail_failure_is_counted_and_not_saved(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    quiet_catalog(client, monkeypatch, [{"id": "MLBP3", "name": "Produto provisório", "status": "active"}])
    monkeypatch.setattr(client, "product_detail", lambda product_id: (_ for _ in ()).throw(
        MarketplaceRequestError(status_code=403, endpoint=f"/products/{product_id}", detail="forbidden")
    ))
    result = client.discover()
    assert result == []
    assert client.discovery_stats["product_detail_failures"] == 1


def test_highlight_product_is_enriched_without_reading_third_party_item(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "trends", lambda: [])
    monkeypatch.setattr(client, "catalog_product_search", lambda *args, **kwargs: [])
    monkeypatch.setattr(client, "_target_categories", lambda max_per_group=1: {"cozinha": ["MLB123"]})
    monkeypatch.setattr(client, "_highlights_with_ancestor_fallback", lambda category_id: ([{"id": "MLBP9", "position": 2, "type": "PRODUCT"}], category_id))
    monkeypatch.setattr(client, "product_detail", lambda product_id: product_payload(product_id, item_id="MLBITEM9"))
    result = client.discover()
    assert result[0].external_id == "MLBITEM9"
    assert result[0].source == "mercado_livre_highlights"
    assert result[0].source_rank == 2


def test_highlight_item_reference_is_ignored_to_avoid_policyagent(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "trends", lambda: [])
    monkeypatch.setattr(client, "catalog_product_search", lambda *args, **kwargs: [])
    monkeypatch.setattr(client, "_target_categories", lambda max_per_group=1: {"casa": ["MLB1"]})
    monkeypatch.setattr(client, "_highlights_with_ancestor_fallback", lambda category_id: ([{"id": "MLBITEMX", "position": 1, "type": "ITEM"}], category_id))
    monkeypatch.setattr(client, "item_details", lambda ids: (_ for _ in ()).throw(AssertionError("não deve consultar item")))
    assert client.discover() == []


def test_nested_winner_payload_is_supported():
    candidate = MercadoLivreClient._candidate_from_product(
        {
            "id": "MLBP4", "status": "active", "name": "Escova secadora",
            "buy_box_winner": {"item": {"id": "MLB44", "price": 129.9, "seller_id": 7, "available_quantity": 4}},
        },
        internal_category="beleza", trend_keyword="escova secadora", source="catalogo", source_rank=1,
    )
    assert candidate is not None
    assert candidate.external_id == "MLB44"
    assert candidate.offer_available is True


def test_public_category_request_does_not_send_authorization(monkeypatch):
    captured = []
    def fake_get(self, url, headers=None, params=None):
        captured.append(headers or {})
        return make_response(200, str(httpx.URL(url, params=params)), [{"id": "MLB1574", "name": "Casa"}])
    monkeypatch.setattr(httpx.Client, "get", fake_get)
    client = MercadoLivreClient(access_token="token")
    assert client.site_categories()
    assert "Authorization" not in captured[0]


def test_auto_mode_retries_with_opposite_authentication(monkeypatch):
    captured = []
    def fake_get(self, url, headers=None, params=None):
        captured.append(headers or {})
        if len(captured) == 1:
            return make_response(403, str(httpx.URL(url, params=params)), {"blocked_by": "PolicyAgent"})
        return make_response(200, str(httpx.URL(url, params=params)), [{"id": "MLB1574", "name": "Casa"}])
    monkeypatch.setattr(httpx.Client, "get", fake_get)
    client = MercadoLivreClient(access_token="token")
    assert client.site_categories()
    assert "Authorization" not in captured[0]
    assert captured[1]["Authorization"] == "Bearer token"


def test_target_categories_uses_fixed_fallback_when_api_is_blocked(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "site_categories", lambda: [])
    result = client._target_categories()
    assert result["casa"] == ["MLB1574"]
    assert result["beleza"] == ["MLB1246"]


def test_highlights_falls_back_to_parent_category_on_404(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "category_detail", lambda category_id: {"id": category_id, "path_from_root": [{"id": "MLB1574"}, {"id": category_id}]})
    def fake_highlights(category_id):
        if category_id != "MLB1574":
            raise MarketplaceRequestError(status_code=404, endpoint="/highlights", detail="not found")
        return [{"id": "MLBP1", "position": 1, "type": "PRODUCT"}]
    monkeypatch.setattr(client, "highlights", fake_highlights)
    entries, used = client._highlights_with_ancestor_fallback("MLB459667")
    assert entries and used == "MLB1574"


def test_catalog_product_search_uses_authenticated_official_endpoint(monkeypatch):
    captured = {}
    def fake_get(self, url, headers=None, params=None):
        captured.update(url=url, headers=headers or {}, params=params or {})
        return make_response(200, str(httpx.URL(url, params=params)), {"results": [{"id": "MLBP1", "status": "active"}]})
    monkeypatch.setattr(httpx.Client, "get", fake_get)
    client = MercadoLivreClient(access_token="token")
    assert client.catalog_product_search("organizador")[0]["id"] == "MLBP1"
    assert captured["url"].endswith("/products/search")
    assert captured["headers"]["Authorization"] == "Bearer token"


def test_product_items_parses_results(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "_get", lambda *args, **kwargs: {"results": [{"item_id": "MLB1", "status": "active"}, {"id": "MLB2", "status": "active"}]})
    assert client.product_items("PROD1") == ["MLB1", "MLB2"]


def test_discover_expands_parent_to_buyable_children(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    quiet_catalog(client, monkeypatch, [{"id": "MLBPARENT", "name": "Celular modelo"}])

    payloads = {
        "MLBPARENT": {
            "id": "MLBPARENT", "status": "active", "name": "Celular modelo",
            "children_ids": ["MLBCHILD1", "MLBCHILD2"], "buy_box_winner": None,
        },
        "MLBCHILD1": product_payload("MLBCHILD1", "MLBITEM101", 1999.0),
        "MLBCHILD2": {
            "id": "MLBCHILD2", "status": "active", "name": "Celular modelo azul",
            "buy_box_winner": None,
        },
    }
    monkeypatch.setattr(client, "product_detail", lambda product_id: payloads[product_id])
    result = client.discover()
    assert {item.catalog_product_id for item in result} == {"MLBCHILD1"}
    offer = result[0]
    assert offer.external_id == "MLBITEM101"
    assert offer.parent_catalog_product_id == "MLBPARENT"
    assert client.discovery_stats["parents_detected"] == 1
    assert client.discovery_stats["children_checked"] >= 1


def test_invalid_cent_price_is_not_an_offer():
    candidate = MercadoLivreClient._candidate_from_product(
        product_payload("MLBPX", "MLBITEMX", 0.01),
        internal_category="cozinha", trend_keyword="organizador", source="catalogo", source_rank=1,
    )
    assert candidate is not None
    assert candidate.offer_available is False
    assert candidate.price == 0.0


def test_out_of_stock_product_is_not_an_offer():
    payload = product_payload("MLBPY", "MLBITEMY", 59.9)
    payload["buy_box_winner"]["available_quantity"] = 0
    candidate = MercadoLivreClient._candidate_from_product(
        payload, internal_category="cozinha", trend_keyword="organizador", source="catalogo", source_rank=1,
    )
    assert candidate is not None
    assert candidate.offer_available is False


def test_rating_and_reviews_supports_nested_reviews_payload():
    rating, count = MercadoLivreClient._rating_and_reviews({
        "reviews": {"rating_average": 4.7, "total": 1234}
    })
    assert rating == 4.7
    assert count == 1234


def test_target_categories_keeps_multiple_specific_categories(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "site_categories", lambda: [{"id": "MLBROOT", "name": "Casa e Cozinha"}])
    monkeypatch.setattr(client, "category_detail", lambda category_id: {
        "children_categories": [
            {"id": "MLBPANELAS", "name": "Panelas e Frigideiras"},
            {"id": "MLBUTENS", "name": "Utensílios de Cozinha"},
            {"id": "MLBORGAN", "name": "Organizadores"},
        ]
    })
    result = client._target_categories(max_per_group=3)
    assert len(result["cozinha"]) >= 2
    assert "MLBPANELAS" in result["cozinha"]


def test_public_page_json_ld_extracts_real_commercial_fields():
    html = '''
    <html><head><script type="application/ld+json">{
      "@context":"https://schema.org", "@type":"Product",
      "name":"Jogo de panelas cerâmico",
      "image":"https://example.test/panela.jpg",
      "aggregateRating":{"@type":"AggregateRating","ratingValue":"4.8","reviewCount":"24669"},
      "offers":{"@type":"Offer","price":"569.00","availability":"https://schema.org/InStock"}
    }</script></head><body></body></html>
    '''
    data = MercadoLivreClient._public_snapshot_from_html(html, "https://www.mercadolivre.com.br/p/MLB1")
    assert data["name"] == "Jogo de panelas cerâmico"
    assert data["price"] == 569.0
    assert data["rating"] == 4.8
    assert data["reviews_count"] == 24669
    assert data["available_quantity"] == 1


def test_public_page_marks_explicit_unavailable():
    html = '''<script type="application/ld+json">{
      "@type":"Product", "name":"Organizador", "offers":{"price":"49.90","availability":"https://schema.org/OutOfStock"}
    }</script><p>Este produto está indisponível.</p>'''
    data = MercadoLivreClient._public_snapshot_from_html(html, "https://www.mercadolivre.com.br/p/MLB2")
    assert data["price"] == 49.9
    assert data["status"] == "inactive"
    assert data["available_quantity"] == 0


def test_policy_block_family_is_cached_after_repeated_denials(monkeypatch):
    calls = []
    def fake_get(self, url, headers=None, params=None):
        calls.append(url)
        return make_response(403, str(httpx.URL(url, params=params)), {"blocked_by": "PolicyAgent", "code": "PA_UNAUTHORIZED_RESULT_FROM_POLICIES"})
    monkeypatch.setattr(httpx.Client, "get", fake_get)
    client = MercadoLivreClient(access_token="token")
    for product_id in ("MLBP1", "MLBP2"):
        try:
            client.product_detail(product_id)
        except MarketplaceRequestError:
            pass
    before = len(calls)
    try:
        client.product_detail("MLBP3")
    except MarketplaceRequestError:
        pass
    assert len(calls) == before
    assert client._policy_skipped_requests == 1
    assert len(client.warnings) == 1
