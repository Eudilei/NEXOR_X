from __future__ import annotations

import json
from types import SimpleNamespace

from app.services.affiliate_links import AffiliateLinkResult
from app.services.product_enrichment import missing_fields


def test_missing_fields_priority_inputs():
    product = SimpleNamespace(
        sold_quantity=0,
        commission_pct=0.0,
        stock_available=True,
        rating=4.8,
        review_count=1200,
        original_price=None,
        price=99.9,
    )
    meta = {"stock_confirmed": True, "affiliate_link_confirmed": False}
    assert missing_fields(product, meta) == [
        "sold_quantity", "commission_pct", "original_price", "affiliate_link"
    ]


def test_affiliate_result_can_carry_confirmed_commission():
    result = AffiliateLinkResult(
        url="https://meli.la/exemplo",
        confirmed=True,
        source="configured_official_api",
        commission_pct=12.5,
    )
    assert result.confirmed is True
    assert result.commission_pct == 12.5
