from app.models.schemas import ProductInput, ScriptRequest
from app.services.production import normalize_spoken_text_ptbr
from app.services.scripts import _facts, _spoken_title, generate_script


def product():
    return ProductInput(
        title="Kit C/ 3 Toalha De Banho Gigante Luxo 70 X 1,40 Atacado Sortida Listrados E Estampado",
        price=44.0,
        rating=4.3,
        review_count=7899,
        sold_quantity=53400,
        affiliate_url="https://example.com/p",
        category="casa",
    )


def test_spoken_title_preserves_luxo_and_rewrites_product():
    spoken = _spoken_title(product().title)
    assert spoken == "kit com 3 toalhas de banho grandes e de luxo"
    assert " lu" not in spoken.lower().replace("luxo", "")


def test_measurement_x_does_not_cut_words():
    value = normalize_spoken_text_ptbr("Luxo Max Box 70 X 1,40")
    assert "Luxo Max Box" in value
    assert "70 por 1,40" in value


def test_facts_are_product_specific():
    facts = _facts(product().title)
    assert facts == ["kit com 3 toalhas", "70 cm × 1,40 m"]


def test_humorous_script_is_specific_and_grammatical():
    req = ScriptRequest(
        product=product(), duration_seconds=20, variation_index=0,
        format="humor_observacao", voice_instructions="narrador divertido",
    )
    out = generate_script(req)
    assert "toalha que já pediu aposentadoria" in out.narration
    assert "toalhas de banho grandes e de luxo" in out.narration
    assert "70 centímetros por 1 metro e 40 centímetros" in out.narration
    assert "Gigante Lu" not in out.narration
    assert "por o" not in out.narration
    assert any("KIT COM 3 TOALHAS" in line for line in out.on_screen_text)
    assert any("70 CM × 1,40 M" in line for line in out.on_screen_text)
