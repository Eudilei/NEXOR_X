from app.services.marketplace import MercadoLivreClient


def test_public_snapshot_reads_opinioes_and_minimum_sales():
    html = '''
    <html><body>
      <span class="ui-pdp-review__rating">4,8</span>
      <span class="ui-pdp-review__amount">(1.234 opiniões)</span>
      <span>Mais de 5 mil vendidos</span>
    </body></html>
    '''
    data = MercadoLivreClient._public_snapshot_from_html(html, "https://www.mercadolivre.com.br/p/MLB123")
    assert data["rating"] == 4.8
    assert data["reviews_count"] == 1234
    assert data["sold_quantity"] == 5000
    assert data["sold_quantity_is_minimum"] is True
    assert "5 mil vendidos" in data["sold_quantity_display"].lower()


def test_merge_public_snapshots_keeps_listing_content_and_catalog_metrics():
    listing = {"price": 249.99, "pictures": [{"url": "https://http2.mlstatic.com/D_NQ_NP_1.jpg"}], "rating": 0, "reviews_count": 0}
    catalog = {"price": 0, "rating": 4.9, "reviews_count": 845, "sold_quantity": 1000, "sold_quantity_display": "+1000 vendidos", "sold_quantity_is_minimum": True}
    merged = MercadoLivreClient.merge_public_snapshots(listing, catalog)
    assert merged["price"] == 249.99
    assert merged["rating"] == 4.9
    assert merged["reviews_count"] == 845
    assert merged["sold_quantity"] == 1000
    assert merged["sold_quantity_is_minimum"] is True
