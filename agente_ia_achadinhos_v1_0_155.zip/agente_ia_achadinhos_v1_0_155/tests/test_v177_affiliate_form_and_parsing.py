from pathlib import Path

from app.services.marketplace import MercadoLivreClient


def test_public_html_extracts_original_price_and_decimal_rating():
    html = '''
    <script type="application/ld+json">{"@type":"Product","name":"Produto X","offers":{"price":"147.81","highPrice":"303.86","availability":"https://schema.org/InStock"},"aggregateRating":{"ratingValue":"4.9","reviewCount":"2560"}}</script>
    <div>+5 mil vendidos</div>
    '''
    data = MercadoLivreClient._public_snapshot_from_html(html, "https://produto.mercadolivre.com.br/MLB-123456")
    assert data["price"] == 147.81
    assert data["original_price"] == 303.86
    assert data["rating"] == 4.9
    assert data["reviews_count"] == 2560
    assert data["sold_quantity"] == 5000


def test_manual_form_preserves_affiliate_link_and_has_ptbr_masks():
    html = Path("app/templates/products/form.html").read_text()
    assert "Link de afiliado" in html
    assert 'name="listing_url"' in html
    assert "Intl.NumberFormat('pt-BR'" in html
    assert "submitted_link" in Path("app/main.py").read_text()
