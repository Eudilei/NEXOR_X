from app.services.production import FREE_TTS_PROFILES, resolve_free_voice_profile


def test_explicit_male_profiles_never_resolve_to_female_voice():
    female_voices = {p["voice"] for p in FREE_TTS_PROFILES.values() if p["gender"] == "feminino"}
    for name, profile in FREE_TTS_PROFILES.items():
        if profile["gender"] != "masculino":
            continue
        resolved = resolve_free_voice_profile(name, "feminino")
        assert resolved["gender"] == "masculino"
        assert resolved["voice"].startswith("pt-BR-")
        assert resolved["voice"].endswith("Neural")
        assert resolved["voice"] not in female_voices


def test_explicit_female_profiles_never_resolve_to_male_voice():
    male_voices = {p["voice"] for p in FREE_TTS_PROFILES.values() if p["gender"] == "masculino"}
    for name, profile in FREE_TTS_PROFILES.items():
        if profile["gender"] != "feminino":
            continue
        resolved = resolve_free_voice_profile(name, "masculino")
        assert resolved["gender"] == "feminino"
        assert resolved["voice"].startswith("pt-BR-")
        assert resolved["voice"].endswith("Neural")
        assert resolved["voice"] not in male_voices


def test_auto_follows_presenter_gender_only_when_auto_is_selected():
    assert resolve_free_voice_profile("auto", "masculino")["gender"] == "masculino"
    assert resolve_free_voice_profile("auto", "feminino")["gender"] == "feminino"


def test_voice_library_has_at_least_six_profiles_per_gender():
    female = [p for p in FREE_TTS_PROFILES.values() if p["gender"] == "feminino"]
    male = [p for p in FREE_TTS_PROFILES.values() if p["gender"] == "masculino"]
    assert len(female) >= 6
    assert len(male) >= 6


def test_library_has_real_timbre_diversity_not_only_speed_changes():
    rich = [p for p in FREE_TTS_PROFILES.values() if p.get("provider") == "gemini"]
    gemini_voices = [p["gemini_voice"] for p in rich if p.get("gemini_voice")]
    edge = [p for p in FREE_TTS_PROFILES.values() if p.get("provider") == "edge"]
    assert len(gemini_voices) >= 20
    assert len(set(gemini_voices)) == len(gemini_voices)
    assert {p["voice"] for p in edge} == {"pt-BR-AntonioNeural", "pt-BR-FranciscaNeural"}


def test_invalid_explicit_voice_is_rejected_instead_of_falling_back():
    try:
        resolve_free_voice_profile("voz_inexistente", "masculino")
    except ValueError:
        pass
    else:
        raise AssertionError("Perfil inválido deveria ser rejeitado")
