from app.services import heygen


def test_list_avatars_uses_groups_and_keeps_unknown_age(monkeypatch):
    calls = []
    def fake_pages(path, params, *, max_items):
        calls.append(path)
        if path == "/v3/avatars":
            return [{"id":"g1","name":"Ana","gender":"female","preview_image_url":"group.jpg","status":"completed"}]
        return [{"id":"look1","group_id":"g1","name":"Ana Office","gender":"female","preview_image_url":"look.jpg","supported_api_engines":[],"tags":["business"]}]
    monkeypatch.setattr(heygen, "_request_pages", fake_pages)
    items = heygen.list_avatars(gender="feminino", age="adulto")
    assert calls == ["/v3/avatars", "/v3/avatars/looks"]
    assert len(items) == 1
    assert items[0]["name"] == "Ana"
    assert items[0]["age"] == "nao_informado"
    assert items[0]["looks"][0]["id"] == "look1"


def test_list_avatars_never_crosses_gender(monkeypatch):
    def fake_pages(path, params, *, max_items):
        if path == "/v3/avatars":
            return [
                {"id":"gf","name":"Ana","gender":"female"},
                {"id":"gm","name":"Joao","gender":"male"},
            ]
        return [
            {"id":"lf","group_id":"gf","supported_api_engines":[]},
            {"id":"lm","group_id":"gm","supported_api_engines":[]},
        ]
    monkeypatch.setattr(heygen, "_request_pages", fake_pages)
    items = heygen.list_avatars(gender="feminino", age="jovem")
    assert [x["name"] for x in items] == ["Ana"]
