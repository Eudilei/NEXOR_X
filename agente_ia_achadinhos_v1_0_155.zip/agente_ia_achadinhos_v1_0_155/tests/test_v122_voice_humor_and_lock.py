from pathlib import Path

from app.models.schemas import ProductCategory, ProductInput, ScriptRequest
from app.services.scripts import generate_script, resolve_format


def _product():
    return ProductInput(
        title="Kit C/ 3 Toalha De Banho Gigante Luxo 70 X 1,40",
        category=ProductCategory.CASA,
        price=44.0,
        rating=4.3,
        review_count=7899,
        sold_quantity=53247,
        affiliate_url="https://www.mercadolivre.com.br/p/MLB123",
    )


def test_automatic_funny_voice_forces_humor_formats():
    formats = []
    for index in range(3):
        req = ScriptRequest(
            product=_product(),
            format="automatico",
            voice_instructions="Narrador divertido com humor e pequenas pausas para a piada.",
            variation_index=index,
        )
        formats.append(resolve_format(req))
    assert formats == ["humor_viral", "humor_observacao", "humor_seco"]
    assert len(set(formats)) == 3


def test_c_slash_quantity_is_understood_as_kit_with_three():
    req = ScriptRequest(product=_product(), format="humor_observacao")
    output = generate_script(req)
    joined = " ".join(output.on_screen_text).lower() + " " + output.narration.lower()
    assert "kit com 3 toalhas" in joined
    assert "c/ 3" not in output.narration.lower()


def test_script_detail_has_real_script_voice_preview_and_back_button():
    template = Path("app/templates/scripts/detail.html").read_text(encoding="utf-8")
    assert "Ouvir a narração antes do vídeo" in template
    assert "free-voice-preview" in template
    assert "Prévia pronta. Ela usa exatamente este roteiro." in template
    assert 'href="/scripts">← Voltar' in template
