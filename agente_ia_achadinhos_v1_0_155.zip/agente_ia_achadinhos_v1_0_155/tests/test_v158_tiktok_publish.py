from types import SimpleNamespace
from app.services.social_content import build_tiktok_caption, tiktok_caption_issues

def test_tiktok_caption_contains_exact_affiliate_link():
    p=SimpleNamespace(title="Produto",price=49.9,affiliate_url="https://exemplo.com/afiliado",category="casa")
    s=SimpleNamespace(hook="Olha este achado")
    text=build_tiktok_caption(p,s)
    assert p.affiliate_url in text
    assert "link de afiliado" in text.lower()
    assert not tiktok_caption_issues(text,p)

def test_tiktok_caption_rejects_wrong_link():
    p=SimpleNamespace(affiliate_url="https://correto")
    assert tiktok_caption_issues("https://errado",p)
