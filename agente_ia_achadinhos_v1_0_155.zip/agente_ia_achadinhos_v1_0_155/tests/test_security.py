from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_dashboard_redirects_to_login():
    response = client.get("/", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/login"


def test_api_requires_authentication():
    response = client.get("/api/health")
    assert response.status_code == 401


def test_public_health_and_head_root():
    from fastapi.testclient import TestClient
    client = TestClient(app)
    assert client.get("/health").status_code == 200
    assert client.head("/").status_code == 200


def test_mercado_livre_webhook_exists():
    from fastapi.testclient import TestClient
    client = TestClient(app)
    response = client.post("/webhooks/mercadolivre", json={"topic": "items", "resource": "/items/MLB1", "user_id": 1})
    assert response.status_code == 200
    assert response.json()["received"] is True
