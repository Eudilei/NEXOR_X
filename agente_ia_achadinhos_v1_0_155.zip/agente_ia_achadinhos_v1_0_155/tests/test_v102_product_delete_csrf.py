from pathlib import Path


def test_product_delete_forms_use_template_csrf_token():
    text = (Path(__file__).parents[1] / 'app/templates/products/list.html').read_text(encoding='utf-8')
    assert 'action="/products/delete-all"' in text
    assert 'action="/products/{{ product.id }}/delete"' in text
    assert text.count('name="csrf" value="{{ csrf_token }}"') >= 2
    assert 'name="csrf" value="{{ csrf }}"' not in text
