from pathlib import Path

from app.services.production import FREE_TTS_PROFILES, _apply_timbre_fx


def test_modified_timbres_exist_for_both_genders():
    male=[p for p in FREE_TTS_PROFILES.values() if p.get("gender")=="masculino" and p.get("timbre_fx")]
    female=[p for p in FREE_TTS_PROFILES.values() if p.get("gender")=="feminino" and p.get("timbre_fx")]
    assert len(male) >= 8
    assert len(female) >= 8
    assert len({p["timbre_fx"] for p in male}) >= 8
    assert len({p["timbre_fx"] for p in female}) >= 8


def test_modified_labels_are_honest():
    modified=[p for p in FREE_TTS_PROFILES.values() if p.get("timbre_fx")]
    assert modified
    assert all("FX" in p.get("label", "") or "modificada" in p.get("label", "").lower() for p in modified)


def test_fast_preview_route_uses_hash_cache_and_short_sample():
    text=Path("app/main.py").read_text()
    assert "preview136" in text
    assert "hashlib.sha256" in text
    assert "sample_rest[:180]" in text
    assert "target.exists() and target.stat().st_size > 1024" in text


def test_voice_menus_expose_modified_timbres():
    detail=Path("app/templates/scripts/detail.html").read_text()
    production=Path("app/templates/productions/form.html").read_text()
    for key in ("masculina_mod_gravissima", "masculina_mod_cartoon", "feminina_mod_grave", "feminina_mod_cartoon"):
        assert key in detail
        assert key in production
