from fastapi.testclient import TestClient

from app.main import app
from app.core.config import settings


def test_tiktok_verification_is_available_under_terms_and_privacy(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "tiktok-route-proof.txt")
    monkeypatch.setattr(
        settings,
        "tiktok_url_verification_content",
        "tiktok-developers-site-verification=route-proof",
    )

    with TestClient(app) as client:
        for path in (
            "/termos-de-servico/tiktok-route-proof.txt",
            "/politica-de-privacidade/tiktok-route-proof.txt",
        ):
            response = client.get(path)
            assert response.status_code == 200
            assert response.text == "tiktok-developers-site-verification=route-proof\n"
            assert response.headers["content-type"].startswith("text/plain")


def test_normal_application_routes_are_not_captured_by_tiktok_verification(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "tiktok-route-proof.txt")
    monkeypatch.setattr(
        settings,
        "tiktok_url_verification_content",
        "tiktok-developers-site-verification=route-proof",
    )

    with TestClient(app, follow_redirects=False) as client:
        for path in ("/products", "/scripts", "/productions", "/social", "/discovery"):
            response = client.get(path)
            assert response.status_code in {200, 302, 303, 307}, (path, response.status_code, response.text)
            assert "Arquivo de verificação" not in response.text


def test_unknown_root_path_returns_normal_not_found_instead_of_tiktok_error(monkeypatch):
    monkeypatch.setattr(settings, "tiktok_url_verification_filename", "tiktok-route-proof.txt")
    monkeypatch.setattr(
        settings,
        "tiktok_url_verification_content",
        "tiktok-developers-site-verification=route-proof",
    )

    with TestClient(app) as client:
        response = client.get("/rota-que-nao-existe")
        assert response.status_code == 404
        assert response.json()["detail"] == "Not Found"
