import json

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.db.database import Base
from app.db.models import DiscoveryJob, Product
from app.services.discovery_jobs import active_job, start_job
from app.services.tiktok_discovery import run_tiktok_discovery
from app.services.tiktok_shop import TikTokShopCandidate, TikTokShopCreatorClient


def session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_jobs_are_separated_by_source():
    db = session()
    ml, created_ml = start_job(db, source="mercado_livre")
    tt, created_tt = start_job(db, source="tiktok_shop", filters={"min_stock": 20})
    assert created_ml and created_tt
    assert ml.id != tt.id
    assert active_job(db, "mercado_livre").id == ml.id
    assert active_job(db, "tiktok_shop").id == tt.id
    assert json.loads(tt.filters_json)["min_stock"] == 20


def test_tiktok_engine_does_not_fake_products_without_api(monkeypatch):
    db = session()
    monkeypatch.setattr(TikTokShopCreatorClient, "configured", property(lambda self: False))
    result = run_tiktok_discovery(db, filters={}, max_products=10)
    assert result["status"] == "configuracao_pendente"
    assert db.scalar(select(Product)) is None


def test_tiktok_products_stay_in_their_own_source(monkeypatch):
    db = session()
    candidate = TikTokShopCandidate(
        product_id="tt-123",
        title="Organizador de cozinha",
        category="cozinha",
        price=79.9,
        rating=4.8,
        review_count=900,
        sold_quantity=3500,
        monthly_sold_quantity=1200,
        commission_pct=12,
        stock=500,
        affiliate_url="https://shop.tiktok.com/view/product/123",
        image_urls=["https://img.example/1.jpg", "https://img.example/2.jpg", "https://img.example/3.jpg"],
        metadata={"description": "Organizador compacto"},
    )
    monkeypatch.setattr(TikTokShopCreatorClient, "configured", property(lambda self: True))
    monkeypatch.setattr(TikTokShopCreatorClient, "search_open_collaboration_products", lambda self, **kwargs: [candidate])
    result = run_tiktok_discovery(db, filters={"min_commission_pct": 5}, max_products=10)
    product = db.scalar(select(Product))
    assert result["status"] == "concluido"
    assert product.marketplace == "tiktok_shop"
    assert product.external_product_id == "tt-123"
    assert product.monthly_sold_quantity == 1200
    assert product.commission_pct == 12
    assert "TikTok Shop" in product.notes
