from app.models.schemas import ProductInput, ProductCategory
from app.services.scoring import score_product


def test_unlicensed_media_does_not_erase_commercial_score() -> None:
    product = ProductInput(
        title="Organizador de gaveta", category=ProductCategory.ORGANIZACAO,
        price=49.90, rating=4.8, review_count=500, sold_quantity=2000,
        seller_reputation=95, commission_pct=10,
        affiliate_url="https://example.com/produto", media_license="origem_nao_confirmada",
    )
    result = score_product(product)
    assert result.total > 0
    assert any("aguardando mídia" in reason.lower() for reason in result.reasons)


def test_approves_good_product() -> None:
    product = ProductInput(
        title="Organizador de gaveta", category=ProductCategory.ORGANIZACAO,
        price=49.90, rating=4.8, review_count=500, sold_quantity=2000,
        seller_reputation=95, commission_pct=10, visual_quality=9,
        demonstration_ease=9, novelty=7, return_risk=2,
        affiliate_url="https://example.com/produto", media_license="autorizado_vendedor",
    )
    result = score_product(product)
    assert result.approved is True


def test_allows_rating_4_with_very_high_sales_without_exception() -> None:
    product = ProductInput(
        title="Produto campeão de vendas", category=ProductCategory.CASA,
        price=34.53, rating=4.2, review_count=500, sold_quantity=100000,
        affiliate_url="https://example.com/produto", media_license="origem_nao_confirmada",
    )
    result = score_product(product)
    assert result.approved is True
    assert any("nota mínima de 4,0" in reason.lower() for reason in result.reasons)


def test_allows_rating_4_without_high_sales() -> None:
    product = ProductInput(
        title="Produto mediano", category=ProductCategory.CASA,
        price=34.53, rating=4.2, review_count=500, sold_quantity=10000,
        affiliate_url="https://example.com/produto", media_license="origem_nao_confirmada",
    )
    result = score_product(product)
    assert result.approved is True
