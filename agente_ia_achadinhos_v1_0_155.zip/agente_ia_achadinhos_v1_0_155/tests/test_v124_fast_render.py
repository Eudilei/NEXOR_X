from pathlib import Path


def test_fast_renderer_is_single_pass():
    source = Path("app/services/production.py").read_text(encoding="utf-8")
    block = source[source.index("def compose_product_first_video"):]
    assert "timeout=150" in block
    assert '"fps=15,format=yuv420p"' in block
    assert "_render_motion_segment(ffmpeg" not in block.split("return output", 1)[0]
    assert "desired_scenes = max(5, min(7" in block


def test_worker_has_bounded_retry():
    source = Path("app/workers/production_worker.py").read_text(encoding="utf-8")
    assert 'attempts >= 2' in source
    assert 'assembly_timeout_seconds' in source
    assert 'persistent_queue_v3_fast' in source
