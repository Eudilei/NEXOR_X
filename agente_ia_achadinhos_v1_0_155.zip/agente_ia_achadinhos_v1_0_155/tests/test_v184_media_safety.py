from pathlib import Path
from unittest.mock import Mock, patch
import io
import httpx
from PIL import Image
from app.services.marketplace import MercadoLivreClient
from app.services.production import _download_product_images

def _jpeg(size=(600, 600)):
    buf = io.BytesIO(); Image.new('RGB', size, 'white').save(buf, 'JPEG'); return buf.getvalue()

def test_public_snapshot_filters_ui_and_suspicious_assets():
    html = '''<meta property="og:image" content="https://http2.mlstatic.com/D_NQ_NP_123-MLB999-F.jpg"><script>{"imageUrl":"https://http2.mlstatic.com/frontend-assets/suspicious-traffic-frontend/button.jpg"}</script><script>{"imageUrl":"https://http2.mlstatic.com/icon-cart.png"}</script><script>{"imageUrl":"https://http2.mlstatic.com/D_NQ_NP_456-MLB999-F.jpg"}</script>'''
    snap = MercadoLivreClient._public_snapshot_from_html(html, 'https://www.mercadolivre.com.br/p/MLB999')
    urls = [x['url'] for x in snap['pictures']]
    assert urls == ['https://http2.mlstatic.com/D_NQ_NP_123-MLB999-F.jpg','https://http2.mlstatic.com/D_NQ_NP_456-MLB999-F.jpg']

def test_downloader_skips_broken_and_keeps_valid(tmp_path: Path):
    good = Mock(status_code=200, content=_jpeg(), headers={'content-type':'image/jpeg'}); good.raise_for_status.return_value=None
    bad = Mock(status_code=404, content=b'', headers={'content-type':'text/html'}); bad.raise_for_status.side_effect=httpx.HTTPStatusError('404', request=Mock(), response=bad)
    client=Mock(); client.__enter__=Mock(return_value=client); client.__exit__=Mock(return_value=False); client.get.side_effect=[bad,good]
    with patch('app.services.production.httpx.Client', return_value=client):
        paths=_download_product_images(['https://http2.mlstatic.com/D_NQ_NP_111-MLB-F.jpg','https://http2.mlstatic.com/D_NQ_NP_222-MLB-F.jpg'], tmp_path)
    assert len(paths)==1 and paths[0].exists()
