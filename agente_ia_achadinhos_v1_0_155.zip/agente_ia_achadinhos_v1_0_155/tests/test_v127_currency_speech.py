from app.services.production import normalize_spoken_text_ptbr


def test_integer_price_is_spoken_naturally():
    assert normalize_spoken_text_ptbr("Preço atual R$ 44,00") == "Preço atual quarenta e quatro reais"


def test_price_with_cents_is_spoken_naturally():
    assert normalize_spoken_text_ptbr("Agora por R$ 44,90") == "Agora por quarenta e quatro reais e noventa centavos"


def test_thousand_price_and_singular_currency():
    assert normalize_spoken_text_ptbr("R$ 1,00 e R$ 1.249,99") == "um real e mil duzentos e quarenta e nove reais e noventa e nove centavos"
