from pathlib import Path
from app.models.schemas import ProductCategory, ProductInput
from app.services.scoring import score_product


def test_product_form_has_single_script_and_clean_title():
    html=Path('app/templates/products/form.html').read_text()
    assert html.count("id=\"analyze-link\"") == 1
    assert html.count("button.addEventListener") == 1
    title_block=html.split('{% block title %}',1)[1].split('{% endblock %}',1)[0]
    assert '<script' not in title_block


def test_unknown_commercial_fields_are_not_invented():
    product=ProductInput(title='Produto bem avaliado', category=ProductCategory.CASA, price=100, rating=4.8, review_count=1000, sold_quantity=0, seller_reputation=0, commission_pct=0, stock_available=True, affiliate_url='https://example.com/p', media_license='origem_nao_confirmada')
    result=score_product(product)
    assert result.approved
    assert any('Comissão não informada' in r for r in result.reasons)
    assert any('Reputação do vendedor não informada' in r for r in result.reasons)


def test_unconfirmed_availability_is_rejected():
    product=ProductInput(title='Produto sem estoque confirmado', category=ProductCategory.CASA, price=100, rating=4.8, review_count=1000, stock_available=False, affiliate_url='https://example.com/p')
    assert score_product(product).approved is False
