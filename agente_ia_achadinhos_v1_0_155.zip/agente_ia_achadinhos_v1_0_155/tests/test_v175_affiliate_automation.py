from app.services.affiliate_links import resolve_affiliate_link
from app.core.config import settings


def test_normal_listing_is_never_promoted_to_affiliate(monkeypatch):
    monkeypatch.setattr(settings, 'mercado_livre_affiliate_api_url', None)
    monkeypatch.setattr(settings, 'mercado_livre_affiliate_links_json', None)
    result = resolve_affiliate_link(listing_url='https://www.mercadolivre.com.br/p/MLB123')
    assert result.confirmed is False
    assert result.url == ''


def test_official_mapping_generates_link_automatically(monkeypatch):
    monkeypatch.setattr(settings, 'mercado_livre_affiliate_api_url', None)
    monkeypatch.setattr(settings, 'mercado_livre_affiliate_links_json', '{"MLB123":"https://mercadolivre.com/sec/affiliate-123"}')
    result = resolve_affiliate_link(listing_url='https://www.mercadolivre.com.br/p/MLB999', item_id='MLB123')
    assert result.confirmed is True
    assert result.source == 'official_mapping'
    assert result.url.endswith('affiliate-123')


def test_confirmed_existing_link_is_preserved(monkeypatch):
    monkeypatch.setattr(settings, 'mercado_livre_affiliate_api_url', None)
    result = resolve_affiliate_link(
        listing_url='https://www.mercadolivre.com.br/p/MLB999',
        existing_url='https://mercadolivre.com/sec/existing',
        existing_confirmed=True,
    )
    assert result.confirmed is True
    assert result.source == 'existing_confirmed'
