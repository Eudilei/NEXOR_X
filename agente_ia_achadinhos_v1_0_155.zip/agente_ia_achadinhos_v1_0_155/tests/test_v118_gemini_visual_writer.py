from app.models.schemas import ProductCategory, ProductInput, ScriptRequest
from app.services import scripts
from app.core.config import settings


def _request():
    product = ProductInput(
        title='Câmera Instantânea Fujifilm Instax Mini 12 Verde',
        category=ProductCategory.ELETRONICOS,
        marketplace='mercado_livre', price=499.0, rating=4.8, review_count=2300,
        sold_quantity=1000, affiliate_url='https://example.com/afiliado',
        media_license='oficial_marketplace'
    )
    return ScriptRequest(
        product=product, writer_engine='gemini_vision', format='humor_observacao',
        product_description='Câmera instantânea com espelho para selfie e exposição automática.',
        source_images=['https://img.example/a.jpg', 'https://img.example/b.jpg'],
        variation_index=0,
    )


def test_gemini_visual_uses_images_and_returns_scene_plan(monkeypatch):
    monkeypatch.setattr(settings, 'gemini_api_key', 'test-key')
    monkeypatch.setattr(scripts, '_gemini_inline_images', lambda urls, limit: [
        {'inline_data': {'mime_type': 'image/jpeg', 'data': 'AAA='}},
        {'inline_data': {'mime_type': 'image/jpeg', 'data': 'BBB='}},
    ])
    monkeypatch.setattr(scripts, '_gemini_json_from_response', lambda data: {
        'hook': 'Piscou estranho? Agora virou lembrança oficial.',
        'narration': 'A foto sai na hora, e isso muda completamente o jeito de usar a câmera. O espelho frontal ajuda na selfie e o corpo compacto aparece nas fotos como algo feito para levar para encontros e festas. A graça é que não existe apagar e tentar de novo: cada clique vira parte da história. Antes de comprar, confira o filme compatível e o que acompanha esta versão.',
        'spoken_cta': 'Quer ver a oferta? O link está na bio.',
        'strategy': 'nostalgia_com_punchline',
        'visual_insights': ['espelho frontal visível', 'cor verde e corpo compacto'],
        'scene_plan': ['Abrir com a foto frontal mostrando o espelho', 'Depois mostrar a câmera inteira para dar escala'],
        'why_specific': 'Usa o espelho e a impressão instantânea visíveis neste produto.'
    })
    class DummyResponse:
        status_code = 200
        text = '{}'
        def json(self): return {}
    class DummyClient:
        def __init__(self, *a, **k): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def post(self, *a, **k): return DummyResponse()
    monkeypatch.setattr(scripts.httpx, 'Client', DummyClient)
    out = scripts.generate_script(_request())
    assert 'lembrança' in out.hook.lower()
    assert any('CENA ·' in x for x in out.on_screen_text)
    assert any('2 fotos analisadas' in x for x in out.on_screen_text)
    assert '#roteiroVisual' in out.hashtags


def test_script_request_keeps_visual_context():
    req = _request()
    assert len(req.source_images) == 2
    assert 'espelho' in req.product_description.lower()
