from types import SimpleNamespace

from app.services.social_content import build_instagram_caption, caption_issues, naturalize_title


def test_title_is_naturalized_for_publication():
    assert naturalize_title("Kit C/ 3 Toalha de Banho") == "Kit com 3 toalhas de Banho"


def test_caption_has_permanent_bio_page_and_no_internal_pipeline_text(monkeypatch):
    product = SimpleNamespace(
        title="Kit C/ 3 Toalha de Banho",
        category="casa",
        rating=4.3,
        review_count=7899,
        sold_quantity=50000,
        price=99.9,
    )
    script = SimpleNamespace(hook="Seu banheiro ainda está sobrevivendo com a toalha antiga?")
    caption = build_instagram_caption(product, script)
    assert "Kit com 3 toalhas" in caption
    assert "link na bio" in caption.lower()
    assert "http" not in caption.lower()
    assert "Roteiro em estrutura" not in caption
    assert caption_issues(caption, product) == []


def test_instagram_template_exposes_schedule_batch_and_link_hub():
    html = open("app/templates/social/index.html", encoding="utf-8").read()
    assert "/achadinhos" in html
    assert "/social/instagram/agendar" in html
    assert "/social/instagram/lote" in html
    assert "caption_map" in html


def test_instagram_service_preflights_video_and_persists_publish_time():
    source = open("app/services/instagram.py", encoding="utf-8").read()
    assert "validate_public_video" in source
    assert "HTTP {response.status_code}" in source
    assert "publication.published_at" in source
    assert "start_instagram_publisher" in source
