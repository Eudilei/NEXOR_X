from app.services.instagram_automation import has_buy_intent, parse_comment_events


def test_parser_accepts_comments_and_logs_expected_shape():
    payload = {
        "object": "instagram",
        "entry": [{"changes": [{"field": "comments", "value": {
            "id": "c1", "text": "Quero", "from": {"username": "cliente"},
            "media": {"id": "m1"},
        }}]}],
    }
    assert parse_comment_events(payload) == [{
        "comment_id": "c1", "media_id": "m1", "text": "Quero", "username": "cliente"
    }]
    assert has_buy_intent("Quero")


def test_parser_accepts_singular_comment_and_flat_media_id():
    payload = {"entry": [{"changes": [{"field": "comment", "value": {
        "comment_id": "c2", "message": "manda o link", "media_id": "m2", "username": "u2"
    }}]}]}
    assert parse_comment_events(payload)[0]["media_id"] == "m2"
    assert parse_comment_events(payload)[0]["text"] == "manda o link"


def test_parser_ignores_unrelated_fields_and_malformed_entries():
    payload = {"entry": [None, {"changes": [None, {"field": "messages", "value": {}}]}]}
    assert parse_comment_events(payload) == []
