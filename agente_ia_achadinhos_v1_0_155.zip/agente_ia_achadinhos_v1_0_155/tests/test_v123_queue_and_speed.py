from pathlib import Path


def test_local_production_is_queued_not_rendered_in_request():
    main = Path("app/main.py").read_text(encoding="utf-8")
    create = main[main.index('@app.post("/scripts/{script_id}/production/new")'):main.index('@app.get("/productions/{production_id}"')]
    assert 'production.status = "na_fila"' in create
    assert '"assembly": "queued"' in create
    assert "generate_production_assets(" not in create


def test_worker_processes_local_and_heygen_jobs():
    worker = Path("app/workers/production_worker.py").read_text(encoding="utf-8")
    assert "def _assemble_local" in worker
    assert "def _assemble_heygen" in worker
    assert 'Production.status.in_(["na_fila", "montando"])' in worker
    assert 'production.status = "falhou" if attempts >= 2 else "na_fila"' in worker


def test_queue_ui_shows_position_and_cancel():
    template = Path("app/templates/productions/detail.html").read_text(encoding="utf-8")
    assert "Posição na fila" in template
    assert "/cancel" in template
    assert "window.location.reload" in template


def test_faster_scene_budget_keeps_vertical_quality():
    service = Path("app/services/production.py").read_text(encoding="utf-8")
    assert "min(7, round(duration_seconds / 3.3))" in service
    assert '"-preset", "ultrafast"' in service
    assert "VIDEO_SIZE = (720, 1280)" in service
