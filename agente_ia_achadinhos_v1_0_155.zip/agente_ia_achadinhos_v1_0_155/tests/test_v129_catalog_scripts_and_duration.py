from app.services.scripts import product_visual_facts, _product_profile
from app.services.production import _commercial_scene_texts, normalize_spoken_text_ptbr


def test_caderneta_has_semantic_title_and_attributes():
    title = "Caderneta Anotação A5 Executiva Tipo Moleskine Couro Sintético com Elástico Sem Pauta 20,5 x 13,5 cm"
    facts = product_visual_facts(title)
    assert facts["product"] == "CADERNETA A5 TIPO MOLESKINE"
    assert "CAPA EM COURO SINTÉTICO" in facts["attributes"]
    assert "CAPA COM ELÁSTICO" in facts["attributes"]
    assert "MIOLO SEM PAUTA" in facts["attributes"]


def test_scene_texts_remove_generic_fallback_and_end_with_cta():
    texts = _commercial_scene_texts(
        "Caderneta A5 Tipo Moleskine Couro Sintético",
        "VEJA OS DETALHES REAIS\nCAPA COM ELÁSTICO",
        "Para quem anota tudo e esquece onde anotou.",
        "Confira o link na bio.",
        rating=4.9, review_count=4810, sold_quantity=25000,
    )
    assert "VEJA OS DETALHES REAIS" not in texts
    assert any("MAIS DE 20 MIL VENDAS" == x for x in texts)
    assert texts[-1] == "Confira o link na bio."


def test_spoken_abbreviations_are_normalized():
    assert normalize_spoken_text_ptbr("kit c/3 unidades") == "kit com 3 unidades"
