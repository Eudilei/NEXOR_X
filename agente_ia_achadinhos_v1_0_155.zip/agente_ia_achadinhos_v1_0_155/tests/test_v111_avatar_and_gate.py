from app.models.schemas import ProductInput
from app.services import heygen
from app.services.scoring import meets_commercial_gate


def test_avatar_library_falls_back_to_looks_when_groups_are_empty(monkeypatch):
    def fake_pages(path, params, *, max_items):
        if path == "/v3/avatars":
            return []
        return [
            {"id": "ana-office", "group_id": "ana", "name": "Ana Office1", "gender": "female", "preview_image_url": "ana.jpg", "status": "completed"},
            {"id": "ana-kitchen", "group_id": "ana", "name": "Ana Kitchen2", "gender": "female", "preview_image_url": "ana2.jpg", "status": "completed"},
            {"id": "marco-office", "group_id": "marco", "name": "Marco Office1", "gender": "male", "preview_image_url": "marco.jpg", "status": "completed"},
        ]
    monkeypatch.setattr(heygen, "_request_pages", fake_pages)
    result = heygen.list_avatars(gender="feminino", age="adulto")
    assert len(result) == 1
    assert result[0]["group_id"] == "ana"
    assert result[0]["age"] == "nao_informado"
    assert len(result[0]["looks"]) == 2


def test_rating_4_is_accepted_without_minimum_sales():
    product = ProductInput(
        title="Produto", category="casa", marketplace="mercado_livre",
        affiliate_url="https://produto.mercadolivre.com.br/MLB-123",
        price=99, original_price=None, rating=4.0, review_count=500,
        sold_quantity=0, seller_reputation=0, commission_pct=0,
        stock_available=True, media_license="oficial_marketplace",
        visual_quality=5, demonstration_ease=5, novelty=5, return_risk=5,
    )
    ok, reason = meets_commercial_gate(product)
    assert ok is True
    assert "vendas não são requisito" in reason
