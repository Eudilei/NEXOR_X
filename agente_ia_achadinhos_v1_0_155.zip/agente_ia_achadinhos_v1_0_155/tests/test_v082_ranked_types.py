from app.services.marketplace import MercadoLivreClient


def test_item_public_url():
    assert MercadoLivreClient.item_public_url("MLB123456") == "https://produto.mercadolivre.com.br/MLB-123456-_JM"


def test_public_snapshot_visible_fields():
    html = '''<html><h1>Jogo de Panelas</h1>
    <span class="andes-money-amount__fraction">569</span><span class="andes-money-amount__cents">90</span>
    <div class="ui-review-capability__rating__average">4,8</div>
    <span>24.669 avaliações</span><span>+50 mil vendidos</span><button>Comprar agora</button></html>'''
    data = MercadoLivreClient._public_snapshot_from_html(html, "https://example")
    assert data["price"] == 569.90
    assert data["rating"] == 4.8
    assert data["reviews_count"] == 24669
    assert data["sold_quantity"] == 50000
    assert data["status"] == "active"
    assert data["availability_confirmed"] is True


def test_price_without_availability_is_not_offer():
    product = {"id":"MLB123", "name":"Produto", "price":99.9, "status":"active", "rating":4.8, "reviews_count":1000}
    candidate = MercadoLivreClient._candidate_from_product(product, internal_category="casa", trend_keyword="x", source="highlights", source_rank=1)
    assert candidate is not None
    assert candidate.offer_available is False
    assert candidate.seller_reputation == 0
