from app.services.marketplace import MercadoLivreClient


def test_listing_media_can_skip_third_party_item_api(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    calls = {"item": 0, "public": 0}

    monkeypatch.setattr(client, "product_detail", lambda _id: {
        "id": "MLB123",
        "buy_box_winner": {"item_id": "MLB999", "price": 99.9},
        "pictures": [{"url": "https://http2.mlstatic.com/D_NQ_NP_1.jpg"}],
    })

    def forbidden_item(_item_id):
        calls["item"] += 1
        raise AssertionError("item API should not be called")

    monkeypatch.setattr(client, "_item_detail_individual", forbidden_item)
    monkeypatch.setattr(client, "item_description", lambda _id: "")

    def public(_url):
        calls["public"] += 1
        return {
            "pictures": [{"url": "https://http2.mlstatic.com/D_NQ_NP_2.jpg"}],
            "description": "Descrição pública confirmada do produto.",
        }

    monkeypatch.setattr(client, "public_product_snapshot", public)
    result = client.listing_media_and_description(
        link="https://www.mercadolivre.com.br/p/MLB123",
        allow_item_api=False,
    )

    assert calls["item"] == 0
    assert calls["public"] >= 1
    assert len(result["pictures"]) == 2
    assert result["description"]


def test_policy_warning_is_human_and_unique():
    client = MercadoLivreClient(access_token="token")
    client._register_policy_block("/items/MLB1")
    client._register_policy_block("/items/MLB2")
    assert client.warnings == [
        "O Mercado Livre restringiu uma consulta detalhada; o agente usou fontes públicas alternativas."
    ]
    assert "/items/{id}" in client._policy_blocked_families
