from app.services.marketplace import MercadoLivreClient
from app.core.config import settings


def test_browser_fallback_disabled_returns_empty(monkeypatch):
    client = MercadoLivreClient(db=None)
    monkeypatch.setattr(settings, "mercado_livre_browser_fallback_enabled", False)
    assert client.browser_product_snapshot("https://www.mercadolivre.com.br/p/MLB123") == {}


def test_browser_snapshot_parser_reads_rendered_metrics():
    html = """
    <html><head><script type="application/ld+json">
    {"@type":"Product","name":"Produto Teste","aggregateRating":{"ratingValue":"4.8","reviewCount":"1234"},"offers":{"price":"249.99","availability":"https://schema.org/InStock"}}
    </script></head><body><span>Mais de 5 mil vendidos</span></body></html>
    """
    snap = MercadoLivreClient._public_snapshot_from_html(html, "https://www.mercadolivre.com.br/p/MLB123")
    assert snap["rating"] == 4.8
    assert snap["reviews_count"] == 1234
    assert snap["sold_quantity"] == 5000
    assert snap["sold_quantity_is_minimum"] is True
