import json
from app.db.models import Product
from app.services.zavomi_site import product_payload, set_site_flag

def product(**kwargs):
    defaults=dict(id=1,title="Kit C/ 3 Toalhas",category="casa",price=44,affiliate_url="https://produto.example/item",media_urls="https://img.example/1.jpg\nhttps://img.example/2.jpg",original_description="Descrição original completa",status="pronto_publicacao",stock_available=True,marketplace="mercado_livre",rating=4.8,review_count=900,sold_quantity=5000,source_metadata_json=json.dumps({"source_verified":True}))
    defaults.update(kwargs); return Product(**defaults)

def test_payload_has_gallery_metrics_and_normalized_title():
    payload=product_payload(product())
    assert payload["title"] == "Kit com 3 Toalhas"
    assert len(payload["images"]) == 2
    assert payload["sold_count"] == 5000 and payload["review_count"] == 900

def test_internal_note_is_never_public_description():
    p=product(original_description="Produto pré-selecionado pelo ranking oficial catalog_product_id=MLB1")
    assert product_payload(p)["description"] == ""

def test_excluded_product_is_removed():
    p=product(); set_site_flag(p,"excluded",True); assert product_payload(p) is None
