import json
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.db.database import Base
from app.db.models import Product
from app.services.autonomous import _save_preselected, _apply_product
from app.services.marketplace import Candidate
from app.models.schemas import ProductInput, ProductCategory


def _candidate_partial():
    return Candidate(
        external_id="MLB29491287",
        title="Cortina 2,00 x 1,80 m Blackout",
        category="utilidades",
        price=0.0,
        original_price=None,
        rating=0.0,
        review_count=0,
        sold_quantity=0,
        seller_reputation=0,
        stock_available=False,
        listing_url="https://www.mercadolivre.com.br/p/MLB29491287",
        thumbnail="",
        trend_keyword="cortina",
        source="ranking_preselecionado",
        source_rank=13,
        offer_available=False,
        catalog_product_id="MLB29491287",
        item_id="",
        description="",
        picture_urls=(),
    )


def _completed_product():
    return Product(
        title="Cortina preenchida manualmente",
        category="utilidades",
        marketplace="mercado_livre",
        price=52.99,
        original_price=69.90,
        rating=4.7,
        review_count=8800,
        sold_quantity=110000,
        seller_reputation=4.9,
        commission_pct=12.5,
        stock_available=True,
        visual_quality=8.0,
        demonstration_ease=8.0,
        novelty=7.0,
        return_risk=2.0,
        affiliate_url="https://meli.la/abc123",
        media_license="oficial_marketplace",
        original_description="Descrição que o usuário já completou e não pode ser apagada.",
        media_urls="https://img/1.jpg\nhttps://img/2.jpg",
        notes="Observação manual",
        score=78.0,
        classification="Boa oportunidade",
        status="pronto_publicacao",
        score_reasons="Cadastro concluído",
        source_metadata_json=json.dumps({
            "listing_url": "https://www.mercadolivre.com.br/p/MLB29491287",
            "catalog_product_id": "MLB29491287",
            "affiliate_link_confirmed": True,
        }),
    )


def test_partial_rediscovery_never_downgrades_completed_legacy_product(monkeypatch):
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    db = Session(engine)
    product = _completed_product()
    db.add(product)
    db.commit()
    monkeypatch.setattr("app.services.autonomous._automatic_affiliate", lambda *a, **k: type("A", (), {"confirmed": False, "url": "", "source": "", "error": ""})())

    created, _ = _save_preselected(db, _candidate_partial())
    db.commit()
    db.refresh(product)

    assert created is False
    assert product.status == "pronto_publicacao"
    assert product.price == 52.99
    assert product.rating == 4.7
    assert product.review_count == 8800
    assert product.sold_quantity == 110000
    assert product.commission_pct == 12.5
    assert product.affiliate_url == "https://meli.la/abc123"
    assert product.original_description.startswith("Descrição que o usuário")
    assert "https://img/1.jpg" in product.media_urls


def test_confirmed_rediscovery_updates_live_metrics_without_erasing_completed_fields():
    product = _completed_product()
    data = ProductInput(
        title="Título automático novo",
        category=ProductCategory("utilidades"),
        marketplace="mercado_livre",
        price=49.99,
        original_price=65.0,
        rating=4.8,
        review_count=9000,
        sold_quantity=111000,
        seller_reputation=0.0,
        commission_pct=0.0,
        stock_available=True,
        visual_quality=5.0,
        demonstration_ease=5.0,
        novelty=5.0,
        return_risk=5.0,
        affiliate_url="https://produto.mercadolivre.com.br/auto",
        media_license="origem_nao_confirmada",
    )
    _apply_product(product, data, score=60, classification="Potencial comercial", status="aprovado_comercial", notes="auto", reasons="auto")

    assert product.price == 49.99
    assert product.rating == 4.8
    assert product.review_count == 9000
    assert product.sold_quantity == 111000
    assert product.title == "Cortina preenchida manualmente"
    assert product.commission_pct == 12.5
    assert product.affiliate_url == "https://meli.la/abc123"
    assert product.media_license == "oficial_marketplace"
    assert product.status == "pronto_publicacao"
    assert product.classification == "Boa oportunidade"
