from app.services.marketplace import MercadoLivreClient


def test_direct_item_imports_all_pictures_and_description(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    monkeypatch.setattr(client, "_item_detail_individual", lambda item_id: {
        "id": item_id,
        "pictures": [
            {"secure_url": "https://img.example/1.jpg"},
            {"url": "https://img.example/2.jpg"},
        ],
    })
    monkeypatch.setattr(client, "item_description", lambda item_id: "Descrição original")

    data = client.listing_media_and_description(
        link="https://produto.mercadolivre.com.br/MLB-1234567890-produto-_JM"
    )

    assert data["item_id"] == "MLB1234567890"
    assert data["pictures"] == [
        "https://img.example/1.jpg",
        "https://img.example/2.jpg",
    ]
    assert data["description"] == "Descrição original"
    assert data["media_source"] == "official_marketplace"


def test_catalog_uses_buy_box_item_for_media(monkeypatch):
    client = MercadoLivreClient(access_token="token")
    catalog = {
        "id": "MLB999",
        "buy_box_winner": {"item_id": "MLB777", "price": 99.0},
        "pictures": [{"url": "https://img.example/catalog.jpg"}],
    }
    monkeypatch.setattr(client, "_item_detail_individual", lambda item_id: {
        "id": item_id,
        "pictures": [{"url": "https://img.example/item.jpg"}],
    })
    monkeypatch.setattr(client, "item_description", lambda item_id: "Texto do vendedor")

    data = client.listing_media_and_description(
        link="https://www.mercadolivre.com.br/p/MLB999", catalog_product=catalog
    )

    assert data["item_id"] == "MLB777"
    assert data["pictures"] == ["https://img.example/item.jpg"]
    assert data["description"] == "Texto do vendedor"


def test_catalog_falls_back_to_product_pictures_without_winner():
    client = MercadoLivreClient(access_token="token")
    catalog = {
        "id": "MLB999",
        "pictures": [
            {"secure_url": "https://img.example/a.jpg"},
            {"secure_url": "https://img.example/b.jpg"},
        ],
    }

    data = client.listing_media_and_description(
        link="https://www.mercadolivre.com.br/p/MLB999", catalog_product=catalog
    )

    assert data["item_id"] == ""
    assert len(data["pictures"]) == 2
    assert data["description"] == ""


def test_product_form_has_auto_fill_targets():
    html = open("app/templates/products/form.html", encoding="utf-8").read()
    assert 'id="original_description"' in html
    assert 'id="media_urls"' in html
    assert "Atualizar fotos e descrição do anúncio" in open(
        "app/templates/products/detail.html", encoding="utf-8"
    ).read()
