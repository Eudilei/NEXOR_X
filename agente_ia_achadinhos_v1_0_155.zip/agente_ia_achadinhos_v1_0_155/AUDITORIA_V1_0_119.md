# Auditoria v1.0.119

- Adicionado perfil gratuito **Narrador Cômico Zavomi**: voz masculina pt-BR, rápida, expressiva e com pausas de punchline.
- O perfil é original e não clona nem imita uma pessoa real específica.
- Novos perfis: Review natural, Vendedor dinâmico e Narrador premium.
- Seleção automática de voz passa a considerar o formato do roteiro.
- Prévia de voz continua usando o roteiro real antes da produção.
- Mantidas as melhorias do Roteirista Visual Gratuito e enquadramento de mídia.
