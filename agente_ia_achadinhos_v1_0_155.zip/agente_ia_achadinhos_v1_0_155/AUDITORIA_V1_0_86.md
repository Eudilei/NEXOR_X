# Auditoria v1.0.86 — Motor Híbrido Gratuito

## Implementado
- Novo motor `hybrid`: Roteirista Zavomi + direção multimodal Gemini + voz gratuita + Editor Zavomi.
- Análise de até 6 fotos reais, redimensionadas para reduzir memória e tráfego.
- Gemini ordena as cenas e pode refinar gancho, narração e textos de tela dentro dos fatos confirmados.
- Validação da ordem das imagens: sem repetição, sem omissão e com preservação das fotos não analisadas.
- Fallback automático e obrigatório: limite, timeout, chave ausente ou JSON inválido não interrompem a produção.
- O motor gratuito atual foi preservado e não foi duplicado internamente.
- Manifesto registra provedor, resultado da direção, fallback e aviso técnico.

## Garantia por código
O fluxo de renderização não depende do Gemini para terminar. A direção externa é opcional; a montagem, a voz gratuita e o MP4 continuam pelo motor Zavomi. Assim, a indisponibilidade da segunda IA degrada a qualidade criativa, mas não derruba a produção.

## Configuração
Adicionar no Render:
- `GEMINI_API_KEY`
- opcional: `GEMINI_VIDEO_MODEL=gemini-3.5-flash`
- opcional: `GEMINI_TIMEOUT_SECONDS=75`
