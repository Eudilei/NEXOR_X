# Auditoria v1.0.131

## Vozes
- Paridade feminina ampliada.
- Perfis de risada usam Gemini TTS e instrução não verbal após a primeira frase.
- Não há pedido de clonagem ou imitação de voz/risada de pessoa real.

## Roteiros
- Novo `humor_risada` com gerador local dedicado.
- Gemini Visual recebe regra específica para comédia primeiro e anúncio depois.
- O texto não escreve `haha`/`risos`; a risada é atuação do TTS.
