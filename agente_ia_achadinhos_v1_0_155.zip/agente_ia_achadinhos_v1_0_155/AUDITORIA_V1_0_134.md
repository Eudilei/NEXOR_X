# Auditoria v1.0.135

## Diagnóstico
A GEMINI_API_KEY já é suficiente para TTS e para o roteirista visual. Não existe uma segunda chave de visão. O roteirista visual dependia de um único caminho de modelo/resposta e podia falhar por modelo, cota, formato estruturado, rede ou fotos grandes.

## Correções
1. Failover de modelos multimodais: gemini-2.5-flash -> gemini-2.5-flash-lite -> gemini-3.6-flash.
2. Segunda tentativa compatível sem responseMimeType/topP/temperature quando necessário.
3. Headers de navegador + compressão JPEG das fotos antes do envio.
4. Diagnóstico legível para 403, 429, timeout e indisponibilidade de modelo.
5. Risada migrada para tags expressivas nativas Gemini 3.1 TTS: [laughs], [laughs uncontrollably], [gasp], [laughs].
6. Formato humor_risada aplica a risada após o gancho para qualquer perfil de voz Gemini escolhido.
7. Novos perfis cômicos com timbres distintos para homens e mulheres.

## Validação local
- Compilação Python do app concluída.
- 24 testes legados focados de voz passaram.
- Teste de failover visual simulado: 404 no primeiro modelo e sucesso automático no segundo.
- Teste de posição da risada confirmou as tags imediatamente após a primeira frase.
- Teste de diversidade cômica confirmou 6 timbres masculinos e 6 femininos distintos no conjunto auditado.

Observação: a chamada real à Gemini API depende da GEMINI_API_KEY secreta configurada no Render e não pode ser executada neste pacote local sem expor a chave.
