# Auditoria v1.0.89

Correção do bloqueio incorreto em roteiros de contraste. A auditoria visual agora identifica a capa real pela cena `recommended_product`, em vez de presumir que a primeira cena seja o produto. Isso preserva a abertura com modelos inadequados e garante que o CTA feche com o produto recomendado.
