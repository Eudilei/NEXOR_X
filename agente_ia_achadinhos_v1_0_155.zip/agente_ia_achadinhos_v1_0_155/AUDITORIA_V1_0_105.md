# Auditoria v1.0.105

## Objetivo
Completar os dados ainda pendentes na importação do Mercado Livre sem inventar métricas privadas.

## Alterações
- Segunda tentativa de avaliações depois da resolução do ITEM_ID real, incluindo até 5 ofertas do mesmo produto de catálogo.
- Atualização manual do anúncio agora também tenta preencher avaliação, quantidade de avaliações, vendas públicas, disponibilidade, preço e promoção sem apagar dados confirmados.
- Quantidade vendida só é salva quando aparece explicitamente em fonte pública/API permitida; posição em ranking nunca é convertida em vendas.
- Nova fila `/affiliate-links` para produtos sem link afiliado confirmado.
- Importação em lote de links oficiais por `ID|URL`, `ITEM_ID|URL`, `catalog_product_id|URL`, `listing_url|URL` ou apenas URLs na ordem da fila.
- Links comuns continuam separados de links afiliados e nunca são marcados automaticamente como comissionáveis.

## Validação
- Compilação Python completa sem erros.
- Testes específicos de métricas/afiliados + enriquecimento oficial + catálogo inicial: 9 aprovados.
