# Auditoria v1.0.146

Objetivo: corrigir falhas de prévia por HTTP 429 sem desmontar o motor aprovado da v136.

## Mudanças
1. `generate_gemini_tts` ganhou retry controlado, cooldown por modelo e prioridade para o último modelo funcional.
2. Ao receber 429, tenta o outro modelo Gemini antes de aguardar/repetir.
3. Perfis com risada foram reduzidos de até três chamadas Gemini para uma única chamada com tags, seguindo a estratégia simples da v136.
4. Risada continua posicionada após o gancho e antes da continuação.
5. Cache da prévia continua evitando nova chamada depois de uma geração bem-sucedida.
6. Não há fallback Edge para perfil com risada.
