# Auditoria v1.0.87 — Direção comercial e movimento real

## Diagnóstico confirmado nos vídeos 17467 e 17468

O vídeo final ainda tinha aparência de apresentação de slides: muitas imagens parecidas, cenas demais, pouca progressão comercial, movimentos discretos e narração sem vínculo explícito com a ordem visual.

## Substituições executadas

- O diretor híbrido passou a produzir um `scene_plan` semântico com até 7 cenas úteis.
- O prompt agora exige estrutura de problema, solução, benefício, prova visual e CTA.
- A seleção automática deixou de tentar usar até 12 fotos em 40 segundos.
- O renderizador deixou de concatenar JPGs estáticos.
- Cada cena agora é renderizada como segmento MP4 com movimento alternado de aproximação e deslocamento.
- A sincronização de áudio passou a usar de fato o filtro calculado para terminar antes do CTA.
- Somente gancho e CTA recebem texto sobreposto; o corpo não vira uma apresentação carregada.
- O manifesto registra objetivos, movimentos e versão do diretor.

## Fallback

Sem Gemini ou com resposta inválida, o Diretor Zavomi monta um plano compacto de 4 a 7 cenas e a produção continua.

## Validação executada

- `python -m compileall -q app`
- 20 testes focados em vídeo, produção, worker e diretor híbrido: aprovados.
- Renderização real de fumaça com 4 imagens, áudio AAC, movimentos, concatenação e MP4 final: aprovada.
- Plano de cenas gerado e validado com fechamento exato da duração.

A suíte integral foi iniciada, mas contém testes lentos que excederam o limite de execução disponível; por isso a aprovação declarada se limita aos testes focados e ao teste real de renderização descritos acima.
