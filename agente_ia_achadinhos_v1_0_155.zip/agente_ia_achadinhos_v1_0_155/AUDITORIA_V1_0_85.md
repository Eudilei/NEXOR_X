# Auditoria v1.0.85 — motor profissional de descoberta

## Problemas encontrados

- A varredura descobria e enriquecia quase todos os resultados na mesma etapa.
- Consultas detalhadas de itens de terceiros ainda eram usadas durante o enriquecimento e provocavam bloqueios PolicyAgent.
- Pendências antigas permaneciam acumuladas no painel, mesmo quando já não faziam parte da seleção atual.
- O parâmetro de limite não controlava de fato o custo do enriquecimento.
- Avisos repetidos deixavam o diagnóstico confuso.

## Correções consolidadas

1. Descoberta ampla e enriquecimento limitado aos candidatos mais bem posicionados.
2. Orçamento de enriquecimento entre 12 e 40 candidatos, conforme o limite solicitado.
3. Durante a varredura, o motor não consulta mais `/items/{id}` de anúncios de terceiros para obter preço e vendas.
4. Dados comerciais usam produto, reviews e página pública do mesmo anúncio como fontes independentes.
5. Bloqueios repetidos de uma família de endpoints interrompem novas chamadas dessa família.
6. Pendências de varreduras anteriores são arquivadas, em vez de permanecerem acumuladas no painel.
7. Cada registro recebe identificador e horário da varredura atual.
8. Estatísticas agora distinguem total descoberto, selecionado para enriquecimento e ignorado por orçamento.
9. Avisos são deduplicados antes de chegar ao painel.
10. O fluxo público antigo continua apontando para um único pipeline consolidado.

## Segurança dos dados

- Nenhum valor ausente é inventado.
- O link comum continua sendo usado somente como fonte de consulta quando o link afiliado não está confirmado.
- Produtos arquivados não são apagados; podem voltar numa varredura futura.
- Dados anteriormente confirmados permanecem preservados.

## Validação

- Compilação dos módulos alterados.
- Testes de descoberta, marketplace e versões recentes aprovados.
- Novos testes confirmam que a varredura pode evitar a API de item de terceiros e que avisos PolicyAgent não se repetem.
