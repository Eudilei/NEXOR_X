# Auditoria v1.0.113

## Objetivo
Completar automaticamente dados comerciais ausentes sem inventar métricas.

## Prioridade de enriquecimento
1. quantidade vendida;
2. comissão;
3. estoque/disponibilidade;
4. nota e quantidade de avaliações;
5. preço anterior;
6. link afiliado.

## Fontes
- APIs permitidas do Mercado Livre;
- oferta/buy box e página pública;
- PDP de catálogo;
- navegador público sem login/cookies como último fallback;
- integração/mapa oficial de afiliados configurada.

## Segurança de dados
- valores confirmados são preservados;
- comissão só é gravada quando uma integração oficial retorna porcentagem explícita;
- ranking não é convertido em vendas;
- ausência continua marcada como indisponível;
- tentativas usam backoff para evitar consultas excessivas.

## Automação
Worker incremental processa pequenos lotes periodicamente e registra em `source_metadata_json` a fonte, campos pendentes, tentativa, próxima tentativa e erro.
