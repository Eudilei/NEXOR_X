# Auditoria v1.0.125

- Corrigida a prévia de voz: headers HTTP agora são ASCII-safe; emojis/em dash não quebram mais o FileResponse.
- Fallback Edge consulta a lista real de vozes pt-BR disponível em runtime e evita nomes que o endpoint público não suporta.
- Preço atual passa a priorizar a PDP pública visível ao comprador e pode corrigir preço antigo já preenchido.
- Título público atual pode corrigir título de variação/catálogo obsoleto.
- Parser de vendas entende “250 mil”, “1,2 mi” e similares.
- Adicionados testes de regressão para prévia de voz e métricas públicas.
