# Auditoria v1.0.103 — preservação e enriquecimento real de dados

## Causa raiz encontrada
A v1.0.102 ainda descartava dados em dois pontos críticos:
1. `/products/{catalog_product_id}/items` era reduzido a uma lista de IDs, eliminando preço/status/estoque que o próprio endpoint já havia retornado. Depois o agente tentava recuperar tudo novamente em `/items/{id}`, sujeito a 403 PolicyAgent.
2. Quando a oferta não atingia todos os critérios de qualificação, o objeto `Candidate` pré-selecionado era recriado sem `item_id`, descrição, galeria e fontes; `_save_preselected` também não persistia esse conteúdo. Resultado: a tela Completar dados aparecia vazia mesmo quando a varredura havia coletado dados parciais.

## Correções
- Novo `product_offers()` preserva a resposta completa de `/products/{id}/items`.
- Preço/status/disponibilidade da resposta de competição são utilizados diretamente antes de qualquer fallback.
- Durante descoberta de terceiros, não chama `/items/{id}` para mídia; usa a página pública e APIs específicas apenas para completar campos faltantes.
- Extração de ITEM_ID de estados JSON da PDP pública quando disponível.
- `_candidate_from_product` reconhece `payload.item_id` resolvido.
- Pré-selecionados preservam preço, preço anterior, nota, avaliações, vendas, item_id, descrição, fotos e fontes já obtidas.
- `_save_preselected` persiste descrição, galeria, item real e metadados mesmo quando ainda falta algum campo essencial.
- Observação de pendência agora lista apenas os campos realmente ausentes.
