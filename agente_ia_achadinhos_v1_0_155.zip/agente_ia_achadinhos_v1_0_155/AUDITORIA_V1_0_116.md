# Auditoria v1.0.116

## Objetivo
Eliminar repetição estrutural dos roteiros e impedir cortes visuais nas fotos dos vídeos.

## Alterações
- Diversificação determinística por produto, categoria, formato e variação.
- 18 estruturas de roteiro e 8 ângulos comerciais.
- Contrato de diversidade reforçado no roteirista OpenAI.
- Limpeza de finais truncados após ajuste de duração.
- Render de cena em 720x1280 preservado integralmente no FFmpeg, com fade leve em vez de zoompan/crop.

## Segurança editorial
- Nenhum dado comercial novo é inferido ou inventado.
- Regras de prova social e claims confirmados permanecem inalteradas.
