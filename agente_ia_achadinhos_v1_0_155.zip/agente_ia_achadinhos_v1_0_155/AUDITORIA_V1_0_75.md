# Auditoria v1.0.76 — links afiliados automáticos

## Falha encontrada
A v1.0.74 armazenava o link comum do produto no campo `affiliate_url` enquanto o link afiliado não era confirmado. A tela de confirmação também misturava os dois endereços.

## Correção
- link original preservado apenas em `source_metadata.listing_url`;
- geração automática por integração oficial configurável ou mapa/feed oficial;
- nenhuma conversão inventada do link comum;
- tela separa link original e link afiliado;
- varredura tenta gerar e confirmar o link antes da confirmação do produto;
- site, roteiros e publicações continuam bloqueados sem `affiliate_link_confirmed`;
- botão para repetir a geração automática;
- fallback manual fica disponível apenas quando a integração oficial falhar.

## Variáveis novas
- `MERCADO_LIVRE_AFFILIATE_API_URL`
- `MERCADO_LIVRE_AFFILIATE_API_TOKEN`
- `MERCADO_LIVRE_AFFILIATE_API_TIMEOUT_SECONDS`
- `MERCADO_LIVRE_AFFILIATE_LINKS_JSON`

Sem uma fonte oficial configurada, o agente informa a pendência em vez de apresentar o link comum como afiliado.
