# Auditoria v1.0.83

## Correção executada

O cadastro manual por link afiliado agora tenta recuperar a galeria completa do anúncio, não apenas a imagem principal.

### Alterações
- Extração de todas as imagens oficiais presentes no JSON-LD da página.
- Extração de URLs `mlstatic.com` presentes nos estados JSON embutidos.
- Suporte a URLs escapadas (`https:\/\/...`).
- Deduplicação e limite de 24 fotos.
- Complementação automática pela página pública mesmo quando a API retorna somente a capa.
- Preservação do link afiliado para publicação e uso do link resolvido apenas para coleta.

## Validação
- Compilação completa do diretório `app` aprovada.
- Testes direcionados de cadastro manual, galeria, descrição e link afiliado aprovados.
