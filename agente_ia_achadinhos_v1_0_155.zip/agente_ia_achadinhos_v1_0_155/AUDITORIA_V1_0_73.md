# Auditoria v1.0.73

- Busca completa antes do ranking: item real, preço, estoque, descrição, fotos, nota, avaliações e vendas.
- Preserva link afiliado confirmado durante novas varreduras.
- Roteiros só são gerados após confirmação do link afiliado e incluem esse link automaticamente nas legendas.
- Métricas guardam origem para evitar mistura silenciosa entre anúncio e catálogo.
