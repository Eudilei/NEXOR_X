# Auditoria v1.0.91

- Corrigido conflito com variáveis legadas de verificação do TikTok no Render.
- As três URLs atuais passam a ser servidas mesmo quando TIKTOK_URL_VERIFICATION_CONTENT antigo permanece configurado.
- Compatibilidade com arquivo legado preservada.
