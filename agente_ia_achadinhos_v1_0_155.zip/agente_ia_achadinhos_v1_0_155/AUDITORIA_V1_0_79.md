# Auditoria v1.0.79

## Correção
- Campo Avaliação inicia vazio no cadastro manual, usando `4,9` apenas como exemplo visual.
- Ao tocar no campo, o conteúdo inteiro é selecionado para substituição imediata.
- Backspace/Delete remove completamente o valor selecionado.
- Respostas automáticas com avaliação zero deixam o campo vazio, em vez de preencher `0,0`.
- Mantida a máscara por dígitos: `49` vira `4,9` e o limite permanece em `5,0`.

## Escopo
- Tela Cadastrar e avaliar.
- Tela Completar dados.
