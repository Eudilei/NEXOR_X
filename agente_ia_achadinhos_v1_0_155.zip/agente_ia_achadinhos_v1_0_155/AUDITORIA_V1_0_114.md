# Auditoria v1.0.114

## Objetivo
Corrigir lentidão/reinicialização observada no Render após a v1.0.113 sem remover o enriquecimento comercial.

## Correções
- Fallback Playwright desligado por padrão; pode ser reativado por variável de ambiente quando Chromium estiver realmente instalado.
- Preflight global verifica o executável uma única vez e desativa novas tentativas quando ausente.
- Timeout do navegador reduzido para 7 s, máximo de 2 páginas por varredura e espera dinâmica reduzida.
- Worker de enriquecimento inicia após 300 s, processa no máximo 3 produtos por ciclo e roda em intervalo mínimo de 30 min / padrão 1 h.
- Política 403 do Mercado Livre continua usando circuit breaker por família de endpoint.

## Garantias
Nenhuma métrica é inventada. Valores já confirmados são preservados e campos ausentes continuam pendentes para nova tentativa.
