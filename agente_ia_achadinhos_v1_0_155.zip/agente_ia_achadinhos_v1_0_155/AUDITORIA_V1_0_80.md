# Auditoria v1.0.80

## Falha confirmada
A máscara do campo Avaliação era executada a cada tecla. Em navegadores móveis isso reescrevia o valor, deslocava o cursor e impedia apagar ou substituir `0,0` naturalmente. A tela Completar dados também continha o mesmo script de máscara duplicado.

## Correção
- Avaliação aceita somente os dígitos crus durante a edição.
- A conversão `49 -> 4,9` ocorre apenas no evento `blur`.
- Campo vazio permanece vazio.
- Ao receber foco, o conteúdo existente é selecionado para substituição direta.
- Removido o script duplicado da tela Completar dados.
- Mantido o limite máximo de 5,0.

## Testes
Foram adicionados testes de regressão para garantir máscara somente no blur e apenas um script ativo na tela Completar dados.
