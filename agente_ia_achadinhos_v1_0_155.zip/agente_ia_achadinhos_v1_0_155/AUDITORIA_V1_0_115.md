# Auditoria v1.0.115

## Objetivo
Priorizar o enriquecimento comercial dos produtos pré-selecionados pelo ranking oficial, sem sobrecarregar o Render.

## Alterações
- Pré-selecionados (`pre_selecionado`) passam na frente dos demais produtos no worker periódico.
- Dentro dos pré-selecionados, a melhor posição no ranking oficial tem prioridade.
- Ao concluir uma varredura do Mercado Livre, o worker executa um pequeno lote de enriquecimento prioritário (padrão: 6 produtos).
- O lote pós-varredura roda fora do boot web e mantém o Playwright desativado por padrão no Render.
- Metadados passam a registrar prioridade e posição de ranking usada no enriquecimento.
- Demais produtos continuam no enriquecimento periódico normal após os candidatos prioritários.

## Segurança de dados
Nenhuma métrica é inferida ou inventada. Valores só são salvos quando confirmados pelas fontes suportadas.
