# Auditoria v1.0.150

## Evidências do vídeo 19282.mp4
- Duração total observada: aproximadamente 12m15s.
- O maior gargalo continuou na etapa "Criando o vídeo", que permaneceu por vários minutos.
- O TikTok não concluiu Direct Post público; o histórico mostrou `Enviado TikTok Revisão`, confirmando que o fallback `video.upload` funcionou.
- Faltava uma ação visível para abrir o TikTok após esse envio.

## Correções
1. Removida a codificação separada de cada cena seguida de uma segunda codificação do vídeo completo.
2. As cenas agora são concatenadas como imagens com duração e codificadas uma única vez junto com o áudio (`fps=15`, H.264 ultrafast).
3. Adicionado botão para abrir o TikTok quando o vídeo estiver aguardando revisão/publicação no app.
4. Publicações com `remote_url` continuam abrindo diretamente o post.

## Compatibilidade
Nenhuma rota OAuth, token, banco, status de produção, Instagram ou endpoint TikTok foi removido.
