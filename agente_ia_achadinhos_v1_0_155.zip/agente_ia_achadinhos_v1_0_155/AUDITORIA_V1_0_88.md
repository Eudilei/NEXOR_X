# Auditoria v1.0.88

## Objetivo
Corrigir a direção visual de roteiros do tipo "erro comum", preservando imagens de outros modelos como contraste intencional no início e impedindo que essas imagens voltem após a apresentação do produto recomendado.

## Alterações
- Adicionados papéis semânticos de cena: `contrast`, `transition`, `recommended_product`, `feature`, `use_case`, `detail`, `proof` e `cta`.
- O Gemini foi instruído a usar no máximo duas cenas de contraste antes do produto recomendado.
- O código valida o plano retornado e remove qualquer contraste que apareça depois de `recommended_product`.
- O fallback gratuito também reconhece roteiros comparativos por expressões como "erro comum", "evite" e "mais adequado".
- A capa/CTA final passa a usar a primeira imagem marcada como produto recomendado, e não a imagem de contraste.
- A duração das cenas foi ajustada para tornar o contraste curto e dar mais tempo ao produto indicado.
- O manifesto agora registra `commercial_storyboard_v4_contrast_aware`.

## Garantias de código
- Contraste só é permitido antes do produto recomendado.
- O plano precisa conter uma cena `recommended_product` em roteiros comparativos.
- Depois da transição, papéis `contrast` ou `transition` são convertidos em cenas normais do produto.
- Sem Gemini, o comportamento continua disponível no Diretor Zavomi gratuito.

## Validação
- Compilação completa de `app` aprovada.
- Testes v1.0.86 e v1.0.87 de direção híbrida aprovados.
- Novos testes v1.0.88 aprovados para contraste intencional e bloqueio de contraste tardio.
- A suíte completa foi iniciada e avançou sem falhas observadas, mas excedeu o limite de execução disponível nesta sessão; por isso não é declarada como concluída integralmente.
