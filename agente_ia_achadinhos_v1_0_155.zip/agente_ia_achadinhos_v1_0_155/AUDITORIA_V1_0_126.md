# Auditoria v1.0.127

Problema confirmado no vídeo 18849: as prévias indicavam `edge_tts_free`. O Edge público pt-BR não entregava os vários nomes configurados e o resolver acabava reutilizando as mesmas vozes físicas.

Correção: perfis de diversidade são Gemini-only, cada um com `gemini_voice` próprio. Se Gemini não estiver configurado/falhar, a aplicação informa o erro e não substitui silenciosamente por Antonio/Francisca. Os dois fallbacks Edge ficam explícitos.
