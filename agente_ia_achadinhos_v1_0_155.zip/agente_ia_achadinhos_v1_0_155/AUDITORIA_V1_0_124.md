# Auditoria v1.0.124

Correção focada na prévia de narração.

- seleção manual preservada;
- áudio sempre regenerado com o roteiro atual;
- cache desabilitado;
- retorno HTTP com erro legível quando Gemini/Edge falham;
- UI exibe perfil/provedor usados;
- reprodução automática tem fallback para botão play quando o navegador bloquear autoplay.
