# Auditoria v1.0.84

## Problemas confirmados
- A coleta pública aceitava recursos visuais da interface do Mercado Livre, inclusive páginas anti-bot e assets de botões.
- A rotina agregava fotos de produtos filhos/variações, podendo misturar cores, modelos e ofertas diferentes.
- Uma única URL de imagem com erro 404 interrompia toda a produção do vídeo.

## Correções
- A extração pública aceita somente arquivos de produto com padrão D_NQ_NP/D_Q_NP.
- Recursos frontend-assets, suspicious-traffic, sprites, ícones, logos e placeholders são descartados.
- Imagens de produtos filhos/variações não são mais agregadas ao anúncio principal.
- O downloader valida cada imagem individualmente e ignora URLs quebradas sem cancelar o vídeo.
- Imagens pequenas, estreitas, não-imagem ou acima de 12 MB são rejeitadas.
- Cabeçalhos de navegador e Referer do Mercado Livre são usados ao baixar imagens.

## Validação
- Compilação integral do diretório app concluída.
- Testes específicos de mídia e produção aprovados.
- Testes de filtro de assets e tolerância a 404 adicionados.
