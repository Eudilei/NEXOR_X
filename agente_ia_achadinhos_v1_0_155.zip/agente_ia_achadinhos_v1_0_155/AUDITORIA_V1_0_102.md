# Auditoria v1.0.102

Correção do CSRF dos botões de exclusão na tela Produtos.

## Causa
O template `products/list.html` usava `{{ csrf }}` nos formulários de exclusão, enquanto `template_context()` expõe o token como `csrf_token`. O POST chegava com token vazio e `validate_csrf()` retornava HTTP 403 `Token de segurança inválido`.

## Correção
- Exclusão individual passa `{{ csrf_token }}`.
- Exclusão total passa `{{ csrf_token }}`.
- Mantidas confirmações antes da exclusão.
