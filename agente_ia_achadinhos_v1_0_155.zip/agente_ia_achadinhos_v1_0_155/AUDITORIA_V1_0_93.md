# Auditoria v1.0.93 — Catálogo inicial Zavomi

## Objetivo
Iniciar o agente com meta de 25 produtos em cada uma das 20 categorias oficiais (500 produtos), usando o mesmo pipeline profissional de descoberta, classificação, pontuação, persistência e publicação do agente.

## Implementação
- Carga inicial automática e idempotente após o deploy.
- Processamento separado por categoria para preservar equilíbrio de 25 produtos por categoria.
- Produtos existentes contam para a meta e não são duplicados.
- Novas tentativas em deploys seguintes completam categorias que ficaram abaixo da meta por bloqueio temporário ou falta de ofertas qualificadas.
- Links comuns continuam separados de links afiliados. O site publica somente links afiliados confirmados pela integração oficial já configurada.
- Sincronização do catálogo com o repositório do site ao final da carga.

## Variáveis
- `INITIAL_CATALOG_BOOTSTRAP_ENABLED=true`
- `INITIAL_CATALOG_PRODUCTS_PER_CATEGORY=25`
- `INITIAL_CATALOG_MAX_ROUNDS=4`
- `INITIAL_CATALOG_PAUSE_SECONDS=2`

## Segurança comercial
Nenhum link comum é rotulado como afiliado. A geração depende de `MERCADO_LIVRE_AFFILIATE_API_URL`/token ou de `MERCADO_LIVRE_AFFILIATE_LINKS_JSON`.
