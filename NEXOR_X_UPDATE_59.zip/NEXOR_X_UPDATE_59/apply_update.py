
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def verify_update_58_present() -> None:
    runner = ROOT / "tools/validation_campaign_runner.py"
    verifier = ROOT / "tools/rc_verify.py"

    if not runner.exists():
        raise RuntimeError(
            "Update 58 não detectada: validation_campaign_runner.py ausente"
        )
    if not verifier.exists():
        raise RuntimeError(
            "Update 57 não detectada: rc_verify.py ausente"
        )


def copy_payload() -> None:
    for rel in (
        "tools/evidence_progress_recorder.py",
        "tests/test_evidence_progress_recorder.py",
        "docs/AUDIT_UPDATE_59.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.59.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.59.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    verify_update_58_present()
    copy_payload()
    patch_version()
    print(
        "NEXOR X Update 59 aplicada: Evidence Progress Recorder instalado. "
        "Trading runtime não alterado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
