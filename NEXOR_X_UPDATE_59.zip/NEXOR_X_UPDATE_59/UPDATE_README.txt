NEXOR X UPDATE 59 — EVIDENCE PROGRESS RECORDER

Objetivo:
  acompanhar a evidência real acumulada pelo NEXOR durante a fase PAPER/TESTNET.

O recorder consulta:
  - GET /api/live/certification
  - GET /api/validation/final-snapshot
  - GET /api/validation/release-candidate

Registra:
  - status da certificação;
  - progresso da campanha;
  - candidate_ready;
  - evidence_certified;
  - blockers atuais;
  - métricas retornadas pela certificação;
  - histórico temporal em JSONL.

Arquivos:
  reports/evidence_progress_history.jsonl
  reports/evidence_progress_latest.json

Uso:
  python tools/evidence_progress_recorder.py --once

ou continuamente:
  python tools/evidence_progress_recorder.py

Variáveis:
  NEXOR_BASE_URL=http://127.0.0.1:8000
  NEXOR_ADMIN_TOKEN=<token administrativo>
  NEXOR_EVIDENCE_INTERVAL_SECONDS=1800

IMPORTANTE:
  - read-only;
  - não chama endpoints de ordem;
  - não altera PAPER/TESTNET;
  - não habilita LIVE.

LIVE permanece bloqueado.
