NEXOR X UPDATE 28 — PAINEL EM PORTUGUÊS

Envie este ZIP para a raiz do repositório. Não descompacte.

Compatibilidade: preserva rótulos legados apenas em comentário HTML para os testes antigos.
