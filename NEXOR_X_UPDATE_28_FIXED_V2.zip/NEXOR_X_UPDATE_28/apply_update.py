from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.28.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.28.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_version()
    print("NEXOR X Update 28 aplicado com sucesso.")


if __name__ == "__main__":
    main()
