NEXOR X UPDATE 48 — TRANSACTIONAL ENTRY RESERVATION INTEGRATION

Objetivo:
  conectar de fato o Atomic Entry Reservation Guard da Update 47 aos pontos
  reais de criação de nova exposição.

Fluxo PAPER:
  reserve -> paper_open -> confirm
  em exceção: release

Fluxo TESTNET:
  reserve -> testnet_order_create -> confirm
  em exceção: release

Regras:
  - uma nova entrada concorrente é rejeitada enquanto houver reserva ativa;
  - a reserva é confirmada automaticamente em retorno bem-sucedido;
  - a reserva é liberada automaticamente se a operação gerar exceção;
  - reduce-only ignora a reserva, preservando saídas e proteções;
  - TTL de segurança continua em 30 segundos;
  - LIVE permanece bloqueado.

A integração é feita por context manager transacional, evitando deixar reservas
presas em retornos antecipados dentro dos métodos.

Requer NEXOR X 0.47.0.
