
from __future__ import annotations

import ast
from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    items = (
        (
            PAYLOAD / "src/nexor_x/operations/entry_reservation.py",
            ROOT / "src/nexor_x/operations/entry_reservation.py",
        ),
        (
            PAYLOAD / "tests/test_entry_reservation_transaction.py",
            ROOT / "tests/test_entry_reservation_transaction.py",
        ),
        (
            PAYLOAD / "docs/AUDIT_UPDATE_48.md",
            ROOT / "docs/AUDIT_UPDATE_48.md",
        ),
    )
    for src, dst in items:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _find_method(tree: ast.AST, name: str) -> ast.AsyncFunctionDef:
    matches = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.AsyncFunctionDef) and node.name == name
    ]
    if len(matches) != 1:
        raise RuntimeError(
            f"Esperado exatamente um método async {name}; encontrado {len(matches)}"
        )
    return matches[0]


def _wrap_method_body(
    text: str,
    *,
    method_name: str,
    wrapper_lines: list[str],
    already_marker: str,
) -> str:
    if already_marker in text:
        return text

    tree = ast.parse(text)
    node = _find_method(tree, method_name)

    if not node.body:
        raise RuntimeError(f"Método {method_name} não possui corpo")

    lines = text.splitlines(keepends=True)
    body_start = node.body[0].lineno - 1
    body_end = node.end_lineno

    # O corpo original do método está em 8 espaços. Ele passa a ficar dentro
    # do `with`, portanto recebe mais 4 espaços.
    original = lines[body_start:body_end]
    indented = [
        ("    " + line if line.strip() else line)
        for line in original
    ]

    wrapper = [line + "\n" for line in wrapper_lines]
    lines[body_start:body_end] = wrapper + indented
    return "".join(lines)


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    required = "self.entry_reservation_guard = AtomicEntryReservationGuard("
    if required not in text:
        raise RuntimeError(
            "Update 47 não detectada: entry_reservation_guard ausente"
        )

    paper_wrapper = [
        "        with self.entry_reservation_guard.transaction(",
        '            action="PAPER_OPEN",',
        '            metadata={"symbol": symbol},',
        "        ):",
    ]
    text = _wrap_method_body(
        text,
        method_name="paper_open",
        wrapper_lines=paper_wrapper,
        already_marker='action="PAPER_OPEN_TRANSACTION"',
    )

    # Marca semanticamente a integração sem depender de comentário dentro do
    # wrapper para detecção idempotente.
    paper_token = '            action="PAPER_OPEN",\n'
    if 'action="PAPER_OPEN_TRANSACTION"' not in text:
        text = text.replace(
            paper_token,
            '            action="PAPER_OPEN_TRANSACTION",\n',
            1,
        )

    testnet_wrapper = [
        "        with self.entry_reservation_guard.transaction(",
        '            action="TESTNET_CREATE_TRANSACTION",',
        '            metadata={"symbol": payload.get("symbol")},',
        '            bypass=bool(payload.get("reduce_only", False)),',
        "        ):",
    ]
    text = _wrap_method_body(
        text,
        method_name="testnet_order_create",
        wrapper_lines=testnet_wrapper,
        already_marker='action="TESTNET_CREATE_TRANSACTION"',
    )

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.48.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = _read(init)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.48.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_kernel()
    patch_version()
    print(
        "NEXOR X Update 48 aplicada: reserva transacional integrada "
        "a PAPER e TESTNET. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
