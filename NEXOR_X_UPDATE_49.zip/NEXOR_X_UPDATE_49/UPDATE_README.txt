NEXOR X UPDATE 49 — TRANSACTIONAL PROBATION COMMIT

Corrige a contagem da provacao: uma admissao so e consumida depois que PAPER/TESTNET termina com sucesso. Falhas nao consomem vaga nem avancam o degrau de exposicao.

Fluxo: avaliar -> calcular multiplicador -> executar -> commit somente no sucesso.

Resultado: 1a entrada 25%, 2a 50%, 3a 75%; falha nao altera o contador; reduce-only nao conta.

LIVE permanece bloqueado.
