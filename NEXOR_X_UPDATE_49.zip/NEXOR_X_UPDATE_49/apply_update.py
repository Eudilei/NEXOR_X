from __future__ import annotations
import ast
from pathlib import Path
import re, shutil
ROOT=Path.cwd(); HERE=Path(__file__).resolve().parent; PAYLOAD=HERE/'payload'

def _read(p:Path)->str:
    if not p.exists(): raise RuntimeError(f'Arquivo obrigatório não encontrado: {p}')
    return p.read_text(encoding='utf-8')

def copy_payload():
    for rel in ('src/nexor_x/operations/post_recovery_probation.py','tests/test_transactional_probation_commit.py','docs/AUDIT_UPDATE_49.md'):
        s=PAYLOAD/rel; d=ROOT/rel; d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(s,d)

def _find_method(tree,name):
    m=[n for n in ast.walk(tree) if isinstance(n,ast.AsyncFunctionDef) and n.name==name]
    if len(m)!=1: raise RuntimeError(f'Esperado um método {name}; encontrado {len(m)}')
    return m[0]

def _wrap(text,method,lines_to_add,marker):
    if marker in text: return text
    node=_find_method(ast.parse(text),method); lines=text.splitlines(keepends=True)
    start=node.body[0].lineno-1; end=node.end_lineno
    original=lines[start:end]; indented=[('    '+ln if ln.strip() else ln) for ln in original]
    lines[start:end]=[ln+'\n' for ln in lines_to_add]+indented
    return ''.join(lines)

def patch_kernel():
    p=ROOT/'src/nexor_x/kernel.py'; t=_read(p)
    if 'action="PAPER_OPEN_TRANSACTION"' not in t or 'action="TESTNET_CREATE_TRANSACTION"' not in t:
        raise RuntimeError('Update 48 não detectada')
    t=t.replace('probation = self.post_recovery_probation.admit(\n','probation = self.post_recovery_probation.evaluate(\n',1)
    if 'self.post_recovery_probation.admit(' in t: raise RuntimeError('admit pré-execução ainda presente')
    t=_wrap(t,'paper_open',[
        '        with self.post_recovery_probation.successful_entry_transaction(',
        '            action="PAPER_OPEN_SUCCESS",','            bypass=False,','        ):'
    ],'action="PAPER_OPEN_SUCCESS"')
    t=_wrap(t,'testnet_order_create',[
        '        with self.post_recovery_probation.successful_entry_transaction(',
        '            action="TESTNET_CREATE_SUCCESS",','            bypass=bool(payload.get("reduce_only", False)),','        ):'
    ],'action="TESTNET_CREATE_SUCCESS"')
    p.write_text(t,encoding='utf-8')

def patch_version():
    p=ROOT/'pyproject.toml'; t=_read(p); p.write_text(re.sub(r'version = "[^"]+"','version = "0.49.0"',t,count=1),encoding='utf-8')
    i=ROOT/'src/nexor_x/__init__.py'; t=_read(i); i.write_text(re.sub(r'__version__\s*=\s*"[^"]+"','__version__ = "0.49.0"',t),encoding='utf-8')

def main():
    copy_payload(); patch_kernel(); patch_version(); print('NEXOR X Update 49 aplicada. LIVE permanece bloqueado.')
if __name__=='__main__': main()
