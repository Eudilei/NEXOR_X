NEXOR X UPDATE 52 — OPERATIONAL ACCEPTANCE AUDIT

Objetivo:
  executar uma auditoria automática de ponta a ponta sobre os gates
  operacionais já implementados.

A auditoria verifica:
  - LIVE continua bloqueado em todas as camadas;
  - readiness e certification não se contradizem;
  - degradation BLOCKED impede nova entrada;
  - entry trace e readiness summary concordam;
  - exposure_multiplier está entre 0 e 1;
  - blockers de entrada aparecem no resumo consolidado;
  - read-only endpoints continuam marcados como read_only;
  - PAPER/TESTNET não ficam liberados quando o sistema está BLOCKED.

Resultado:
  PASS
  FAIL

Novo endpoint administrativo:
  GET /api/operations/acceptance-audit

IMPORTANTE:
  PASS não habilita LIVE.
  Ele significa somente que a arquitetura atual está coerente para
  PAPER/TESTNET e pronta para a campanha final de validação.

LIVE permanece bloqueado.

Requer NEXOR X 0.51.0.
