NEXOR X UPDATE 31 — GESTOR DA CAMPANHA DE VALIDAÇÃO

Envie este ZIP para a raiz do repositório.
Não descompacte e não use Codespaces.

O GitHub Actions executará a suíte completa antes do commit automático.
