from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.campaign import ValidationCampaignService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.validation_campaign = ValidationCampaignService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        text = text.replace(
            marker,
            "        self.validation_campaign = "
            "ValidationCampaignService(self.database)\n"
            + marker,
            1,
        )

    if "await self.validation_campaign.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.validation_campaign.start()\n",
            1,
        )

    if "async def validation_campaign_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def validation_campaign_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.validation_campaign.status()\n\n"
            "    async def validation_campaign_evaluate(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.validation_campaign.evaluate(payload)\n"
            "        await self.event_bus.publish(Event(\n"
            "            'validation.campaign_evaluated',\n"
            "            {\n"
            "                'phase': result['phase'],\n"
            "                'continue_campaign': result['continue_campaign'],\n"
            "                'paper_allowed': result['paper_allowed'],\n"
            "                'testnet_allowed': result['testnet_allowed'],\n"
            "                'live_allowed': False,\n"
            "            },\n"
            "            'validation_campaign',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if "class ValidationCampaignRequest(BaseModel):" not in text:
        marker = "class ChatRequest(BaseModel):\n"
        if marker not in text:
            raise RuntimeError("ChatRequest marker not found")
        model = (
            "class ValidationCampaignRequest(BaseModel):\n"
            "    days_running: int = Field(ge=0, le=100000)\n"
            "    paper_trades: int = Field(ge=0, le=100000000)\n"
            "    profit_factor: float = Field(ge=0, le=1000)\n"
            "    expected_r: float = Field(ge=-100, le=100)\n"
            "    drawdown_pct: float = Field(ge=0, le=100)\n"
            "    recent_profit_factor: float = Field(ge=0, le=1000)\n"
            "    recent_expected_r: float = Field(ge=-100, le=100)\n"
            "    operational_incidents: int = Field(ge=0, le=1000000)\n"
            "    critical_test_failures: int = Field(ge=0, le=1000000)\n"
            "    integration_healthy: bool\n"
            "    recovery_ok: bool\n"
            "    supervisor_paper_allowed: bool\n"
            "    supervisor_testnet_allowed: bool\n\n"
        )
        text = text.replace(marker, model + marker, 1)

    if '@app.get("/api/validation/campaign/status")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.get("/api/validation/campaign/status")\n'
            "    async def validation_campaign_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_campaign_status()\n\n"
            '    @app.post("/api/validation/campaign/evaluate")\n'
            "    async def validation_campaign_evaluate(\n"
            "        body: ValidationCampaignRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_campaign_evaluate(\n"
            "            body.model_dump()\n"
            "        )\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.31.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.31.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 31 aplicado com sucesso.")


if __name__ == "__main__":
    main()
