from pathlib import Path

def test_auto_paper_reads_positions_list_not_open_position_count():
    text=Path("src/nexor_x/autopaper/service.py").read_text(encoding="utf-8")
    assert 'portfolio.get("positions")' in text

def test_position_management_is_scheduled():
    text=Path("src/nexor_x/kernel.py").read_text(encoding="utf-8")
    assert "auto_position_management_cycle" in text
    assert "_scheduled_auto_position_management" in text
