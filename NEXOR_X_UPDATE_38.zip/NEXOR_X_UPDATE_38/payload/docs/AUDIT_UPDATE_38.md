# Update 38 — Gestão Autônoma das Posições PAPER

Fecha o ciclo autônomo em Simulação. O gestor acompanha continuamente posições abertas e usa a política já existente de stop protetivo, break-even, parcial e trailing. Por padrão roda a cada 5 segundos.

Também corrige um erro encontrado na Update 37: `PortfolioService.snapshot()` entrega a lista real em `positions`, enquanto `open_positions` é apenas uma contagem.

LIVE permanece bloqueado.
