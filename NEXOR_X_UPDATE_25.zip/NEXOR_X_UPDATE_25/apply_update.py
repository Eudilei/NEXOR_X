from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_connector() -> None:
    path = ROOT / "src/nexor_x/exchange/binance_live.py"
    text = path.read_text(encoding="utf-8")

    if "async def testnet_positions(" not in text:
        marker = "    async def get_testnet_order(\n"
        if marker not in text:
            raise RuntimeError("get_testnet_order marker not found")
        methods = (
            "    async def testnet_positions(self) -> list[dict[str, Any]]:\n"
            "        if not self.policy.use_testnet:\n"
            "            raise RuntimeError('Position query is restricted to TESTNET')\n"
            "        result = await self._signed_get('/fapi/v2/positionRisk', {})\n"
            "        if isinstance(result, dict):\n"
            "            return list(result.get('positions') or [])\n"
            "        return list(result)\n\n"
            "    async def testnet_open_orders(self) -> list[dict[str, Any]]:\n"
            "        if not self.policy.use_testnet:\n"
            "            raise RuntimeError('Open order query is restricted to TESTNET')\n"
            "        result = await self._signed_get('/fapi/v1/openOrders', {})\n"
            "        if isinstance(result, dict):\n"
            "            return list(result.get('orders') or [])\n"
            "        return list(result)\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    # Signed GET originally annotated dict; testnet position/openOrders return lists.
    text = text.replace(
        "    ) -> dict[str, Any]:\n"
        "        client = self._require_client()\n"
        "        timestamp = int(time.time() * 1000) + self._time_offset_ms\n",
        "    ) -> Any:\n"
        "        client = self._require_client()\n"
        "        timestamp = int(time.time() * 1000) + self._time_offset_ms\n",
        1,
    )

    old_return = "        return dict(response.json())\n"
    if old_return in text:
        # Replace only the final occurrence used by _signed_get.
        pos = text.rfind(old_return)
        text = text[:pos] + "        return response.json()\n" + text[pos + len(old_return):]

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.recovery import RecoveryGuardService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.recovery_guard = RecoveryGuardService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        block = (
            "        self.recovery_guard = RecoveryGuardService(\n"
            "            self.database,\n"
            "            self.binance_live,\n"
            "        )\n"
        )
        text = text.replace(marker, block + marker, 1)

    if "await self.recovery_guard.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.recovery_guard.start()\n",
            1,
        )

    if "async def recovery_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def recovery_status(self) -> dict[str, object]:\n"
            "        return await self.recovery_guard.status()\n\n"
            "    async def recovery_reconcile(self) -> dict[str, object]:\n"
            "        result = await self.recovery_guard.reconcile()\n"
            "        await self.event_bus.publish(Event(\n"
            "            'recovery.reconciled',\n"
            "            {\n"
            "                'status': result['status'],\n"
            "                'recovery_ok': result['recovery_ok'],\n"
            "                'issue_count': len(result['issues']),\n"
            "                'live_execution_allowed': False,\n"
            "            },\n"
            "            'recovery_guard',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    # Guard testnet order creation. It starts locked until first clean reconciliation.
    needle = (
        "    async def testnet_order_create(\n"
        "        self, payload: dict[str, object]\n"
        "    ) -> dict[str, object]:\n"
    )
    guard = (
        needle
        + "        if not await self.recovery_guard.allows_testnet_orders():\n"
        + "            raise RuntimeError(\n"
        + "                'TESTNET orders locked: run recovery reconciliation first'\n"
        + "            )\n"
    )
    if needle in text and "TESTNET orders locked: run recovery reconciliation first" not in text:
        text = text.replace(needle, guard, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if '@app.get("/api/recovery/status")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.get("/api/recovery/status")\n'
            "    async def recovery_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.recovery_status()\n\n"
            '    @app.post("/api/recovery/reconcile")\n'
            "    async def recovery_reconcile(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        try:\n"
            "            return await kernel.recovery_reconcile()\n"
            "        except RuntimeError as exc:\n"
            "            raise HTTPException(status_code=503, detail=str(exc)) from exc\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(r'version = "[^"]+"', 'version = "0.25.0"', text, count=1)
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.25.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_connector()
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 25 aplicado com sucesso.")


if __name__ == "__main__":
    main()
