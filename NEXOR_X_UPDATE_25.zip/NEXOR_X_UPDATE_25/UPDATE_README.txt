NEXOR X UPDATE 25

Envie este ZIP para a raiz do repositório.
O GitHub Actions aplicará, testará e fará o commit automaticamente.

Após a atualização, novas ordens TESTNET ficam bloqueadas até uma
reconciliação limpa ser executada.
