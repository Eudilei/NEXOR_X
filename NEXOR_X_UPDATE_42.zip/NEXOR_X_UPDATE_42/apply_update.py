from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    items = (
        (
            PAYLOAD / "src/nexor_x/operations/performance_degradation.py",
            ROOT / "src/nexor_x/operations/performance_degradation.py",
        ),
        (
            PAYLOAD / "tests/test_performance_degradation.py",
            ROOT / "tests/test_performance_degradation.py",
        ),
        (
            PAYLOAD / "docs/AUDIT_UPDATE_42.md",
            ROOT / "docs/AUDIT_UPDATE_42.md",
        ),
    )
    for src, dst in items:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)

    imp = (
        "from .performance_degradation import "
        "DegradationPolicy, PerformanceDegradationGuard\n"
    )
    if imp not in text:
        text = imp + text

    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "PerformanceDegradationGuard" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += (
            '\n    "DegradationPolicy",'
            '\n    "PerformanceDegradationGuard",\n'
        )
        text = text[:match.start(1)] + body + text[match.end(1):]

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.operations.performance_degradation import "
        "PerformanceDegradationGuard\n"
    )
    if import_line not in text:
        marker = (
            "from nexor_x.operations.live_certification import "
            "LiveCertificationEvaluator\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 41 não detectada: LiveCertificationEvaluator ausente"
            )
        text = text.replace(marker, marker + import_line, 1)

    init_line = (
        "        self.performance_degradation_guard = "
        "PerformanceDegradationGuard()\n"
    )
    if init_line not in text:
        marker = (
            "        self.live_certification_evaluator = "
            "LiveCertificationEvaluator()\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 41 não detectada: live_certification_evaluator ausente"
            )
        text = text.replace(marker, marker + init_line, 1)

    if "async def performance_degradation_status(" not in text:
        marker = "    async def live_certification_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 41 não detectada: live_certification_status ausente"
            )

        method = """    async def performance_degradation_status(
        self,
    ) -> dict[str, object]:
        cycle = await self.validation_cycle_status()
        certification = await self.live_certification_status()
        report = self.performance_degradation_guard.evaluate(
            recent=cycle,
            certification=certification,
        )
        await self.event_bus.publish(Event(
            "operations.performance_degradation_evaluated",
            {
                "state": report["state"],
                "new_entries_allowed": report["new_entries_allowed"],
                "hard_reasons": report["hard_reasons"],
                "caution_reasons": report["caution_reasons"],
            },
            "performance_degradation",
        ))
        return report

    async def new_entries_allowed_by_performance(
        self,
    ) -> bool:
        report = await self.performance_degradation_status()
        return bool(report["new_entries_allowed"])

"""
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/operations/degradation")' not in text:
        marker = '@app.get("/api/live/certification")'
        if marker not in text:
            raise RuntimeError(
                "Update 41 não detectada: endpoint certification ausente"
            )
        block = """@app.get("/api/operations/degradation")
    async def performance_degradation_status(
        _: None = Depends(require_admin),
    ) -> dict[str, Any]:
        return await kernel.performance_degradation_status()

    """
        text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_notifications() -> None:
    path = ROOT / "src/nexor_x/notifications/telegram_events.py"
    if not path.exists():
        return

    text = path.read_text(encoding="utf-8")

    if '"operations.performance_degradation_evaluated",' not in text:
        candidates = (
            '        "live.certification_evaluated",\n',
            '        "live.readiness_evaluated",\n',
        )
        for marker in candidates:
            if marker in text:
                text = text.replace(
                    marker,
                    marker
                    + '        "operations.performance_degradation_evaluated",\n',
                    1,
                )
                break

    if 'if topic == "operations.performance_degradation_evaluated":' not in text:
        marker = '        if topic == "live.certification_evaluated":'
        if marker in text:
            block = """        if topic == "operations.performance_degradation_evaluated":
            state = str(payload.get("state", "NORMAL"))
            hard = list(payload.get("hard_reasons") or [])
            caution = list(payload.get("caution_reasons") or [])
            reasons = hard or caution
            reason_text = ", ".join(str(item) for item in reasons[:6])
            return (
                "🛡️ MONITOR DE DEGRADAÇÃO\\n"
                f"Estado: {state}\\n"
                f"Novas entradas: {'SIM' if payload.get('new_entries_allowed') else 'BLOQUEADAS'}\\n"
                f"Motivos: {reason_text or '-'}"
            )

"""
            text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.42.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = _read(init)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.42.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_notifications()
    patch_version()
    print(
        "NEXOR X Update 42 aplicada: monitor de degradação adicionado; "
        "LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
