NEXOR X UPDATE 42 — PERFORMANCE DEGRADATION GUARD

Objetivo:
  detectar quando o desempenho recente do NEXOR deteriora depois de uma
  validação/certificação aparentemente saudável.

Estados:
  NORMAL   -> novas entradas permitidas no modo atual.
  CAUTION  -> novas entradas permitidas, mas com alerta.
  BLOCKED  -> novas entradas devem ser bloqueadas.

Critérios padrão:
  - janela mínima recente: 20 trades;
  - PF de cautela: < 1.20;
  - PF de bloqueio: < 1.00;
  - drawdown de cautela: >= 10%;
  - drawdown de bloqueio: >= 15%;
  - sequência de perdas para cautela: >= 4;
  - sequência de perdas para bloqueio: >= 6.

Segurança:
  - LIVE permanece bloqueado;
  - posições abertas não são encerradas à força por este módulo;
  - proteção, stop e trailing continuam sendo responsabilidade dos módulos
    operacionais existentes;
  - o guard atua sobre NOVAS ENTRADAS.

Novo endpoint administrativo:
  GET /api/operations/degradation

Requer NEXOR X 0.41.0.
