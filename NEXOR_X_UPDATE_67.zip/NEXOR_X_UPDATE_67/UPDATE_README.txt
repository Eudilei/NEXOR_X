NEXOR X UPDATE 67 — NET PNL RUNTIME INTEGRATION

Objetivo:
  fazer o resultado liquido da Update 66 virar o resultado operacional padrao.

A partir desta update:
  - trade fechado usa net_pnl como pnl principal;
  - lucro bruto continua salvo em gross_pnl;
  - entry_fee, exit_fee e total_fees continuam salvos;
  - agregacoes de PnL usam net_pnl quando disponivel;
  - Profit Factor usa ganhos/perdas liquidos;
  - painel/API podem expor gross_pnl e fees como auditoria;
  - saldo PAPER pode ser atualizado pelo net_pnl.

Compatibilidade:
  trades antigos sem net_pnl continuam usando pnl/realized_pnl como fallback.

Seguranca:
  - nao altera sinais;
  - nao altera stop/TP;
  - nao altera sizing;
  - nao habilita LIVE.

Requer NEXOR X 0.66.0.
