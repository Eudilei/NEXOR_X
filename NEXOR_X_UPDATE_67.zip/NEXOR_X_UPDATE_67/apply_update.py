
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/accounting/__init__.py",
        "src/nexor_x/accounting/net_pnl.py",
        "src/nexor_x/accounting/runtime_integration.py",
        "tests/test_net_pnl_runtime.py",
        "docs/AUDIT_UPDATE_67.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = read(path)

    import_line = (
        "from nexor_x.accounting.runtime_integration import "
        "NetPerformanceAggregator, NetPnLRuntimeAdapter\n"
    )
    if import_line not in text:
        # safe insertion close to other nexor imports
        marker = "from nexor_x."
        idx = text.find(marker)
        if idx < 0:
            raise RuntimeError("Imports do kernel não encontrados")
        line_start = text.rfind("\n", 0, idx) + 1
        text = text[:line_start] + import_line + text[line_start:]

    init_lines = (
        "        self.net_pnl_runtime = NetPnLRuntimeAdapter()\n"
        "        self.net_performance = NetPerformanceAggregator()\n"
    )
    if "self.net_pnl_runtime = NetPnLRuntimeAdapter()" not in text:
        # conservative insertion after first self.* assignment in __init__
        init_idx = text.find("def __init__(")
        if init_idx < 0:
            raise RuntimeError("Kernel __init__ não encontrado")
        first_self = text.find("        self.", init_idx)
        if first_self < 0:
            raise RuntimeError("Inicialização do kernel não encontrada")
        text = text[:first_self] + init_lines + text[first_self:]

    path.write_text(text, encoding="utf-8")


def patch_closed_trade_flow() -> None:
    """
    Integração conservadora:
    procura métodos de fechamento conhecidos e normaliza o objeto/dict do trade
    imediatamente antes de persistência/retorno, apenas quando uma estrutura
    reconhecível existe. Se não houver padrão seguro, não força alteração.
    """
    candidates = [
        ROOT / "src/nexor_x/kernel.py",
        ROOT / "src/nexor_x/trading/paper.py",
        ROOT / "src/nexor_x/paper.py",
    ]

    for path in candidates:
        if not path.exists():
            continue

        text = read(path)
        if "normalize_closed_trade(" in text:
            continue

        # Pattern: closed_trade = { ... } then append/persist/return.
        anchors = (
            "closed_trade = {",
            "trade_result = {",
            "result = {",
        )

        anchor = next((a for a in anchors if a in text), None)
        if anchor is None:
            continue

        # Do not attempt to rewrite arbitrary dict construction. Add a helper
        # method only; runtime can call it from exact closure path later.
        if "def normalize_closed_trade_net(" not in text:
            insert_at = text.rfind("\n")
            helper = (
                "\n\n"
                "def normalize_closed_trade_net(kernel, trade):\n"
                "    return kernel.net_pnl_runtime.normalize_closed_trade(trade)\n"
            )
            text = text[:insert_at] + helper + text[insert_at:]
            path.write_text(text, encoding="utf-8")
        break


def patch_api_net_metrics() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    if not path.exists():
        return

    text = read(path)

    if '@app.get("/api/operations/net-pnl-accounting")' in text:
        return

    # Add a read-only capability endpoint near another operations endpoint.
    marker = '@app.get("/api/operations/filter-rigidity")'
    if marker not in text:
        return

    block = (
        '@app.get("/api/operations/net-pnl-accounting")\n'
        "    async def net_pnl_accounting_status(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return {\n"
        '            "pnl_basis": "NET_AFTER_FEES",\n'
        '            "gross_pnl_preserved": True,\n'
        '            "fees_preserved": True,\n'
        '            "profit_factor_basis": "NET_AFTER_FEES",\n'
        '            "live_allowed": False,\n'
        "        }\n\n"
        "    "
    )

    text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.67.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.67.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_kernel()
    patch_closed_trade_flow()
    patch_api_net_metrics()
    patch_version()

    print(
        "Update 67 aplicada: runtime de PnL liquido integrado; "
        "metricas usam NET_AFTER_FEES; LIVE bloqueado."
    )


if __name__ == "__main__":
    main()
