
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "tools/final_runtime_integration_audit.py",
        "tests/test_final_runtime_integration_audit.py",
        "docs/AUDIT_UPDATE_68.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.68.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.68.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_version()
    print(
        "Update 68 aplicada: auditoria final de integração instalada. "
        "Execute: python tools/final_runtime_integration_audit.py"
    )
    print("Trading logic alterada: NÃO")
    print("LIVE: BLOQUEADO")


if __name__ == "__main__":
    main()
