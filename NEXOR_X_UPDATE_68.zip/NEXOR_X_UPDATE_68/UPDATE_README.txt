NEXOR X UPDATE 68 — FINAL RUNTIME INTEGRATION AUDIT

Esta update NÃO altera lógica de trading.

Ela verifica no repositório instalado:

- versão mínima 0.67.0;
- banca PAPER configurada para 200;
- moeda PAPER BRL;
- existência do NetPnLCalculator;
- existência do NetPnLRuntimeAdapter;
- uso de net_pnl no runtime;
- Profit Factor líquido;
- taxas maker/taker configuráveis;
- FilterRigidityMonitor;
- FilterDecisionTelemetry;
- endpoint /api/operations/filter-rigidity;
- endpoint /api/operations/net-pnl-accounting;
- LIVE bloqueado em manifests recentes;
- ausência de caches proibidos.

Saída:
  reports/final_runtime_integration_audit.json

Status:
  FINAL_RUNTIME_INTEGRATION_PASS
  FINAL_RUNTIME_INTEGRATION_FAIL

Uso:
  python tools/final_runtime_integration_audit.py

Esta auditoria não habilita LIVE.
