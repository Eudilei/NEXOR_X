from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.validation import ValidationSnapshotService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.validation_snapshot = ValidationSnapshotService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        text = text.replace(
            marker,
            "        self.validation_snapshot = "
            "ValidationSnapshotService(self.database)\n"
            + marker,
            1,
        )

    if "await self.validation_snapshot.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.validation_snapshot.start()\n",
            1,
        )

    if "async def validation_snapshot_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def validation_snapshot_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.validation_snapshot.status()\n\n"
            "    async def validation_snapshot_evaluate(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.validation_snapshot.evaluate(payload)\n"
            "        await self.event_bus.publish(Event(\n"
            "            'validation.snapshot_evaluated',\n"
            "            {\n"
            "                'status': result['status'],\n"
            "                'paper_validation_ready': "
            "result['paper_validation_ready'],\n"
            "                'testnet_validation_ready': "
            "result['testnet_validation_ready'],\n"
            "                'live_validation_ready': False,\n"
            "            },\n"
            "            'validation_snapshot',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if "class ValidationSnapshotRequest(BaseModel):" not in text:
        marker = "class ChatRequest(BaseModel):\n"
        if marker not in text:
            raise RuntimeError("ChatRequest marker not found")
        model = (
            "class ValidationSnapshotRequest(BaseModel):\n"
            "    paper_trades: int = Field(ge=0, le=100000000)\n"
            "    profit_factor: float = Field(ge=0, le=1000)\n"
            "    expected_r: float = Field(ge=-100, le=100)\n"
            "    drawdown_pct: float = Field(ge=0, le=100)\n"
            "    recent_profit_factor: float = Field(ge=0, le=1000)\n"
            "    recent_expected_r: float = Field(ge=-100, le=100)\n"
            "    walk_forward_pass_ratio: float = Field(ge=0, le=1)\n"
            "    monte_carlo_ruin_probability: float = Field(ge=0, le=1)\n"
            "    brier_score_oos: float = Field(ge=0, le=1)\n"
            "    calibration_ece_oos: float = Field(ge=0, le=1)\n"
            "    integration_healthy: bool\n"
            "    recovery_ok: bool\n"
            "    supervisor_paper_allowed: bool\n"
            "    supervisor_testnet_allowed: bool\n"
            "    operational_incidents: int = Field(ge=0, le=1000000)\n"
            "    critical_test_failures: int = Field(ge=0, le=1000000)\n\n"
        )
        text = text.replace(marker, model + marker, 1)

    if '@app.get("/api/validation/status")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.get("/api/validation/status")\n'
            "    async def validation_snapshot_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_snapshot_status()\n\n"
            '    @app.post("/api/validation/evaluate")\n'
            "    async def validation_snapshot_evaluate(\n"
            "        body: ValidationSnapshotRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_snapshot_evaluate(\n"
            "            body.model_dump()\n"
            "        )\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.30.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.30.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 30 aplicado com sucesso.")


if __name__ == "__main__":
    main()
