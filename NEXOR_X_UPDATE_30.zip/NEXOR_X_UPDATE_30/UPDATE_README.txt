NEXOR X UPDATE 30 — SNAPSHOT DE VALIDAÇÃO

Envie este ZIP para a raiz do repositório.
Não descompacte e não use Codespaces.

O GitHub Actions executará a suíte completa antes do commit automático.
