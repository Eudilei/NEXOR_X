NEXOR X UPDATE 75

Requer a versao 0.74.0.

Correcoes:
- banca inicial PAPER de R$ 200 em instalacao nova;
- risco liquido maximo de 2% por operacao, incluindo stop, taxas e slippage;
- risco total reservado das posicoes abertas limitado a 10%;
- nova entrada bloqueada se a perda projetada atingir drawdown de 25%;
- calibracao quantitativa e probabilistica usa apenas o proprio simbolo;
- backtest contextual continua especifico por simbolo;
- stop PAPER e Shadow encerram no preco protegido, com slippage configurado;
- scanner real continua analisando o mercado, selecionando 60 e aprofundando 60.

Contas PAPER existentes nao sao reiniciadas. A banca atual e preservada.
LIVE continua bloqueado.
