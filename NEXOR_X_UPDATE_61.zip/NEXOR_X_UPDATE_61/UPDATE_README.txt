NEXOR X UPDATE 61 — FINAL EVIDENCE INTEGRITY AUDIT

Objetivo:
  validar de forma independente o pacote final criado pela Update 60.

O auditor verifica:
  - existência de reports/final_evidence_bundle.json;
  - existência de reports/final_evidence_bundle.sha256;
  - SHA-256 interno e arquivo .sha256 coerentes;
  - status FINAL_EVIDENCE_READY;
  - todos os requirements do bundle = true;
  - live_allowed=false;
  - live_certified=false;
  - RC_READY;
  - TECHNICALLY_COMPLETE;
  - campanha COMPLETE;
  - evidence_certified=true.

Saída:
  FINAL_EVIDENCE_VERIFIED
  ou
  FINAL_EVIDENCE_INVALID

Relatório:
  reports/final_evidence_integrity_audit.json

Uso:
  python tools/final_evidence_integrity_audit.py

IMPORTANTE:
  FINAL_EVIDENCE_VERIFIED NÃO habilita LIVE.
  A liberação LIVE deverá continuar sendo uma etapa explícita, separada
  e posterior.

Trading runtime não é alterado.
LIVE permanece bloqueado.
