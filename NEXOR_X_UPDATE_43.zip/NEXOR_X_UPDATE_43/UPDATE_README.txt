NEXOR X UPDATE 43 — ENTRY ADMISSION GUARD

Objetivo:
  transformar o monitor de degradação da Update 42 em um gate efetivo
  antes da criação de uma NOVA exposição.

Aplicação:
  - PAPER: bloqueio antes de paper_open criar a posição;
  - AutoPaper: protegido porque utiliza paper_open;
  - TESTNET: bloqueio antes de criar ordens que aumentem exposição;
  - ordens reduce-only continuam permitidas;
  - gestão/proteção das posições abertas continua funcionando;
  - LIVE continua bloqueado.

Regra:
  NORMAL  -> permite novas entradas;
  CAUTION -> permite novas entradas e mantém alerta;
  BLOCKED -> rejeita novas entradas.

Novo endpoint administrativo:
  GET /api/operations/entry-admission

Requer NEXOR X 0.42.0.
