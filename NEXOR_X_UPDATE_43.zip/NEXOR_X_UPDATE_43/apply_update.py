from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    items = (
        (
            PAYLOAD / "src/nexor_x/operations/entry_admission.py",
            ROOT / "src/nexor_x/operations/entry_admission.py",
        ),
        (
            PAYLOAD / "tests/test_entry_admission.py",
            ROOT / "tests/test_entry_admission.py",
        ),
        (
            PAYLOAD / "docs/AUDIT_UPDATE_43.md",
            ROOT / "docs/AUDIT_UPDATE_43.md",
        ),
    )
    for src, dst in items:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)

    imp = "from .entry_admission import EntryAdmissionController\n"
    if imp not in text:
        text = imp + text

    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "EntryAdmissionController" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += '\n    "EntryAdmissionController",\n'
        text = text[:match.start(1)] + body + text[match.end(1):]

    path.write_text(text, encoding="utf-8")


def patch_kernel_import_and_init(text: str) -> str:
    import_line = (
        "from nexor_x.operations.entry_admission import "
        "EntryAdmissionController\n"
    )
    if import_line not in text:
        marker = (
            "from nexor_x.operations.performance_degradation import "
            "PerformanceDegradationGuard\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 42 não detectada: PerformanceDegradationGuard ausente"
            )
        text = text.replace(marker, marker + import_line, 1)

    init_line = (
        "        self.entry_admission_controller = "
        "EntryAdmissionController()\n"
    )
    if init_line not in text:
        marker = (
            "        self.performance_degradation_guard = "
            "PerformanceDegradationGuard()\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 42 não detectada: performance_degradation_guard ausente"
            )
        text = text.replace(marker, marker + init_line, 1)
    return text


def patch_kernel_admission_method(text: str) -> str:
    if "async def entry_admission_status(" in text:
        return text

    marker = "    async def performance_degradation_status(\n"
    if marker not in text:
        raise RuntimeError(
            "Update 42 não detectada: performance_degradation_status ausente"
        )

    method = """    async def entry_admission_status(
        self,
        *,
        action: str = "NEW_ENTRY",
        reduce_only: bool = False,
    ) -> dict[str, object]:
        degradation = await self.performance_degradation_status()
        report = self.entry_admission_controller.evaluate(
            degradation=degradation,
            action=action,
            reduce_only=reduce_only,
        )
        if not report["allowed"]:
            await self.event_bus.publish(Event(
                "execution.entry_blocked_degradation",
                {
                    "action": report["action"],
                    "state": report["state"],
                    "reason": report["reason"],
                    "hard_reasons": report["hard_reasons"],
                    "live_allowed": False,
                },
                "entry_admission_guard",
            ))
        return report

    async def require_entry_admission(
        self,
        *,
        action: str,
        reduce_only: bool = False,
    ) -> dict[str, object]:
        report = await self.entry_admission_status(
            action=action,
            reduce_only=reduce_only,
        )
        if report["allowed"]:
            return report
        reasons = list(report.get("hard_reasons") or [])
        raise RuntimeError(
            "New entry blocked by performance degradation: "
            + ", ".join(str(item) for item in reasons or ["blocked"])
        )

"""
    return text.replace(marker, method + marker, 1)


def patch_paper_open(text: str) -> str:
    if 'action="PAPER_OPEN"' in text:
        return text

    old = """    async def paper_open(self, symbol: str) -> dict[str, object]:
        market = await self.market_state(symbol)
"""
    new = """    async def paper_open(self, symbol: str) -> dict[str, object]:
        await self.require_entry_admission(
            action="PAPER_OPEN",
            reduce_only=False,
        )
        market = await self.market_state(symbol)
"""
    if old not in text:
        raise RuntimeError(
            "Marcador paper_open não encontrado; atualização abortada com segurança"
        )
    return text.replace(old, new, 1)


def patch_testnet_create(text: str) -> str:
    if 'action="TESTNET_CREATE"' in text:
        return text

    old = """    async def testnet_order_create(
        self, payload: dict[str, object]
    ) -> dict[str, object]:
        if not await self.recovery_guard.allows_testnet_orders():
"""
    new = """    async def testnet_order_create(
        self, payload: dict[str, object]
    ) -> dict[str, object]:
        reduce_only = bool(payload.get("reduce_only", False))
        await self.require_entry_admission(
            action="TESTNET_CREATE",
            reduce_only=reduce_only,
        )
        if not await self.recovery_guard.allows_testnet_orders():
"""
    if old not in text:
        raise RuntimeError(
            "Marcador testnet_order_create não encontrado; "
            "atualização abortada com segurança"
        )

    text = text.replace(old, new, 1)
    request_old = "            reduce_only=bool(payload.get('reduce_only', False)),\n"
    if request_old in text:
        text = text.replace(
            request_old,
            "            reduce_only=reduce_only,\n",
            1,
        )
    return text


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)
    text = patch_kernel_import_and_init(text)
    text = patch_kernel_admission_method(text)
    text = patch_paper_open(text)
    text = patch_testnet_create(text)
    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/operations/entry-admission")' not in text:
        marker = '@app.get("/api/operations/degradation")'
        if marker not in text:
            raise RuntimeError(
                "Update 42 não detectada: endpoint degradation ausente"
            )
        block = """@app.get("/api/operations/entry-admission")
    async def entry_admission_status(
        _: None = Depends(require_admin),
    ) -> dict[str, Any]:
        return await kernel.entry_admission_status()

    """
        text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_notifications() -> None:
    path = ROOT / "src/nexor_x/notifications/telegram_events.py"
    if not path.exists():
        return

    text = path.read_text(encoding="utf-8")

    if '"execution.entry_blocked_degradation",' not in text:
        marker = '        "operations.performance_degradation_evaluated",\n'
        if marker in text:
            text = text.replace(
                marker,
                marker + '        "execution.entry_blocked_degradation",\n',
                1,
            )

    if 'if topic == "execution.entry_blocked_degradation":' not in text:
        marker = (
            '        if topic == '
            '"operations.performance_degradation_evaluated":'
        )
        if marker in text:
            block = """        if topic == "execution.entry_blocked_degradation":
            reasons = list(payload.get("hard_reasons") or [])
            reason_text = ", ".join(str(item) for item in reasons[:6])
            return (
                "⛔ NOVA ENTRADA BLOQUEADA\\n"
                f"Ação: {payload.get('action', '-')}\\n"
                f"Estado: {payload.get('state', 'BLOCKED')}\\n"
                f"Motivos: {reason_text or '-'}\\n"
                "Posições abertas continuam protegidas"
            )

"""
            text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.43.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = _read(init)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.43.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_notifications()
    patch_version()
    print(
        "NEXOR X Update 43 aplicada: novas entradas PAPER/TESTNET "
        "agora respeitam o guard de degradação. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
