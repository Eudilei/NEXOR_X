from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    src = PAYLOAD / "src" / "nexor_x" / "operations" / "live_certification.py"
    dst = ROOT / "src" / "nexor_x" / "operations" / "live_certification.py"
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

    test_src = PAYLOAD / "tests" / "test_live_certification.py"
    test_dst = ROOT / "tests" / "test_live_certification.py"
    test_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(test_src, test_dst)

    doc_src = PAYLOAD / "docs" / "AUDIT_UPDATE_41.md"
    doc_dst = ROOT / "docs" / "AUDIT_UPDATE_41.md"
    doc_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(doc_src, doc_dst)


def patch_operations_init() -> None:
    path = ROOT / "src" / "nexor_x" / "operations" / "__init__.py"
    text = _read(path)

    imp = (
        "from .live_certification import "
        "CertificationPolicy, LiveCertificationEvaluator\n"
    )
    if imp not in text:
        text = imp + text

    if "__all__" in text and "LiveCertificationEvaluator" not in text.split("__all__", 1)[1]:
        match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
        if match:
            body = match.group(1).rstrip()
            if body and not body.endswith(","):
                body += ","
            body += (
                '\n    "CertificationPolicy",'
                '\n    "LiveCertificationEvaluator",\n'
            )
            text = text[:match.start(1)] + body + text[match.end(1):]

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src" / "nexor_x" / "kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.operations.live_certification import "
        "LiveCertificationEvaluator\n"
    )
    if import_line not in text:
        marker = "from nexor_x.operations import LiveReadinessEvaluator\n"
        if marker in text:
            text = text.replace(marker, marker + import_line, 1)
        else:
            text = import_line + text

    init_line = (
        "        self.live_certification_evaluator = "
        "LiveCertificationEvaluator()\n"
    )
    if init_line not in text:
        marker = "        self.live_readiness_evaluator = LiveReadinessEvaluator()\n"
        if marker not in text:
            raise RuntimeError(
                "Update 40 não detectada: live_readiness_evaluator ausente"
            )
        text = text.replace(marker, marker + init_line, 1)

    if "async def live_certification_status(" not in text:
        marker = "    async def live_readiness_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 40 não detectada: live_readiness_status ausente"
            )

        method = """    async def live_certification_status(
        self,
    ) -> dict[str, object]:
        readiness = await self.live_readiness_status()
        cycle = await self.validation_cycle_status()
        runtime = await self.runtime_status()
        report = self.live_certification_evaluator.evaluate(
            readiness=readiness,
            validation_cycle=cycle,
            runtime=runtime,
        )
        await self.event_bus.publish(Event(
            "live.certification_evaluated",
            {
                "status": report["status"],
                "evidence_certified": report["evidence_certified"],
                "live_allowed": False,
                "blockers": report["blockers"],
            },
            "live_certification",
        ))
        return report

"""
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src" / "nexor_x" / "api" / "app.py"
    text = _read(path)

    if '@app.get("/api/live/certification")' not in text:
        marker = '@app.get("/api/live/readiness")'
        if marker not in text:
            raise RuntimeError(
                "Update 40 não detectada: endpoint readiness ausente"
            )
        block = """@app.get("/api/live/certification")
    async def live_certification_status(
        _: None = Depends(require_admin),
    ) -> dict[str, Any]:
        return await kernel.live_certification_status()

    """
        text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_notifications() -> None:
    path = ROOT / "src" / "nexor_x" / "notifications" / "telegram_events.py"
    if not path.exists():
        return

    text = path.read_text(encoding="utf-8")

    if '"live.certification_evaluated",' not in text:
        marker = '        "live.readiness_evaluated",\n'
        if marker in text:
            text = text.replace(
                marker,
                marker + '        "live.certification_evaluated",\n',
                1,
            )

    if 'if topic == "live.certification_evaluated":' not in text:
        marker = '        if topic == "live.readiness_evaluated":'
        if marker in text:
            block = """        if topic == "live.certification_evaluated":
            certified = bool(payload.get("evidence_certified", False))
            blockers = list(payload.get("blockers") or [])
            blocker_text = ", ".join(str(item) for item in blockers[:6])
            return (
                "📊 CERTIFICAÇÃO DE EVIDÊNCIAS\\n"
                f"Resultado: {'APROVADA' if certified else 'PENDENTE'}\\n"
                f"Bloqueios: {blocker_text or '-'}\\n"
                "Operação real: BLOQUEADA"
            )

"""
            text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.41.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src" / "nexor_x" / "__init__.py"
    text = _read(init)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.41.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_notifications()
    patch_version()
    print(
        "NEXOR X Update 41 aplicada. "
        "Certificação de evidências adicionada; LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
