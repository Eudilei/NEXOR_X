NEXOR X UPDATE 41 — CERTIFICAÇÃO DE EVIDÊNCIAS

Objetivo:
  acrescentar um gate técnico mensurável entre "pronto para avaliar"
  e uma futura decisão sobre operação real.

IMPORTANTE:
  esta atualização NÃO habilita LIVE.
  live_allowed permanece sempre false.

Critérios padrão:
  - Readiness da Update 40 aprovado;
  - pelo menos 30 dias de evidência;
  - pelo menos 100 trades fechados;
  - Profit Factor >= 1.20;
  - Drawdown máximo <= 15%;
  - runtime LIVE desabilitado.

Os limites podem ser ajustados no futuro, mas a Update 41 mantém
valores conservadores e auditáveis como referência de certificação.

Novo endpoint administrativo:
  GET /api/live/certification

Requer NEXOR X 0.40.0.
