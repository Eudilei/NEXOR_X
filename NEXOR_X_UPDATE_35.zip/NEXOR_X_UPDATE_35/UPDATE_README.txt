NEXOR X UPDATE 35 — CREDENCIAIS BINANCE E TELEGRAM

Envie este ZIP para a raiz do repositório.
Não descompacte e não use Codespaces.

Esta atualização:
- adiciona .env.example;
- deixa campos para Binance;
- deixa campos para Telegram;
- mantém TESTNET como padrão;
- impede exposição das chaves pela API;
- mantém LIVE bloqueado.
