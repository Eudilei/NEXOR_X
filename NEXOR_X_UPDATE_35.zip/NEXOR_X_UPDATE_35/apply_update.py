from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_config() -> None:
    path = ROOT / "src/nexor_x/config.py"
    text = path.read_text(encoding="utf-8")

    fields = (
        '    binance_api_key: str = ""\n'
        '    binance_api_secret: str = ""\n'
        '    telegram_bot_token: str = ""\n'
        '    telegram_chat_id: str = ""\n'
    )

    if "binance_api_key:" not in text:
        marker = "    model_config = SettingsConfigDict("
        if marker not in text:
            raise RuntimeError("Config insertion marker not found")
        text = text.replace(marker, fields + "\n" + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = (
        "from nexor_x.secrets import ExternalCredentialsStatusService\n"
    )
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.external_credentials = ExternalCredentialsStatusService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        block = (
            "        self.external_credentials = "
            "ExternalCredentialsStatusService(settings)\n"
        )
        text = text.replace(marker, block + marker, 1)

    if "async def external_credentials_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        method = (
            "    async def external_credentials_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.external_credentials.status()\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if '@app.get("/api/system/credentials")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoint = (
            '    @app.get("/api/system/credentials")\n'
            "    async def external_credentials_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.external_credentials_status()\n\n"
        )
        text = text.replace(marker, endpoint + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_gitignore() -> None:
    path = ROOT / ".gitignore"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    entries = [
        ".env",
        ".env.local",
        ".env.*.local",
    ]

    lines = {line.strip() for line in text.splitlines()}
    missing = [entry for entry in entries if entry not in lines]
    if missing:
        if text and not text.endswith("\n"):
            text += "\n"
        text += "\n# NEXOR X secrets\n"
        text += "\n".join(missing) + "\n"
        path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.35.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.35.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_config()
    patch_kernel()
    patch_api()
    patch_gitignore()
    patch_version()
    print("NEXOR X Update 35 aplicado com sucesso.")


if __name__ == "__main__":
    main()
