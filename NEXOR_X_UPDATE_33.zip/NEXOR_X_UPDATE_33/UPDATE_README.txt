NEXOR X UPDATE 33 — CICLO AUTOMÁTICO DE VALIDAÇÃO

Envie este ZIP para a raiz do repositório.
Não descompacte e não use Codespaces.

O GitHub Actions executará compilação, lint crítico e a suíte completa
antes do commit automático.

O ciclo de validação é executado a cada 15 minutos e também pode ser
acionado manualmente pela API administrativa.
