from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.validation_cycle import ValidationCycleService\n"
    if import_line not in text:
        marker = "from nexor_x.evidence import EvidenceCollector\n"
        if marker not in text:
            raise RuntimeError("EvidenceCollector import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.validation_cycle = ValidationCycleService(" not in text:
        marker = "        self.evidence_collector = EvidenceCollector(self.database)\n"
        if marker not in text:
            raise RuntimeError("EvidenceCollector instance marker not found")
        block = (
            marker
            + "        self.validation_cycle = ValidationCycleService(\n"
            + "            self.database,\n"
            + "            self.evidence_collector,\n"
            + "            self.validation_campaign,\n"
            + "        )\n"
        )
        text = text.replace(marker, block, 1)

    if "await self.validation_cycle.start()" not in text:
        marker = "        await self.validation_campaign.start()\n"
        if marker not in text:
            raise RuntimeError("Validation campaign startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.validation_cycle.start()\n",
            1,
        )

    schedule_signature = '"validation_cycle",'
    if schedule_signature not in text:
        marker = (
            "        if self.settings.scanner_enabled:\n"
            "            self.scheduler.add_job(\n"
        )
        if marker not in text:
            raise RuntimeError("Scheduler scanner marker not found")

        # Add the validation cycle independently, before scanner scheduling.
        addition = (
            "        self.scheduler.add_job(\n"
            "            ScheduledJob(\n"
            "                \"validation_cycle\",\n"
            "                900.0,\n"
            "                self._scheduled_validation_cycle,\n"
            "            )\n"
            "        )\n"
        )
        text = text.replace(marker, addition + marker, 1)

    if "async def validation_cycle_status" not in text:
        marker = "    async def validation_evidence_collect(\n"
        if marker not in text:
            raise RuntimeError("Validation evidence method marker not found")
        methods = (
            "    async def validation_cycle_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.validation_cycle.status()\n\n"
            "    async def validation_cycle_run(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.validation_cycle.run_once()\n"
            "        await self.event_bus.publish(Event(\n"
            "            'validation.cycle_completed',\n"
            "            {\n"
            "                'days_running': result['days_running'],\n"
            "                'phase': result['campaign']['phase'],\n"
            "                'live_allowed': False,\n"
            "            },\n"
            "            'validation_cycle',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    if "async def _scheduled_validation_cycle" not in text:
        marker = "    async def _scheduled_scan(self) -> None:\n"
        if marker not in text:
            raise RuntimeError("Scheduled scan marker not found")
        scheduled = (
            "    async def _scheduled_validation_cycle(self) -> None:\n"
            "        try:\n"
            "            await self.validation_cycle_run()\n"
            "        except Exception as exc:\n"
            "            self._log.warning(\n"
            "                'scheduled_validation_cycle_failed error=%s',\n"
            "                exc,\n"
            "            )\n"
            "\n"
        )
        text = text.replace(marker, scheduled + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if '@app.get("/api/validation/cycle/status")' not in text:
        marker = '    @app.get("/api/validation/evidence")\n'
        if marker not in text:
            raise RuntimeError("Validation evidence endpoint marker not found")
        endpoints = (
            '    @app.get("/api/validation/cycle/status")\n'
            "    async def validation_cycle_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_cycle_status()\n\n"
            '    @app.post("/api/validation/cycle/run")\n'
            "    async def validation_cycle_run(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.validation_cycle_run()\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.33.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.33.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 33 aplicado com sucesso.")


if __name__ == "__main__":
    main()
