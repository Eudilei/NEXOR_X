NEXOR X UPDATE 66 — NET PNL & BINANCE FEE ACCOUNTING

Regra principal:
  net_pnl = gross_pnl - entry_fee - exit_fee

O valor principal exibido/armazenado como resultado da operação passa a ser
o lucro/prejuizo liquido.

Mantidos para auditoria:
  - gross_pnl
  - entry_fee
  - exit_fee
  - total_fees
  - net_pnl

PAPER:
  taxas podem ser estimadas pela configuração de fee rate.

TESTNET/LIVE futuro:
  quando a exchange fornecer a taxa efetivamente cobrada, esse valor pode ser
  informado diretamente ao calculador.

Segurança:
  - não altera sinais;
  - não altera sizing;
  - não altera stop/TP;
  - não habilita LIVE.

Requer NEXOR X 0.65.0.
