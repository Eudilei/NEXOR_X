
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/accounting/__init__.py",
        "src/nexor_x/accounting/net_pnl.py",
        "tests/test_net_pnl.py",
        "docs/AUDIT_UPDATE_66.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_env_example() -> None:
    path = ROOT / ".env.example"
    if not path.exists():
        return

    text = read(path)

    additions = []
    if "NEXOR_PAPER_MAKER_FEE_RATE=" not in text:
        additions.append("NEXOR_PAPER_MAKER_FEE_RATE=0.0002")
    if "NEXOR_PAPER_TAKER_FEE_RATE=" not in text:
        additions.append("NEXOR_PAPER_TAKER_FEE_RATE=0.0005")

    if additions:
        text = text.rstrip() + "\n" + "\n".join(additions) + "\n"
        path.write_text(text, encoding="utf-8")


def patch_closed_trade_models() -> None:
    """
    Patch conservador: somente adiciona campos quando um modelo claramente
    identificado de trade fechado existir. Se não existir, o módulo contábil
    continua disponível sem quebrar a instalação.
    """
    candidates = [
        ROOT / "src/nexor_x/models.py",
        ROOT / "src/nexor_x/models/trade.py",
        ROOT / "src/nexor_x/trading/models.py",
    ]

    for path in candidates:
        if not path.exists():
            continue

        text = read(path)
        if "class ClosedTrade" not in text:
            continue

        if "net_pnl:" in text and "total_fees:" in text:
            continue

        marker = "class ClosedTrade"
        start = text.find(marker)
        if start < 0:
            continue

        # Insert fields only if a common pnl field is present in the class area.
        tail = text[start:start + 3000]
        field_marker = None
        for candidate in (
            "    pnl: float",
            "    realized_pnl: float",
            "    gross_pnl: float",
        ):
            if candidate in tail:
                field_marker = candidate
                break

        if field_marker is None:
            continue

        absolute = start + tail.find(field_marker)
        line_end = text.find("\n", absolute)
        insert = (
            "\n"
            "    gross_pnl: float = 0.0\n"
            "    entry_fee: float = 0.0\n"
            "    exit_fee: float = 0.0\n"
            "    total_fees: float = 0.0\n"
            "    net_pnl: float = 0.0"
        )
        text = text[:line_end] + insert + text[line_end:]
        path.write_text(text, encoding="utf-8")
        break


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.66.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.66.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_env_example()
    patch_closed_trade_models()
    patch_version()

    print(
        "Update 66 aplicada: contabilidade de PnL líquido adicionada; "
        "taxas preservadas para auditoria; LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
