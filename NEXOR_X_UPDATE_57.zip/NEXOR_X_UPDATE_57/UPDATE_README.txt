NEXOR X UPDATE 57 — RC VERIFICATION HARNESS

Objetivo:
  verificar a Release Candidate real instalada no repositório sem adicionar
  novas funções de trading.

O verificador confere:
  - versão 0.57.0;
  - módulos críticos das Updates 40–56;
  - endpoints finais;
  - existência do documento Release Candidate;
  - ausência de __pycache__, .pytest_cache, .pyc e .pyo;
  - manifestos recentes continuam com live_execution_allowed=false;
  - nenhuma alteração desta update habilita LIVE.

Execução manual após aplicar a Update 57:

  python tools/rc_verify.py

Saída:
  RC_VERIFY_PASS
  ou
  RC_VERIFY_FAIL

Também gera:
  reports/rc_verification_report.json

Esta update NÃO altera a lógica de entrada, sizing, proteção, execução,
PAPER ou TESTNET.

LIVE permanece bloqueado.
