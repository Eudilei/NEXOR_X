
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "tools/rc_verify.py",
        "tests/test_rc_verify.py",
        "docs/AUDIT_UPDATE_57.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def verify_update_56_present() -> None:
    required = (
        ROOT / "src/nexor_x/validation/release_candidate.py",
        ROOT / "docs/NEXOR_X_RELEASE_CANDIDATE.md",
    )
    missing = [
        str(path)
        for path in required
        if not path.exists()
    ]
    if missing:
        raise RuntimeError(
            "Update 56 não detectada. Ausentes: "
            + ", ".join(missing)
        )

    api = _read(ROOT / "src/nexor_x/api/app.py")
    if "/api/validation/release-candidate" not in api:
        raise RuntimeError(
            "Update 56 não detectada: endpoint release-candidate ausente"
        )


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.57.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.57.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    verify_update_56_present()
    copy_payload()
    patch_version()
    print(
        "NEXOR X Update 57 aplicada: RC Verification Harness instalado. "
        "Lógica de trading não alterada. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
