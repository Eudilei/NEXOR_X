NEXOR X UPDATE 39 — ALERTAS TELEGRAM

Envie este ZIP para a raiz do repositório.

Depois de configurar:
  TELEGRAM_BOT_TOKEN=
  TELEGRAM_CHAT_ID=
  TELEGRAM_NOTIFICATIONS_ENABLED=true

o NEXOR X passa a avisar entradas, saídas, ações de proteção,
reconciliação e fases relevantes da validação.

LIVE permanece bloqueado.
