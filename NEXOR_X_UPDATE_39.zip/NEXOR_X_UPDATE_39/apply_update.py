from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_config() -> None:
    path = ROOT / "src/nexor_x/config.py"
    text = path.read_text(encoding="utf-8")

    field = "    telegram_notifications_enabled: bool = True\n"
    if "telegram_notifications_enabled:" not in text:
        marker = "    model_config = SettingsConfigDict("
        if marker not in text:
            raise RuntimeError("Config model marker not found")
        text = text.replace(marker, field + "\n" + marker, 1)

    mapping_marker = (
        '        "TELEGRAM_BOT_TOKEN": "telegram_bot_token",\n'
    )
    mapping = (
        '        "TELEGRAM_NOTIFICATIONS_ENABLED": '
        '"telegram_notifications_enabled",\n'
    )
    if '"TELEGRAM_NOTIFICATIONS_ENABLED"' not in text:
        if mapping_marker not in text:
            raise RuntimeError("Telegram mapping marker not found")
        text = text.replace(
            mapping_marker,
            mapping_marker + mapping,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = (
        "from nexor_x.notifications import TelegramEventNotifier\n"
    )
    if import_line not in text:
        marker = (
            "from nexor_x.infrastructure.telegram import TelegramService\n"
        )
        if marker not in text:
            raise RuntimeError("Telegram import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.telegram_notifier = TelegramEventNotifier(" not in text:
        marker = (
            "        self.telegram = TelegramService("
            "settings.telegram_bot_token, settings.telegram_chat_id)\n"
        )
        if marker not in text:
            raise RuntimeError("Telegram constructor marker not found")
        block = (
            marker
            + "        self.telegram_notifier = TelegramEventNotifier(\n"
            + "            self.telegram,\n"
            + "            enabled=settings.telegram_notifications_enabled,\n"
            + "        )\n"
        )
        text = text.replace(marker, block, 1)

    if "self.telegram_notifier.subscribe(self.event_bus)" not in text:
        marker = (
            '        self.event_bus.subscribe("*", self._persist_event)\n'
        )
        if marker not in text:
            raise RuntimeError("EventBus subscription marker not found")
        text = text.replace(
            marker,
            marker
            + "        self.telegram_notifier.subscribe(self.event_bus)\n",
            1,
        )

    # Avoid duplicated startup message: system.started event is now responsible.
    old = (
        "        await self.telegram.send("
        "f\"NEXOR X iniciado em modo "
        "{self.settings.nexor_mode.value}.\")\n"
    )
    if old in text:
        text = text.replace(old, "", 1)

    path.write_text(text, encoding="utf-8")


def patch_env_example() -> None:
    path = ROOT / ".env.example"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    line = "TELEGRAM_NOTIFICATIONS_ENABLED=true\n"
    if "TELEGRAM_NOTIFICATIONS_ENABLED=" not in text:
        marker = "TELEGRAM_CHAT_ID=\n"
        if marker in text:
            text = text.replace(
                marker,
                marker + line,
                1,
            )
        else:
            text += "\n# TELEGRAM\n" + line
        path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.39.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.39.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_config()
    patch_kernel()
    patch_env_example()
    patch_version()
    print("NEXOR X Update 39 aplicado com sucesso.")


if __name__ == "__main__":
    main()
