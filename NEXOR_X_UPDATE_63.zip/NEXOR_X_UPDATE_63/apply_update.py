
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def verify_prerequisites() -> None:
    required = (
        "tools/rc_verify.py",
        "tools/validation_campaign_runner.py",
        "tools/evidence_progress_recorder.py",
        "tools/evidence_completion_watchdog.py",
        "tools/final_evidence_integrity_audit.py",
        "tools/live_preauthorization_dossier.py",
    )

    missing = [
        rel
        for rel in required
        if not (ROOT / rel).exists()
    ]

    if missing:
        raise RuntimeError(
            "Updates 57-62 incompletas. Ausentes: "
            + ", ".join(missing)
        )


def copy_payload() -> None:
    for rel in (
        "tools/validation_orchestrator.py",
        "tests/test_validation_orchestrator.py",
        "docs/AUDIT_UPDATE_63.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.63.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.63.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    verify_prerequisites()
    copy_payload()
    patch_version()

    print(
        "NEXOR X Update 63 aplicada: Autonomous Validation Orchestrator "
        "instalado. Arquitetura permanece congelada. "
        "Trading runtime não alterado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
