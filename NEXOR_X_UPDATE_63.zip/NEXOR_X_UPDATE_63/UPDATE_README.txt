NEXOR X UPDATE 63 — AUTONOMOUS VALIDATION ORCHESTRATOR

Objetivo:
  encerrar a construção e deixar a fase de validação PAPER/TESTNET
  funcionando de forma automática.

O orquestrador coordena:
  1. RC Verification Harness
  2. Final Validation Campaign Runner
  3. Evidence Progress Recorder
  4. Evidence Completion Watchdog
  5. Final Evidence Integrity Audit (quando houver bundle)
  6. LIVE Pre-Authorization Dossier (somente quando a evidência estiver verificada)

Também:
  - impede duas instâncias simultâneas;
  - grava heartbeat;
  - grava histórico de ciclos;
  - respeita intervalo mínimo de 30 minutos;
  - não chama endpoints de ordem;
  - não modifica estratégia, sizing, risco ou execução.

Arquivos:
  reports/validation_orchestrator_heartbeat.json
  reports/validation_orchestrator_history.jsonl
  data/validation_orchestrator.lock

Uso único:
  python tools/validation_orchestrator.py --once

Uso contínuo:
  python tools/validation_orchestrator.py

Variáveis:
  NEXOR_BASE_URL=http://127.0.0.1:8000
  NEXOR_ADMIN_TOKEN=<token>
  NEXOR_VALIDATION_INTERVAL_SECONDS=1800

Depois desta Update 63, a arquitetura deve permanecer congelada.
Novas updates somente para corrigir bug real ou falha encontrada na validação.

LIVE permanece bloqueado.
