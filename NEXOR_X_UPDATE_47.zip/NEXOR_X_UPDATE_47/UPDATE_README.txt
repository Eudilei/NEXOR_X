NEXOR X UPDATE 47 — ATOMIC ENTRY RESERVATION GUARD

Objetivo:
  impedir que duas tentativas simultâneas atravessem os gates ao mesmo tempo.

Regras:
  - uma reserva ativa por vez;
  - ID único por reserva;
  - expiração automática após 30 segundos;
  - confirmação após sucesso;
  - liberação após erro/cancelamento;
  - reduce-only fica fora deste bloqueio;
  - estado persistido em data/entry_reservation_state.json.

Endpoint:
  GET /api/operations/entry-reservation

LIVE permanece bloqueado.
