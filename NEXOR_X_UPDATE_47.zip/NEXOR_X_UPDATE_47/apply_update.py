from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/operations/entry_reservation.py",
        "tests/test_entry_reservation.py",
        "docs/AUDIT_UPDATE_47.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)
    imp = (
        "from .entry_reservation import "
        "AtomicEntryReservationGuard, EntryReservationPolicy\n"
    )
    if imp not in text:
        text = imp + text
    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "AtomicEntryReservationGuard" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += (
            '\n    "AtomicEntryReservationGuard",'
            '\n    "EntryReservationPolicy",\n'
        )
        text = text[:match.start(1)] + body + text[match.end(1):]
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)
    import_line = (
        "from nexor_x.operations.entry_reservation import "
        "AtomicEntryReservationGuard\n"
    )
    marker = (
        "from nexor_x.operations.probation_exposure_ramp import "
        "ProbationExposureRamp\n"
    )
    if import_line not in text:
        if marker not in text:
            raise RuntimeError("Update 46 não detectada")
        text = text.replace(marker, marker + import_line, 1)
    init_line = (
        "        self.entry_reservation_guard = AtomicEntryReservationGuard(\n"
        '            state_path="data/entry_reservation_state.json"\n'
        "        )\n"
    )
    marker2 = "        self.probation_exposure_ramp = ProbationExposureRamp()\n"
    if "self.entry_reservation_guard = AtomicEntryReservationGuard(" not in text:
        if marker2 not in text:
            raise RuntimeError("Update 46 não detectada: exposure ramp ausente")
        text = text.replace(marker2, marker2 + init_line, 1)
    if "async def entry_reservation_status(" not in text:
        marker3 = "    async def probation_exposure_ramp_status(\n"
        if marker3 not in text:
            raise RuntimeError("Update 46 não detectada: status exposure ramp ausente")
        method = (
            "    async def entry_reservation_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return self.entry_reservation_guard.status()\n\n"
        )
        text = text.replace(marker3, method + marker3, 1)
    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)
    if '@app.get("/api/operations/entry-reservation")' not in text:
        marker = '@app.get("/api/operations/exposure-ramp")'
        if marker not in text:
            raise RuntimeError("Update 46 não detectada: endpoint exposure-ramp ausente")
        block = (
            '@app.get("/api/operations/entry-reservation")\n'
            "    async def entry_reservation_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.entry_reservation_status()\n\n"
            "    "
        )
        text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    p = ROOT / "pyproject.toml"
    t = _read(p)
    t = re.sub(r'version = "[^"]+"', 'version = "0.47.0"', t, count=1)
    p.write_text(t, encoding="utf-8")
    i = ROOT / "src/nexor_x/__init__.py"
    t = _read(i)
    t = re.sub(r'__version__\s*=\s*"[^"]+"', '__version__ = "0.47.0"', t)
    i.write_text(t, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 47 aplicada. LIVE permanece bloqueado.")


if __name__ == "__main__":
    main()
