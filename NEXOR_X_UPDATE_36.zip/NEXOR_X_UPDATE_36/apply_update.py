from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_config() -> None:
    path = ROOT / "src/nexor_x/config.py"
    text = path.read_text(encoding="utf-8")
    fields = (
        "    ollama_autostart: bool = True\n"
        '    ollama_command: str = "ollama"\n'
        "    cloudflared_enabled: bool = True\n"
        '    cloudflared_command: str = "cloudflared"\n'
    )
    if "cloudflared_enabled:" not in text:
        marker = "    model_config = SettingsConfigDict("
        if marker not in text:
            raise RuntimeError("Config model marker not found")
        text = text.replace(marker, fields + "\n" + marker, 1)
    path.write_text(text, encoding="utf-8")


def replace_main() -> None:
    path = ROOT / "src/nexor_x/main.py"
    path.write_text('from __future__ import annotations\n\nimport asyncio\n\nimport uvicorn\n\nfrom nexor_x.api.app import create_app\nfrom nexor_x.config import get_settings\nfrom nexor_x.kernel import Kernel\nfrom nexor_x.logging import configure_logging\nfrom nexor_x.runtime import RuntimeProcessManager\n\n\nasync def serve() -> None:\n    settings = get_settings()\n    configure_logging(settings.nexor_log_level)\n    runtime = RuntimeProcessManager(settings)\n\n    await runtime.start_ollama()\n\n    kernel = Kernel(settings)\n    await kernel.start()\n    kernel.runtime_processes = runtime\n\n    app = create_app(kernel)\n    config = uvicorn.Config(\n        app=app,\n        host=settings.nexor_host,\n        port=settings.nexor_port,\n        log_level=settings.nexor_log_level.lower(),\n    )\n    server = uvicorn.Server(config)\n    server_task = asyncio.create_task(server.serve())\n\n    try:\n        for _ in range(100):\n            if server.started:\n                break\n            if server_task.done():\n                await server_task\n                return\n            await asyncio.sleep(0.05)\n\n        await runtime.start_cloudflared()\n        public_url = await runtime.wait_for_public_url(timeout=15.0)\n        status = await runtime.status()\n\n        print("")\n        print("==============================================")\n        print(" NEXOR X INICIADO")\n        print("==============================================")\n        print(f" Painel local:  {status[\'local_panel_url\']}")\n        print(\n            " Painel público: "\n            + (public_url or "Cloudflared indisponível/não configurado")\n        )\n        print(\n            " IA local: "\n            + ("ATIVA" if status["ollama"]["running"] else "NÃO INICIADA")\n        )\n        print(f" Modo: {settings.nexor_mode.value}")\n        print(" Operação real: BLOQUEADA")\n        print("==============================================")\n        print("")\n\n        await server_task\n    finally:\n        await runtime.stop()\n        await kernel.stop()\n\n\ndef run() -> None:\n    asyncio.run(serve())\n\n\nif __name__ == "__main__":\n    run()\n', encoding="utf-8")


def patch_kernel_runtime_status() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    if "self.runtime_processes = None" not in text:
        marker = "        self._started = False\n"
        if marker not in text:
            raise RuntimeError("Kernel _started marker not found")
        text = text.replace(
            marker,
            "        self.runtime_processes = None\n" + marker,
            1,
        )

    if "async def runtime_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        method = (
            "    async def runtime_status(self) -> dict[str, object]:\n"
            "        if self.runtime_processes is None:\n"
            "            return {\n"
            "                'local_panel_url': "
            "f'http://127.0.0.1:{self.settings.nexor_port}',\n"
            "                'public_panel_url': None,\n"
            "                'ollama': {'running': False, "
            "'details': 'Gerenciador não anexado.'},\n"
            "                'cloudflared': {'running': False, "
            "'details': 'Gerenciador não anexado.'},\n"
            "                'live_enabled': False,\n"
            "            }\n"
            "        return await self.runtime_processes.status()\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")
    if '@app.get("/api/system/runtime")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoint = (
            '    @app.get("/api/system/runtime")\n'
            "    async def runtime_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.runtime_status()\n\n"
        )
        text = text.replace(marker, endpoint + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.36.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.36.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_config()
    replace_main()
    patch_kernel_runtime_status()
    patch_api()
    patch_version()
    print("NEXOR X Update 36 aplicado com sucesso.")


if __name__ == "__main__":
    main()
