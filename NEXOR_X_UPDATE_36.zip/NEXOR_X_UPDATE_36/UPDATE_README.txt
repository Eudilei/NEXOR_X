NEXOR X UPDATE 36 — UM COMANDO + CLOUDFLARED

Após aplicar, use apenas: nexor-x
LIVE permanece bloqueado.
