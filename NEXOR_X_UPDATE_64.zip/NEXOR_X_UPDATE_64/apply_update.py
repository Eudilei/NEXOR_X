
from __future__ import annotations
from pathlib import Path
import re, shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"

def read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")

def copy_payload():
    for rel in (
        "src/nexor_x/operations/filter_rigidity.py",
        "tests/test_filter_rigidity.py",
        "docs/AUDIT_UPDATE_64.md",
    ):
        src, dst = PAYLOAD / rel, ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def patch_bankroll():
    changed = False
    candidates = [
        ROOT / ".env.example",
        ROOT / "src/nexor_x/config.py",
        ROOT / "src/nexor_x/settings.py",
        ROOT / "src/nexor_x/config/settings.py",
    ]
    for path in candidates:
        if not path.exists():
            continue
        text = read(path)
        original = text
        text = re.sub(
            r"INITIAL_BANKROLL\s*=\s*5000(?:\.0+)?",
            "INITIAL_BANKROLL=200",
            text,
            count=1,
        )
        text = re.sub(
            r"initial_bankroll\s*:\s*float\s*=\s*5000(?:\.0+)?",
            "initial_bankroll: float = 200.0",
            text,
            count=1,
        )
        text = re.sub(
            r"initial_bankroll\s*=\s*5000(?:\.0+)?",
            "initial_bankroll = 200.0",
            text,
            count=1,
        )
        if text != original:
            path.write_text(text, encoding="utf-8")
            changed = True

    env = ROOT / ".env.example"
    if env.exists():
        text = read(env)
        if "INITIAL_BANKROLL=" not in text:
            text += "\nINITIAL_BANKROLL=200\n"
        if "PAPER_BANKROLL_CURRENCY=" not in text:
            text += "PAPER_BANKROLL_CURRENCY=BRL\n"
        env.write_text(text, encoding="utf-8")
        changed = True

    if not changed:
        raise RuntimeError("Configuração de banca não localizada; patch abortado.")

def patch_ops_init():
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = read(path)
    imp = "from .filter_rigidity import FilterRigidityMonitor, FilterRigidityPolicy\n"
    if imp not in text:
        text = imp + text
    path.write_text(text, encoding="utf-8")

def patch_kernel():
    path = ROOT / "src/nexor_x/kernel.py"
    text = read(path)

    imp = "from nexor_x.operations.filter_rigidity import FilterRigidityMonitor\n"
    anchor = "from nexor_x.operations.entry_decision_trace import UnifiedEntryDecisionTrace\n"
    if imp not in text:
        if anchor not in text:
            raise RuntimeError("Entry Decision Trace não encontrado")
        text = text.replace(anchor, anchor + imp, 1)

    init = (
        "        self.filter_rigidity_monitor = FilterRigidityMonitor(\n"
        '            state_path="data/filter_rigidity_state.json"\n'
        "        )\n"
    )
    anchor2 = "        self.entry_decision_trace = UnifiedEntryDecisionTrace()\n"
    if "self.filter_rigidity_monitor = FilterRigidityMonitor(" not in text:
        if anchor2 not in text:
            raise RuntimeError("entry_decision_trace não encontrado")
        text = text.replace(anchor2, anchor2 + init, 1)

    if "async def filter_rigidity_status(" not in text:
        marker = "    async def unified_entry_decision_trace(\n"
        if marker not in text:
            raise RuntimeError("unified_entry_decision_trace não encontrado")
        method = (
            "    async def filter_rigidity_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return self.filter_rigidity_monitor.status()\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")

def patch_api():
    path = ROOT / "src/nexor_x/api/app.py"
    text = read(path)
    if '@app.get("/api/operations/filter-rigidity")' in text:
        return
    marker = '@app.get("/api/operations/entry-decision-trace")'
    if marker not in text:
        raise RuntimeError("entry-decision-trace endpoint não encontrado")
    block = (
        '@app.get("/api/operations/filter-rigidity")\n'
        "    async def filter_rigidity_status(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return await kernel.filter_rigidity_status()\n\n"
        "    "
    )
    text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")

def patch_version():
    path = ROOT / "pyproject.toml"
    text = read(path)
    text = re.sub(r'version = "[^"]+"', 'version = "0.64.0"', text, count=1)
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = read(path)
    text = re.sub(r'__version__\s*=\s*"[^"]+"', '__version__ = "0.64.0"', text)
    path.write_text(text, encoding="utf-8")

def main():
    copy_payload()
    patch_bankroll()
    patch_ops_init()
    patch_kernel()
    patch_api()
    patch_version()
    print("Update 64 aplicada: PAPER R$200; monitor de rigidez ativo; LIVE bloqueado.")

if __name__ == "__main__":
    main()
