import nexor_x.evidence as evidence


def test_evidence_package_preserves_legacy_symbol() -> None:
    assert hasattr(evidence, "EvidenceEngine")


def test_new_collector_is_available() -> None:
    assert hasattr(evidence, "EvidenceCollector")
