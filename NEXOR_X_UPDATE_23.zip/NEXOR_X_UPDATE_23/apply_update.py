from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.update_engine import UpdateRegistryService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.update_registry = UpdateRegistryService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        text = text.replace(
            marker,
            "        self.update_registry = UpdateRegistryService(self.database)\n"
            + marker,
            1,
        )

    if "await self.update_registry.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker
            + "        await self.update_registry.start()\n"
            + "        await self.update_registry.register_runtime_version(\n"
            + "            version=__version__,\n"
            + "            update_id='23',\n"
            + "            source='runtime_startup',\n"
            + "        )\n",
            1,
        )

        version_import = "from nexor_x import __version__\n"
        if version_import not in text:
            first_import = "from nexor_x.ai.ollama import OllamaService\n"
            if first_import in text:
                text = text.replace(first_import, version_import + first_import, 1)
            else:
                text = version_import + text

    if "async def update_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        text = text.replace(
            marker,
            "    async def update_status(self) -> dict[str, object]:\n"
            + "        return await self.update_registry.status()\n\n"
            + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    endpoint = '@app.get("/api/system/updates")'
    if endpoint not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("API portfolio marker not found")
        text = text.replace(
            marker,
            '    @app.get("/api/system/updates")\n'
            + "    async def system_updates(\n"
            + "        _: None = Depends(require_admin),\n"
            + "    ) -> dict[str, Any]:\n"
            + "        return await kernel.update_status()\n\n"
            + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(r'version = "[^"]+"', 'version = "0.23.0"', text, count=1)
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.23.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def cleanup_legacy_installers() -> None:
    tools = ROOT / "tools"
    if tools.exists():
        for path in tools.glob("apply_sprint*.py"):
            path.unlink()


def main() -> None:
    patch_kernel()
    patch_api()
    patch_version()
    cleanup_legacy_installers()
    print("NEXOR X Update 23 aplicado com sucesso.")


if __name__ == "__main__":
    main()
