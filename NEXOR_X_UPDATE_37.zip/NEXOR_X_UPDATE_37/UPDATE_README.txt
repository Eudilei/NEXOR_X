NEXOR X UPDATE 37 — EXECUÇÃO AUTÔNOMA EM SIMULAÇÃO

Envie o ZIP para a raiz do repositório.

Com AUTO_PAPER_ENABLED=true, a cada ciclo o NEXOR X:
- varre o mercado;
- pega os melhores candidatos;
- evita símbolo já aberto;
- executa trading_readiness;
- exige backtest contextual aprovado;
- abre no máximo 1 nova posição PAPER por ciclo.

Nenhuma ordem TESTNET ou LIVE é criada por este módulo.
