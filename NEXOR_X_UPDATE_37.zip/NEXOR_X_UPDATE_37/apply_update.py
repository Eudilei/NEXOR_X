from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_config() -> None:
    path = ROOT / "src/nexor_x/config.py"
    text = path.read_text(encoding="utf-8")

    fields = (
        "    auto_paper_enabled: bool = True\n"
        "    auto_paper_interval_seconds: float = 60.0\n"
        "    auto_paper_maximum_entries_per_cycle: int = 1\n"
    )
    if "auto_paper_enabled:" not in text:
        marker = "    model_config = SettingsConfigDict("
        if marker not in text:
            raise RuntimeError("Config model marker not found")
        text = text.replace(marker, fields + "\n" + marker, 1)

    mapping_marker = '        "SCANNER_ENABLED": "scanner_enabled",\n'
    mapping_fields = (
        '        "AUTO_PAPER_ENABLED": "auto_paper_enabled",\n'
        '        "AUTO_PAPER_INTERVAL_SECONDS": '
        '"auto_paper_interval_seconds",\n'
        '        "AUTO_PAPER_MAXIMUM_ENTRIES_PER_CYCLE": '
        '"auto_paper_maximum_entries_per_cycle",\n'
    )
    if '"AUTO_PAPER_ENABLED"' not in text:
        if mapping_marker not in text:
            raise RuntimeError("Config environment mapping marker not found")
        text = text.replace(
            mapping_marker,
            mapping_fields + mapping_marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.autopaper import AutoPaperService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.auto_paper = AutoPaperService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Scanner constructor marker not found")
        block = (
            "        self.auto_paper = AutoPaperService(\n"
            "            self.database,\n"
            "            scanner_run=self.scanner_run,\n"
            "            trading_readiness=self.trading_readiness,\n"
            "            paper_open=self.paper_open,\n"
            "            portfolio_snapshot=self.portfolio.snapshot,\n"
            "            maximum_entries_per_cycle="
            "settings.auto_paper_maximum_entries_per_cycle,\n"
            "        )\n"
        )
        # Must be after self.scanner exists, so inject after constructor block via
        # the telegram marker which follows scanner construction in current Kernel.
        telegram_marker = (
            "        self.telegram = TelegramService("
        )
        if telegram_marker not in text:
            raise RuntimeError("Telegram constructor marker not found")
        text = text.replace(
            telegram_marker,
            block + telegram_marker,
            1,
        )

    if "await self.auto_paper.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Portfolio startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.auto_paper.start()\n",
            1,
        )

    if '"auto_paper_cycle"' not in text:
        marker = (
            "        if self.settings.scanner_enabled:\n"
        )
        if marker not in text:
            raise RuntimeError("Scanner scheduler marker not found")
        schedule = (
            "        if self.settings.auto_paper_enabled:\n"
            "            self.scheduler.add_job(\n"
            "                ScheduledJob(\n"
            "                    'auto_paper_cycle',\n"
            "                    self.settings.auto_paper_interval_seconds,\n"
            "                    self._scheduled_auto_paper,\n"
            "                )\n"
            "            )\n"
        )
        text = text.replace(marker, schedule + marker, 1)

    if "async def auto_paper_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def auto_paper_status(self) -> dict[str, object]:\n"
            "        return await self.auto_paper.status()\n\n"
            "    async def auto_paper_run(self) -> dict[str, object]:\n"
            "        if self.settings.nexor_mode.value != 'PAPER':\n"
            "            raise RuntimeError(\n"
            "                'Execução automática permitida somente em PAPER'\n"
            "            )\n"
            "        result = await self.auto_paper.run_once()\n"
            "        await self.event_bus.publish(Event(\n"
            "            'execution.auto_paper_cycle',\n"
            "            {\n"
            "                'status': result['status'],\n"
            "                'opened_positions': result['opened_positions'],\n"
            "                'errors': result['errors'],\n"
            "                'live_execution_allowed': False,\n"
            "            },\n"
            "            'auto_paper',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    if "async def _scheduled_auto_paper" not in text:
        marker = "    async def _scheduled_scan(self) -> None:\n"
        if marker not in text:
            raise RuntimeError("Scheduled scan marker not found")
        scheduled = (
            "    async def _scheduled_auto_paper(self) -> None:\n"
            "        try:\n"
            "            await self.auto_paper_run()\n"
            "        except Exception as exc:\n"
            "            self._log.warning(\n"
            "                'scheduled_auto_paper_failed error=%s',\n"
            "                exc,\n"
            "            )\n"
            "\n"
        )
        text = text.replace(marker, scheduled + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if '@app.get("/api/execution/auto-paper/status")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.get("/api/execution/auto-paper/status")\n'
            "    async def auto_paper_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.auto_paper_status()\n\n"
            '    @app.post("/api/execution/auto-paper/run")\n'
            "    async def auto_paper_run(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        try:\n"
            "            return await kernel.auto_paper_run()\n"
            "        except RuntimeError as exc:\n"
            "            raise HTTPException(\n"
            "                status_code=409,\n"
            "                detail=str(exc),\n"
            "            ) from exc\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_env_example() -> None:
    path = ROOT / ".env.example"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    block = (
        "\n# EXECUÇÃO AUTOMÁTICA EM SIMULAÇÃO\n"
        "AUTO_PAPER_ENABLED=true\n"
        "AUTO_PAPER_INTERVAL_SECONDS=60\n"
        "AUTO_PAPER_MAXIMUM_ENTRIES_PER_CYCLE=1\n"
    )
    if "AUTO_PAPER_ENABLED=" not in text:
        text += block
        path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.37.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.37.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_config()
    patch_kernel()
    patch_api()
    patch_env_example()
    patch_version()
    print("NEXOR X Update 37 aplicado com sucesso.")


if __name__ == "__main__":
    main()
