from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_connector() -> None:
    path = ROOT / "src/nexor_x/exchange/binance_live.py"
    text = path.read_text(encoding="utf-8")

    if "async def create_testnet_order(" not in text:
        marker = "    async def _signed_get(\n"
        if marker not in text:
            raise RuntimeError("Signed GET marker not found")
        method = (
            "    async def create_testnet_order(\n"
            "        self,\n"
            "        *,\n"
            "        symbol: str,\n"
            "        side: str,\n"
            "        order_type: str,\n"
            "        quantity: float,\n"
            "        price: float | None,\n"
            "        reduce_only: bool,\n"
            "        client_order_id: str,\n"
            "    ) -> dict[str, Any]:\n"
            "        if not self.policy.use_testnet:\n"
            "            raise RuntimeError('Order creation is restricted to TESTNET')\n"
            "        if not self.credentials.configured:\n"
            "            raise RuntimeError('Binance credentials are not configured')\n"
            "        params: dict[str, Any] = {\n"
            "            'symbol': symbol,\n"
            "            'side': side,\n"
            "            'type': order_type,\n"
            "            'quantity': quantity,\n"
            "            'reduceOnly': 'true' if reduce_only else 'false',\n"
            "            'newClientOrderId': client_order_id,\n"
            "        }\n"
            "        if price is not None:\n"
            "            params['price'] = price\n"
            "            params['timeInForce'] = 'GTC'\n"
            "        return await self._signed_post('/fapi/v1/order', params)\n\n"
            "    async def _signed_post(\n"
            "        self,\n"
            "        path: str,\n"
            "        params: dict[str, Any],\n"
            "    ) -> dict[str, Any]:\n"
            "        client = self._require_client()\n"
            "        timestamp = int(time.time() * 1000) + self._time_offset_ms\n"
            "        payload = {\n"
            "            **params,\n"
            "            'timestamp': timestamp,\n"
            "            'recvWindow': self.policy.recv_window_ms,\n"
            "        }\n"
            "        query = urlencode(payload)\n"
            "        signature = hmac.new(\n"
            "            self.credentials.api_secret.encode('utf-8'),\n"
            "            query.encode('utf-8'),\n"
            "            hashlib.sha256,\n"
            "        ).hexdigest()\n"
            "        headers = {'X-MBX-APIKEY': self.credentials.api_key}\n"
            "        response = await client.post(\n"
            "            f'{self.base_url}{path}?{query}&signature={signature}',\n"
            "            headers=headers,\n"
            "        )\n"
            "        response.raise_for_status()\n"
            "        return dict(response.json())\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    if "from nexor_x.orders import OrderSide, OrderType, TestnetOrderRequest, TestnetOrderService" not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(
            marker,
            marker
            + "from nexor_x.orders import (\n"
            + "    OrderSide,\n"
            + "    OrderType,\n"
            + "    TestnetOrderRequest,\n"
            + "    TestnetOrderService,\n"
            + ")\n",
            1,
        )

    if "self.testnet_orders = TestnetOrderService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        block = (
            "        self.testnet_orders = TestnetOrderService(\n"
            "            self.database,\n"
            "            self.binance_live,\n"
            "        )\n"
        )
        text = text.replace(marker, block + marker, 1)

    if "await self.testnet_orders.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.testnet_orders.start()\n",
            1,
        )

    if "async def testnet_order_create" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        method = (
            "    async def testnet_order_create(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        request = TestnetOrderRequest(\n"
            "            symbol=str(payload['symbol']),\n"
            "            side=OrderSide(str(payload['side']).upper()),\n"
            "            order_type=OrderType(str(payload['order_type']).upper()),\n"
            "            quantity=float(payload['quantity']),\n"
            "            price=(None if payload.get('price') is None else float(payload['price'])),\n"
            "            reduce_only=bool(payload.get('reduce_only', False)),\n"
            "            client_order_id=(\n"
            "                None if not payload.get('client_order_id')\n"
            "                else str(payload['client_order_id'])\n"
            "            ),\n"
            "        )\n"
            "        result = await self.testnet_orders.create(\n"
            "            strategy_id=str(payload['strategy_id']),\n"
            "            signal_id=str(payload['signal_id']),\n"
            "            request=request,\n"
            "        )\n"
            "        await self.event_bus.publish(Event(\n"
            "            'order.testnet_submitted',\n"
            "            {\n"
            "                'symbol': result['request']['symbol'],\n"
            "                'status': result['status'],\n"
            "                'duplicate': result['duplicate'],\n"
            "                'live_order_sent': False,\n"
            "            },\n"
            "            'testnet_order_service',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if "class TestnetOrderCreateRequest(BaseModel):" not in text:
        marker = "class ChatRequest(BaseModel):\n"
        if marker not in text:
            raise RuntimeError("ChatRequest marker not found")
        model = (
            "class TestnetOrderCreateRequest(BaseModel):\n"
            "    strategy_id: str = Field(min_length=2, max_length=80)\n"
            "    signal_id: str = Field(min_length=2, max_length=120)\n"
            "    symbol: str = Field(min_length=3, max_length=30)\n"
            "    side: str = Field(pattern='^(BUY|SELL)$')\n"
            "    order_type: str = Field(pattern='^(MARKET|LIMIT)$')\n"
            "    quantity: float = Field(gt=0)\n"
            "    price: float | None = Field(default=None, gt=0)\n"
            "    reduce_only: bool = False\n"
            "    client_order_id: str | None = Field(default=None, max_length=36)\n\n"
        )
        text = text.replace(marker, model + marker, 1)

    if '@app.post("/api/exchange/testnet/orders")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoint = (
            '    @app.post("/api/exchange/testnet/orders")\n'
            "    async def create_testnet_order(\n"
            "        body: TestnetOrderCreateRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        try:\n"
            "            return await kernel.testnet_order_create(body.model_dump())\n"
            "        except (KeyError, TypeError, ValueError, RuntimeError) as exc:\n"
            "            raise HTTPException(status_code=422, detail=str(exc)) from exc\n\n"
        )
        text = text.replace(marker, endpoint + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(r'version = "[^"]+"', 'version = "0.22.0"', text, count=1)
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(r'__version__\s*=\s*"[^"]+"', '__version__ = "0.22.0"', text)
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_connector()
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 22 aplicado com sucesso.")


if __name__ == "__main__":
    main()
