NEXOR X UPDATE 22

Novo formato de atualização automática.

Como usar:
1. Envie NEXOR_X_UPDATE_22.zip para a RAIZ do repositório GitHub.
2. Não descompacte.
3. O workflow .github/workflows/nexor-auto-update.yml fará:
   - validação do pacote;
   - extração;
   - aplicação do payload;
   - execução do apply_update.py;
   - instalação das dependências;
   - compilação;
   - Ruff;
   - suíte completa de testes;
   - remoção do ZIP;
   - commit automático se tudo passar.

Não é necessário usar Codespaces.

Segurança:
- Esta atualização continua restrita à Binance Futures TESTNET.
- LIVE permanece bloqueado.
