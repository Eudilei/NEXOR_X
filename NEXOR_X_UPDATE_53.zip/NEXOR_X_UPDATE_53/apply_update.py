
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/validation/final_campaign.py",
        "tests/test_final_validation_campaign.py",
        "docs/AUDIT_UPDATE_53.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_validation_init() -> None:
    path = ROOT / "src/nexor_x/validation/__init__.py"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    imp = (
        "from .final_campaign import "
        "FinalValidationCampaignController, "
        "FinalValidationCampaignPolicy\n"
    )
    if imp not in text:
        text = imp + text

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.validation.final_campaign import "
        "FinalValidationCampaignController\n"
    )
    anchor = (
        "from nexor_x.operations.operational_acceptance_audit import "
        "OperationalAcceptanceAudit\n"
    )

    if import_line not in text:
        if anchor not in text:
            raise RuntimeError(
                "Update 52 não detectada: OperationalAcceptanceAudit ausente"
            )
        text = text.replace(
            anchor,
            anchor + import_line,
            1,
        )

    init_line = (
        "        self.final_validation_campaign = "
        "FinalValidationCampaignController(\n"
        '            state_path="data/final_validation_campaign.json"\n'
        "        )\n"
    )
    anchor2 = (
        "        self.operational_acceptance_audit = "
        "OperationalAcceptanceAudit()\n"
    )

    if "self.final_validation_campaign = FinalValidationCampaignController(" not in text:
        if anchor2 not in text:
            raise RuntimeError(
                "Update 52 não detectada: acceptance audit object ausente"
            )
        text = text.replace(
            anchor2,
            anchor2 + init_line,
            1,
        )

    if "async def final_validation_campaign_status(" not in text:
        marker = "    async def operational_acceptance_audit(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 52 não detectada: acceptance audit method ausente"
            )

        methods = (
            "    async def final_validation_campaign_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return self.final_validation_campaign.status()\n\n"
            "    async def final_validation_campaign_tick(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        audit = await self.operational_acceptance_audit()\n"
            "        return self.final_validation_campaign.record(\n"
            "            audit=audit,\n"
            "        )\n\n"
        )
        text = text.replace(
            marker,
            methods + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    marker = '@app.get("/api/operations/acceptance-audit")'
    if marker not in text:
        raise RuntimeError(
            "Update 52 não detectada: acceptance-audit endpoint ausente"
        )

    if '@app.get("/api/validation/final-campaign")' not in text:
        block = (
            '@app.get("/api/validation/final-campaign")\n'
            "    async def final_validation_campaign_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.final_validation_campaign_status()\n\n"
            "    "
            '@app.post("/api/validation/final-campaign/tick")\n'
            "    async def final_validation_campaign_tick(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.final_validation_campaign_tick()\n\n"
            "    "
        )
        text = text.replace(
            marker,
            block + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.53.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.53.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_validation_init()
    patch_kernel()
    patch_api()
    patch_version()
    print(
        "NEXOR X Update 53 aplicada: Final Validation Campaign "
        "adicionada. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
