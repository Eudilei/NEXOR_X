NEXOR X UPDATE 53 — FINAL VALIDATION CAMPAIGN

Objetivo:
  transformar o PASS/FAIL da Update 52 em uma campanha de validação acumulada
  e persistente antes de encerrarmos a fase técnica PAPER/TESTNET.

Política padrão:
  - exige 20 auditorias PASS válidas;
  - intervalo mínimo de 30 minutos entre amostras válidas;
  - exige pelo menos 24 horas entre a primeira e a última amostra;
  - FAIL zera a sequência consecutiva de PASS;
  - polling repetido antes do intervalo mínimo não conta;
  - estado persiste em data/final_validation_campaign.json.

IMPORTANTE:
  esta campanha NÃO substitui a certificação de evidências da Update 41
  (30 dias / 100 trades / PF / drawdown). Ela apenas valida a coerência
  operacional do sistema ao longo do tempo.

Endpoints administrativos:
  GET  /api/validation/final-campaign
  POST /api/validation/final-campaign/tick

LIVE permanece bloqueado.

Requer NEXOR X 0.52.0.
