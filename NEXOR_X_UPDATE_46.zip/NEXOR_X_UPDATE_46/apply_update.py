
from __future__ import annotations
from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"

def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")

def copy_payload() -> None:
    for rel in (
        "src/nexor_x/operations/probation_exposure_ramp.py",
        "tests/test_probation_exposure_ramp.py",
        "docs/AUDIT_UPDATE_46.md",
    ):
        src = PAYLOAD / rel
        if rel.startswith("src/"):
            dst = ROOT / rel
        else:
            dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)
    imp = "from .probation_exposure_ramp import ProbationExposureRamp, ProbationExposureRampPolicy\n"
    if imp not in text:
        text = imp + text
    if "__all__" in text and "ProbationExposureRamp" not in text.split("__all__", 1)[1]:
        text = text.replace(
            "__all__ = [",
            '__all__ = ["ProbationExposureRamp", "ProbationExposureRampPolicy", ',
            1,
        )
    path.write_text(text, encoding="utf-8")

def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    imp = "from nexor_x.operations.probation_exposure_ramp import ProbationExposureRamp\n"
    marker = "from nexor_x.operations.post_recovery_probation import PostRecoveryProbationController\n"
    if imp not in text:
        if marker not in text:
            raise RuntimeError("Update 45 não detectada")
        text = text.replace(marker, marker + imp, 1)

    init = "        self.probation_exposure_ramp = ProbationExposureRamp()\n"
    marker2 = (
        "        self.post_recovery_probation = PostRecoveryProbationController(\n"
        '            state_path="data/entry_probation_state.json"\n'
        "        )\n"
    )
    if init not in text:
        if marker2 not in text:
            raise RuntimeError("Update 45 não detectada: probation controller ausente")
        text = text.replace(marker2, marker2 + init, 1)

    block = (
        '        report["post_recovery_probation"] = {\n'
        '            "active": probation["active"],\n'
        '            "allowed": probation["allowed"],\n'
        '            "block_reason": probation["block_reason"],\n'
        '            "admitted_entries": probation["admitted_entries"],\n'
        '            "max_entries_during_probation": (\n'
        '                probation["max_entries_during_probation"]\n'
        '            ),\n'
        '            "remaining_seconds": probation["remaining_seconds"],\n'
        '        }\n'
    )
    if 'report["exposure_multiplier"]' not in text:
        if block not in text:
            raise RuntimeError("Bloco probation da Update 45 não encontrado")
        add = (
            block
            + '        exposure = self.probation_exposure_ramp.evaluate(\n'
            + '            probation=probation, reduce_only=reduce_only\n'
            + '        )\n'
            + '        report["exposure_ramp"] = exposure\n'
            + '        report["exposure_multiplier"] = exposure["exposure_multiplier"]\n'
        )
        text = text.replace(block, add, 1)

    block2 = (
        '                report["post_recovery_probation"] = {\n'
        '                    "active": probation["active"],\n'
        '                    "allowed": probation["allowed"],\n'
        '                    "block_reason": probation["block_reason"],\n'
        '                    "admitted_entries": probation["admitted_entries"],\n'
        '                    "max_entries_during_probation": (\n'
        '                        probation["max_entries_during_probation"]\n'
        '                    ),\n'
        '                    "remaining_seconds": probation["remaining_seconds"],\n'
        '                }\n'
    )
    if text.count('report["exposure_multiplier"]') < 2:
        if block2 not in text:
            raise RuntimeError("Bloco de admissão da Update 45 não encontrado")
        add2 = (
            block2
            + '                exposure = self.probation_exposure_ramp.evaluate(\n'
            + '                    probation=probation, reduce_only=False\n'
            + '                )\n'
            + '                report["exposure_ramp"] = exposure\n'
            + '                report["exposure_multiplier"] = exposure["exposure_multiplier"]\n'
        )
        text = text.replace(block2, add2, 1)

    if "async def probation_exposure_ramp_status(" not in text:
        marker3 = "    async def post_recovery_probation_status(\n"
        if marker3 not in text:
            raise RuntimeError("Status probation da Update 45 não encontrado")
        method = (
            "    async def probation_exposure_ramp_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        probation = self.post_recovery_probation.status()\n"
            "        return self.probation_exposure_ramp.evaluate(\n"
            "            probation=probation, reduce_only=False\n"
            "        )\n\n"
        )
        text = text.replace(marker3, method + marker3, 1)

    old = (
        '        reduce_only = bool(payload.get("reduce_only", False))\n'
        '        await self.require_entry_admission(\n'
        '            action="TESTNET_CREATE",\n'
        '            reduce_only=reduce_only,\n'
        '        )\n'
    )
    if 'payload["original_quantity"]' not in text:
        if old not in text:
            raise RuntimeError("Fluxo TESTNET esperado não encontrado")
        new = (
            '        reduce_only = bool(payload.get("reduce_only", False))\n'
            '        admission = await self.require_entry_admission(\n'
            '            action="TESTNET_CREATE",\n'
            '            reduce_only=reduce_only,\n'
            '        )\n'
            '        if not reduce_only and payload.get("quantity") is not None:\n'
            '            payload = dict(payload)\n'
            '            original_quantity = payload["quantity"]\n'
            '            payload["original_quantity"] = original_quantity\n'
            '            payload["quantity"] = self.probation_exposure_ramp.scale_quantity(\n'
            '                original_quantity,\n'
            '                float(admission.get("exposure_multiplier", 1.0)),\n'
            '            )\n'
            '            payload["exposure_multiplier"] = admission.get(\n'
            '                "exposure_multiplier", 1.0\n'
            '            )\n'
        )
        text = text.replace(old, new, 1)

    path.write_text(text, encoding="utf-8")

def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)
    if '@app.get("/api/operations/exposure-ramp")' not in text:
        marker = '@app.get("/api/operations/post-recovery-probation")'
        if marker not in text:
            raise RuntimeError("Endpoint probation da Update 45 não encontrado")
        block = (
            '@app.get("/api/operations/exposure-ramp")\n'
            '    async def probation_exposure_ramp_status(\n'
            '        _: None = Depends(require_admin),\n'
            '    ) -> dict[str, Any]:\n'
            '        return await kernel.probation_exposure_ramp_status()\n\n'
            '    '
        )
        text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")

def patch_version() -> None:
    p = ROOT / "pyproject.toml"
    t = _read(p)
    t = re.sub(r'version = "[^"]+"', 'version = "0.46.0"', t, count=1)
    p.write_text(t, encoding="utf-8")
    i = ROOT / "src/nexor_x/__init__.py"
    t = _read(i)
    t = re.sub(r'__version__\s*=\s*"[^"]+"', '__version__ = "0.46.0"', t)
    i.write_text(t, encoding="utf-8")

def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 46 aplicada. LIVE permanece bloqueado.")

if __name__ == "__main__":
    main()
