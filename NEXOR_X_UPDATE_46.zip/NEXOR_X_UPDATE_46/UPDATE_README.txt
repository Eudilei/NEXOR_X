NEXOR X UPDATE 46 — PROBATION EXPOSURE RAMP

Durante a provação pós-recuperação:
- 1ª admissão: 25%
- 2ª admissão: 50%
- 3ª admissão: 75%
- fora da provação: 100%
- reduce-only: 100%

O gate passa a retornar exposure_multiplier.
TESTNET com quantity explícita é escalada.
LIVE permanece bloqueado.
