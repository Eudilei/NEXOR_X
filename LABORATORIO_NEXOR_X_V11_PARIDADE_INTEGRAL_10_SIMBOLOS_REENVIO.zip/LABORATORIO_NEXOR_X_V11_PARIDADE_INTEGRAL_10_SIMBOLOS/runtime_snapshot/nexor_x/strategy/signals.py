from __future__ import annotations

from collections.abc import Iterable
from dataclasses import asdict, dataclass
from math import sqrt


@dataclass(frozen=True, slots=True)
class StrategyCandle:
    timestamp_ms: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True, slots=True)
class StrategySignal:
    strategy_id: str
    decision: str
    score: float
    passed: bool
    checks: dict[str, bool]
    metrics: dict[str, float]
    rationale: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["rationale"] = list(self.rationale)
        return data


class StrategySignalEngine:
    """Causal OHLCV signal engine shared by PAPER and historical replay."""

    minimum_bars = 60

    def evaluate(
        self, candles: Iterable[StrategyCandle], *, regime: str, market_decision: str
    ) -> tuple[StrategySignal, ...]:
        bars = tuple(candles)
        if len(bars) < self.minimum_bars:
            return ()
        closes = [bar.close for bar in bars]
        highs = [bar.high for bar in bars]
        lows = [bar.low for bar in bars]
        volumes = [bar.volume for bar in bars]
        ema20 = self._ema(closes, 20)
        ema50 = self._ema(closes, 50)
        rsi = self._rsi(closes, 14)
        atr = self._atr(bars, 14)
        mean20 = sum(closes[-20:]) / 20
        std20 = sqrt(sum((x - mean20) ** 2 for x in closes[-20:]) / 20)
        prior_high = max(highs[-21:-1])
        prior_low = min(lows[-21:-1])
        avg_volume = sum(volumes[-21:-1]) / 20
        metrics = {
            "ema20": ema20,
            "ema50": ema50,
            "rsi14": rsi,
            "atr_pct": atr / closes[-1] if closes[-1] else 0.0,
            "zscore20": (closes[-1] - mean20) / std20 if std20 else 0.0,
            "volume_ratio": volumes[-1] / avg_volume if avg_volume else 0.0,
            "roc5": closes[-1] / closes[-6] - 1 if closes[-6] else 0.0,
            "prior_high20": prior_high,
            "prior_low20": prior_low,
        }
        bar = bars[-1]
        candidates = (
            self._trend_pullback(bar, regime, metrics),
            self._breakout(bar, regime, metrics),
            self._mean_reversion(bar, regime, metrics),
            self._momentum(bar, regime, metrics),
            self._liquidity_sweep(bar, regime, metrics),
        )
        return tuple(self._align(item, market_decision) for item in candidates)

    @staticmethod
    def select(signals: Iterable[StrategySignal]) -> StrategySignal | None:
        eligible = [item for item in signals if item.passed]
        return max(eligible, key=lambda item: (item.score, item.strategy_id), default=None)

    def _trend_pullback(
        self, bar: StrategyCandle, regime: str, m: dict[str, float]
    ) -> StrategySignal:
        long = (
            m["ema20"] > m["ema50"]
            and bar.low <= m["ema20"] <= bar.close
            and 45 <= m["rsi14"] <= 68
        )
        short = (
            m["ema20"] < m["ema50"]
            and bar.high >= m["ema20"] >= bar.close
            and 32 <= m["rsi14"] <= 55
        )
        return self._signal("trend_pullback", regime in {"TREND_UP", "TREND_DOWN"}, long, short, m)

    def _breakout(self, bar: StrategyCandle, regime: str, m: dict[str, float]) -> StrategySignal:
        long = bar.close > m["prior_high20"] and m["volume_ratio"] >= 1.20
        short = bar.close < m["prior_low20"] and m["volume_ratio"] >= 1.20
        return self._signal("breakout", regime in {"COMPRESSION", "EXPANSION"}, long, short, m)

    def _mean_reversion(
        self, bar: StrategyCandle, regime: str, m: dict[str, float]
    ) -> StrategySignal:
        long = m["zscore20"] <= -1.5 and m["rsi14"] <= 35
        short = m["zscore20"] >= 1.5 and m["rsi14"] >= 65
        return self._signal("mean_reversion", regime == "RANGE", long, short, m)

    def _momentum(self, bar: StrategyCandle, regime: str, m: dict[str, float]) -> StrategySignal:
        long = m["ema20"] > m["ema50"] and m["rsi14"] >= 55 and m["roc5"] > 0
        short = m["ema20"] < m["ema50"] and m["rsi14"] <= 45 and m["roc5"] < 0
        return self._signal(
            "momentum", regime in {"TREND_UP", "TREND_DOWN", "EXPANSION"}, long, short, m
        )

    def _liquidity_sweep(
        self, bar: StrategyCandle, regime: str, m: dict[str, float]
    ) -> StrategySignal:
        long = bar.low < m["prior_low20"] and bar.close > m["prior_low20"]
        short = bar.high > m["prior_high20"] and bar.close < m["prior_high20"]
        return self._signal("liquidity_sweep", regime in {"RANGE", "EXPANSION"}, long, short, m)

    @staticmethod
    def _signal(
        strategy_id: str, regime_ok: bool, long: bool, short: bool, metrics: dict[str, float]
    ) -> StrategySignal:
        decision = "LONG_BIAS" if long else "SHORT_BIAS" if short else "NO_EDGE"
        checks = {"strategy_regime": regime_ok, "strategy_setup": bool(long or short)}
        score = (
            min(
                abs(metrics["roc5"]) * 10
                + abs(metrics["zscore20"]) * 0.15
                + max(metrics["volume_ratio"] - 1, 0) * 0.10
                + 0.50,
                1.0,
            )
            if all(checks.values())
            else 0.0
        )
        return StrategySignal(
            strategy_id,
            decision,
            round(score, 6),
            all(checks.values()),
            checks,
            dict(metrics),
            tuple(k for k, v in checks.items() if not v),
        )

    @staticmethod
    def _align(signal: StrategySignal, market_decision: str) -> StrategySignal:
        aligned = signal.passed and signal.decision == market_decision
        checks = {**signal.checks, "quant_direction_alignment": signal.decision == market_decision}
        rationale = signal.rationale + (
            () if checks["quant_direction_alignment"] else ("quant_direction_alignment",)
        )
        return StrategySignal(
            signal.strategy_id,
            signal.decision,
            signal.score if aligned else 0.0,
            aligned,
            checks,
            signal.metrics,
            rationale,
        )

    @staticmethod
    def _ema(values: list[float], period: int) -> float:
        value = values[0]
        alpha = 2 / (period + 1)
        for item in values[1:]:
            value = alpha * item + (1 - alpha) * value
        return value

    @staticmethod
    def _rsi(values: list[float], period: int) -> float:
        changes = [values[i] - values[i - 1] for i in range(1, len(values))][-period:]
        gain = sum(max(x, 0) for x in changes) / period
        loss = sum(max(-x, 0) for x in changes) / period
        return 100.0 if loss == 0 else 100 - (100 / (1 + gain / loss))

    @staticmethod
    def _atr(bars: tuple[StrategyCandle, ...], period: int) -> float:
        values = [
            max(bar.high - bar.low, abs(bar.high - prior.close), abs(bar.low - prior.close))
            for prior, bar in zip(
                bars[-period - 1 : -1], bars[-period:], strict=True
            )
        ]
        return sum(values) / len(values) if values else 0.0
