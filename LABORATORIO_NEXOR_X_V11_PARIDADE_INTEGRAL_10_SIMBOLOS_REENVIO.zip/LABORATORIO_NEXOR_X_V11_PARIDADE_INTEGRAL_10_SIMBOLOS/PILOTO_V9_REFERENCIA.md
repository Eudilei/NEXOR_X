# Piloto V9 — recuperação controlada em 50 símbolos

Esta rodada amplia o teste causal para 50 símbolos, mantendo a análise profunda
restrita aos 10 melhores de cada ciclo para controlar o tempo de execução.

- Universo: 50 símbolos elegíveis; BTC, ETH, BNB, SOL, XRP, ADA, DOGE, TRX,
  LINK e LTC têm prioridade quando existem na base.
- Risco PAPER por operação: 2% da banca atual.
- Risco agregado máximo aberto: 10%.
- Hard stop de drawdown: 25%.
- Calibração e backtest contextual: somente amostras anteriores do mesmo ativo.
- Banca inicial única e cumulativa: R$ 200,00.
- Progresso: bloqueio atual separado do principal bloqueio acumulado.
- Proteção adaptativa: bloqueia novas entradas por PF recente abaixo de 1,
  drawdown de 15% ou seis perdas consecutivas.
- Posições já abertas continuam sendo administradas até o fechamento protegido.
- O bloqueio só libera uma tentativa após 30 novos resultados shadow saudáveis.
- A tentativa usa 25% do risco normal; sucessos permitem 50% e depois 75%.
- Cada trade PAPER invalida a evidência shadow anterior, evitando reutilização.

Se algum símbolo preferencial não existir na base, ele é substituído por outro
símbolo elegível disponível, mantendo o universo máximo de cinquenta.
