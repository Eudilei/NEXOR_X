# Paridade do runtime V3

O laboratório não usa mais as regras ATR e os quatro alvos do replay de pesquisa
como resposta principal. A opção 2 reproduz os padrões do runtime atual:

- scanner BTC, ETH, SOL, BNB e XRP;
- snapshot e regime de 24 horas;
- Market Intelligence, Evidence e Quant equivalentes;
- calibração mínima de 30 observações;
- backtest contextual por símbolo, direção e regime;
- banca solicitada de R$ 200, risco de 10% e alavancagem máxima de 15x;
- stop de 1%, break-even em 0,8R, parcial de 35% em 1,5R;
- trailing iniciado em 2R com distância de 0,8R;
- taxa de 0,05% e slippage de 0,03% por lado;
- máximo de dez posições e uma nova entrada por ciclo;
- hard stop de drawdown em 25%.

O modo estrito demonstra o bloqueio circular da versão anterior. O modo corrigido
usa o mesmo bootstrap Shadow causal introduzido na Update 72.
