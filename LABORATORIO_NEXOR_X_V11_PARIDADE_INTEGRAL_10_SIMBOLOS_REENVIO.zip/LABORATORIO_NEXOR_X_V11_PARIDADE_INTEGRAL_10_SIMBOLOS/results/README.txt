Os relatorios produzidos pelo laboratorio serao gravados nesta pasta.
