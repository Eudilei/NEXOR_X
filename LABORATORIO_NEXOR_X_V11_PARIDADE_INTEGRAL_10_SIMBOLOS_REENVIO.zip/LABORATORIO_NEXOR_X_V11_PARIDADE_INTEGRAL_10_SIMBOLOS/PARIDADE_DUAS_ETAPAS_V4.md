# Paridade causal em duas etapas

O laboratório 4.0 lê todos os contratos USDT encontrados, sem carregar a base inteira na memória.
Em cada instante histórico fechado ele usa somente as 24 horas anteriores para:

1. excluir históricos sem continuidade ou liquidez mínima;
2. executar o ranking raso e manter no máximo 60 ativos;
3. executar a análise profunda somente nesses 60;
4. alimentar o shadow learning causal;
5. simular entrada PAPER somente quando calibração, contexto, risco e capacidade aprovarem.

Nenhum candle futuro participa da seleção. A base de 5 minutos não contém livro, funding,
latência ou spread observado; essas limitações aparecem no relatório.
