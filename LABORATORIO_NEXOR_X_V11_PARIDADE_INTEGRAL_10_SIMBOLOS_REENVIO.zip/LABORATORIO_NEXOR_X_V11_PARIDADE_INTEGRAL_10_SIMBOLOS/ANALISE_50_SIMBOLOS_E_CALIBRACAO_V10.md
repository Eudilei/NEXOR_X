# Análise do laboratório com 50 símbolos e calibração V10

## Resultado observado

- Banca inicial: R$ 200,00
- Banca final: R$ 193,18
- Resultado líquido: -R$ 6,82 (-3,41%)
- Operações: 62 (20 ganhos e 42 perdas)
- Profit Factor líquido: 0,8975
- Custos totais: R$ 11,86
- Resultado bruto antes dos custos: +R$ 5,05
- Drawdown financeiro máximo: R$ 24,98

O sistema encontrou vantagem bruta pequena, porém insuficiente para pagar os
custos simulados. Portanto, não há evidência de rentabilidade líquida e esta
rodada não autoriza TESTNET nem LIVE.

## O que a proteção fez

As primeiras 20 operações, anteriores ao bloqueio, perderam R$ 9,61 e tiveram
PF 0,7756. As 42 tentativas controladas de recuperação produziram +R$ 2,79 e PF
1,1177. A recuperação, portanto, reduziu a perda total e comprovou que o sistema
consegue sair do bloqueio de forma limitada.

O problema identificado foi instabilidade na liberação: o estado bruto alternou
339 vezes para `RECOVERY_TRIAL`, acompanhando pequenas oscilações da janela
shadow ao redor dos limiares. Uma leitura saudável isolada não é evidência
suficiente para reabrir risco.

## Distribuição relevante

| Recorte | Operações | Resultado líquido | PF líquido |
| --- | ---: | ---: | ---: |
| Operações normais | 20 | -R$ 9,61 | 0,7756 |
| Recuperação controlada | 42 | +R$ 2,79 | 1,1177 |
| LONG | 31 | -R$ 3,70 | 0,8621 |
| SHORT | 31 | -R$ 3,11 | 0,9215 |
| TREND_DOWN | 18 | +R$ 10,70 | 2,3139 |
| RANGE | 9 | +R$ 6,21 | 1,5918 |
| TREND_UP | 19 | -R$ 5,97 | 0,4505 |
| EXPANSION | 16 | -R$ 17,76 | 0,5204 |

Os regimes negativos não foram desativados automaticamente. Fazer isso com uma
única rodada criaria sobreajuste ao histórico. Eles permanecem sujeitos à
calibração causal por símbolo, direção e regime nas próximas rodadas.

## Correção aplicada na V10

1. Universo reduzido de 50 para 10 símbolos para acelerar a próxima rodada.
2. A recuperação agora exige três leituras shadow saudáveis consecutivas.
3. As leituras precisam estar separadas por pelo menos cinco minutos.
4. Uma leitura não saudável zera a contagem de confirmações.
5. Continua permitida somente uma tentativa de recuperação por vez.
6. O risco de recuperação continua em 25%, 50% e 75%, subindo somente após
   tentativa lucrativa.
7. O limite de drawdown de 15% continua sem possibilidade de exceção.

O NEXOR X 0.77 já contém histerese operacional equivalente. A correção necessária
foi alinhar o laboratório a esse comportamento; não foi criada uma alteração
adicional no robô baseada apenas nesta amostra.

## Critério para a próxima decisão

A rodada de 10 símbolos deverá ser comparada principalmente por PF líquido,
resultado após custos, drawdown, quantidade de recuperações confirmadas e
estabilidade por regime. Somente depois de repetição fora desta amostra será
seguro alterar filtros direcionais ou excluir regimes.

