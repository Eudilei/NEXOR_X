# Arquitetura e segurança

O Laboratório é um processo offline independente. Ele não importa módulos do
NEXOR X e não abre o banco operacional.

Entradas permitidas:

- arquivos mensais Binance já existentes;
- resultados `.json`, `.jsonl` ou `.csv` escolhidos pelo usuário;
- configuração local `config/lab_policy.json`.

Saídas:

- relatórios JSON completos;
- relatórios Markdown legíveis;
- nenhum comando de execução.

Limites metodológicos:

- spread, slippage, funding, livro e open interest não são inferidos dos OHLCV;
- candles ausentes não são preenchidos;
- o motor antigo é identificado como legado;
- sugestões são hipóteses para novo teste, não alterações automáticas;
- o pacote não contém cliente HTTP, conector de exchange ou credenciais.
