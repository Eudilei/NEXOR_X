# Correção da perda excessiva — V6

O V5 encerrava uma posição pelo fechamento do candle de 5 minutos quando o
stop havia sido atravessado. Em candles fortes, isso transformava o stop de 1%
em uma perda muito maior. A V6 fecha no preço do stop, aplica somente o
slippage adverso configurado e reserva previamente o risco agregado das
posições abertas.

Proteções adicionais:

- limite de 20% de risco reservado simultaneamente;
- bloqueio preventivo quando perdas reservadas alcançariam o hard stop de 25%;
- drawdown e estado da proteção exibidos durante o progresso;
- testes contra fechamento no preço do candle e excesso de risco conjunto.

A banca continua única, cumulativa e iniciada uma vez em R$ 200,00.
