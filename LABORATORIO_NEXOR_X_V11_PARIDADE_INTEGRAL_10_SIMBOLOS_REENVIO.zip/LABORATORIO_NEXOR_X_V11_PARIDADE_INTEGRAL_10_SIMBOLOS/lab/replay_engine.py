from __future__ import annotations

import csv
import io
import json
import math
import re
import zipfile
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Iterable


ZIP_RE = re.compile(r"^(?P<symbol>[A-Z0-9]+USDT)-5m-(?P<month>\d{4}-\d{2})\.zip$", re.I)
FIVE_MINUTES_MS = 300_000


@dataclass(slots=True)
class Bar:
    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    segment: int = 0


@dataclass(slots=True)
class ReplayConfig:
    initial_bankroll_brl: float = 200.0
    risk_per_trade_pct: float = 2.0
    fee_bps_per_side: float = 5.0
    slippage_bps_per_side: float = 2.0
    spread_bps: float = 1.0
    minimum_score: float = 75.0
    stop_atr: float = 1.05
    trailing_atr: float = 1.60
    maximum_holding_bars: int = 384
    warmup_15m_bars: int = 800
    maximum_leverage: float = 15.0
    maximum_estimated_cost_r: float = 0.35
    minimum_bankroll_brl: float = 1.0
    minimum_stop_pct: float = 0.001


class NexorResearchReplay:
    """Deterministic, offline 15m/4h research replay for the current NEXOR X lab.

    It deliberately identifies itself as RESEARCH_REPLAY: the runtime currently
    exposes strategy definitions, but no shared candle-by-candle execution authority.
    """

    profile = "NEXOR_X_CURRENT_RESEARCH_REPLAY_V2_2_CORRECTED"

    EXCLUDED_BASE_ASSETS = {
        "USDC", "BUSD", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "TRY",
        "BRL", "UST", "USTC", "BTCDOM", "ETHDOM",
    }

    def __init__(self, config: ReplayConfig | None = None) -> None:
        self.config = config or ReplayConfig()

    def run(self, data_root: Path, symbols: Iterable[str],
            progress: Callable[[int, int, str], None] | None = None) -> dict[str, Any]:
        requested = [item.strip().upper() for item in symbols if item.strip()]
        if not requested:
            raise ValueError("informe ao menos um simbolo")
        if any(item in {"TODOS", "ALL", "*"} for item in requested):
            requested = self.discover_symbols(data_root)
        if not requested:
            raise ValueError("nenhum simbolo USDT encontrado na pasta historica")
        candidates: list[dict[str, Any]] = []
        data_quality: dict[str, Any] = {}
        eligible: list[str] = []
        excluded_symbols: dict[str, str] = {}
        for symbol in requested:
            reason = self.symbol_exclusion_reason(symbol)
            if reason:
                excluded_symbols[symbol] = reason
            else:
                eligible.append(symbol)
        requested = eligible
        total_symbols = len(requested)
        for position, symbol in enumerate(requested, 1):
            if progress:
                progress(position, total_symbols, symbol)
            bars, quality = self.load_symbol(data_root, symbol)
            data_quality[symbol] = quality
            if len(bars) < self.config.warmup_15m_bars + 2:
                quality["replay_status"] = "INSUFFICIENT_HISTORY"
                continue
            symbol_candidates = self._candidate_trades(symbol, bars)
            candidates.extend(symbol_candidates)
            quality["replay_status"] = "PROCESSED"
            quality["candidate_count"] = len(symbol_candidates)

        candidates.sort(key=lambda item: (item["entry_time_ms"], -item["score"], item["symbol"]))
        bankroll = self.config.initial_bankroll_brl
        peak = bankroll
        max_drawdown = 0.0
        busy_until = -1
        trades: list[dict[str, Any]] = []
        skipped_overlap = 0
        skipped_cost = 0
        bankruptcy_stopped = False
        for candidate in candidates:
            if bankroll < self.config.minimum_bankroll_brl:
                bankruptcy_stopped = True
                break
            if candidate["entry_time_ms"] <= busy_until:
                skipped_overlap += 1
                continue
            if candidate["estimated_cost_r"] > self.config.maximum_estimated_cost_r:
                skipped_cost += 1
                continue
            bankroll_before = bankroll
            notional, risk_brl = self.position_size(bankroll_before, candidate["stop_pct"])
            gross = risk_brl * candidate.pop("gross_r")
            fees = risk_brl * candidate.pop("fee_r")
            net = gross - fees
            bankroll = max(0.0, bankroll + net)
            peak = max(peak, bankroll)
            max_drawdown = max(max_drawdown, peak - bankroll)
            candidate.update({
                "trade_id": f"RX-{len(trades)+1:06d}",
                "risk_brl": round(risk_brl, 8),
                "risk_pct": self.config.risk_per_trade_pct,
                "actual_risk_pct": round(risk_brl / max(bankroll_before, 1e-12) * 100, 6),
                "position_notional_brl": round(notional, 8),
                "effective_leverage": round(notional / max(bankroll_before, 1e-12), 6),
                "gross_pnl": round(gross, 8),
                "total_fees": round(fees, 8),
                "net_pnl": round(net, 8),
                "realized_r": round(net / risk_brl, 6) if risk_brl else 0.0,
                "bankroll_after_brl": round(bankroll, 8),
            })
            trades.append(candidate)
            busy_until = candidate["exit_time_ms"]

        wins = sum(item["net_pnl"] > 0 for item in trades)
        losses = sum(item["net_pnl"] < 0 for item in trades)
        gross_profit = sum(max(0.0, item["net_pnl"]) for item in trades)
        gross_loss = abs(sum(min(0.0, item["net_pnl"]) for item in trades))
        return {
            "schema": "nexor_x.research_replay.v2.2",
            "profile": self.profile,
            "generated_at": datetime.now(UTC).isoformat(),
            "fidelity": {
                "status": "RESEARCH_REPLAY_NOT_LIVE_PARITY",
                "runtime_version_target": "NEXOR_X_CURRENT_AFTER_UPDATE_69",
                "old_7_3_15_58_engine_used": False,
                "reason": "runtime nao possui autoridade unica de estrategia por candle reutilizavel",
            },
            "assumptions": {
                **asdict(self.config),
                "source_timeframe": "5m",
                "signal_timeframe": "15m",
                "context_timeframe": "4h",
                "signal_on_closed_bar": True,
                "execution": "NEXT_15M_OPEN",
                "same_bar_policy": "STOP_BEFORE_TARGET_CONSERVATIVE",
                "funding": "NOT_AVAILABLE_ASSUMED_ZERO",
                "spread_slippage_fees": "SIMULATED_NOT_OBSERVED",
                "portfolio": "ONE_POSITION_AT_A_TIME_SHARED_BANKROLL",
            },
            "data_quality": data_quality,
            "symbols_requested": requested,
            "excluded_symbols": excluded_symbols,
            "summary": {
                "initial_bankroll_brl": round(self.config.initial_bankroll_brl, 8),
                "final_bankroll_brl": round(bankroll, 8),
                "net_pnl_brl": round(bankroll - self.config.initial_bankroll_brl, 8),
                "return_pct": round((bankroll / self.config.initial_bankroll_brl - 1) * 100, 6),
                "trade_count": len(trades), "wins": wins, "losses": losses,
                "win_rate_pct": round(wins / len(trades) * 100, 4) if trades else 0.0,
                "profit_factor_net": round(gross_profit / gross_loss, 6) if gross_loss else None,
                "total_fees_brl": round(sum(item["total_fees"] for item in trades), 8),
                "maximum_drawdown_brl": round(max_drawdown, 8),
                "maximum_drawdown_pct_of_initial": round(max_drawdown / self.config.initial_bankroll_brl * 100, 6),
                "candidates": len(candidates), "skipped_portfolio_overlap": skipped_overlap,
                "skipped_excessive_cost": skipped_cost,
                "bankruptcy_stopped": bankruptcy_stopped,
                "symbols_processed": len(requested),
                "symbols_excluded": len(excluded_symbols),
            },
            "trades": trades,
            "execution_allowed": False,
            "live_certified": False,
        }

    @classmethod
    def symbol_exclusion_reason(cls, symbol: str) -> str | None:
        value = symbol.upper()
        if not value.endswith("USDT"):
            return "NOT_USDT_QUOTE"
        base = value[:-4]
        if base in cls.EXCLUDED_BASE_ASSETS:
            return "STABLE_FIAT_OR_INDEX_BASE"
        if base.endswith("UP") or base.endswith("DOWN") or base.endswith("BULL") or base.endswith("BEAR"):
            return "LEVERAGED_TOKEN"
        return None

    def position_size(self, bankroll: float, stop_pct: float) -> tuple[float, float]:
        if bankroll <= 0 or stop_pct <= 0:
            return 0.0, 0.0
        planned_risk = bankroll * self.config.risk_per_trade_pct / 100.0
        desired_notional = planned_risk / stop_pct
        maximum_notional = bankroll * self.config.maximum_leverage
        notional = min(desired_notional, maximum_notional)
        return notional, notional * stop_pct

    @staticmethod
    def discover_symbols(data_root: Path) -> list[str]:
        root = data_root.expanduser().resolve()
        if not root.is_dir():
            raise ValueError(f"pasta historica nao encontrada: {root}")
        symbols = {
            match.group("symbol").upper()
            for path in root.rglob("*USDT-5m-*.zip")
            if path.is_file() and (match := ZIP_RE.match(path.name))
        }
        return sorted(symbols)

    def load_symbol(self, root: Path, symbol: str) -> tuple[list[Bar], dict[str, Any]]:
        paths = sorted(path for path in root.rglob(f"{symbol}-5m-*.zip") if path.is_file())
        if not paths:
            return [], {"archives": 0, "five_minute_rows": 0, "excluded_archives": [], "segments": 0}
        five: list[Bar] = []
        excluded: list[dict[str, str]] = []
        previous_ts: int | None = None
        segment = 0
        segment_ids: list[int] = []
        for path in paths:
            try:
                current = self._read_zip(path)
            except Exception as exc:
                excluded.append({"archive": path.name, "reason": f"{type(exc).__name__}:{exc}"})
                previous_ts = None
                continue
            for bar in current:
                if previous_ts is None or bar.ts - previous_ts != FIVE_MINUTES_MS:
                    segment += 1
                bar.segment = segment
                five.append(bar)
                segment_ids.append(segment)
                previous_ts = bar.ts
        grouped: dict[int, list[Bar]] = {}
        for bar, sid in zip(five, segment_ids):
            grouped.setdefault(sid, []).append(bar)
        fifteen: list[Bar] = []
        for values in grouped.values():
            fifteen.extend(self._resample(values, 3, FIVE_MINUTES_MS * 3))
        fifteen.sort(key=lambda item: item.ts)
        return fifteen, {
            "archives": len(paths), "five_minute_rows": len(five),
            "fifteen_minute_bars": len(fifteen), "excluded_archives": excluded,
            "segments": segment,
        }

    @staticmethod
    def _read_zip(path: Path) -> list[Bar]:
        result: list[Bar] = []
        with zipfile.ZipFile(path) as archive:
            members = [name for name in archive.namelist() if name.lower().endswith(".csv")]
            if len(members) != 1:
                raise ValueError(f"ZIP_CSV_COUNT:{len(members)}")
            with archive.open(members[0]) as raw:
                rows = csv.reader(io.TextIOWrapper(raw, encoding="utf-8-sig", newline=""))
                previous = None
                for row in rows:
                    if not row or not row[0].strip().isdigit():
                        continue
                    ts = int(row[0])
                    while ts > 99_999_999_999_999:
                        ts //= 1000
                    if ts < 100_000_000_000:
                        ts *= 1000
                    o, h, l, c, v = (float(row[index]) for index in range(1, 6))
                    if previous is not None and ts <= previous:
                        raise ValueError("NON_MONOTONIC")
                    if not (min(o, h, l, c) > 0 and v >= 0 and h >= max(o, c, l) and l <= min(o, c, h)):
                        raise ValueError("INVALID_OHLCV")
                    result.append(Bar(ts, o, h, l, c, v))
                    previous = ts
        return result

    @staticmethod
    def _resample(bars: list[Bar], count: int, bucket_ms: int) -> list[Bar]:
        output: list[Bar] = []
        bucket: list[Bar] = []
        bucket_id = None
        for bar in bars:
            current = bar.ts // bucket_ms
            if bucket_id is not None and current != bucket_id:
                if len(bucket) == count:
                    output.append(Bar(bucket[0].ts, bucket[0].open, max(x.high for x in bucket),
                                      min(x.low for x in bucket), bucket[-1].close,
                                      sum(x.volume for x in bucket), bucket[0].segment))
                bucket = []
            bucket_id = current
            bucket.append(bar)
        if len(bucket) == count:
            output.append(Bar(bucket[0].ts, bucket[0].open, max(x.high for x in bucket),
                              min(x.low for x in bucket), bucket[-1].close,
                              sum(x.volume for x in bucket), bucket[0].segment))
        return output

    def _candidate_trades(self, symbol: str, bars: list[Bar]) -> list[dict[str, Any]]:
        output: list[dict[str, Any]] = []
        grouped: dict[int, list[Bar]] = {}
        for bar in bars:
            grouped.setdefault(bar.segment, []).append(bar)
        for segment_bars in grouped.values():
            if len(segment_bars) >= self.config.warmup_15m_bars + 2:
                output.extend(self._candidate_trades_segment(symbol, segment_bars))
        return output

    def _candidate_trades_segment(self, symbol: str, bars: list[Bar]) -> list[dict[str, Any]]:
        close = [bar.close for bar in bars]
        high = [bar.high for bar in bars]
        low = [bar.low for bar in bars]
        volume = [bar.volume for bar in bars]
        ema20, ema50, ema200 = self._ema(close, 20), self._ema(close, 50), self._ema(close, 200)
        atr = self._atr(bars, 14)
        rsi = self._rsi(close, 14)
        vol_ema = self._ema(volume, 20)
        context_trend = self._closed_4h_trends(bars)
        output: list[dict[str, Any]] = []
        next_allowed = 0
        for i in range(max(self.config.warmup_15m_bars, 200), len(bars)-2):
            if i < next_allowed or not atr[i] or not ema200[i]:
                continue
            trend = context_trend[i]
            if trend == 0:
                continue
            direction = 0
            strategy = ""
            score = 0.0
            vol_ratio = volume[i] / vol_ema[i] if vol_ema[i] else 1.0
            recent_high = max(high[i-20:i])
            recent_low = min(low[i-20:i])
            if trend > 0 and ema20[i] > ema50[i] > ema200[i] and low[i] <= ema20[i] and close[i] > ema20[i] and 45 <= rsi[i] <= 68:
                direction, strategy, score = 1, "trend_pullback", 72 + min(10, max(0, vol_ratio-1)*10)
            elif trend < 0 and ema20[i] < ema50[i] < ema200[i] and high[i] >= ema20[i] and close[i] < ema20[i] and 32 <= rsi[i] <= 55:
                direction, strategy, score = -1, "trend_pullback", 72 + min(10, max(0, vol_ratio-1)*10)
            elif close[i] > recent_high and trend > 0 and vol_ratio >= 1.25 and rsi[i] < 76:
                direction, strategy, score = 1, "breakout", 68 + min(15, (vol_ratio-1.25)*12)
            elif close[i] < recent_low and trend < 0 and vol_ratio >= 1.25 and rsi[i] > 24:
                direction, strategy, score = -1, "breakout", 68 + min(15, (vol_ratio-1.25)*12)
            elif low[i] < recent_low and close[i] > recent_low and rsi[i] < 38 and trend >= 0:
                direction, strategy, score = 1, "liquidity_sweep", 70 + min(10, (38-rsi[i])*.5)
            elif high[i] > recent_high and close[i] < recent_high and rsi[i] > 62 and trend <= 0:
                direction, strategy, score = -1, "liquidity_sweep", 70 + min(10, (rsi[i]-62)*.5)
            if not direction or score < self.config.minimum_score:
                continue
            candidate = self._walk_trade(symbol, bars, i, direction, strategy, score, atr[i], trend)
            if candidate:
                output.append(candidate)
                next_allowed = candidate.pop("exit_index") + 1
        return output

    def _closed_4h_trends(self, bars: list[Bar]) -> list[int]:
        four_hour_ms = 14_400_000
        context = self._resample(bars, 16, four_hour_ms)
        result = [0] * len(bars)
        if len(context) < 50:
            return result
        closes = [bar.close for bar in context]
        ema20, ema50 = self._ema(closes, 20), self._ema(closes, 50)
        pointer = -1
        for index, bar in enumerate(bars):
            current_bucket = bar.ts // four_hour_ms
            while pointer + 1 < len(context) and context[pointer + 1].ts // four_hour_ms < current_bucket:
                pointer += 1
            if pointer >= 49:
                result[index] = 1 if ema20[pointer] > ema50[pointer] else -1
        return result

    def _walk_trade(self, symbol: str, bars: list[Bar], signal_i: int, direction: int,
                    strategy: str, score: float, atr: float, trend: int) -> dict[str, Any] | None:
        entry_i = signal_i + 1
        raw_entry = bars[entry_i].open
        friction_bps = self.config.slippage_bps_per_side + self.config.spread_bps / 2
        entry = raw_entry * (1 + direction * friction_bps / 10_000)
        stop_distance = atr * self.config.stop_atr
        stop_pct = stop_distance / entry if entry else 0.0
        if stop_distance <= 0 or stop_pct > 0.20 or stop_pct < self.config.minimum_stop_pct:
            return None
        estimated_cost_r = (
            (2*self.config.fee_bps_per_side + 2*self.config.slippage_bps_per_side + self.config.spread_bps)
            / 10_000 / stop_pct
        )
        stop = entry - direction * stop_distance
        targets = [entry + direction * atr * multiple for multiple in (1.0, 1.7, 2.6, 4.0)]
        fractions = [.3, .3, .2, .2]
        remaining = 1.0
        gross_r = 0.0
        fee_notional_factor = 1.0
        mfe = mae = 0.0
        hit = 0
        exit_reason = "TIMEOUT"
        exit_i = min(len(bars)-1, entry_i + self.config.maximum_holding_bars)
        trailing = stop
        def realized_r(price: float, fraction: float) -> float:
            exit_fill = price * (1 - direction * friction_bps / 10_000)
            return fraction * direction * (exit_fill-entry) / stop_distance

        for j in range(entry_i, exit_i + 1):
            bar = bars[j]
            favorable = (bar.high-entry) if direction > 0 else (entry-bar.low)
            adverse = (entry-bar.low) if direction > 0 else (bar.high-entry)
            mfe, mae = max(mfe, favorable/stop_distance), max(mae, adverse/stop_distance)
            active_stop = trailing
            stop_hit = bar.low <= active_stop if direction > 0 else bar.high >= active_stop
            if stop_hit:  # conservative when stop and target coexist in one candle
                stop_fill_reference = min(active_stop, bar.open) if direction > 0 else max(active_stop, bar.open)
                gross_r += realized_r(stop_fill_reference, remaining)
                fee_notional_factor += remaining
                remaining = 0
                exit_i, exit_reason = j, "STOP" if hit == 0 else "TRAILING_STOP"
                break
            while hit < len(targets) and ((bar.high >= targets[hit]) if direction > 0 else (bar.low <= targets[hit])):
                fraction = min(remaining, fractions[hit])
                gross_r += realized_r(targets[hit], fraction)
                fee_notional_factor += fraction
                remaining -= fraction
                hit += 1
                if hit == 1:
                    trailing = entry
                if remaining <= 1e-9:
                    exit_i, exit_reason = j, "TP4"
                    break
            if remaining <= 1e-9:
                break
            if hit >= 1:
                proposed = (bar.high-self.config.trailing_atr*atr) if direction > 0 else (bar.low+self.config.trailing_atr*atr)
                trailing = max(trailing, proposed) if direction > 0 else min(trailing, proposed)
        if remaining > 1e-9:
            gross_r += realized_r(bars[exit_i].close, remaining)
            fee_notional_factor += remaining
        notional_to_risk = entry / stop_distance
        fee_r = fee_notional_factor * self.config.fee_bps_per_side / 10_000 * notional_to_risk
        return {
            "symbol": symbol, "strategy_id": strategy, "regime": "TREND" if trend else "RANGE",
            "signal_time_ms": bars[signal_i].ts, "entry_time_ms": bars[entry_i].ts,
            "exit_time_ms": bars[exit_i].ts, "entry_price": entry, "initial_stop": stop,
            "exit_reason": exit_reason, "score": round(score, 4), "raw_edge": round(score/100, 4),
            "planned_rr": round(4.0/self.config.stop_atr, 4), "slippage_bps": self.config.slippage_bps_per_side,
            "mfe_r": round(mfe, 6), "mae_r": round(mae, 6), "targets_hit": hit,
            "stop_pct": round(stop_pct, 10), "estimated_cost_r": round(estimated_cost_r, 6),
            "gross_r": gross_r, "fee_r": fee_r, "exit_index": exit_i,
        }

    @staticmethod
    def _ema(values: list[float], period: int) -> list[float]:
        if not values:
            return []
        alpha = 2 / (period + 1)
        result = [values[0]]
        for value in values[1:]:
            result.append(alpha * value + (1-alpha) * result[-1])
        return result

    @staticmethod
    def _atr(bars: list[Bar], period: int) -> list[float]:
        tr = [bars[0].high-bars[0].low]
        for previous, bar in zip(bars, bars[1:]):
            tr.append(max(bar.high-bar.low, abs(bar.high-previous.close), abs(bar.low-previous.close)))
        return NexorResearchReplay._ema(tr, period)

    @staticmethod
    def _rsi(values: list[float], period: int) -> list[float]:
        gains = [0.0]
        losses = [0.0]
        for previous, value in zip(values, values[1:]):
            delta = value-previous
            gains.append(max(0.0, delta)); losses.append(max(0.0, -delta))
        avg_gain = NexorResearchReplay._ema(gains, period)
        avg_loss = NexorResearchReplay._ema(losses, period)
        return [100.0 if loss == 0 else 100 - 100/(1+gain/loss) for gain, loss in zip(avg_gain, avg_loss)]

    @staticmethod
    def write_reports(report: dict[str, Any], output: Path) -> tuple[Path, Path, Path]:
        output.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        json_path = output / f"replay_{stamp}.json"
        jsonl_path = output / f"positions_{stamp}.jsonl"
        md_path = output / f"replay_{stamp}.md"
        json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        jsonl_path.write_text("".join(json.dumps(item, ensure_ascii=False)+"\n" for item in report["trades"]), encoding="utf-8")
        summary = report["summary"]
        lines = ["# Replay financeiro NEXOR X", "", f"- Perfil: `{report['profile']}`",
                 f"- Fidelidade: `{report['fidelity']['status']}`",
                 f"- Banca inicial: R$ {summary['initial_bankroll_brl']:.2f}",
                 f"- Banca final: R$ {summary['final_bankroll_brl']:.2f}",
                 f"- PnL líquido: R$ {summary['net_pnl_brl']:.2f}",
                 f"- Retorno: {summary['return_pct']:.2f}%", f"- Operações: {summary['trade_count']}",
                 f"- Taxas simuladas: R$ {summary['total_fees_brl']:.2f}",
                 f"- Drawdown máximo: R$ {summary['maximum_drawdown_brl']:.2f}", "",
                 "## Aviso de fidelidade", "",
                 "Este é um replay de pesquisa determinístico. Não é prova de paridade com LIVE, pois o runtime atual ainda não compartilha uma autoridade completa de estratégia por candle.", "",
                 "## Custos não observados", "", "Spread, slippage e taxas são hipóteses configuráveis; funding foi assumido como zero."]
        md_path.write_text("\n".join(lines)+"\n", encoding="utf-8")
        return json_path, jsonl_path, md_path
