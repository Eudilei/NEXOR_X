from __future__ import annotations

import csv, heapq, io, math, zipfile
from collections import Counter, deque
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Iterator

from .replay_engine import Bar
from .runtime_parity_engine import RuntimeParityReplay


class TwoStageRuntimeParityReplay(RuntimeParityReplay):
    """Memory-bounded causal pilot: 10 symbols -> shallow/deep gate."""
    profile = "NEXOR_X_078_SHARED_RUNTIME_COUNTERFACTUAL_PARITY_V11"
    universe_limit = 10
    priority_symbols = ("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
                     "ADAUSDT", "DOGEUSDT", "TRXUSDT", "LINKUSDT", "LTCUSDT")

    def run(self, data_root: Path, symbols=None, progress: Callable[[str], None] | None = None) -> dict[str, Any]:
        requested = [str(x).strip().upper() for x in (symbols or ("TODOS",)) if str(x).strip()]
        if any(x in {"TODOS", "ALL", "*"} for x in requested):
            discovered = set(self.reader.discover_symbols(data_root))
            requested = [x for x in self.priority_symbols if x in discovered]
            if len(requested) < self.universe_limit:
                requested.extend(sorted(discovered-set(requested))[
                    :self.universe_limit-len(requested)])
        requested = requested[:self.universe_limit]
        requested = [x for x in requested if not self.reader.symbol_exclusion_reason(x)]
        if not requested: raise ValueError("nenhum simbolo historico elegivel")
        corrected = self._stream(data_root, requested, progress)
        return {"schema": "nexor_x.integral_runtime_parity.v11", "profile": self.profile,
                "generated_at": datetime.now(UTC).isoformat(),
                "source_runtime": {"version": "0.78.0_shared_strategy_runtime",
                                   "universe": "10-symbol pilot",
                                   "shallow_limit": 10, "deep_analysis": "top 10 per cycle",
                                   "historical_clock_resolution": "5m"},
                "strict_current": {"mode": "TWO_STAGE_CAUSAL", "trade_count": corrected["trade_count"],
                                   "net_pnl_brl": corrected["net_pnl_brl"],
                                   "final_equity_brl": corrected["final_equity_brl"], "reason": "fluxo 0.73 aplicado"},
                "corrected_with_causal_shadow": corrected,
                "data_quality": {"symbols_discovered": len(requested), "streaming_memory_bounded": True},
                "limitations": ["Candles de 5m nao reconstroem ciclos reais de 60s.",
                                "Livro, funding, latencia e spread observado nao existem na base."],
                "execution_allowed": False, "live_certified": False}

    def _bar_stream(self, root: Path, symbol: str) -> Iterator[Bar]:
        previous = None; segment = 0
        for path in sorted(root.rglob(f"{symbol}-5m-*.zip")):
            try:
                with zipfile.ZipFile(path) as archive:
                    members = [x for x in archive.namelist() if x.lower().endswith(".csv")]
                    if len(members) != 1: previous = None; continue
                    with archive.open(members[0]) as raw:
                        for row in csv.reader(io.TextIOWrapper(raw, encoding="utf-8-sig", newline="")):
                            if not row or not row[0].strip().isdigit(): continue
                            ts = int(row[0])
                            while ts > 99_999_999_999_999: ts //= 1000
                            if ts < 100_000_000_000: ts *= 1000
                            o, h, l, c, v = (float(row[i]) for i in range(1, 6))
                            if min(o, h, l, c) <= 0 or v < 0: continue
                            if previous is None or ts-previous != 300_000: segment += 1
                            if previous is not None and ts <= previous: continue
                            previous = ts; yield Bar(ts, o, h, l, c, v, segment)
            except (OSError, ValueError, zipfile.BadZipFile): previous = None

    def _stream(self, root: Path, symbols: list[str], progress) -> dict[str, Any]:
        p = self.policy; streams = {s: self._bar_stream(root, s) for s in symbols}; heap = []
        for symbol, stream in streams.items():
            bar = next(stream, None)
            if bar: heapq.heappush(heap, (bar.ts, symbol, bar))
        windows = {s: deque(maxlen=288) for s in symbols}; latest = {}; observations = []
        quote_totals = {s: 0.0 for s in symbols}
        rolling_highs = {s: deque() for s in symbols}
        rolling_lows = {s: deque() for s in symbols}
        shadow_positions = {}; paper_positions = {}; trades = []; blocked = Counter()
        counterfactual_positions = {}; counterfactual_trades = []
        counterfactual_cooldown: dict[tuple[str, str, str], int] = {}
        equity = peak = p.initial_equity; max_dd = 0.0; cycles = shallow_total = deep_total = 0; first_calibration = None
        total_entry_fees_paid = 0.0
        protection_transitions = []
        last_protection_state = "NORMAL"
        recovery_trial_pending = False
        successful_recovery_trials = 0
        recovery_confirmation = {"healthy_checks": 0, "last_check_ms": None}
        while heap:
            cycle_blocked = Counter()
            timestamp = heap[0][0]; current = {}
            while heap and heap[0][0] == timestamp:
                _, symbol, bar = heapq.heappop(heap); current[symbol] = bar; latest[symbol] = bar
                window = windows[symbol]
                if window and (bar.segment != window[-1].segment or bar.ts-window[-1].ts != 300_000):
                    window.clear(); quote_totals[symbol] = 0.0
                    rolling_highs[symbol].clear(); rolling_lows[symbol].clear()
                if len(window) == window.maxlen:
                    expired = window[0]
                    quote_totals[symbol] -= expired.volume*expired.close
                window.append(bar); quote_totals[symbol] += bar.volume*bar.close
                highs = rolling_highs[symbol]; lows = rolling_lows[symbol]
                while highs and highs[-1][1] <= bar.high: highs.pop()
                while lows and lows[-1][1] >= bar.low: lows.pop()
                highs.append((bar.ts, bar.high)); lows.append((bar.ts, bar.low))
                minimum_ts = bar.ts-(window.maxlen-1)*300_000
                while highs and highs[0][0] < minimum_ts: highs.popleft()
                while lows and lows[0][0] < minimum_ts: lows.popleft()
                following = next(streams[symbol], None)
                if following: heapq.heappush(heap, (following.ts, symbol, following))
            for symbol, bar in current.items():
                self._manage_shadow(symbol, bar, shadow_positions, observations)
                closed = self._manage_paper(symbol, bar, paper_positions)
                if closed:
                    equity += closed["account_delta"]
                    closed["equity_after"] = round(equity, 8)
                    trades.append(closed)
                    if closed.get("recovery_trial"):
                        recovery_trial_pending = False
                        if closed["net_pnl"] > 0:
                            successful_recovery_trials = min(successful_recovery_trials + 1, 3)
                        else:
                            successful_recovery_trials = 0
                hypothetical = self._manage_paper(
                    symbol, bar, counterfactual_positions
                )
                if hypothetical:
                    counterfactual_trades.append(hypothetical)
            shallow = []
            for symbol, window in windows.items():
                if len(window) != 288 or window[-1].ts != timestamp: continue
                first, last = window[0], window[-1]; quote_volume = quote_totals[symbol]
                if quote_volume < 1_000_000: continue
                range_pct = (rolling_highs[symbol][0][1]-rolling_lows[symbol][0][1])/first.open*100
                if range_pct <= .05 or range_pct > 80: continue
                change = (last.close-first.open)/first.open*100
                score = min(math.log1p(quote_volume)/25, 1)*.60 + max(0, 1-abs(range_pct-4)/20)*.25 + min(abs(change)/15, 1)*.15
                shallow.append((score, symbol))
            selected = heapq.nlargest(p.scanner_top_candidates, shallow,
                                      key=lambda x: (x[0], x[1]))
            shallow_total += len(selected); assessments = []
            for _, symbol in selected:
                assessment = self._assessment(symbol, list(windows[symbol]), observations)
                assessment["rank_score"] = self._rank_score(assessment); assessments.append(assessment)
                if assessment["decision"] in {"LONG_BIAS", "SHORT_BIAS"} and symbol not in shadow_positions:
                    shadow_positions[symbol] = self._open_position(symbol, assessment, latest[symbol].close, 1_000, True)
            deep_total += len(assessments); assessments.sort(key=lambda x: (-x["rank_score"], x["symbol"])); opened = 0
            raw_protection = self._performance_protection(
                trades, equity, peak, observations
            )
            protection = self._confirmed_recovery(
                raw_protection, timestamp, recovery_trial_pending,
                recovery_confirmation,
            )
            if protection["state"] != last_protection_state:
                protection_transitions.append({"timestamp_ms": timestamp, **protection})
                last_protection_state = protection["state"]
            for assessment in assessments:
                if opened >= p.maximum_entries_per_cycle: break
                symbol = assessment["symbol"]
                if symbol in paper_positions:
                    blocked["POSITION_ALREADY_OPEN"] += 1
                    cycle_blocked["POSITION_ALREADY_OPEN"] += 1
                    continue
                if not protection["new_entries_allowed"]:
                    reasons = ["DEGRADATION_" + reason.upper() for reason in protection["hard_reasons"]]
                    blocked.update(reasons); cycle_blocked.update(reasons)
                    self._open_counterfactual_if_new(
                        counterfactual_positions, counterfactual_cooldown,
                        assessment, reasons, equity, timestamp,
                        latest[symbol].close,
                    )
                    continue
                if protection["recovery_trial"] and recovery_trial_pending:
                    reasons = ["RECOVERY_TRIAL_PENDING"]
                    blocked.update(reasons); cycle_blocked.update(reasons)
                    self._open_counterfactual_if_new(
                        counterfactual_positions, counterfactual_cooldown,
                        assessment, reasons, equity, timestamp,
                        latest[symbol].close,
                    )
                    continue
                reasons = self._gate_reasons(
                    assessment, observations, equity, peak, len(paper_positions),
                    paper_positions,
                )
                if reasons:
                    blocked.update(reasons)
                    cycle_blocked.update(reasons)
                    self._open_counterfactual_if_new(
                        counterfactual_positions, counterfactual_cooldown,
                        assessment, reasons, equity, timestamp,
                        latest[symbol].close,
                    )
                    continue
                if first_calibration is None: first_calibration = timestamp
                multiplier = (min(.25 + successful_recovery_trials*.25, .75)
                              if protection["recovery_trial"] else 1.0)
                risk = equity*p.risk_per_trade_pct/100*multiplier
                paper_positions[symbol] = self._open_position(symbol, assessment, latest[symbol].close, risk, False, equity, timestamp)
                paper_positions[symbol]["recovery_trial"] = protection["recovery_trial"]
                paper_positions[symbol]["risk_multiplier"] = multiplier
                if protection["recovery_trial"]:
                    recovery_trial_pending = True
                    recovery_confirmation["healthy_checks"] = 0
                    recovery_confirmation["last_check_ms"] = None
                entry_fee = paper_positions[symbol]["entry_fee"]
                equity -= entry_fee; total_entry_fees_paid += entry_fee; opened += 1
            peak = max(peak, equity); max_dd = max(max_dd, peak-equity); cycles += 1
            if progress and cycles % 10_000 == 0:
                top_block = blocked.most_common(1)[0][0] if blocked else "NENHUM"
                current_block = cycle_blocked.most_common(1)[0][0] if cycle_blocked else "NENHUM"
                drawdown_pct = (peak-equity)/peak*100 if peak else 0.0
                status = self._performance_protection(trades, equity, peak, observations)
                protection = status["state"]
                progress(f"Ciclos {cycles} | universo={len(windows)} | raso={len(selected)} | "
                         f"shadow={len(observations)} | paper_abertas={len(paper_positions)} | "
                         f"trades={len(trades)} | banca=R$ {equity:.2f} | "
                         f"dd={drawdown_pct:.2f}% | protecao={protection} | "
                         f"bloqueio_atual={current_block} | bloqueio_acumulado={top_block}")
        for symbol, position in list(paper_positions.items()):
            if symbol not in latest: continue
            closed = self._close_position(position, latest[symbol].close, "END_OF_DATA")
            equity += closed["account_delta"]; closed["equity_after"] = round(equity, 8); trades.append(closed)
        for symbol, position in list(counterfactual_positions.items()):
            if symbol not in latest: continue
            closed = self._close_position(position, latest[symbol].close, "END_OF_DATA")
            closed["closed_at"] = latest[symbol].ts
            counterfactual_trades.append(closed)
        wins = sum(x["net_pnl"] > 0 for x in trades); loss_sum = abs(sum(min(0, x["net_pnl"]) for x in trades)); profit = sum(max(0, x["net_pnl"]) for x in trades)
        expected_equity = p.initial_equity + sum(x["account_delta"] for x in trades) - total_entry_fees_paid
        accounting_drift = equity-expected_equity
        if abs(accounting_drift) > 1e-6:
            raise RuntimeError(f"falha na banca cumulativa: drift={accounting_drift:.10f}")
        final_protection = protection if cycles else self._performance_protection(
            trades, equity, peak, observations
        )
        return {"mode": "PILOT_10_SYMBOLS_CONFIRMED_RECOVERY_DEEP_GATE", "initial_equity_brl": p.initial_equity,
                "final_equity_brl": round(equity, 8), "net_pnl_brl": round(equity-p.initial_equity, 8),
                "return_pct": round((equity/p.initial_equity-1)*100, 6), "trade_count": len(trades),
                "wins": wins, "losses": sum(x["net_pnl"] < 0 for x in trades),
                "win_rate_pct": round(wins/len(trades)*100, 4) if trades else 0,
                "profit_factor_net": round(profit/loss_sum, 6) if loss_sum else None,
                "maximum_drawdown_brl": round(max_dd, 8), "shadow_observations": len(observations),
                "first_calibration_time_ms": first_calibration, "blocked_reasons": dict(blocked.most_common()),
                "cycles": cycles, "average_shallow_selected": round(shallow_total/max(cycles, 1), 2),
                "deep_assessments": deep_total,
                "performance_protection": {**final_protection,
                                           "transitions": protection_transitions},
                "capital_accounting": {"mode": "SINGLE_CUMULATIVE_BANKROLL_NO_RESET",
                                       "initial_brl": p.initial_equity,
                                       "entry_fees_paid_brl": round(total_entry_fees_paid, 8),
                                       "accounting_drift_brl": round(accounting_drift, 10),
                                       "checkpoint_supported": False,
                                       "restart_behavior": "NEW_EXPERIMENT_FROM_INITIAL_BANKROLL"},
                "counterfactual_filter_audit": self._filter_audit(
                    counterfactual_trades
                ),
                "blocked_opportunities": counterfactual_trades,
                "trades": trades}

    def _open_counterfactual_if_new(
        self,
        positions: dict[str, dict[str, Any]],
        cooldown: dict[tuple[str, str, str], int],
        assessment: dict[str, Any],
        reasons: list[str],
        equity: float,
        timestamp: int,
        price: float,
    ) -> None:
        if assessment["decision"] not in {"LONG_BIAS", "SHORT_BIAS"}:
            return
        symbol = assessment["symbol"]
        strategy_id = str(
            (assessment.get("selected_strategy") or {}).get(
                "strategy_id", "NO_STRATEGY"
            )
        )
        signature = (symbol, assessment["decision"], strategy_id)
        if symbol in positions or timestamp-cooldown.get(signature, 0) < 86_400_000:
            return
        risk = equity*self.policy.risk_per_trade_pct/100
        candidate = self._open_position(
            symbol, assessment, price, risk, False, equity, timestamp,
        )
        candidate["counterfactual"] = True
        candidate["blocked_filters"] = list(reasons)
        candidate["filter_checks"] = dict(assessment.get("filter_checks") or {})
        positions[symbol] = candidate
        cooldown[signature] = timestamp

    @staticmethod
    def _filter_audit(trades: list[dict[str, Any]]) -> dict[str, Any]:
        rows: dict[str, dict[str, Any]] = {}
        for trade in trades:
            failed = list(trade.get("blocked_filters") or [])
            for name in failed:
                row = rows.setdefault(name, {
                    "filter": name, "blocked_opportunities": 0,
                    "profitable_rejections": 0, "losing_rejections": 0,
                    "rejected_net_pnl_brl": 0.0, "loss_avoided_brl": 0.0,
                    "profit_missed_brl": 0.0,
                    "individual_removal_would_admit": 0,
                })
                net = float(trade.get("net_pnl") or 0.0)
                row["blocked_opportunities"] += 1
                row["rejected_net_pnl_brl"] += net
                if net > 0:
                    row["profitable_rejections"] += 1
                    row["profit_missed_brl"] += net
                elif net < 0:
                    row["losing_rejections"] += 1
                    row["loss_avoided_brl"] += abs(net)
                if len(failed) == 1:
                    row["individual_removal_would_admit"] += 1
        for row in rows.values():
            for key in ("rejected_net_pnl_brl", "loss_avoided_brl", "profit_missed_brl"):
                row[key] = round(row[key], 8)
            total = row["blocked_opportunities"]
            row["blocking_accuracy_pct"] = round(
                row["losing_rejections"]/total*100, 4
            ) if total else 0.0
        total_net = sum(float(x.get("net_pnl") or 0.0) for x in trades)
        return {
            "method": "CAUSAL_SHADOW_NO_BANKROLL_EFFECT",
            "deduplication": "one active opportunity per symbol; 24h signature cooldown",
            "opportunities": len(trades),
            "hypothetical_net_pnl_brl": round(total_net, 8),
            "filters": sorted(rows.values(), key=lambda x: x["filter"]),
            "causal_claim": False,
        }

    def _confirmed_recovery(
        self,
        raw: dict[str, Any],
        timestamp_ms: int,
        trial_pending: bool,
        confirmation: dict[str, Any],
    ) -> dict[str, Any]:
        """Require stable shadow evidence before one reduced-risk trial.

        A single 5-minute fluctuation no longer toggles the laboratory between
        BLOCKED and RECOVERY_TRIAL. This mirrors the three-check hysteresis used
        by the NEXOR X operational runtime.
        """
        p = self.policy
        result = dict(raw)
        raw_trial = bool(raw.get("recovery_trial"))
        if not raw_trial:
            confirmation["healthy_checks"] = 0
            confirmation["last_check_ms"] = None
        elif not trial_pending:
            last = confirmation.get("last_check_ms")
            if last is None or timestamp_ms-int(last) >= p.recovery_healthy_check_interval_ms:
                confirmation["healthy_checks"] = int(
                    confirmation.get("healthy_checks", 0)
                ) + 1
                confirmation["last_check_ms"] = timestamp_ms

        checks = int(confirmation.get("healthy_checks", 0))
        confirmed = bool(
            raw_trial
            and not trial_pending
            and checks >= p.recovery_required_healthy_checks
        )
        result["recovery_confirmation"] = {
            "healthy_checks": checks,
            "required_healthy_checks": p.recovery_required_healthy_checks,
            "check_interval_ms": p.recovery_healthy_check_interval_ms,
            "confirmed": confirmed,
        }
        if raw_trial and not confirmed:
            result["state"] = "BLOCKED"
            result["new_entries_allowed"] = False
            result["recovery_trial"] = False
            hard = list(result.get("hard_reasons") or [])
            reason = (
                "recovery_trial_pending" if trial_pending
                else "recovery_confirmation_pending"
            )
            if reason not in hard:
                hard.append(reason)
            result["hard_reasons"] = hard
        return result

    def _performance_protection(self, trades: list[dict[str, Any]],
                                equity: float, peak: float,
                                observations: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        p = self.policy
        recent = trades[-100:]
        profit = sum(max(0.0, x["net_pnl"]) for x in recent)
        loss = abs(sum(min(0.0, x["net_pnl"]) for x in recent))
        profit_factor = profit/loss if loss else (999.0 if profit else 0.0)
        streak = 0
        for trade in reversed(recent):
            if trade["net_pnl"] >= 0: break
            streak += 1
        drawdown = (peak-equity)/peak*100 if peak else 0.0
        enough = len(recent) >= p.degradation_min_recent_trades
        hard = []; caution = []
        if enough:
            if profit_factor < p.degradation_block_profit_factor:
                hard.append("profit_factor_below_1")
            elif profit_factor < p.degradation_caution_profit_factor:
                caution.append("profit_factor_weak")
            if drawdown >= p.degradation_block_drawdown_pct:
                hard.append("drawdown_limit_reached")
            elif drawdown >= p.degradation_caution_drawdown_pct:
                caution.append("drawdown_elevated")
        if streak >= p.degradation_block_loss_streak:
            hard.append("loss_streak_critical")
        elif streak >= p.degradation_caution_loss_streak:
            caution.append("loss_streak_elevated")
        shadow = self._shadow_recovery_metrics(trades, observations or [])
        shadow_healthy = bool(
            shadow["samples"] >= p.recovery_shadow_samples
            and shadow["profit_factor"] >= p.recovery_shadow_profit_factor
            and shadow["expected_r"] >= p.recovery_shadow_expected_r
        )
        recoverable = {"profit_factor_below_1", "loss_streak_critical"}
        recovery_trial = bool(hard and set(hard).issubset(recoverable) and shadow_healthy)
        state = ("RECOVERY_TRIAL" if recovery_trial else
                 "BLOCKED" if hard else "CAUTION" if caution else "NORMAL")
        return {"state": state,
                "new_entries_allowed": not hard or recovery_trial,
                "recovery_trial": recovery_trial, "hard_reasons": hard,
                "caution_reasons": caution, "recent_trades": len(recent),
                "recent_profit_factor": round(profit_factor, 6),
                "drawdown_pct": round(drawdown, 6), "loss_streak": streak,
                "shadow_recovery": {**shadow, "healthy": shadow_healthy}}

    @staticmethod
    def _shadow_recovery_metrics(trades: list[dict[str, Any]],
                                 observations: list[dict[str, Any]]) -> dict[str, Any]:
        cutoff = max((int(x.get("closed_at") or 0) for x in trades), default=0)
        values = [float(x["realized_r"]) for x in observations
                  if int(x.get("closed_at") or 0) > cutoff][-100:]
        profit = sum(x for x in values if x > 0)
        loss = abs(sum(x for x in values if x < 0))
        pf = profit/loss if loss else (999.0 if profit else 0.0)
        return {"samples": len(values), "profit_factor": round(pf, 6),
                "expected_r": round(sum(values)/len(values), 6) if values else 0.0,
                "after_last_paper_close_ms": cutoff}
