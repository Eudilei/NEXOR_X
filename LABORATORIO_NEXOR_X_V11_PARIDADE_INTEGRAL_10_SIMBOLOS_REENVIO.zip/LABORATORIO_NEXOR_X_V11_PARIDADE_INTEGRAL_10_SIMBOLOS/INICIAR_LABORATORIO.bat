@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title LABORATORIO NEXOR X FINAL - ISOLADO
set "PY=python"
where python >nul 2>&1 || set "PY=py -3"
:menu
cls
echo ============================================================
echo       LABORATORIO NEXOR X FINAL - TOTALMENTE SEPARADO
echo ============================================================
echo 1 - Auditar todos os dados historicos Binance
echo 2 - Simular como o NEXOR X atual teria operado
echo 3 - Diagnosticar resultado do Laboratorio 7.3.15.58
echo 4 - Diagnosticar resultado de backtest JSON, JSONL ou CSV
echo 5 - Executar autoteste
echo 0 - Sair
echo.
set /p "OPTION=Escolha: "
if "%OPTION%"=="1" goto audit
if "%OPTION%"=="2" goto replay
if "%OPTION%"=="3" goto legacy
if "%OPTION%"=="4" goto generic
if "%OPTION%"=="5" goto selftest
if "%OPTION%"=="0" exit /b 0
goto menu

:replay
if exist "data_path.txt" set /p "DATA_PATH="<"data_path.txt"
if not defined DATA_PATH (
  echo Cole o caminho da pasta binance_todos_simbolos:
  set /p "DATA_PATH=> "
)
set "DATA_PATH=%DATA_PATH:"=%"
if not exist "%DATA_PATH%" (
  echo ERRO: pasta nao encontrada: %DATA_PATH%
  set "DATA_PATH="
  pause
  goto menu
)
>"data_path.txt" echo %DATA_PATH%
echo Etapa 1: piloto causal limitado a 10 simbolos.
echo Etapa 2: ranking raso e analise profunda dos 10 simbolos.
echo Etapa 3: operacao simulada somente apos todos os gates do NEXOR X.
echo Este processamento completo pode levar horas. Nao feche esta janela.
%PY% main.py run-runtime-parity --data "%DATA_PATH%" --symbols TODOS --output "results\runtime_parity"
pause
goto menu

:audit
if exist "data_path.txt" set /p "DATA_PATH="<"data_path.txt"
if not defined DATA_PATH (
  echo Cole o caminho da pasta binance_todos_simbolos:
  set /p "DATA_PATH=> "
)
set "DATA_PATH=%DATA_PATH:"=%"
if not exist "%DATA_PATH%" (
  echo ERRO: pasta nao encontrada: %DATA_PATH%
  set "DATA_PATH="
  pause
  goto menu
)
>"data_path.txt" echo %DATA_PATH%
%PY% main.py audit-data --data "%DATA_PATH%" --output "results\dataset_audit" --workers 4
pause
goto menu

:legacy
echo Cole o caminho completo do positions.jsonl do Laboratorio antigo:
set /p "INPUT_PATH=> "
set "INPUT_PATH=%INPUT_PATH:"=%"
%PY% main.py diagnose --legacy --input "%INPUT_PATH%" --output "results\legacy_diagnostics"
pause
goto menu

:generic
echo Cole o caminho do resultado .json, .jsonl ou .csv:
set /p "INPUT_PATH=> "
set "INPUT_PATH=%INPUT_PATH:"=%"
%PY% main.py diagnose --input "%INPUT_PATH%" --output "results\diagnostics"
pause
goto menu

:selftest
%PY% main.py self-test
pause
goto menu
