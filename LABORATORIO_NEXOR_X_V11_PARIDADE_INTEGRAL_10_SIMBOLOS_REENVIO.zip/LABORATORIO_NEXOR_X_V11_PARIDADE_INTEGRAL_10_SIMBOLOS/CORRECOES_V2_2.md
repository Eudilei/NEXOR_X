# Correções do replay 2.2

Esta versão substitui o replay 2.1. O resultado financeiro da execução 2.1 não
deve ser usado como resultado final do NEXOR X.

## Falhas corrigidas

- dimensionamento agora respeita banca, risco e alavancagem máxima de 15x;
- operações com stop inferior a 0,10% são rejeitadas;
- custo estimado superior a 0,35R é rejeitado antes da entrada;
- stablecoins, moedas fiduciárias, índices e tokens alavancados são excluídos;
- o replay termina se a banca ficar abaixo do mínimo operacional;
- sinais simultâneos são ordenados pelo maior score;
- indicadores são reiniciados após qualquer lacuna histórica;
- o contexto 4H usa somente candles 4H completamente fechados;
- spread e slippage são aplicados aos fills, sem cobrança duplicada;
- o relatório registra notional, alavancagem efetiva e risco efetivo.

## Segurança

O laboratório permanece offline, não recebe credenciais e não envia ordens.
O perfil continua sendo um replay de pesquisa, sem alegação de paridade LIVE.
