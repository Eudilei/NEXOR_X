# Piloto V11 — paridade integral e auditoria por filtro

Esta versão executa os módulos compartilhados do NEXOR X 0.78 usando no máximo
10 símbolos. Além das operações oficiais, acompanha causalmente oportunidades
bloqueadas e mede o resultado líquido contrafactual de cada filtro.

Use a opção 2 do menu. Os resultados novos serão gravados em
`results/runtime_parity`. Nenhuma ordem real, TESTNET ou LIVE é enviada.
