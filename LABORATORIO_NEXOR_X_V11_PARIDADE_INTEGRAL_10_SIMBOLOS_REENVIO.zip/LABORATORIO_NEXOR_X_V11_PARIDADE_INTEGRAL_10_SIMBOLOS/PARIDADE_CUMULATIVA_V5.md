# Laboratório V5 — paridade cumulativa

O replay começa uma única vez com R$ 200,00. Cada entrada paga taxa na banca
corrente; cada saída aplica o resultado líquido na mesma banca. O risco da
próxima operação é calculado sobre o saldo acumulado, nunca sobre R$ 200,00
reiniciados.

Ao final, uma reconciliação independente confirma:

`banca final = 200 + fluxos das saídas - taxas de entrada`

Qualquer diferença acima de R$ 0,000001 encerra o replay com erro, em vez de
publicar um resultado financeiro inválido.

O Shadow Learning fecha amostras que permanecerem abertas por 576 candles de
5 minutos (48 horas). A calibração pode usar um grupo causal equivalente de
direção, regime e faixa de edge até existir amostra própria suficiente, sem
reduzir os requisitos de expectativa, Profit Factor ou walk-forward.
