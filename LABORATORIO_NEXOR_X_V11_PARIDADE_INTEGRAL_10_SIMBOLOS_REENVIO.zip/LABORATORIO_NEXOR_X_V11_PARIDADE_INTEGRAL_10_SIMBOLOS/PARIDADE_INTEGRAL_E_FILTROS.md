# Paridade integral e diagnóstico dos filtros

## Componentes compartilhados com o NEXOR X 0.78

- Market Intelligence e classificação do regime.
- Evidence Engine e Quant Brain.
- Cinco motores estratégicos causais em candles de 15 minutos.
- Calibração por símbolo, direção, regime e faixa de edge.
- Pre-Trade Gate e backtest contextual.
- Taxas, deslizamento, stop, break-even, parcial e trailing.
- Proteção de desempenho e recuperação confirmada.

O diretório `runtime_snapshot/nexor_x` contém a cópia versionada dos módulos
reais usada pela rodada. Isso impede que o laboratório use fórmulas estratégicas
diferentes das instaladas no robô.

## Auditoria contrafactual

Cada sinal direcional reprovado pode abrir uma posição hipotética separada. Essa
posição não movimenta a banca oficial e respeita os mesmos custos e regras de
saída. Sinais repetidos são deduplicados: uma oportunidade ativa por símbolo e
intervalo mínimo de 24 horas para a mesma assinatura de direção e estratégia.

O JSON final contém:

- `blocked_opportunities`: operações hipotéticas completas;
- `blocked_filters`: filtros específicos que reprovaram a entrada;
- `filter_checks`: mapa verdadeiro/falso de cada filtro;
- `counterfactual_filter_audit.filters`: lucro rejeitado, prejuízo evitado,
  acerto do bloqueio e remoção individual.

Quando vários filtros falham, todos recebem atribuição compartilhada. O campo
`individual_removal_would_admit` só aumenta quando aquele era o único filtro
reprovado; assim o relatório não afirma incorretamente que remover apenas um
filtro liberaria uma operação ainda bloqueada por outros.

## Segurança estatística

O resultado contrafactual não altera parâmetros automaticamente e não certifica
LIVE. Ele serve para localizar filtros frouxos, rígidos ou redundantes. Qualquer
mudança deverá se repetir em outras janelas históricas e permanecer positiva
depois de taxas e deslizamento.
