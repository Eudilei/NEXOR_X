@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py -3"
if exist "data_path.txt" set /p "DATA_PATH="<"data_path.txt"
if not defined DATA_PATH set /p "DATA_PATH=Cole o caminho da pasta binance_todos_simbolos: "
set "DATA_PATH=%DATA_PATH:"=%"
if not exist "%DATA_PATH%" (echo ERRO: pasta nao encontrada.& pause& exit /b 1)
>"data_path.txt" echo %DATA_PATH%
%PY% main.py audit-data --data "%DATA_PATH%" --output "results\dataset_audit" --workers 4
pause
