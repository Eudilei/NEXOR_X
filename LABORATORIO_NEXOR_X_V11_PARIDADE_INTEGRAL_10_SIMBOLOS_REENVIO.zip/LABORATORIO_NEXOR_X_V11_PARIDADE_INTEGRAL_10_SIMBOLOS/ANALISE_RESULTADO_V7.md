# Análise da rodada V7 — 10 símbolos

## Resultado observado

- 167 operações: 52 vitórias e 115 perdas; acerto de 31,14%.
- Banca: R$ 200,00 para R$ 189,13; resultado líquido de -R$ 10,87 (-5,43%).
- PnL bruto das operações: +R$ 51,52.
- Taxas totais: R$ 62,39.
- Profit Factor líquido: 0,964.
- Drawdown máximo em valor: R$ 59,94; queda final desde o pico: 24,06%.

## Causa principal

A estratégia não perdeu antes dos custos: produziu R$ 51,52 brutos. As taxas
de R$ 62,39 superaram todo o ganho bruto e transformaram o resultado em perda.
Logo, aprovar poucos sinais não garante lucro: cada sinal precisa possuir margem
líquida suficiente para pagar entrada, saída e slippage.

O desempenho também se deteriorou ao longo do tempo. O primeiro terço ficou em
+R$ 1,41, o segundo em +R$ 13,32 e o último em -R$ 25,59. A proteção adaptativa
existente no NEXOR não reagiu porque lia o nível externo do relatório de
validação e não as evidências das operações PAPER realmente fechadas.

## Concentração das perdas

- SHORT: 38 operações, -R$ 27,07, PF 0,668.
- LONG: 129 operações, +R$ 16,21, PF 1,073.
- TREND_DOWN: -R$ 27,07.
- TREND_UP: +R$ 38,38.
- BNBUSDT: -R$ 14,68; TRXUSDT: -R$ 13,49.
- BTCUSDT: +R$ 10,25; ETHUSDT: +R$ 7,05, mas ETH teve somente 4 operações.

Esses recortes são evidência para investigar, não autorização para proibir
SHORT, BNB ou TRX definitivamente. Fazer isso após uma única amostra causaria
overfitting. A correção segura é interromper novas entradas quando a performance
recente degrada, preservar a gestão das posições abertas e repetir em universo
maior.

## Correções da V8 / Update 76

- Evidência PAPER obtida de `portfolio_positions` fechadas e PnL líquido.
- Amostra recente, sequência de perdas e drawdown calculados corretamente.
- Bloqueio de novas entradas com PF recente abaixo de 1 após 20 trades,
  drawdown de 15% ou seis perdas consecutivas.
- Gestão das posições abertas mantida durante o bloqueio.
- Universo ampliado para 50 símbolos, com análise profunda dos 10 melhores.
- Relatório passa a registrar horários e métricas de calibração da entrada.
- LIVE permanece bloqueado.

Aplicada retrospectivamente apenas à sequência de fechamentos da V7, a nova
regra teria acionado o primeiro bloqueio depois da 25ª operação, quando o PF
recente caiu para 0,947 e o PnL acumulado estava em aproximadamente -R$ 2,45.
Isso é uma comparação contrafactual simplificada, não uma promessa de resultado,
pois posições que já estivessem abertas ainda precisariam ser administradas.
