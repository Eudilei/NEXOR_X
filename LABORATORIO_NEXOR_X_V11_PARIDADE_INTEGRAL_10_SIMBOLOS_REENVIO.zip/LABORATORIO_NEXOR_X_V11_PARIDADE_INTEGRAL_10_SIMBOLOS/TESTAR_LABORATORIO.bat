@echo off
cd /d "%~dp0"
python main.py self-test
pause
