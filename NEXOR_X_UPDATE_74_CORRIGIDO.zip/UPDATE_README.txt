NEXOR X UPDATE 74

Requer a Update 73 (versao 0.73.0).

Esta atualizacao impede que posicoes Shadow fiquem abertas indefinidamente:
elas encerram em no maximo 48 horas e alimentam a calibracao causal.

O fluxo permanece:
mercado elegivel -> analise rasa -> top 60 -> analise profunda -> gates -> PAPER.

LIVE continua bloqueado.
