
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    for rel in (
        "src/nexor_x/validation/final_dashboard.py",
        "tests/test_final_dashboard_snapshot.py",
        "docs/AUDIT_UPDATE_55.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_validation_init() -> None:
    path = ROOT / "src/nexor_x/validation/__init__.py"
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    imp = (
        "from .final_dashboard import "
        "FinalTechnicalDashboardSnapshot\n"
    )
    if imp not in text:
        text = imp + text

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.validation.final_dashboard import "
        "FinalTechnicalDashboardSnapshot\n"
    )
    anchor = (
        "from nexor_x.validation.final_completion import "
        "FinalTechnicalCompletionGate\n"
    )

    if import_line not in text:
        if anchor not in text:
            raise RuntimeError(
                "Update 54 não detectada: FinalTechnicalCompletionGate ausente"
            )
        text = text.replace(
            anchor,
            anchor + import_line,
            1,
        )

    init_line = (
        "        self.final_dashboard_snapshot = "
        "FinalTechnicalDashboardSnapshot()\n"
    )
    anchor2 = (
        "        self.final_technical_completion = "
        "FinalTechnicalCompletionGate()\n"
    )

    if init_line not in text:
        if anchor2 not in text:
            raise RuntimeError(
                "Update 54 não detectada: final_technical_completion ausente"
            )
        text = text.replace(
            anchor2,
            anchor2 + init_line,
            1,
        )

    if "async def final_dashboard_snapshot_status(" not in text:
        marker = "    async def final_technical_completion_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 54 não detectada: final completion method ausente"
            )

        method = (
            "    async def final_dashboard_snapshot_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        completion = await self.final_technical_completion_status()\n"
            "        campaign = await self.final_validation_campaign_status()\n"
            "        acceptance = await self.operational_acceptance_audit()\n"
            "        readiness_summary = await self.operational_readiness_summary()\n"
            "        return self.final_dashboard_snapshot.build(\n"
            "            completion=completion,\n"
            "            campaign=campaign,\n"
            "            acceptance=acceptance,\n"
            "            readiness_summary=readiness_summary,\n"
            "        )\n\n"
        )

        text = text.replace(
            marker,
            method + marker,
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_api_endpoint() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if '@app.get("/api/validation/final-snapshot")' in text:
        return

    marker = '@app.get("/api/validation/final-completion")'
    if marker not in text:
        raise RuntimeError(
            "Update 54 não detectada: final-completion endpoint ausente"
        )

    block = (
        '@app.get("/api/validation/final-snapshot")\n'
        "    async def final_dashboard_snapshot_status(\n"
        "        _: None = Depends(require_admin),\n"
        "    ) -> dict[str, Any]:\n"
        "        return await kernel.final_dashboard_snapshot_status()\n\n"
        "    "
    )

    text = text.replace(
        marker,
        block + marker,
        1,
    )
    path.write_text(text, encoding="utf-8")


def patch_command_center() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)

    if 'id="finalTechnicalStatus"' in text:
        return

    # Insere um card no grid existente do Command Center.
    card_anchor = (
        '<section class="card wide"><div class="label">Scanner de mercado</div>'
    )
    if card_anchor not in text:
        raise RuntimeError(
            "Command Center esperado não encontrado em api/app.py"
        )

    card = (
        '<section class="card wide"><div class="label">Fechamento Técnico</div>'
        '<div class="value" id="finalTechnicalStatus">Aguardando token</div>'
        '<div class="small" id="finalTechnicalProgress">Campanha: -</div>'
        '<div class="services">'
        '<div class="service"><b>Acceptance Audit</b><br><small id="finalAcceptance">-</small></div>'
        '<div class="service"><b>Readiness</b><br><small id="finalReadiness">-</small></div>'
        '<div class="service"><b>Evidence</b><br><small id="finalEvidence">-</small></div>'
        '<div class="service"><b>Exposure</b><br><small id="finalExposure">-</small></div>'
        '<div class="service"><b>LIVE</b><br><small id="finalLive">BLOQUEADO</small></div>'
        '<div class="service"><b>Pendências</b><br><small id="finalPending">-</small></div>'
        '</div></section>'
    )

    text = text.replace(
        card_anchor,
        card + card_anchor,
        1,
    )

    # Acrescenta função JS antes de ask().
    js_anchor = "async function ask(){"
    if js_anchor not in text:
        raise RuntimeError(
            "Bloco JavaScript esperado do Command Center não encontrado"
        )

    js = (
        "async function finalTechnical(){"
        "const token=adminToken.value;"
        "if(!token){finalTechnicalStatus.textContent='INFORME O TOKEN';return}"
        "try{"
        "const r=await fetch('/api/validation/final-snapshot',{headers:{'X-NEXOR-ADMIN-TOKEN':token}});"
        "const x=await r.json();"
        "if(!r.ok)throw new Error(x.detail||'Falha');"
        "finalTechnicalStatus.textContent=x.status;"
        "finalTechnicalProgress.textContent=`Campanha: ${Number(x.validation_progress_percent).toFixed(1)}% • ${x.validation_passes}/${x.validation_required_passes} PASS`;"
        "finalAcceptance.textContent=x.acceptance_status;"
        "finalReadiness.textContent=x.candidate_ready?'CANDIDATE READY':'PENDENTE';"
        "finalEvidence.textContent=x.evidence_certified?'CERTIFICADO':'PENDENTE';"
        "finalExposure.textContent=(Number(x.exposure_multiplier)*100).toFixed(0)+'%';"
        "finalLive.textContent='BLOQUEADO';"
        "finalPending.textContent=(x.pending_requirements||[]).join(' • ')||'Nenhuma';"
        "}catch(e){finalTechnicalStatus.textContent='INDISPONIVEL';finalTechnicalProgress.textContent=e.message}"
        "}\n"
    )

    text = text.replace(
        js_anchor,
        js + js_anchor,
        1,
    )

    # Consulta junto com os demais ciclos de atualização.
    interval_anchor = (
        "setInterval(()=>{market();quant();scanner()},15000);"
    )
    if interval_anchor in text:
        text = text.replace(
            interval_anchor,
            "setInterval(()=>{market();quant();scanner();finalTechnical()},15000);",
            1,
        )

    # Ao perguntar à IA, aproveita que o token já foi preenchido.
    ask_anchor = (
        "async function ask(){answer.textContent='Processando...';"
    )
    if ask_anchor in text:
        text = text.replace(
            ask_anchor,
            "async function ask(){finalTechnical();answer.textContent='Processando...';",
            1,
        )

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.55.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.55.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_validation_init()
    patch_kernel()
    patch_api_endpoint()
    patch_command_center()
    patch_version()
    print(
        "NEXOR X Update 55 aplicada: fechamento técnico integrado "
        "ao Command Center. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
