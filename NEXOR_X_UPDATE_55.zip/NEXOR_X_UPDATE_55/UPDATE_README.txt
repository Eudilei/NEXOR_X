NEXOR X UPDATE 55 — FINAL TECHNICAL DASHBOARD

Objetivo:
  levar o fechamento técnico da Update 54 para o Command Center já existente.

Nova seção no painel:
  FECHAMENTO TÉCNICO

Mostra:
  - status final: TECHNICALLY_COMPLETE / VALIDATION_PENDING /
    EVIDENCE_PENDING / BLOCKED;
  - progresso da Final Validation Campaign;
  - Acceptance Audit PASS/FAIL;
  - candidate_ready;
  - evidence_certified;
  - exposure multiplier atual;
  - blockers e requisitos pendentes;
  - LIVE: BLOQUEADO.

Novo endpoint administrativo:
  GET /api/validation/final-snapshot

O painel usa o mesmo X-NEXOR-ADMIN-TOKEN já utilizado pela IA local.

LIVE permanece bloqueado.

Requer NEXOR X 0.54.0.
