from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()
VERSION = "0.69.0"


def replace_version(path: Path, pattern: str, replacement: str) -> None:
    text = path.read_text(encoding="utf-8")
    updated, count = re.subn(pattern, replacement, text, count=1)
    if count != 1:
        raise RuntimeError(f"Marcador de versao nao encontrado: {path}")
    path.write_text(updated, encoding="utf-8")


def main() -> None:
    replace_version(
        ROOT / "pyproject.toml",
        r'version = "[^"]+"',
        f'version = "{VERSION}"',
    )
    replace_version(
        ROOT / "src/nexor_x/__init__.py",
        r'__version__\s*=\s*"[^"]+"',
        f'__version__ = "{VERSION}"',
    )
    print("NEXOR X Update 69 aplicada: PnL liquido conectado ao fechamento PAPER.")
    print("LIVE permanece bloqueado.")


if __name__ == "__main__":
    main()
