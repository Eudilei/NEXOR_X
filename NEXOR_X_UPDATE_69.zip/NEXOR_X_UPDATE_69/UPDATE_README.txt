NEXOR X UPDATE 69 - NET PNL RUNTIME CLOSURE FIX

Objetivo:
- corrigir exclusivamente runtime_net_pnl_connected;
- usar NetPnLRuntimeAdapter no fechamento PAPER real;
- persistir gross_pnl, entry_fee, exit_fee, total_fees e net_pnl;
- manter pnl e realized_pnl como aliases do resultado liquido;
- preservar a contabilidade correta do saldo sem cobrar a entrada duas vezes;
- manter LIVE bloqueado.

Validacao realizada:
- auditoria final: FINAL_RUNTIME_INTEGRATION_PASS (15/15);
- suite completa: 324 testes aprovados;
- compilacao Python e lint critico aprovados.

Depois que o GitHub Actions ficar verde, atualize o projeto no VS Code com:
git pull

Em seguida execute:
python tools/final_runtime_integration_audit.py

Resultado esperado:
FINAL_RUNTIME_INTEGRATION_PASS
checks=15/15
LIVE: BLOQUEADO
