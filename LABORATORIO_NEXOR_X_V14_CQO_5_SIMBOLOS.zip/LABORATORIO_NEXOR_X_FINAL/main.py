from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from lab import (
    BacktestDiagnosticEngine,
    DiagnosticPolicy,
    HistoricalDatasetBridge,
    LegacyLaboratoryResultsAdapter,
    NexorResearchReplay,
    ReplayConfig,
    RuntimeParityReplay,
    RuntimePolicy,
    TwoStageRuntimeParityReplay,
    CausalAuditEngine,
)


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results"


def load_policy(path: Path) -> DiagnosticPolicy:
    data = json.loads(path.read_text(encoding="utf-8"))
    return DiagnosticPolicy(**data["diagnostic_thresholds"])


def read_records(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        raise ValueError(f"arquivo nao encontrado: {path}")
    suffix = path.suffix.lower()
    if suffix == ".jsonl":
        records = []
        with path.open(encoding="utf-8-sig") as handle:
            for line_number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise ValueError(f"JSON invalido na linha {line_number}") from exc
        return records
    if suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(data, list):
            return [dict(item) for item in data]
        for key in ("trades", "positions", "records"):
            if isinstance(data.get(key), list):
                return [dict(item) for item in data[key]]
        raise ValueError("JSON nao contem lista trades/positions/records")
    if suffix == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as handle:
            return [dict(item) for item in csv.DictReader(handle)]
    raise ValueError("formatos aceitos: .jsonl, .json ou .csv")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def diagnostic_markdown(report: dict[str, Any]) -> str:
    summary = report["summary"]
    lines = [
        "# Diagnóstico do Backtest", "",
        f"- Perfil: `{report['profile']}`",
        f"- Operações: {summary['trade_count']}",
        f"- Vitórias: {summary['wins']}",
        f"- Perdas: {summary['losses']}",
        f"- PnL bruto: {summary['gross_pnl']}",
        f"- Taxas: {summary['total_fees']}",
        f"- PnL líquido: {summary['net_pnl']}",
        f"- Profit Factor líquido: {summary['profit_factor_net']}",
        f"- Drawdown máximo em valor: {summary['maximum_drawdown_value']}", "",
        "## Principais causas negativas", "",
    ]
    causes = summary["top_diagnostic_causes"]
    lines.extend(f"- {item['code']}: {item['count']}" for item in causes)
    if not causes:
        lines.append("- Nenhuma causa negativa classificada.")
    lines.extend(["", "## Fatores positivos recorrentes", ""])
    strengths = summary["top_positive_factors"]
    lines.extend(f"- {item['code']}: {item['count']}" for item in strengths)
    if not strengths:
        lines.append("- Nenhum fator positivo pôde ser classificado.")
    lines.extend(["", "## Resultado por estratégia", ""])
    lines.extend(
        f"- {name}: {value:.8f}" for name, value in summary["net_pnl_by_strategy"].items()
    )
    lines.extend(["", "## Resultado por regime", ""])
    lines.extend(f"- {name}: {value:.8f}" for name, value in summary["net_pnl_by_regime"].items())
    lines.extend(["", "## Operações", ""])
    for trade in report["trades"]:
        cause_codes = ", ".join(item["code"] for item in trade["causes"]) or "nenhuma"
        strength_codes = ", ".join(item["code"] for item in trade["strengths"]) or "nenhum"
        lines.append(
            f"- {trade['trade_id']} | {trade['symbol']} | {trade['outcome']} | "
            f"líquido={trade['net_pnl']} | causas={cause_codes} | positivos={strength_codes} | "
            f"confiança={trade['diagnostic_confidence']}"
        )
    lines.extend(["", "## Limitações", ""])
    lines.extend(f"- {item}" for item in report["limitations"])
    return "\n".join(lines) + "\n"


def command_audit(args: argparse.Namespace) -> None:
    bridge = HistoricalDatasetBridge()
    report = bridge.audit(args.data, workers=args.workers)
    json_path, md_path = bridge.write_reports(report, args.output)
    print(json.dumps({
        "status": report["status_counts"], "symbols": report["symbol_count"],
        "archives": report["archive_count"], "candles": report["total_rows"],
        "json": str(json_path), "markdown": str(md_path),
    }, ensure_ascii=False, indent=2))


def command_diagnose(args: argparse.Namespace) -> None:
    records = read_records(args.input)
    if args.legacy:
        records = LegacyLaboratoryResultsAdapter().adapt(records)
    policy = load_policy(args.policy)
    report = BacktestDiagnosticEngine(policy).diagnose(records)
    if args.legacy:
        report["profile"] = "LEGACY_7_3_15_58_DIAGNOSTIC_ONLY"
        report["limitations"].insert(
            0, "Motor 7.3.15.58 nao equivale ao motor final do NEXOR X."
        )
    args.output.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    json_path = args.output / f"backtest_diagnostic_{stamp}.json"
    md_path = args.output / f"backtest_diagnostic_{stamp}.md"
    write_json(json_path, report)
    md_path.write_text(diagnostic_markdown(report), encoding="utf-8")
    print(json.dumps({
        "trades": report["summary"]["trade_count"],
        "net_pnl": report["summary"]["net_pnl"],
        "json": str(json_path), "markdown": str(md_path),
    }, ensure_ascii=False, indent=2))


def command_self_test(_: argparse.Namespace) -> None:
    report = BacktestDiagnosticEngine().diagnose([
        {"symbol": "TESTUSDT", "strategy_id": "SELF_TEST", "regime": "TREND",
         "gross_pnl": 2, "total_fees": 0.5, "net_pnl": 1.5, "realized_r": 1},
        {"symbol": "TESTUSDT", "strategy_id": "SELF_TEST", "regime": "RANGE",
         "gross_pnl": -1, "total_fees": 0.2, "net_pnl": -1.2, "realized_r": -1},
    ])
    assert report["summary"]["trade_count"] == 2
    assert report["execution_allowed"] is False
    print("SELF_TEST_PASS | laboratorio isolado | LIVE inexistente")


def command_replay(args: argparse.Namespace) -> None:
    policy_data = json.loads(args.policy.read_text(encoding="utf-8"))
    config = ReplayConfig(**policy_data.get("replay", {}))
    symbols = [item for value in args.symbols for item in value.split(",")]
    engine = NexorResearchReplay(config)
    def show_progress(position: int, total: int, symbol: str) -> None:
        print(f"[{position}/{total}] Processando {symbol}...", flush=True)
    report = engine.run(args.data, symbols, progress=show_progress)
    json_path, positions_path, md_path = engine.write_reports(report, args.output)
    diagnostics: dict[str, str] = {}
    if report["trades"]:
        diagnosis = BacktestDiagnosticEngine(load_policy(args.policy)).diagnose(report["trades"])
        diagnosis["profile"] = report["profile"] + "_DIAGNOSTIC"
        diagnostic_json = args.output / "diagnostic_latest.json"
        diagnostic_md = args.output / "diagnostic_latest.md"
        write_json(diagnostic_json, diagnosis)
        diagnostic_md.write_text(diagnostic_markdown(diagnosis), encoding="utf-8")
        diagnostics = {"diagnostic_json": str(diagnostic_json), "diagnostic_markdown": str(diagnostic_md)}
    print(json.dumps({**report["summary"], "replay_json": str(json_path),
                      "positions_jsonl": str(positions_path), "replay_markdown": str(md_path),
                      **diagnostics}, ensure_ascii=False, indent=2))


def command_runtime_replay(args: argparse.Namespace) -> None:
    policy_data = json.loads(args.policy.read_text(encoding="utf-8"))
    policy = RuntimePolicy(**policy_data.get("runtime_parity", {}))
    engine = TwoStageRuntimeParityReplay(policy)
    symbols = [item for value in args.symbols for item in value.split(",")]
    report = engine.run(args.data, symbols, progress=lambda message: print(message, flush=True))
    json_path, md_path = engine.write_report(report, args.output)
    audit = CausalAuditEngine().analyze(report)
    audit_json, audit_md = CausalAuditEngine.write(audit, args.output)
    corrected = report["corrected_with_causal_shadow"]
    print(json.dumps({"strict_current": report["strict_current"],
                      "corrected_summary": {key: value for key, value in corrected.items() if key not in {"trades", "blocked_opportunities"}},
                      "json": str(json_path), "markdown": str(md_path),
                      "causal_audit_json": str(audit_json),
                      "causal_audit_markdown": str(audit_md)},
                     ensure_ascii=False, indent=2))



def command_analyze_results(args: argparse.Namespace) -> None:
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    audit = CausalAuditEngine().analyze(payload)
    json_path, md_path = CausalAuditEngine.write(audit, args.output)
    print(json.dumps({
        "executed_trades": audit["executed"]["overall"]["samples"],
        "validated_contexts": len(audit["walk_forward_context_validation"]["validated"]),
        "json": str(json_path),
        "markdown": str(md_path),
    }, ensure_ascii=False, indent=2))

def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Laboratorio NEXOR X Final - isolado")
    commands = result.add_subparsers(dest="command", required=True)
    audit = commands.add_parser("audit-data")
    audit.add_argument("--data", required=True, type=Path)
    audit.add_argument("--output", type=Path, default=DEFAULT_RESULTS / "dataset_audit")
    audit.add_argument("--workers", type=int, default=4)
    audit.set_defaults(handler=command_audit)
    diagnose = commands.add_parser("diagnose")
    diagnose.add_argument("--input", required=True, type=Path)
    diagnose.add_argument("--output", type=Path, default=DEFAULT_RESULTS / "diagnostics")
    diagnose.add_argument("--policy", type=Path, default=ROOT / "config" / "lab_policy.json")
    diagnose.add_argument("--legacy", action="store_true")
    diagnose.set_defaults(handler=command_diagnose)
    replay = commands.add_parser("run-replay")
    replay.add_argument("--data", required=True, type=Path)
    replay.add_argument("--symbols", nargs="+", default=["TODOS"])
    replay.add_argument("--output", type=Path, default=DEFAULT_RESULTS / "replay")
    replay.add_argument("--policy", type=Path, default=ROOT / "config" / "lab_policy.json")
    replay.set_defaults(handler=command_replay)
    runtime_replay = commands.add_parser("run-runtime-parity")
    runtime_replay.add_argument("--data", required=True, type=Path)
    runtime_replay.add_argument("--symbols", nargs="+", default=["TODOS"])
    runtime_replay.add_argument("--output", type=Path, default=DEFAULT_RESULTS / "runtime_parity")
    runtime_replay.add_argument("--policy", type=Path, default=ROOT / "config" / "lab_policy.json")
    runtime_replay.set_defaults(handler=command_runtime_replay)
    analyze = commands.add_parser("analyze-results")
    analyze.add_argument("--input", required=True, type=Path)
    analyze.add_argument("--output", type=Path, default=DEFAULT_RESULTS / "causal_audit")
    analyze.set_defaults(handler=command_analyze_results)
    check = commands.add_parser("self-test")
    check.set_defaults(handler=command_self_test)
    return result


def main() -> None:
    try:
        args = parser().parse_args()
        args.handler(args)
    except Exception as exc:
        print(f"LAB_ERROR | {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
