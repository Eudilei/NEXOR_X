# Auditoria causal do resultado recebido — V12

Arquivo analisado: `results/runtime_parity/runtime_parity_20260820_221111.json`.

## Resultado confirmado

- 34 trades executados.
- PnL líquido: -R$ 12,47.
- Profit Factor líquido: 0,702667.
- 70.034 outcomes Shadow.
- 28.494 oportunidades bloqueadas acompanhadas contrafactualmente.
- Período inferido pelos outcomes: 01/01/2024 23:55 UTC a 30/06/2026 23:55 UTC, aproximadamente 2,49 anos.
- Frequência executada: aproximadamente 13,63 trades/ano.

## Validação 70/30 sem olhar o futuro

A V12 ordenou as oportunidades bloqueadas cronologicamente, usou 70% apenas para descobrir hipóteses de contexto e preservou os 30% finais como holdout.

Somente um contexto bloqueado atingiu os critérios mínimos no trecho de treino: `UNKNOWN + TREND_DOWN + SHORT`. No holdout ele falhou: PF 0,628061, Expected R -0,202007 e PnL -R$ 64,65. Resultado: 0 contextos validados para promoção.

Isto é evidência de que não devemos transformar os bons números agregados da rodada em regras fixas sem nova validação.

## Contribuição marginal dos filtros

Remover isoladamente os principais bloqueios de degradação teria admitido muitos trades, mas com resultado contrafactual negativo:

- `DEGRADATION_PROFIT_FACTOR_BELOW_1`: 17.216 oportunidades que seriam admitidas; PF 0,748385; PnL -R$ 8.502,19.
- `DEGRADATION_LOSS_STREAK_CRITICAL`: 5.049; PF 0,778740; PnL -R$ 2.082,80.
- `CONTEXT_MAXIMUM_DRAWDOWN`: 10; PF 0,368729; PnL -R$ 14,45.
- `STRATEGY_APPROVED`: 6; PF 0,120540; PnL -R$ 10,41.
- `CONTEXT_WALK_FORWARD`: 1; PnL -R$ 0,28.

Conclusão: simplesmente afrouxar esses filtros pioraria o conjunto analisado.

## Redundância detectada

Há sobreposição praticamente total entre alguns gates:

- `CALIBRATED`, `MINIMUM_SAMPLES` e `CONTEXT_MINIMUM_SAMPLES`: Jaccard 1,0.
- `CONTEXT_EXPECTED_R` e `POSITIVE_EXPECTED_R`: Jaccard 0,9989.
- `CONTEXT_PROFIT_FACTOR` e `PROFIT_FACTOR`: Jaccard 0,9989.
- `CONTEXT_RECENT_EXPECTED_R` e `CONTEXT_RECENT_PROFIT_FACTOR`: Jaccard 0,9871.

A próxima otimização deve consolidar/avaliar gates redundantes por contribuição marginal, não removê-los cegamente.

## Correções implementadas na V12

- Auditoria causal automática após o replay.
- Holdout cronológico 70/30.
- Análise de contribuição marginal por filtro.
- Matriz de redundância de filtros.
- Análise por símbolo, direção, regime, estratégia e combinação contextual.
- Diagnóstico de frequência de trades.
- Classificação real do tipo de saída: `INITIAL_STOP`, `BREAK_EVEN_STOP`, `TRAILING_STOP`, `TRAILING_STOP_AFTER_PARTIAL` e `END_OF_DATA`.
- Registro de `best_r_before_exit` e se houve parcial.
- Nenhuma alteração automática de parâmetros ou liberação para LIVE.

## Decisão de engenharia

A V12 não grava regras como “não operar TRX”, “não operar RANGE” ou “usar apenas Trend Pullback”. Essas conclusões seriam overfitting com a amostra atual. O próximo replay deve medir novamente, e qualquer hipótese precisa sobreviver ao holdout antes de ser considerada para o NEXOR X.
