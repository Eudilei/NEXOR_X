# Laboratório NEXOR X V12 — auditoria causal e proteção contra overfitting

## Alterações

- Adicionada auditoria causal automática após `run-runtime-parity`.
- Adicionado corte cronológico 70/30: hipóteses são descobertas apenas no primeiro bloco e verificadas no holdout posterior.
- Nenhuma regra, filtro, ativo ou estratégia é promovido automaticamente para o NEXOR X.
- Adicionada contribuição marginal dos filtros: mede o que aconteceria quando um filtro era o único bloqueador.
- Adicionada matriz de redundância por sobreposição (Jaccard) entre filtros.
- Adicionada análise contextual por estratégia + regime + direção.
- Adicionada análise de frequência de trades em relação a ciclos, shadow e período coberto.
- Saídas agora distinguem `INITIAL_STOP`, `BREAK_EVEN_STOP`, `TRAILING_STOP` e `TRAILING_STOP_AFTER_PARTIAL`, além de registrar o melhor R alcançado antes da saída.
- Mantidos LIVE, testnet e ordens reais desabilitados.

## Descoberta da rodada recebida

A auditoria V12 do resultado `runtime_parity_20260820_221111.json` não encontrou nenhum contexto bloqueado que tenha passado simultaneamente os critérios mínimos no trecho de treino e no holdout. Portanto, os bons números pontuais observados em estratégia/regime/direção não devem virar regras fixas.

Também foi detectada redundância quase total entre alguns gates, incluindo `CALIBRATED`/`MINIMUM_SAMPLES`/`CONTEXT_MINIMUM_SAMPLES`, e forte sobreposição entre gates de Expected R e Profit Factor. A próxima otimização deve avaliar a contribuição marginal, e não simplesmente remover filtros em bloco.

## Uso

No menu, a opção 2 executa o replay e gera também `causal_audit_latest.json/.md`. A opção 6 reanalisa o último resultado já existente sem repetir o replay histórico.
