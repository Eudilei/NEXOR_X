# NEXOR X / Laboratório V13 — Edge Adaptativo, 5 símbolos

## Universo fixado para o piloto
- BTCUSDT
- ETHUSDT
- SOLUSDT
- BNBUSDT
- XRPUSDT

O Laboratório limita a execução a 5 símbolos e o scanner profundo processa no máximo os mesmos 5 por ciclo.

## Mudanças centrais
1. Novo `AdaptiveContextEdge`: estima vantagem por hierarquia causal (símbolo + direção + regime + estratégia), com shrinkage para contextos mais amplos quando a amostra local é pequena.
2. Peso temporal: evidências recentes recebem mais peso, sem apagar o histórico.
3. Gate de expectativa líquida: exige margem positiva depois de um buffer explícito para custos.
4. Estabilidade multi-janelas: exige que a vantagem apareça em mais de uma subjanela, reduzindo overfitting.
5. Filtros quantitativos redundantes deixam de ser empilhados no replay V13. Os gates de segurança, dados frescos, capacidade, risco agregado e drawdown continuam obrigatórios.
6. O backtest contextual legado continua sendo calculado e salvo para auditoria, mas não duplica a mesma decisão seis vezes.
7. Recuperação ficou mais conservadora: permanece em 25% por pelo menos duas recuperações bem-sucedidas antes de subir exposição; falha zera a sequência.
8. LIVE continua proibido. A V13 é PAPER/Laboratório até validação fora da amostra e PAPER real.

## Objetivo
Aumentar a quantidade de operações somente quando houver vantagem contextual líquida sustentada, em vez de simplesmente afrouxar filtros.
