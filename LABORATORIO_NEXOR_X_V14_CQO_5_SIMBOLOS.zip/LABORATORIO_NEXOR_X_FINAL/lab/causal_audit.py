from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import combinations
from math import sqrt
from pathlib import Path
from typing import Any, Iterable
import json


@dataclass(frozen=True)
class CausalAuditPolicy:
    train_fraction: float = 0.70
    minimum_context_samples: int = 30
    minimum_holdout_samples: int = 10
    minimum_train_profit_factor: float = 1.10
    minimum_train_expected_r: float = 0.05


class CausalAuditEngine:
    """Audit executed and blocked opportunities without changing trading rules.

    The engine deliberately does not auto-tune the runtime. It learns candidate
    contexts only from the chronological training slice and evaluates those
    candidates on the untouched holdout slice. This makes the report useful for
    deciding what to change without converting the laboratory into an overfit
    optimizer.
    """

    def __init__(self, policy: CausalAuditPolicy | None = None) -> None:
        self.policy = policy or CausalAuditPolicy()

    def analyze(self, report: dict[str, Any]) -> dict[str, Any]:
        corrected = report.get("corrected_with_causal_shadow") or report
        trades = [dict(x) for x in corrected.get("trades") or []]
        blocked = [dict(x) for x in corrected.get("blocked_opportunities") or []]
        all_outcomes = trades + blocked
        start_ms, end_ms = self._period(all_outcomes)
        years = max((end_ms - start_ms) / 31_556_952_000, 0.0) if start_ms and end_ms else 0.0

        return {
            "schema": "nexor_x.causal_audit.v12",
            "generated_at": datetime.now(UTC).isoformat(),
            "source_profile": report.get("profile"),
            "period": {
                "first_outcome_ms": start_ms,
                "last_outcome_ms": end_ms,
                "first_outcome_utc": self._iso(start_ms),
                "last_outcome_utc": self._iso(end_ms),
                "covered_years_from_outcomes": round(years, 4),
                "executed_trades_per_year": round(len(trades) / years, 2) if years > 0 else None,
                "note": "periodo inferido pelos resultados; a base OHLCV pode comecar antes do primeiro outcome",
            },
            "executed": self._grouped_performance(trades),
            "recovery": self._recovery_analysis(trades),
            "blocked": self._grouped_performance(blocked),
            "filter_marginal_effect": self._filter_marginal(blocked),
            "filter_redundancy": self._filter_redundancy(blocked),
            "walk_forward_context_validation": self._walk_forward_contexts(blocked),
            "frequency_diagnosis": self._frequency_diagnosis(corrected, years),
            "safety": {
                "automatic_parameter_changes": False,
                "live_certified": False,
                "purpose": "diagnostico e selecao de hipoteses para nova rodada fora da amostra",
            },
        }

    @staticmethod
    def _number(value: Any) -> float:
        try:
            return float(value or 0.0)
        except (TypeError, ValueError):
            return 0.0

    @classmethod
    def _metrics(cls, rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
        rows = list(rows)
        values = [cls._number(x.get("net_pnl")) for x in rows]
        r_values = [cls._number(x.get("realized_r")) for x in rows]
        profit = sum(x for x in values if x > 0)
        loss = abs(sum(x for x in values if x < 0))
        wins = sum(x > 0 for x in values)
        fees = sum(cls._number(x.get("total_fees")) for x in rows)
        gross = sum(cls._number(x.get("gross_pnl")) for x in rows)
        return {
            "samples": len(rows),
            "wins": wins,
            "losses": sum(x < 0 for x in values),
            "win_rate_pct": round(wins / len(rows) * 100, 4) if rows else 0.0,
            "gross_pnl_brl": round(gross, 8),
            "fees_brl": round(fees, 8),
            "net_pnl_brl": round(sum(values), 8),
            "expected_r": round(sum(r_values) / len(r_values), 6) if r_values else 0.0,
            "profit_factor": round(profit / loss, 6) if loss else (999.0 if profit else 0.0),
        }

    def _grouped_performance(self, rows: list[dict[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {"overall": self._metrics(rows)}
        fields = {
            "by_symbol": ("symbol",),
            "by_side": ("side",),
            "by_regime": ("regime",),
            "by_strategy": ("strategy_id",),
            "by_strategy_regime_side": ("strategy_id", "regime", "side"),
        }
        for out_name, keys in fields.items():
            groups: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
            for row in rows:
                groups[tuple(str(row.get(k) or "UNKNOWN") for k in keys)].append(row)
            packed = []
            for key, items in groups.items():
                item = self._metrics(items)
                for index, name in enumerate(keys):
                    item[name] = key[index]
                packed.append(item)
            result[out_name] = sorted(packed, key=lambda x: (-x["samples"], tuple(str(x.get(k, "")) for k in keys)))
        return result

    def _recovery_analysis(self, trades: list[dict[str, Any]]) -> dict[str, Any]:
        normal = [x for x in trades if not bool(x.get("recovery_trial"))]
        recovery = [x for x in trades if bool(x.get("recovery_trial"))]
        by_multiplier: dict[float, list[dict[str, Any]]] = defaultdict(list)
        for trade in recovery:
            by_multiplier[round(self._number(trade.get("risk_multiplier", 1.0)), 4)].append(trade)
        return {
            "normal": self._metrics(normal),
            "recovery": self._metrics(recovery),
            "by_risk_multiplier": [
                {"risk_multiplier": mult, **self._metrics(items)}
                for mult, items in sorted(by_multiplier.items())
            ],
            "interpretation_guardrail": "nao promover multiplicador por resultado agregado desta unica rodada; validar fora da amostra",
        }

    def _filter_marginal(self, blocked: list[dict[str, Any]]) -> list[dict[str, Any]]:
        by_filter: dict[str, list[dict[str, Any]]] = defaultdict(list)
        unique: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in blocked:
            failed = [str(x) for x in row.get("blocked_filters") or []]
            for name in failed:
                by_filter[name].append(row)
            if len(failed) == 1:
                unique[failed[0]].append(row)
        result = []
        for name in sorted(by_filter):
            all_metrics = self._metrics(by_filter[name])
            unique_metrics = self._metrics(unique.get(name, []))
            result.append({
                "filter": name,
                "all_rejections": all_metrics,
                "unique_rejections_if_only_filter_removed": unique_metrics,
                "marginally_actionable": unique_metrics["samples"] > 0,
            })
        return result

    @staticmethod
    def _filter_redundancy(blocked: list[dict[str, Any]]) -> dict[str, Any]:
        sets: dict[str, set[int]] = defaultdict(set)
        counts = Counter()
        for index, row in enumerate(blocked):
            failed = sorted(set(str(x) for x in row.get("blocked_filters") or []))
            counts[len(failed)] += 1
            for name in failed:
                sets[name].add(index)
        pairs = []
        for left, right in combinations(sorted(sets), 2):
            inter = len(sets[left] & sets[right])
            union = len(sets[left] | sets[right])
            if not inter:
                continue
            jaccard = inter / union if union else 0.0
            if jaccard >= 0.50:
                pairs.append({
                    "left": left, "right": right,
                    "co_blocked": inter,
                    "jaccard": round(jaccard, 4),
                })
        pairs.sort(key=lambda x: (-x["jaccard"], -x["co_blocked"]))
        return {
            "failed_filter_count_distribution": {str(k): v for k, v in sorted(counts.items())},
            "high_overlap_pairs_jaccard_gte_0_50": pairs[:40],
        }

    def _walk_forward_contexts(self, blocked: list[dict[str, Any]]) -> dict[str, Any]:
        rows = sorted(blocked, key=lambda x: int(x.get("opened_at") or x.get("closed_at") or 0))
        if not rows:
            return {"train": 0, "holdout": 0, "candidates": [], "validated": []}
        split = max(1, min(len(rows) - 1, int(len(rows) * self.policy.train_fraction)))
        train, holdout = rows[:split], rows[split:]
        key_fields = ("strategy_id", "regime", "side")
        train_groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
        test_groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
        for row in train:
            key = tuple(str(row.get(k) or "UNKNOWN") for k in key_fields)
            train_groups[key].append(row)
        for row in holdout:
            key = tuple(str(row.get(k) or "UNKNOWN") for k in key_fields)
            test_groups[key].append(row)
        candidates = []
        validated = []
        for key, train_rows in train_groups.items():
            tm = self._metrics(train_rows)
            if tm["samples"] < self.policy.minimum_context_samples:
                continue
            if tm["profit_factor"] < self.policy.minimum_train_profit_factor or tm["expected_r"] < self.policy.minimum_train_expected_r:
                continue
            hm = self._metrics(test_groups.get(key, []))
            item = {
                "strategy_id": key[0], "regime": key[1], "side": key[2],
                "train": tm, "holdout": hm,
                "holdout_pass": bool(
                    hm["samples"] >= self.policy.minimum_holdout_samples
                    and hm["profit_factor"] > 1.0
                    and hm["expected_r"] > 0.0
                    and hm["net_pnl_brl"] > 0.0
                ),
            }
            candidates.append(item)
            if item["holdout_pass"]:
                validated.append(item)
        return {
            "method": "CHRONOLOGICAL_70_30_BLOCKED_COUNTERFACTUAL_CONTEXT_TEST",
            "train": len(train), "holdout": len(holdout),
            "candidate_rule": {
                "minimum_train_samples": self.policy.minimum_context_samples,
                "minimum_train_profit_factor": self.policy.minimum_train_profit_factor,
                "minimum_train_expected_r": self.policy.minimum_train_expected_r,
                "minimum_holdout_samples": self.policy.minimum_holdout_samples,
            },
            "candidates": candidates,
            "validated": validated,
            "causal_claim": False,
            "warning": "blocked outcomes are a selected counterfactual sample; validated contexts are hypotheses, not automatic live rules",
        }

    @staticmethod
    def _frequency_diagnosis(corrected: dict[str, Any], years: float) -> dict[str, Any]:
        trades = int(corrected.get("trade_count") or 0)
        cycles = int(corrected.get("cycles") or 0)
        deep = int(corrected.get("deep_assessments") or 0)
        shadows = int(corrected.get("shadow_observations") or 0)
        return {
            "cycles": cycles,
            "deep_assessments": deep,
            "shadow_observations": shadows,
            "executed_trades": trades,
            "executed_per_100k_cycles": round(trades / cycles * 100_000, 4) if cycles else None,
            "executed_per_10k_shadow_outcomes": round(trades / shadows * 10_000, 4) if shadows else None,
            "executed_per_year_from_outcome_period": round(trades / years, 2) if years > 0 else None,
            "diagnosis": "VERY_LOW" if years > 0 and trades / years < 50 else "LOW_OR_NORMAL_REQUIRES_TARGET_POLICY",
        }

    @staticmethod
    def _period(rows: list[dict[str, Any]]) -> tuple[int | None, int | None]:
        starts = [int(x.get("opened_at") or 0) for x in rows if int(x.get("opened_at") or 0) > 0]
        ends = [int(x.get("closed_at") or 0) for x in rows if int(x.get("closed_at") or 0) > 0]
        values = starts + ends
        return (min(values), max(values)) if values else (None, None)

    @staticmethod
    def _iso(value: int | None) -> str | None:
        if not value:
            return None
        return datetime.fromtimestamp(value / 1000, UTC).isoformat()

    @staticmethod
    def write(report: dict[str, Any], output_dir: Path, stem: str = "causal_audit_latest") -> tuple[Path, Path]:
        output_dir.mkdir(parents=True, exist_ok=True)
        json_path = output_dir / f"{stem}.json"
        md_path = output_dir / f"{stem}.md"
        json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        period = report["period"]
        ex = report["executed"]["overall"]
        wf = report["walk_forward_context_validation"]
        lines = [
            "# Auditoria causal V12", "",
            f"- Período inferido pelos outcomes: {period['first_outcome_utc']} a {period['last_outcome_utc']}",
            f"- Trades executados: {ex['samples']}",
            f"- PnL líquido executado: R$ {ex['net_pnl_brl']:.2f}",
            f"- PF executado: {ex['profit_factor']}",
            f"- Frequência estimada: {period['executed_trades_per_year']} trades/ano", "",
            "## Walk-forward das oportunidades bloqueadas", "",
            f"- Treino cronológico: {wf['train']}",
            f"- Holdout intocado: {wf['holdout']}",
            f"- Contextos candidatos: {len(wf['candidates'])}",
            f"- Contextos que também passaram no holdout: {len(wf['validated'])}",
            "- Nenhum contexto é aplicado automaticamente ao NEXOR X.", "",
            "## Princípio", "",
            "O laboratório mede contribuição marginal dos filtros e redundância antes de propor afrouxamento. A rodada seguinte deve usar dados fora da amostra.",
        ]
        md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return json_path, md_path
