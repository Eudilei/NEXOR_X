from __future__ import annotations

import json
import math
import sys
import hashlib
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Iterable

RUNTIME_SNAPSHOT = Path(__file__).resolve().parents[1] / "runtime_snapshot"
if RUNTIME_SNAPSHOT.exists() and str(RUNTIME_SNAPSHOT) not in sys.path:
    sys.path.insert(0, str(RUNTIME_SNAPSHOT))

from nexor_x.domain import OperatingMode
from nexor_x.evidence import EvidenceEngine
from nexor_x.laboratory.models import CalibrationEstimate
from nexor_x.market import MarketIntelligenceEngine, MarketSnapshot
from nexor_x.pretrade_backtest import ContextBacktestEngine, ContextBacktestPolicy
from nexor_x.quant import QuantBrain
from nexor_x.risk import PreTradeGate
from nexor_x.strategy import (AdaptiveContextEdge, AdaptiveEdgePolicy, StrategyCandle, StrategySignalEngine)

from .replay_engine import Bar, NexorResearchReplay


@dataclass(slots=True)
class RuntimePolicy:
    initial_equity: float = 200.0
    risk_per_trade_pct: float = 2.0
    leverage: float = 15.0
    max_open_positions: int = 10
    hard_stop_drawdown_pct: float = 25.0
    fee_rate: float = 0.0005
    slippage_rate: float = 0.0003
    stop_loss_pct: float = 0.01
    break_even_trigger_r: float = 0.8
    break_even_buffer_r: float = 0.05
    partial_trigger_r: float = 1.5
    partial_fraction: float = 0.35
    trailing_start_r: float = 2.0
    trailing_distance_r: float = 0.8
    minimum_samples: int = 30
    minimum_expected_r: float = 0.05
    minimum_profit_factor: float = 1.10
    maximum_context_drawdown_r: float = 8.0
    minimum_walk_forward_ratio: float = 0.60
    scanner_top_candidates: int = 5
    maximum_entries_per_cycle: int = 1
    maximum_open_risk_pct: float = 10.0
    # 48 hours at 5-minute resolution. A shadow sample must eventually close
    # so calibration cannot be locked forever by stagnant positions.
    maximum_shadow_holding_bars: int = 576
    degradation_min_recent_trades: int = 20
    degradation_caution_profit_factor: float = 1.20
    degradation_block_profit_factor: float = 1.00
    degradation_caution_drawdown_pct: float = 10.0
    degradation_block_drawdown_pct: float = 24.0
    degradation_caution_loss_streak: int = 4
    degradation_block_loss_streak: int = 6
    recovery_shadow_samples: int = 30
    recovery_shadow_profit_factor: float = 1.20
    recovery_shadow_expected_r: float = 0.05
    recovery_required_healthy_checks: int = 3
    recovery_healthy_check_interval_ms: int = 300_000
    adaptive_minimum_effective_samples: float = 18.0
    adaptive_minimum_profit_factor: float = 1.05
    adaptive_minimum_expected_r: float = 0.03
    adaptive_minimum_stability_ratio: float = 0.50
    adaptive_cost_buffer_r: float = 0.03
    adaptive_minimum_confidence: float = 0.42
    adaptive_minimum_exact_samples: int = 8
    adaptive_minimum_global_samples: int = 60
    hard_stop_safety_buffer_pct: float = 0.50
    hard_stop_headroom_use_fraction: float = 0.25
    minimum_risk_budget_pct: float = 0.10


class RuntimeParityReplay:
    """Causal replay of the current NEXOR X PAPER decision path.

    STRICT_CURRENT exposes the cold-start lock in the current source. The second
    result adds the missing causal shadow bootstrap and otherwise keeps the
    current scanner, evidence, gate, sizing and position-management rules.
    """

    profile = "NEXOR_X_RUNTIME_PARITY_AFTER_UPDATE_69_V3"
    default_symbols = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT")

    def __init__(self, policy: RuntimePolicy | None = None) -> None:
        self._verify_runtime_snapshot()
        self.policy = policy or RuntimePolicy()
        self.reader = NexorResearchReplay()
        p = self.policy
        self.market_engine = MarketIntelligenceEngine()
        self.evidence_engine = EvidenceEngine()
        self.quant_brain = QuantBrain()
        self.strategy_engine = StrategySignalEngine()
        self.adaptive_edge = AdaptiveContextEdge(AdaptiveEdgePolicy(
            minimum_effective_samples=p.adaptive_minimum_effective_samples,
            minimum_profit_factor=p.adaptive_minimum_profit_factor,
            minimum_expected_r=p.adaptive_minimum_expected_r,
            minimum_stability_ratio=p.adaptive_minimum_stability_ratio,
            cost_buffer_r=p.adaptive_cost_buffer_r,
            minimum_confidence=p.adaptive_minimum_confidence,
            minimum_exact_samples=p.adaptive_minimum_exact_samples,
            minimum_global_samples=p.adaptive_minimum_global_samples,
        ))
        self.context_engine = ContextBacktestEngine(ContextBacktestPolicy(
            minimum_samples=p.minimum_samples,
            minimum_profit_factor=p.minimum_profit_factor,
            minimum_expected_r=p.minimum_expected_r,
            maximum_drawdown_r=p.maximum_context_drawdown_r,
            minimum_walk_forward_pass_ratio=p.minimum_walk_forward_ratio,
        ))
        self.pretrade_gate = PreTradeGate(
            minimum_expected_r=p.minimum_expected_r,
            minimum_profit_factor=p.minimum_profit_factor,
            minimum_calibration_samples=p.minimum_samples,
            risk_per_trade_pct=p.risk_per_trade_pct,
            leverage=p.leverage,
            max_open_positions=p.max_open_positions,
            hard_stop_drawdown_pct=p.hard_stop_drawdown_pct,
            maximum_open_risk_pct=p.maximum_open_risk_pct,
            stop_loss_pct=p.stop_loss_pct,
            fee_rate=p.fee_rate,
            slippage_rate=p.slippage_rate,
            hard_stop_safety_buffer_pct=p.hard_stop_safety_buffer_pct,
            hard_stop_headroom_use_fraction=p.hard_stop_headroom_use_fraction,
            minimum_risk_budget_pct=p.minimum_risk_budget_pct,
        )

    @staticmethod
    def _verify_runtime_snapshot() -> None:
        manifest_path = RUNTIME_SNAPSHOT.parent / "RUNTIME_SNAPSHOT_MANIFEST.json"
        if not manifest_path.exists():
            raise RuntimeError("manifesto de paridade do NEXOR X ausente")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for relative, expected in dict(manifest.get("sha256") or {}).items():
            path = RUNTIME_SNAPSHOT / relative
            if not path.exists():
                raise RuntimeError(f"modulo compartilhado ausente: {relative}")
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual != expected:
                raise RuntimeError(f"paridade do modulo foi alterada: {relative}")

    def run(self, data_root: Path, symbols: Iterable[str] | None = None,
            progress: Callable[[str], None] | None = None) -> dict[str, Any]:
        selected = tuple(dict.fromkeys(x.upper() for x in (symbols or self.default_symbols)))
        series: dict[str, list[Bar]] = {}
        quality: dict[str, Any] = {}
        for symbol in selected:
            if progress:
                progress(f"Carregando {symbol}...")
            bars, item = self._load_five_minute(data_root, symbol)
            series[symbol] = bars
            quality[symbol] = item
        missing = [symbol for symbol, bars in series.items() if len(bars) < 289]
        if missing:
            raise ValueError("historico insuficiente: " + ", ".join(missing))

        strict = {
            "mode": "STRICT_CURRENT_CLEAN_DATABASE",
            "trade_count": 0,
            "net_pnl_brl": 0.0,
            "final_equity_brl": self.policy.initial_equity,
            "reason": (
                "gate exige calibracao e backtest contextual com 30 resultados, "
                "mas o runtime atual nao cria observacoes shadow automaticamente"
            ),
        }
        shadow_result = self._run_shadow_bootstrapped(series, progress)
        return {
            "schema": "nexor_x.runtime_parity_replay.v3",
            "profile": self.profile,
            "generated_at": datetime.now(UTC).isoformat(),
            "source_runtime": {
                "git_base": "d78ea55",
                "update": "69_plus_local_70_71",
                "scanner_symbols": list(selected),
                "historical_clock_resolution": "5m (runtime real agenda 60s)",
            },
            "strict_current": strict,
            "corrected_with_causal_shadow": shadow_result,
            "data_quality": quality,
            "limitations": [
                "OHLCV de 5m nao reconstroi os ciclos reais de 60s.",
                "Snapshot 24h foi reconstruido causalmente dos candles.",
                "Livro, funding, latencia e spread real nao estao na base.",
                "Gestao historica usa o fechamento de 5m como preco observado pelo ciclo.",
            ],
            "execution_allowed": False,
            "live_certified": False,
        }

    def _load_five_minute(self, root: Path, symbol: str) -> tuple[list[Bar], dict[str, Any]]:
        paths = sorted(root.rglob(f"{symbol}-5m-*.zip"))
        result: list[Bar] = []
        excluded: list[str] = []
        previous: int | None = None
        segment = 0
        for path in paths:
            try:
                bars = self.reader._read_zip(path)
            except Exception as exc:
                excluded.append(f"{path.name}:{type(exc).__name__}:{exc}")
                previous = None
                continue
            for bar in bars:
                if previous is None or bar.ts-previous != 300_000:
                    segment += 1
                bar.segment = segment
                result.append(bar)
                previous = bar.ts
        return result, {"archives": len(paths), "bars": len(result),
                        "segments": segment, "excluded": excluded}

    def _run_shadow_bootstrapped(self, series: dict[str, list[Bar]],
                                 progress: Callable[[str], None] | None) -> dict[str, Any]:
        p = self.policy
        pointers = {symbol: 0 for symbol in series}
        timeline = sorted({bar.ts for bars in series.values() for bar in bars})
        observations: list[dict[str, Any]] = []
        shadow_positions: dict[str, dict[str, Any]] = {}
        paper_positions: dict[str, dict[str, Any]] = {}
        trades: list[dict[str, Any]] = []
        blocked = Counter()
        equity = peak = p.initial_equity
        max_drawdown = 0.0
        first_calibration_at: int | None = None

        for step, timestamp in enumerate(timeline, 1):
            assessments: list[dict[str, Any]] = []
            current: dict[str, Bar] = {}
            for symbol, bars in series.items():
                pointer = pointers[symbol]
                while pointer < len(bars) and bars[pointer].ts < timestamp:
                    pointer += 1
                pointers[symbol] = pointer
                if pointer >= len(bars) or bars[pointer].ts != timestamp:
                    continue
                bar = bars[pointer]
                current[symbol] = bar
                self._manage_shadow(symbol, bar, shadow_positions, observations)
                closed = self._manage_paper(symbol, bar, paper_positions)
                if closed:
                    equity += closed["account_delta"]
                    closed["equity_after"] = round(equity, 8)
                    trades.append(closed)
                if pointer < 288 or bars[pointer-288].segment != bar.segment:
                    continue
                window = bars[pointer-287:pointer+1]
                assessment = self._assessment(symbol, window, observations)
                assessments.append(assessment)
                if assessment["decision"] in {"LONG_BIAS", "SHORT_BIAS"} and symbol not in shadow_positions:
                    shadow_positions[symbol] = self._open_position(
                        symbol, assessment, bar.close, 1_000.0, shadow=True
                    )

            if not assessments:
                continue
            for item in assessments:
                item["rank_score"] = self._rank_score(item)
            assessments.sort(key=lambda item: (-item["rank_score"], item["symbol"]))
            opened = 0
            for assessment in assessments[:p.scanner_top_candidates]:
                if opened >= p.maximum_entries_per_cycle:
                    break
                symbol = assessment["symbol"]
                if symbol in paper_positions:
                    blocked["POSITION_ALREADY_OPEN"] += 1
                    continue
                reasons = self._gate_reasons(
                    assessment, observations, equity, peak, len(paper_positions),
                    paper_positions,
                )
                if reasons:
                    blocked.update(reasons)
                    continue
                if first_calibration_at is None:
                    first_calibration_at = timestamp
                risk_budget = equity*p.risk_per_trade_pct/100
                paper_positions[symbol] = self._open_position(
                    symbol, assessment, current[symbol].close, risk_budget, shadow=False,
                    equity=equity,
                )
                equity -= paper_positions[symbol]["entry_fee"]
                opened += 1
            peak = max(peak, equity)
            max_drawdown = max(max_drawdown, peak-equity)
            if progress and step % 50_000 == 0:
                progress(f"Replay causal {step}/{len(timeline)} | shadow={len(observations)} | paper={len(trades)}")

        # Conservative close of remaining positions at last available close.
        for symbol, position in list(paper_positions.items()):
            bar = series[symbol][-1]
            closed = self._close_position(position, bar.close, "END_OF_DATA")
            equity += closed["account_delta"]
            closed["equity_after"] = round(equity, 8)
            trades.append(closed)
        peak = max(peak, equity)
        max_drawdown = max(max_drawdown, peak-equity)
        wins = sum(item["net_pnl"] > 0 for item in trades)
        losses = sum(item["net_pnl"] < 0 for item in trades)
        profit = sum(max(0.0, item["net_pnl"]) for item in trades)
        loss = abs(sum(min(0.0, item["net_pnl"]) for item in trades))
        return {
            "mode": "CURRENT_RUNTIME_WITH_CAUSAL_SHADOW_BOOTSTRAP",
            "initial_equity_brl": p.initial_equity,
            "final_equity_brl": round(equity, 8),
            "net_pnl_brl": round(equity-p.initial_equity, 8),
            "return_pct": round((equity/p.initial_equity-1)*100, 6),
            "trade_count": len(trades), "wins": wins, "losses": losses,
            "win_rate_pct": round(wins/len(trades)*100, 4) if trades else 0.0,
            "profit_factor_net": round(profit/loss, 6) if loss else None,
            "maximum_drawdown_brl": round(max_drawdown, 8),
            "shadow_observations": len(observations),
            "first_calibration_time_ms": first_calibration_at,
            "blocked_reasons": dict(blocked.most_common()),
            "trades": trades,
        }

    def _assessment(self, symbol: str, window: list[Bar],
                    observations: list[dict[str, Any]]) -> dict[str, Any]:
        first, last = window[0], window[-1]
        change = (last.close-first.open)/first.open*100
        volatility = (max(x.high for x in window)-min(x.low for x in window))/first.open*100
        snapshot = MarketSnapshot(
            symbol=symbol, price=last.close, open_price=first.open,
            high_price=max(x.high for x in window), low_price=min(x.low for x in window),
            volume=sum(x.volume for x in window),
            quote_volume=sum(x.volume*x.close for x in window),
            price_change_percent=change,
            fetched_at=datetime.fromtimestamp(last.ts/1000, UTC),
            source="historical_5m_causal", stale=False,
        )
        state = self.market_engine.classify(snapshot)
        evidences = self.evidence_engine.evaluate(state)
        preliminary = self.quant_brain.assess(symbol, evidences)
        regime = state.regime.value
        decision = preliminary.decision.value
        raw_edge = preliminary.raw_edge
        # PAPER may only be authorized by prior samples from the same symbol.
        # V5/V6 pooled unrelated coins here, which could make one asset inherit
        # another asset's apparent edge.
        selected = [o for o in observations if o["symbol"] == symbol
                    and o["decision"] == decision and o["regime"] == regime
                    and raw_edge-.1 <= o["raw_edge"] <= raw_edge+.1]
        metrics = self._metrics([x["realized_r"] for x in selected])
        calibrated = len(selected) >= self.policy.minimum_samples
        calibration = CalibrationEstimate(
            ready=calibrated, sample_count=len(selected),
            win_probability=(sum(x["realized_r"] > 0 for x in selected)+1)/(len(selected)+2) if selected else None,
            expected_r=metrics["expected_r"] if selected else None,
            profit_factor=metrics["profit_factor"] if selected else None,
            brier_score=None, lower_edge=max(-1.0, raw_edge-.1),
            upper_edge=min(1.0, raw_edge+.1),
            reason="historical causal calibration" if calibrated else "amostra insuficiente",
        )
        quant = self.quant_brain.assess(symbol, evidences, calibration)
        candles15 = []
        for index in range(0, len(window)-2, 3):
            group = window[index:index+3]
            candles15.append(StrategyCandle(
                group[-1].ts, group[0].open, max(x.high for x in group),
                min(x.low for x in group), group[-1].close,
                sum(x.volume for x in group),
            ))
        signals = self.strategy_engine.evaluate(
            candles15, regime=regime, market_decision=decision
        )
        strategy = self.strategy_engine.select(signals)
        strategy_id = strategy.strategy_id if strategy else None
        adaptive = self.adaptive_edge.evaluate(
            symbol=symbol, decision=decision, regime=regime, strategy_id=strategy_id,
            observations=observations,
        )
        return {"symbol": symbol, "decision": decision, "regime": regime,
                "raw_edge": raw_edge, "confidence": quant.confidence,
                "calibrated": calibrated,
                "calibration_samples": len(selected),
                "expected_r": metrics["expected_r"] if selected else None,
                "profit_factor": metrics["profit_factor"] if selected else None,
                "market": state.to_dict(),
                "strategy_approved": strategy is not None,
                "adaptive_edge": adaptive,
                "adaptive_edge_approved": bool(adaptive["approved"]),
                "selected_strategy": strategy.to_dict() if strategy else None,
                "strategy_signals": [item.to_dict() for item in signals]}

    def _gate_reasons(self, a: dict[str, Any], observations: list[dict[str, Any]],
                      equity: float, peak: float, open_count: int,
                      open_positions: dict[str, dict[str, Any]] | None = None) -> list[str]:
        positions = open_positions or {}
        reserved = sum(self._loss_reserve(x) for x in positions.values())
        gross_notional = sum(x["entry"]*x["quantity"] for x in positions.values())
        portfolio = {
            "drawdown_pct": (peak-equity)/peak*100 if peak else 0.0,
            "open_positions": open_count, "equity": equity,
            "peak_equity": peak, "open_risk_brl": reserved,
            "gross_notional": gross_notional,
        }
        gate = self.pretrade_gate.evaluate(
            symbol=a["symbol"], mode=OperatingMode.PAPER,
            market=a["market"], quant=a, portfolio=portfolio,
        )
        raw_checks = dict(gate.checks)
        a["_gate_risk_budget"] = float(gate.risk_budget or 0.0)
        # Quantitative PF/Expected-R/minimum-sample checks are deliberately
        # replaced by one hierarchical adaptive edge gate. Safety, freshness,
        # capacity and drawdown checks remain authoritative.
        safety_keys = {
            "paper_mode", "directional_edge", "fresh_market_data",
            "capacity_available", "below_hard_stop",
            "portfolio_risk_available", "hard_stop_risk_reserve",
        }
        checks = {key: value for key, value in raw_checks.items() if key in safety_keys}
        checks["strategy_approved"] = bool(a.get("strategy_approved"))
        checks["adaptive_edge_approved"] = bool(a.get("adaptive_edge_approved"))
        matching = [o["realized_r"] for o in observations if o["symbol"] == a["symbol"]
                    and o["decision"] == a["decision"] and o["regime"] == a["regime"]]
        context = self.context_engine.evaluate(
            symbol=a["symbol"], decision=a["decision"], regime=a["regime"],
            realized_r=matching,
        )
        # Legacy context report is retained for audit but no longer duplicates
        # six highly-correlated binary gates in the entry path.
        a["filter_checks"] = checks
        a["context_backtest"] = context.to_dict()
        reasons = [key.upper() for key, passed in checks.items() if not passed]
        return reasons

    def _candidate_loss_reserve(self, equity: float) -> float:
        risk_budget = equity*self.policy.risk_per_trade_pct/100
        total_loss_rate = (self.policy.stop_loss_pct+self.policy.slippage_rate+
                           2*self.policy.fee_rate)
        notional = min(risk_budget/total_loss_rate,
                       equity*self.policy.leverage)
        return notional*total_loss_rate

    def _loss_reserve(self, position: dict[str, Any]) -> float:
        remaining_notional = position["entry"]*position["quantity"]
        return remaining_notional*(self.policy.stop_loss_pct+
                                  self.policy.slippage_rate+self.policy.fee_rate)

    def _context_approved(self, values: list[float]) -> bool:
        values = values[-300:]
        if len(values) < self.policy.minimum_samples:
            return False
        m = self._metrics(values)
        recent = values[-max(min(len(values)//3, 100), 1):]
        rm = self._metrics(recent)
        folds = [x for x in self._folds(values, 3) if x]
        passed = sum(self._metrics(x)["profit_factor"] >= 1.10 and
                     self._metrics(x)["expected_r"] >= .05 for x in folds)
        return bool(m["profit_factor"] >= 1.10 and m["expected_r"] >= .05
                    and rm["profit_factor"] >= 1 and rm["expected_r"] >= 0
                    and m["max_drawdown_r"] <= 8 and passed/len(folds) >= .60)

    def _open_position(self, symbol: str, a: dict[str, Any], price: float,
                       risk_budget: float, shadow: bool, equity: float = 0,
                       opened_at: int | None = None) -> dict[str, Any]:
        side = "LONG" if a["decision"] == "LONG_BIAS" else "SHORT"
        adverse = self.policy.slippage_rate if side == "LONG" else -self.policy.slippage_rate
        entry = price*(1+adverse)
        if shadow:
            notional = risk_budget/self.policy.stop_loss_pct
        else:
            total_loss_rate = (self.policy.stop_loss_pct+self.policy.slippage_rate+
                               2*self.policy.fee_rate)
            notional = risk_budget/total_loss_rate
            notional = min(notional, equity*self.policy.leverage)
        quantity = notional/entry
        risk = entry*self.policy.stop_loss_pct
        stop = entry-risk if side == "LONG" else entry+risk
        return {"symbol": symbol, "side": side, "decision": a["decision"],
                "regime": a["regime"], "raw_edge": a["raw_edge"], "entry": entry,
                "quantity": quantity, "initial_quantity": quantity, "notional": notional,
                "risk_per_unit": risk, "stop": stop, "highest": entry, "lowest": entry,
                "stop_kind": "INITIAL_STOP", "best_r": 0.0,
                "partial": False, "partial_net": 0.0, "entry_fee": notional*self.policy.fee_rate,
                "risk_budget": (notional*self.policy.stop_loss_pct if shadow else
                                notional*(self.policy.stop_loss_pct+
                                          self.policy.slippage_rate+2*self.policy.fee_rate)),
                "opened_at": opened_at, "calibration_samples": a.get("calibration_samples"),
                "entry_expected_r": a.get("expected_r"),
                "entry_profit_factor": a.get("profit_factor"),
                "entry_rank_score": a.get("rank_score"),
                "strategy_id": (a.get("selected_strategy") or {}).get("strategy_id")}

    def _manage_shadow(self, symbol: str, bar: Bar, positions: dict[str, dict[str, Any]],
                       observations: list[dict[str, Any]]) -> None:
        position = positions.get(symbol)
        if not position:
            return
        position["bars_held"] = int(position.get("bars_held", 0)) + 1
        result = self._manage(position, bar.close, bar.high, bar.low)
        if not result and position["bars_held"] >= self.policy.maximum_shadow_holding_bars:
            result = self._close_position(position, bar.close, "SHADOW_TIME_LIMIT")
        if result:
            result["closed_at"] = bar.ts
            observations.append({"symbol": symbol, "decision": position["decision"],
                                 "regime": position["regime"], "raw_edge": position["raw_edge"],
                                 "strategy_id": position.get("strategy_id"),
                                 "realized_r": result["net_pnl"]/position["risk_budget"],
                                 "closed_at": bar.ts, "exit_reason": result["exit_reason"],
                                 "bars_held": position["bars_held"]})
            del positions[symbol]

    def _manage_paper(self, symbol: str, bar: Bar, positions: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
        position = positions.get(symbol)
        if not position:
            return None
        result = self._manage(position, bar.close, bar.high, bar.low)
        if result:
            result["closed_at"] = bar.ts
            del positions[symbol]
        return result

    def _manage(self, position: dict[str, Any], price: float,
                high: float | None = None, low: float | None = None) -> dict[str, Any] | None:
        side = position["side"]
        high = price if high is None else high
        low = price if low is None else low
        favorable = price-position["entry"] if side == "LONG" else position["entry"]-price
        current_r = favorable/position["risk_per_unit"]
        position["best_r"] = max(float(position.get("best_r", 0.0)), current_r)
        position["highest"] = max(position["highest"], price)
        position["lowest"] = min(position["lowest"], price)
        stop_touched = low <= position["stop"] if side == "LONG" else high >= position["stop"]
        if stop_touched:
            reason = str(position.get("stop_kind") or "INITIAL_STOP")
            if position.get("partial") and reason == "TRAILING_STOP":
                reason = "TRAILING_STOP_AFTER_PARTIAL"
            return self._close_position(position, position["stop"], reason)
        if current_r >= self.policy.break_even_trigger_r:
            candidate = position["entry"] + (position["risk_per_unit"]*self.policy.break_even_buffer_r if side == "LONG" else -position["risk_per_unit"]*self.policy.break_even_buffer_r)
            previous_stop = position["stop"]
            position["stop"] = max(position["stop"], candidate) if side == "LONG" else min(position["stop"], candidate)
            if position["stop"] != previous_stop:
                position["stop_kind"] = "BREAK_EVEN_STOP"
        if current_r >= self.policy.partial_trigger_r and not position["partial"]:
            qty = position["quantity"]*self.policy.partial_fraction
            net, delta, gross, exit_fee, entry_fee = self._exit_values(position, price, qty)
            position["quantity"] -= qty; position["partial"] = True
            position["partial_net"] += net
            position["partial_account_delta"] = position.get("partial_account_delta", 0.0)+delta
            position["partial_gross"] = position.get("partial_gross", 0.0)+gross
            position["partial_exit_fee"] = position.get("partial_exit_fee", 0.0)+exit_fee
            position["partial_entry_fee"] = position.get("partial_entry_fee", 0.0)+entry_fee
        if current_r >= self.policy.trailing_start_r:
            distance = position["risk_per_unit"]*self.policy.trailing_distance_r
            candidate = position["highest"]-distance if side == "LONG" else position["lowest"]+distance
            previous_stop = position["stop"]
            position["stop"] = max(position["stop"], candidate) if side == "LONG" else min(position["stop"], candidate)
            if position["stop"] != previous_stop:
                position["stop_kind"] = "TRAILING_STOP"
        return None

    def _close_position(self, position: dict[str, Any], price: float, reason: str) -> dict[str, Any]:
        net, delta, gross, exit_fee, entry_fee = self._exit_values(position, price, position["quantity"])
        total_net = position["partial_net"]+net
        account_delta = position.get("partial_account_delta", 0.0)+delta
        total_gross = position.get("partial_gross", 0.0)+gross
        total_exit_fee = position.get("partial_exit_fee", 0.0)+exit_fee
        total_entry_fee = position.get("partial_entry_fee", 0.0)+entry_fee
        return {"symbol": position["symbol"], "side": position["side"],
                "decision": position["decision"], "regime": position["regime"],
                "raw_edge": position["raw_edge"], "entry_price": position["entry"],
                "opened_at": position.get("opened_at"),
                "calibration_samples": position.get("calibration_samples"),
                "entry_expected_r": position.get("entry_expected_r"),
                "entry_profit_factor": position.get("entry_profit_factor"),
                "entry_rank_score": position.get("entry_rank_score"),
                "strategy_id": position.get("strategy_id"),
                "blocked_filters": list(position.get("blocked_filters") or []),
                "filter_checks": dict(position.get("filter_checks") or {}),
                "counterfactual": bool(position.get("counterfactual", False)),
                "recovery_trial": bool(position.get("recovery_trial", False)),
                "risk_multiplier": float(position.get("risk_multiplier", 1.0)),
                "best_r_before_exit": round(float(position.get("best_r", 0.0)), 6),
                "partial_taken": bool(position.get("partial", False)),
                "exit_price": price, "exit_reason": reason, "gross_pnl": round(total_gross, 8),
                "entry_fee": round(total_entry_fee, 8), "exit_fee": round(total_exit_fee, 8),
                "total_fees": round(total_entry_fee+total_exit_fee, 8),
                "net_pnl": round(total_net, 8), "realized_r": round(total_net/position["risk_budget"], 6),
                "risk_brl": round(position["risk_budget"], 8), "account_delta": account_delta}

    def _exit_values(self, position: dict[str, Any], price: float, quantity: float,
                     ) -> tuple[float, float, float, float, float]:
        adverse = -self.policy.slippage_rate if position["side"] == "LONG" else self.policy.slippage_rate
        exit_price = price*(1+adverse)
        gross = ((exit_price-position["entry"]) if position["side"] == "LONG" else (position["entry"]-exit_price))*quantity
        exit_fee = abs(exit_price*quantity)*self.policy.fee_rate
        entry_fee = position["entry_fee"]*(quantity/position["initial_quantity"])
        return gross-exit_fee-entry_fee, gross-exit_fee, gross, exit_fee, entry_fee

    @staticmethod
    def _rank_score(a: dict[str, Any]) -> float:
        calibration = .15 if a["calibrated"] else 0
        expected = max(min(a["expected_r"] or 0, 1), -1)*.20
        pf = max(min((a["profit_factor"] or 0)-1, 1), -1)*.10
        return round(abs(a["raw_edge"])*.55+a["confidence"]*.20+calibration+expected+pf, 6)

    @staticmethod
    def _metrics(values: list[float]) -> dict[str, float]:
        profit = sum(x for x in values if x > 0); loss = abs(sum(x for x in values if x < 0))
        equity = peak = drawdown = 0.0
        for value in values:
            equity += value; peak = max(peak, equity); drawdown = max(drawdown, peak-equity)
        return {"expected_r": sum(values)/len(values) if values else 0.0,
                "profit_factor": profit/loss if loss else (999.0 if profit else 0.0),
                "max_drawdown_r": drawdown}

    @staticmethod
    def _folds(values: list[float], count: int) -> list[list[float]]:
        size = max(len(values)//count, 1)
        return [values[i*size:(i+1)*size if i<count-1 else len(values)] for i in range(count)]

    @staticmethod
    def write_report(report: dict[str, Any], output: Path) -> tuple[Path, Path]:
        output.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        json_path = output/f"runtime_parity_{stamp}.json"
        md_path = output/f"runtime_parity_{stamp}.md"
        json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        strict = report["strict_current"]; corrected = report["corrected_with_causal_shadow"]
        audit = corrected.get("counterfactual_filter_audit") or {}
        md_path.write_text("\n".join([
            "# Replay de paridade do NEXOR X", "",
            "## Código atual estrito", f"- Operações: {strict['trade_count']}", f"- Motivo: {strict['reason']}", "",
            "## NEXOR X com Shadow Learning causal", f"- Banca inicial: R$ {corrected['initial_equity_brl']:.2f}",
            f"- Banca final: R$ {corrected['final_equity_brl']:.2f}", f"- PnL: R$ {corrected['net_pnl_brl']:.2f}",
            f"- Retorno: {corrected['return_pct']:.2f}%", f"- Operações: {corrected['trade_count']}",
            f"- Observações shadow: {corrected['shadow_observations']}", "",
            "## Auditoria contrafactual dos bloqueios",
            f"- Oportunidades bloqueadas acompanhadas: {audit.get('opportunities', 0)}",
            f"- Resultado líquido hipotético: R$ {float(audit.get('hypothetical_net_pnl_brl', 0)):.2f}",
            "- O detalhamento de cada filtro está no JSON em counterfactual_filter_audit.filters.", "",
            "Este relatório executa módulos compartilhados do NEXOR X 0.78 e mantém as operações contrafactuais fora da banca oficial."
        ])+"\n", encoding="utf-8")
        return json_path, md_path
