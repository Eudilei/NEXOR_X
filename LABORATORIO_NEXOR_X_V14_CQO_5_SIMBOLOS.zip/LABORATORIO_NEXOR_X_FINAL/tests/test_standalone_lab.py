import csv
import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from lab import (BacktestDiagnosticEngine, HistoricalDatasetBridge,
                 NexorResearchReplay, ReplayConfig, RuntimeParityReplay, RuntimePolicy)
from lab.two_stage_runtime_engine import TwoStageRuntimeParityReplay
from nexor_x.domain import OperatingMode


class StandaloneLaboratoryTests(unittest.TestCase):
    def test_diagnostic_uses_net_and_reports_positive_negative(self) -> None:
        report = BacktestDiagnosticEngine().diagnose([
            {"symbol": "BTCUSDT", "strategy_id": "A", "regime": "TREND",
             "gross_pnl": 10, "total_fees": 1, "net_pnl": 9, "realized_r": 1,
             "planned_rr": 2, "slippage_bps": 2},
            {"symbol": "ETHUSDT", "strategy_id": "B", "regime": "RANGE",
             "gross_pnl": 1, "total_fees": 2, "net_pnl": -1, "realized_r": -1},
        ])
        self.assertEqual(report["summary"]["net_pnl"], 8)
        self.assertTrue(report["summary"]["top_diagnostic_causes"])
        self.assertTrue(report["summary"]["top_positive_factors"])
        self.assertFalse(report["execution_allowed"])

    def test_historical_audit_is_recursive(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive_path = root / "BTCUSDT" / "BTCUSDT-5m-2026-01.zip"
            archive_path.parent.mkdir()
            content = io.StringIO()
            writer = csv.writer(content)
            writer.writerow([1767225600000, 100, 102, 99, 101, 10])
            writer.writerow([1767225900000, 101, 103, 100, 102, 11])
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("BTCUSDT-5m-2026-01.csv", content.getvalue())
            report = HistoricalDatasetBridge().audit(root, workers=1)
            self.assertEqual(report["archive_count"], 1)
            self.assertEqual(report["symbol_count"], 1)
            self.assertEqual(report["total_rows"], 2)
            self.assertTrue(report["dataset_usable_for_segmented_replay"])
            self.assertFalse(
                report["final_replay_readiness"]["exact_final_strategy_replay_claim_allowed"]
            )

    def test_replay_reads_zip_and_never_claims_live_parity(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive_path = root / "BTCUSDT" / "BTCUSDT-5m-2026-01.zip"
            archive_path.parent.mkdir()
            content = io.StringIO()
            writer = csv.writer(content)
            price = 100.0
            for index in range(750):
                timestamp = 1767225600000 + index * 300000
                close = price + (0.08 if index % 9 else -0.03)
                writer.writerow([timestamp, price, max(price, close)+0.02,
                                 min(price, close)-0.02, close, 10+index % 5])
                price = close
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("BTCUSDT-5m-2026-01.csv", content.getvalue())
            replay = NexorResearchReplay(ReplayConfig(warmup_15m_bars=100))
            report = replay.run(root, ["BTCUSDT"])
            self.assertEqual(report["fidelity"]["status"], "RESEARCH_REPLAY_NOT_LIVE_PARITY")
            self.assertFalse(report["execution_allowed"])
            self.assertEqual(report["summary"]["initial_bankroll_brl"], 200.0)
            self.assertEqual(replay.discover_symbols(root), ["BTCUSDT"])
            all_report = replay.run(root, ["TODOS"])
            self.assertEqual(all_report["symbols_requested"], ["BTCUSDT"])

    def test_corrected_risk_controls(self) -> None:
        replay = NexorResearchReplay(ReplayConfig(maximum_leverage=15.0))
        notional, actual_risk = replay.position_size(200.0, 0.0001)
        self.assertEqual(notional, 3000.0)
        self.assertAlmostEqual(actual_risk, 0.3)
        self.assertEqual(replay.symbol_exclusion_reason("USDCUSDT"), "STABLE_FIAT_OR_INDEX_BASE")
        self.assertEqual(replay.symbol_exclusion_reason("BTCDOMUSDT"), "STABLE_FIAT_OR_INDEX_BASE")
        self.assertIsNone(replay.symbol_exclusion_reason("BTCUSDT"))

    def test_runtime_parity_uses_current_nexor_rules(self) -> None:
        engine = RuntimeParityReplay()
        bars = []
        price = 100.0
        from lab.replay_engine import Bar
        for index in range(288):
            close = price * 1.00005
            bars.append(Bar(index*300000, price, close*1.001, price*.999, close, 10, 1))
            price = close
        assessment = engine._assessment("BTCUSDT", bars, [])
        self.assertIn(assessment["decision"], {"LONG_BIAS", "SHORT_BIAS", "INSUFFICIENT_DATA"})
        self.assertFalse(assessment["calibrated"])

    def test_shadow_has_causal_time_limit(self) -> None:
        from lab.replay_engine import Bar
        engine = RuntimeParityReplay(RuntimePolicy(maximum_shadow_holding_bars=2))
        assessment = {"decision": "LONG_BIAS", "regime": "TREND_UP", "raw_edge": .8}
        positions = {"BTCUSDT": engine._open_position(
            "BTCUSDT", assessment, 100.0, 1_000.0, True
        )}
        observations = []
        engine._manage_shadow("BTCUSDT", Bar(0, 100, 100, 100, 100, 1, 1),
                              positions, observations)
        engine._manage_shadow("BTCUSDT", Bar(300000, 100, 100, 100, 100, 1, 1),
                              positions, observations)
        self.assertNotIn("BTCUSDT", positions)
        self.assertEqual(observations[0]["exit_reason"], "SHADOW_TIME_LIMIT")
        self.assertEqual(observations[0]["bars_held"], 2)

    def test_protective_stop_fills_at_stop_not_candle_close(self) -> None:
        from lab.replay_engine import Bar
        engine = RuntimeParityReplay()
        assessment = {"decision": "LONG_BIAS", "regime": "TREND_UP", "raw_edge": .8}
        position = engine._open_position(
            "BTCUSDT", assessment, 100.0, 20.0, False, 200.0
        )
        positions = {"BTCUSDT": position}
        result = engine._manage_paper(
            "BTCUSDT", Bar(0, 100, 101, 94, 95, 1, 1), positions
        )
        self.assertIsNotNone(result)
        self.assertEqual(result["exit_reason"], "INITIAL_STOP")
        self.assertLess(abs(result["realized_r"]), 1.2)

    def test_open_risk_reserve_prevents_joint_hard_stop_breach(self) -> None:
        engine = RuntimeParityReplay(RuntimePolicy(maximum_open_risk_pct=20.0))
        assessment = {"decision": "LONG_BIAS", "regime": "TREND_UP", "raw_edge": .8,
                      "calibrated": True, "calibration_samples": 30,
                      "expected_r": .2, "profit_factor": 1.5,
                      "symbol": "BTCUSDT", "strategy_approved": True,
                      "market": {"snapshot": {"stale": False}}}
        first = engine._open_position("BTCUSDT", assessment, 100, 20, False, 200)
        second = engine._open_position("ETHUSDT", assessment, 100, 20, False, 200)
        reasons = engine._gate_reasons(
            assessment, [], 198.5, 200, 2,
            {"BTCUSDT": first, "ETHUSDT": second},
        )
        self.assertIn("PORTFOLIO_RISK_AVAILABLE", reasons)
        self.assertNotIn("HARD_STOP_DRAWDOWN", reasons)

    def test_pilot_base_risk_is_two_percent_but_gate_can_throttle(self) -> None:
        engine = RuntimeParityReplay()
        self.assertEqual(engine.policy.risk_per_trade_pct, 2.0)
        reserve = engine._candidate_loss_reserve(200.0)
        self.assertLess(reserve, 5.0)

    def test_pilot_uses_five_symbol_universe_and_deep_top_five(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        self.assertEqual(engine.policy.scanner_top_candidates, 5)
        self.assertEqual(engine.universe_limit, 5)
        self.assertEqual(len(set(engine.priority_symbols)), 5)

    def test_adaptive_protection_blocks_six_consecutive_losses(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        trades = [{"net_pnl": -1.0} for _ in range(6)]
        report = engine._performance_protection(trades, 194.0, 200.0)
        self.assertEqual(report["state"], "BLOCKED")
        self.assertFalse(report["new_entries_allowed"])
        self.assertIn("loss_streak_critical", report["hard_reasons"])

    def test_healthy_new_shadow_allows_one_recovery_trial(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        trades = [{"net_pnl": -1.0, "closed_at": 1_000+i} for i in range(20)]
        observations = [
            {"realized_r": .2, "closed_at": 2_000+i} for i in range(30)
        ]
        report = engine._performance_protection(
            trades, 180.0, 200.0, observations
        )
        self.assertEqual(report["state"], "RECOVERY_TRIAL")
        self.assertTrue(report["new_entries_allowed"])
        self.assertTrue(report["recovery_trial"])

    def test_recovery_requires_three_spaced_healthy_checks(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        raw = {
            "state": "RECOVERY_TRIAL", "new_entries_allowed": True,
            "recovery_trial": True, "hard_reasons": ["profit_factor_below_1"],
        }
        confirmation = {"healthy_checks": 0, "last_check_ms": None}
        first = engine._confirmed_recovery(raw, 0, False, confirmation)
        too_soon = engine._confirmed_recovery(raw, 60_000, False, confirmation)
        second = engine._confirmed_recovery(raw, 300_000, False, confirmation)
        third = engine._confirmed_recovery(raw, 600_000, False, confirmation)
        self.assertEqual(first["state"], "BLOCKED")
        self.assertEqual(too_soon["recovery_confirmation"]["healthy_checks"], 1)
        self.assertEqual(second["state"], "BLOCKED")
        self.assertEqual(third["state"], "RECOVERY_TRIAL")
        self.assertTrue(third["new_entries_allowed"])

    def test_unhealthy_shadow_resets_recovery_confirmation(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        confirmation = {"healthy_checks": 2, "last_check_ms": 300_000}
        raw = {
            "state": "BLOCKED", "new_entries_allowed": False,
            "recovery_trial": False, "hard_reasons": ["profit_factor_below_1"],
        }
        report = engine._confirmed_recovery(raw, 600_000, False, confirmation)
        self.assertEqual(report["state"], "BLOCKED")
        self.assertEqual(confirmation["healthy_checks"], 0)

    def test_filter_audit_separates_missed_profit_and_avoided_loss(self) -> None:
        report = TwoStageRuntimeParityReplay._filter_audit([
            {"net_pnl": 2.0, "blocked_filters": ["PROFIT_FACTOR"]},
            {"net_pnl": -1.0, "blocked_filters": ["PROFIT_FACTOR", "EXPECTED_R"]},
        ])
        by_filter = {item["filter"]: item for item in report["filters"]}
        self.assertEqual(by_filter["PROFIT_FACTOR"]["profit_missed_brl"], 2.0)
        self.assertEqual(by_filter["PROFIT_FACTOR"]["loss_avoided_brl"], 1.0)
        self.assertEqual(
            by_filter["PROFIT_FACTOR"]["individual_removal_would_admit"], 1
        )

    def test_old_shadow_cannot_reopen_after_new_paper_close(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        trades = [{"net_pnl": -1.0, "closed_at": 5_000+i} for i in range(20)]
        observations = [
            {"realized_r": .2, "closed_at": 4_000+i} for i in range(40)
        ]
        report = engine._performance_protection(
            trades, 180.0, 200.0, observations
        )
        self.assertEqual(report["state"], "BLOCKED")
        self.assertEqual(report["shadow_recovery"]["samples"], 0)

    def test_shadow_never_overrides_drawdown_limit(self) -> None:
        engine = TwoStageRuntimeParityReplay()
        trades = [{"net_pnl": -1.0, "closed_at": 1_000+i} for i in range(20)]
        observations = [
            {"realized_r": .3, "closed_at": 2_000+i} for i in range(40)
        ]
        report = engine._performance_protection(
            trades, 150.0, 200.0, observations
        )
        self.assertEqual(report["state"], "BLOCKED")
        self.assertIn("drawdown_limit_reached", report["hard_reasons"])

    def test_runtime_parity_end_to_end_is_offline(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for offset, symbol in enumerate(RuntimeParityReplay.default_symbols):
                content = io.StringIO(); writer = csv.writer(content)
                price = 100.0 + offset
                for index in range(900):
                    close = price*(1.0004 if (index//80) % 2 == 0 else .9996)
                    writer.writerow([1767225600000+index*300000, price,
                                     max(price, close)*1.001, min(price, close)*.999,
                                     close, 10+index%7])
                    price = close
                path = root/symbol/f"{symbol}-5m-2026-01.zip"; path.parent.mkdir()
                with zipfile.ZipFile(path, "w") as archive:
                    archive.writestr(f"{symbol}-5m-2026-01.csv", content.getvalue())
            report = RuntimeParityReplay().run(root)
            self.assertEqual(report["strict_current"]["trade_count"], 0)
            self.assertFalse(report["execution_allowed"])
            self.assertIn("corrected_with_causal_shadow", report)

    def test_causal_audit_uses_chronological_holdout_and_no_auto_tuning(self) -> None:
        from lab import CausalAuditEngine
        blocked = []
        for i in range(120):
            blocked.append({
                "opened_at": 1_000 + i, "closed_at": 2_000 + i,
                "symbol": "BTCUSDT", "side": "LONG", "regime": "TREND_UP",
                "strategy_id": "trend_pullback", "net_pnl": 1.0 if i % 3 else -0.4,
                "gross_pnl": 1.1 if i % 3 else -0.3, "total_fees": 0.1,
                "realized_r": 0.25 if i % 3 else -0.1,
                "blocked_filters": ["PROFIT_FACTOR"],
            })
        payload = {"profile": "TEST", "corrected_with_causal_shadow": {
            "trades": [], "blocked_opportunities": blocked, "trade_count": 0,
            "cycles": 1000, "deep_assessments": 5000, "shadow_observations": 200,
        }}
        audit = CausalAuditEngine().analyze(payload)
        self.assertFalse(audit["safety"]["automatic_parameter_changes"])
        wf = audit["walk_forward_context_validation"]
        self.assertEqual(wf["train"] + wf["holdout"], len(blocked))
        self.assertGreaterEqual(len(wf["validated"]), 1)

    def test_exit_reason_distinguishes_break_even_and_trailing(self) -> None:
        engine = RuntimeParityReplay(RuntimePolicy(break_even_trigger_r=.5, trailing_start_r=1.0))
        assessment = {"decision": "LONG_BIAS", "regime": "TREND_UP", "raw_edge": .8}
        pos = engine._open_position("BTCUSDT", assessment, 100.0, 20.0, False, 200.0)
        # Raise the close enough to arm trailing without touching the stop.
        self.assertIsNone(engine._manage(pos, 102.0, 102.0, 101.0))
        self.assertEqual(pos["stop_kind"], "TRAILING_STOP")
        result = engine._manage(pos, pos["stop"], pos["stop"] + .01, pos["stop"] - .01)
        self.assertIsNotNone(result)
        self.assertIn(result["exit_reason"], {"TRAILING_STOP", "TRAILING_STOP_AFTER_PARTIAL"})


    def test_adaptive_edge_uses_hierarchy_and_never_allows_live(self) -> None:
        from nexor_x.strategy.adaptive_edge import AdaptiveContextEdge, AdaptiveEdgePolicy
        engine = AdaptiveContextEdge(AdaptiveEdgePolicy(minimum_effective_samples=5, minimum_confidence=.1, minimum_global_samples=20))
        rows = []
        for i in range(30):
            rows.append({"symbol": "BTCUSDT", "decision": "LONG_BIAS", "regime": "TREND_UP",
                         "strategy_id": "trend_pullback", "realized_r": .20 if i % 3 else -.10})
        report = engine.evaluate(symbol="BTCUSDT", decision="LONG_BIAS", regime="TREND_UP",
                                 strategy_id="trend_pullback", observations=rows)
        self.assertTrue(report["approved"])
        self.assertFalse(report["live_execution_allowed"])
        self.assertGreater(report["net_edge_after_buffer_r"], 0)

    def test_v14_headroom_sizing_allows_tiny_recovery_without_crossing_hard_stop(self) -> None:
        engine = RuntimeParityReplay()
        a = {"decision":"LONG_BIAS","regime":"TREND_UP","raw_edge":.8,
             "calibrated":True,"calibration_samples":100,"expected_r":.2,"profit_factor":1.5,
             "symbol":"BTCUSDT","strategy_approved":True,"market":{"snapshot":{"stale":False}},
             "adaptive_edge":{"approved":True,"net_edge_after_buffer_r":.1,"confidence":.8}}
        gate = engine.pretrade_gate.evaluate(symbol="BTCUSDT", mode=OperatingMode.PAPER,
            market=a["market"], quant=a, portfolio={"drawdown_pct":23.0,"open_positions":0,
            "equity":154.0,"peak_equity":200.0,"open_risk_brl":0.0,"gross_notional":0.0})
        self.assertTrue(gate.allowed)
        self.assertGreater(gate.risk_budget, 0.0)
        self.assertLess(gate.risk_budget, 154.0*.02)

    def test_v14_headroom_sizing_stops_when_safety_buffer_is_exhausted(self) -> None:
        engine = RuntimeParityReplay()
        a = {"decision":"LONG_BIAS","regime":"TREND_UP","raw_edge":.8,
             "calibrated":True,"calibration_samples":100,"expected_r":.2,"profit_factor":1.5,
             "symbol":"BTCUSDT","strategy_approved":True,"market":{"snapshot":{"stale":False}},
             "adaptive_edge":{"approved":True,"net_edge_after_buffer_r":.1,"confidence":.8}}
        gate = engine.pretrade_gate.evaluate(symbol="BTCUSDT", mode=OperatingMode.PAPER,
            market=a["market"], quant=a, portfolio={"drawdown_pct":24.6,"open_positions":0,
            "equity":150.8,"peak_equity":200.0,"open_risk_brl":0.0,"gross_notional":0.0})
        self.assertFalse(gate.allowed)
        self.assertEqual(gate.decision.value, "HARD_STOP")


if __name__ == "__main__":
    unittest.main()
