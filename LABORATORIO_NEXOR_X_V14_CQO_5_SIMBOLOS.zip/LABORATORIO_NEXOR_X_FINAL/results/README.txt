Os resultados das novas execucoes serao gravados aqui.
