# V14 CQO - correcoes de paridade e recuperacao

- Laboratorio limitado a 5 simbolos somente por velocidade.
- Snapshot do runtime sincronizado com o NEXOR X V14.
- Mesmo edge adaptativo com suporte minimo exato/global e margem de incerteza.
- Mesmo dimensionamento de risco por drawdown, confianca e headroom ate o hard stop.
- Recuperacao usa risco reduzido e nunca ultrapassa a reserva absoluta.
- Auditoria Shadow e causal permanecem ativas.
- LIVE nao e certificado por este replay.
