
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(
            f"Arquivo obrigatório não encontrado: {path}"
        )
    return path.read_text(encoding="utf-8")


def verify_update_57_present() -> None:
    verifier = ROOT / "tools/rc_verify.py"
    rc_doc = ROOT / "docs/NEXOR_X_RELEASE_CANDIDATE.md"

    if not verifier.exists():
        raise RuntimeError(
            "Update 57 não detectada: tools/rc_verify.py ausente"
        )
    if not rc_doc.exists():
        raise RuntimeError(
            "Update 56/57 não detectada: documento RC ausente"
        )


def copy_payload() -> None:
    for rel in (
        "tools/validation_campaign_runner.py",
        "tests/test_validation_campaign_runner.py",
        "docs/AUDIT_UPDATE_58.md",
    ):
        src = PAYLOAD / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_version() -> None:
    path = ROOT / "pyproject.toml"
    text = _read(path)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.58.0"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")

    path = ROOT / "src/nexor_x/__init__.py"
    text = _read(path)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.58.0"',
        text,
    )
    path.write_text(text, encoding="utf-8")


def main() -> None:
    verify_update_57_present()
    copy_payload()
    patch_version()
    print(
        "NEXOR X Update 58 aplicada: Validation Campaign Runner instalado. "
        "Trading runtime não alterado. LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
