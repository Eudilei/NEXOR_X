NEXOR X UPDATE 58 — VALIDATION CAMPAIGN RUNNER

Objetivo:
  automatizar a etapa que começa depois do RC_VERIFY_PASS sem alterar a
  arquitetura de trading.

O runner:
  - chama POST /api/validation/final-campaign/tick;
  - consulta GET /api/validation/final-snapshot;
  - consulta GET /api/validation/release-candidate;
  - registra cada ciclo em reports/validation_campaign_history.jsonl;
  - mantém último snapshot em reports/validation_campaign_latest.json;
  - respeita intervalo padrão de 30 minutos;
  - pode rodar uma vez (--once) ou continuamente;
  - não envia ordens e não altera PAPER/TESTNET/LIVE.

Variáveis:
  NEXOR_BASE_URL=http://127.0.0.1:8000
  NEXOR_ADMIN_TOKEN=<token administrativo>
  NEXOR_VALIDATION_INTERVAL_SECONDS=1800

Uso:
  python tools/validation_campaign_runner.py --once

ou:

  python tools/validation_campaign_runner.py

LIVE permanece bloqueado.
