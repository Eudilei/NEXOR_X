from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"


def _read(path: Path) -> str:
    if not path.exists():
        raise RuntimeError(f"Arquivo obrigatório não encontrado: {path}")
    return path.read_text(encoding="utf-8")


def copy_payload() -> None:
    items = (
        (
            PAYLOAD / "src/nexor_x/operations/recovery_hysteresis.py",
            ROOT / "src/nexor_x/operations/recovery_hysteresis.py",
        ),
        (
            PAYLOAD / "tests/test_recovery_hysteresis.py",
            ROOT / "tests/test_recovery_hysteresis.py",
        ),
        (
            PAYLOAD / "docs/AUDIT_UPDATE_44.md",
            ROOT / "docs/AUDIT_UPDATE_44.md",
        ),
    )
    for src, dst in items:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def patch_operations_init() -> None:
    path = ROOT / "src/nexor_x/operations/__init__.py"
    text = _read(path)
    imp = (
        "from .recovery_hysteresis import "
        "RecoveryHysteresisController, RecoveryHysteresisPolicy\n"
    )
    if imp not in text:
        text = imp + text

    match = re.search(r"__all__\s*=\s*\[(.*?)\]", text, re.S)
    if match and "RecoveryHysteresisController" not in match.group(1):
        body = match.group(1).rstrip()
        if body and not body.endswith(","):
            body += ","
        body += (
            '\n    "RecoveryHysteresisController",'
            '\n    "RecoveryHysteresisPolicy",\n'
        )
        text = text[:match.start(1)] + body + text[match.end(1):]
    path.write_text(text, encoding="utf-8")


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = _read(path)

    import_line = (
        "from nexor_x.operations.recovery_hysteresis import "
        "RecoveryHysteresisController\n"
    )
    if import_line not in text:
        marker = (
            "from nexor_x.operations.entry_admission import "
            "EntryAdmissionController\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 43 não detectada: EntryAdmissionController ausente"
            )
        text = text.replace(marker, marker + import_line, 1)

    if "self.entry_recovery_guard = RecoveryHysteresisController(" not in text:
        marker = (
            "        self.entry_admission_controller = "
            "EntryAdmissionController()\n"
        )
        if marker not in text:
            raise RuntimeError(
                "Update 43 não detectada: entry_admission_controller ausente"
            )
        init_line = (
            '        self.entry_recovery_guard = RecoveryHysteresisController(\n'
            '            state_path="data/entry_recovery_state.json"\n'
            '        )\n'
        )
        text = text.replace(marker, marker + init_line, 1)

    old = (
        "        degradation = await self.performance_degradation_status()\n"
        "        report = self.entry_admission_controller.evaluate(\n"
        "            degradation=degradation,\n"
        "            action=action,\n"
        "            reduce_only=reduce_only,\n"
        "        )\n"
    )
    new = (
        "        degradation = await self.performance_degradation_status()\n"
        "        recovery = self.entry_recovery_guard.evaluate(\n"
        "            degradation=degradation,\n"
        "        )\n"
        "        report = self.entry_admission_controller.evaluate(\n"
        '            degradation=recovery["degradation"],\n'
        "            action=action,\n"
        "            reduce_only=reduce_only,\n"
        "        )\n"
        '        report["recovery_hysteresis"] = {\n'
        '            "raw_state": recovery["raw_state"],\n'
        '            "effective_state": recovery["effective_state"],\n'
        '            "latched": recovery["latched"],\n'
        '            "healthy_checks": recovery["healthy_checks"],\n'
        '            "required_healthy_checks": recovery["required_healthy_checks"],\n'
        '            "cooldown_seconds": recovery["cooldown_seconds"],\n'
        '            "elapsed_since_block_seconds": recovery["elapsed_since_block_seconds"],\n'
        '            "transition": recovery["transition"],\n'
        "        }\n"
        '        if recovery["transition"]:\n'
        "            await self.event_bus.publish(Event(\n"
        '                "execution.entry_recovery_state_changed",\n'
        "                {\n"
        '                    "transition": recovery["transition"],\n'
        '                    "raw_state": recovery["raw_state"],\n'
        '                    "effective_state": recovery["effective_state"],\n'
        '                    "healthy_checks": recovery["healthy_checks"],\n'
        '                    "new_entries_allowed": recovery["new_entries_allowed"],\n'
        '                    "live_allowed": False,\n'
        "                },\n"
        '                "recovery_hysteresis_guard",\n'
        "            ))\n"
    )
    if old not in text:
        raise RuntimeError(
            "Update 43 não detectada ou entry_admission_status mudou; "
            "atualização abortada com segurança"
        )
    text = text.replace(old, new, 1)

    if "async def entry_recovery_hysteresis_status(" not in text:
        marker = "    async def entry_admission_status(\n"
        if marker not in text:
            raise RuntimeError(
                "Update 43 não detectada: entry_admission_status ausente"
            )
        method = (
            "    async def entry_recovery_hysteresis_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        degradation = await self.performance_degradation_status()\n"
            "        return self.entry_recovery_guard.evaluate(\n"
            "            degradation=degradation,\n"
            "        )\n\n"
        )
        text = text.replace(marker, method + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = _read(path)
    if '@app.get("/api/operations/recovery-hysteresis")' not in text:
        marker = '@app.get("/api/operations/entry-admission")'
        if marker not in text:
            raise RuntimeError(
                "Update 43 não detectada: endpoint entry-admission ausente"
            )
        block = (
            '@app.get("/api/operations/recovery-hysteresis")\n'
            "    async def entry_recovery_hysteresis_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.entry_recovery_hysteresis_status()\n\n"
            "    "
        )
        text = text.replace(marker, block + marker, 1)
    path.write_text(text, encoding="utf-8")


def patch_notifications() -> None:
    path = ROOT / "src/nexor_x/notifications/telegram_events.py"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")

    if '"execution.entry_recovery_state_changed",' not in text:
        marker = '        "execution.entry_blocked_degradation",\n'
        if marker in text:
            text = text.replace(
                marker,
                marker + '        "execution.entry_recovery_state_changed",\n',
                1,
            )

    if 'if topic == "execution.entry_recovery_state_changed":' not in text:
        marker = '        if topic == "execution.entry_blocked_degradation":'
        if marker in text:
            block = (
                '        if topic == "execution.entry_recovery_state_changed":\n'
                '            transition = str(payload.get("transition", "-"))\n'
                '            if transition == "LATCHED":\n'
                '                return (\n'
                '                    "🔒 BLOQUEIO DE RECUPERAÇÃO ATIVADO\\n"\n'
                '                    "Novas entradas permanecem bloqueadas até "'
                '"recuperação confirmada.\\n"\n'
                '                    "LIVE: BLOQUEADO"\n'
                '                )\n'
                '            if transition == "RECOVERED":\n'
                '                return (\n'
                '                    "✅ RECUPERAÇÃO CONFIRMADA\\n"\n'
                '                    "Cooldown e confirmações saudáveis concluídos.\\n"\n'
                '                    "Novas entradas voltam a seguir os demais gates.\\n"\n'
                '                    "LIVE: BLOQUEADO"\n'
                '                )\n'
                '            return None\n\n'
            )
            text = text.replace(marker, block + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = _read(pyproject)
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.44.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = _read(init)
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.44.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    copy_payload()
    patch_operations_init()
    patch_kernel()
    patch_api()
    patch_notifications()
    patch_version()
    print(
        "NEXOR X Update 44 aplicada: Recovery Hysteresis ativo. "
        "LIVE permanece bloqueado."
    )


if __name__ == "__main__":
    main()
