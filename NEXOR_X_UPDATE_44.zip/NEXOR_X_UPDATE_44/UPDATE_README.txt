NEXOR X UPDATE 44 — RECOVERY HYSTERESIS GUARD

Objetivo:
  impedir que o NEXOR volte a abrir posições imediatamente após sair de uma
  condição crítica de degradação.

Funcionamento padrão:
  - ao entrar em BLOCKED, o bloqueio fica travado;
  - exige pelo menos 15 minutos de cooldown;
  - exige 3 avaliações NORMAL consecutivas;
  - as confirmações devem estar separadas por pelo menos 5 minutos;
  - CAUTION durante a recuperação zera as confirmações;
  - novo BLOCKED reinicia a recuperação;
  - o estado é persistido em data/entry_recovery_state.json;
  - reiniciar o processo não apaga o bloqueio.

Fluxo:
  Performance Degradation Guard
    -> Recovery Hysteresis Guard
    -> Entry Admission Guard
    -> PAPER / TESTNET

LIVE permanece bloqueado.

Novo endpoint administrativo:
  GET /api/operations/recovery-hysteresis

Requer NEXOR X 0.43.0.
