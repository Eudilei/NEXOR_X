NEXOR X UPDATE 26

Envie este ZIP para a raiz do repositório.
O GitHub Actions fará aplicação, compilação, lint crítico,
suíte completa de testes e commit automático.

LIVE permanece bloqueado.
