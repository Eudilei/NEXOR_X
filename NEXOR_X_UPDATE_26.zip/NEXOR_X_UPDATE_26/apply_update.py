from __future__ import annotations

from pathlib import Path
import re


ROOT = Path.cwd()


def patch_kernel() -> None:
    path = ROOT / "src/nexor_x/kernel.py"
    text = path.read_text(encoding="utf-8")

    import_line = "from nexor_x.supervisor import OperationalSupervisorService\n"
    if import_line not in text:
        marker = "from nexor_x.position.service import PositionPolicy\n"
        if marker not in text:
            raise RuntimeError("Kernel import marker not found")
        text = text.replace(marker, marker + import_line, 1)

    if "self.operational_supervisor = OperationalSupervisorService(" not in text:
        marker = "        self.scanner = MarketScannerService(\n"
        if marker not in text:
            raise RuntimeError("Kernel scanner marker not found")
        text = text.replace(
            marker,
            "        self.operational_supervisor = "
            "OperationalSupervisorService(self.database)\n"
            + marker,
            1,
        )

    if "await self.operational_supervisor.start()" not in text:
        marker = "        await self.portfolio.ensure_account()\n"
        if marker not in text:
            raise RuntimeError("Kernel startup marker not found")
        text = text.replace(
            marker,
            marker + "        await self.operational_supervisor.start()\n",
            1,
        )

    if "async def operational_supervisor_status" not in text:
        marker = "    async def portfolio_status(self) -> dict[str, object]:\n"
        if marker not in text:
            raise RuntimeError("portfolio_status marker not found")
        methods = (
            "    async def operational_supervisor_status(\n"
            "        self,\n"
            "    ) -> dict[str, object]:\n"
            "        return await self.operational_supervisor.status()\n\n"
            "    async def operational_supervisor_evaluate(\n"
            "        self, payload: dict[str, object]\n"
            "    ) -> dict[str, object]:\n"
            "        result = await self.operational_supervisor.evaluate(payload)\n"
            "        await self.event_bus.publish(Event(\n"
            "            'supervisor.evaluated',\n"
            "            {\n"
            "                'status': result['status'],\n"
            "                'paper_allowed': result['paper_allowed'],\n"
            "                'testnet_allowed': result['testnet_allowed'],\n"
            "                'live_allowed': False,\n"
            "            },\n"
            "            'operational_supervisor',\n"
            "        ))\n"
            "        return result\n\n"
        )
        text = text.replace(marker, methods + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_api() -> None:
    path = ROOT / "src/nexor_x/api/app.py"
    text = path.read_text(encoding="utf-8")

    if "class OperationalSupervisorRequest(BaseModel):" not in text:
        marker = "class ChatRequest(BaseModel):\n"
        if marker not in text:
            raise RuntimeError("ChatRequest marker not found")
        model = (
            "class OperationalSupervisorRequest(BaseModel):\n"
            "    mode: str = Field(default='PAPER', max_length=20)\n"
            "    recovery_ok: bool\n"
            "    exchange_ready: bool\n"
            "    certification_passed: bool\n"
            "    live_connector_tested: bool\n"
            "    data_freshness_ok: bool\n"
            "    hard_stop_active: bool\n"
            "    critical_test_failures: int = Field(ge=0, le=1000000)\n"
            "    operational_incidents: int = Field(ge=0, le=1000000)\n\n"
        )
        text = text.replace(marker, model + marker, 1)

    if '@app.get("/api/supervisor/status")' not in text:
        marker = '    @app.get("/api/portfolio/status")\n'
        if marker not in text:
            raise RuntimeError("Portfolio endpoint marker not found")
        endpoints = (
            '    @app.get("/api/supervisor/status")\n'
            "    async def operational_supervisor_status(\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.operational_supervisor_status()\n\n"
            '    @app.post("/api/supervisor/evaluate")\n'
            "    async def operational_supervisor_evaluate(\n"
            "        body: OperationalSupervisorRequest,\n"
            "        _: None = Depends(require_admin),\n"
            "    ) -> dict[str, Any]:\n"
            "        return await kernel.operational_supervisor_evaluate(\n"
            "            body.model_dump()\n"
            "        )\n\n"
        )
        text = text.replace(marker, endpoints + marker, 1)

    path.write_text(text, encoding="utf-8")


def patch_version() -> None:
    pyproject = ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    text = re.sub(
        r'version = "[^"]+"',
        'version = "0.26.0"',
        text,
        count=1,
    )
    pyproject.write_text(text, encoding="utf-8")

    init = ROOT / "src/nexor_x/__init__.py"
    text = init.read_text(encoding="utf-8")
    text = re.sub(
        r'__version__\s*=\s*"[^"]+"',
        '__version__ = "0.26.0"',
        text,
    )
    init.write_text(text, encoding="utf-8")


def main() -> None:
    patch_kernel()
    patch_api()
    patch_version()
    print("NEXOR X Update 26 aplicado com sucesso.")


if __name__ == "__main__":
    main()
